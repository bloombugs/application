var require = meteorInstall({"imports":{"api":{"stuff":{"Stuff.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/api/stuff/Stuff.js                                                                                      //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({
  Stuffs: () => Stuffs
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
let Tracker;
module.link("meteor/tracker", {
  Tracker(v) {
    Tracker = v;
  }

}, 2);
let PropTypes;
module.link("prop-types", {
  default(v) {
    PropTypes = v;
  }

}, 3);

/**
 * The StuffsCollection. It encapsulates state and variable values for stuff.
 */
class StuffsCollection {
  constructor() {
    // The name of this collection.
    this.name = 'StuffsCollection'; // Define the Mongo collection.

    this.collection = new Mongo.Collection(this.name); // Define the structure of each document in the collection.

    this.schema = new SimpleSchema({
      name: String,
      phone: String,
      owner: String,
      location: String,
      description: String,
      markers: String,
      behavior: String,
      numPeople: {
        type: String,
        allowedValues: ['0 - 25', '26 - 50', '51 - 100', '100 +'],
        defaultValue: '0 - 25'
      }
    }, {
      tracker: Tracker
    }); // Attach the schema to the collection, so all attempts to insert a document are checked against schema.

    this.collection.attachSchema(this.schema); // Define names for publications and subscriptions

    this.userPublicationName = "".concat(this.name, ".publication.user");
    this.adminPublicationName = "".concat(this.name, ".publication.admin");
  }

}
/**
 * The singleton instance of the StuffsCollection.
 * @type {StuffsCollection}
 */


const Stuffs = new StuffsCollection();
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"startup":{"server":{"Accounts.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/startup/server/Accounts.js                                                                              //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Accounts;
module.link("meteor/accounts-base", {
  Accounts(v) {
    Accounts = v;
  }

}, 1);
let Roles;
module.link("meteor/alanning:roles", {
  Roles(v) {
    Roles = v;
  }

}, 2);

/* eslint-disable no-console */
function createUser(email, password, role) {
  console.log("  Creating user ".concat(email, "."));
  const userID = Accounts.createUser({
    username: email,
    email: email,
    password: password
  });

  if (role === 'admin') {
    Roles.createRole(role, {
      unlessExists: true
    });
    Roles.addUsersToRoles(userID, 'admin');
  }
} // When running app for first time, pass a settings file to set up a default user account.


if (Meteor.users.find().count() === 0) {
  if (Meteor.settings.defaultAccounts) {
    console.log('Creating the default user(s)');
    Meteor.settings.defaultAccounts.map(_ref => {
      let {
        email,
        password,
        role
      } = _ref;
      return createUser(email, password, role);
    });
  } else {
    console.log('Cannot initialize the database!  Please invoke meteor with a settings file.');
  }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"Mongo.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/startup/server/Mongo.js                                                                                 //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Stuffs;
module.link("../../api/stuff/Stuff.js", {
  Stuffs(v) {
    Stuffs = v;
  }

}, 1);

/* eslint-disable no-console */
// Initialize the database with a default data document.
function addData(data) {
  console.log("  Adding: ".concat(data.name, " (").concat(data.owner, ")"));
  Stuffs.collection.insert(data);
} // Initialize the StuffsCollection if empty.


if (Stuffs.collection.find().count() === 0) {
  if (Meteor.settings.defaultData) {
    console.log('Creating default data.');
    Meteor.settings.defaultData.map(data => addData(data));
  }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"Publications.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/startup/server/Publications.js                                                                          //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Roles;
module.link("meteor/alanning:roles", {
  Roles(v) {
    Roles = v;
  }

}, 1);
let Stuffs;
module.link("../../api/stuff/Stuff", {
  Stuffs(v) {
    Stuffs = v;
  }

}, 2);
// User-level publication.
// If logged in, then publish documents owned by this user. Otherwise publish nothing.
Meteor.publish(Stuffs.userPublicationName, function () {
  if (this.userId) {
    const username = Meteor.users.findOne(this.userId).username;
    return Stuffs.collection.find({
      owner: username
    });
  }

  return this.ready();
}); // Admin-level publication.
// If logged in and with admin role, then publish all documents from all users. Otherwise publish nothing.

Meteor.publish(Stuffs.adminPublicationName, function () {
  if (this.userId && Roles.userIsInRole(this.userId, 'admin')) {
    return Stuffs.collection.find();
  }

  return this.ready();
}); // alanning:roles publication
// Recommended code to publish roles for each user.

Meteor.publish(null, function () {
  if (this.userId) {
    return Meteor.roleAssignment.find({
      'user._id': this.userId
    });
  }

  return this.ready();
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},"server":{"main.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/main.js                                                                                                  //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.link("/imports/startup/server/Accounts");
module.link("/imports/startup/server/Publications");
module.link("/imports/startup/server/Mongo");
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".mjs",
    ".jsx"
  ]
});

require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvc3R1ZmYvU3R1ZmYuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc3RhcnR1cC9zZXJ2ZXIvQWNjb3VudHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc3RhcnR1cC9zZXJ2ZXIvTW9uZ28uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc3RhcnR1cC9zZXJ2ZXIvUHVibGljYXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWFpbi5qcyJdLCJuYW1lcyI6WyJtb2R1bGUiLCJleHBvcnQiLCJTdHVmZnMiLCJNb25nbyIsImxpbmsiLCJ2IiwiU2ltcGxlU2NoZW1hIiwiZGVmYXVsdCIsIlRyYWNrZXIiLCJQcm9wVHlwZXMiLCJTdHVmZnNDb2xsZWN0aW9uIiwiY29uc3RydWN0b3IiLCJuYW1lIiwiY29sbGVjdGlvbiIsIkNvbGxlY3Rpb24iLCJzY2hlbWEiLCJTdHJpbmciLCJwaG9uZSIsIm93bmVyIiwibG9jYXRpb24iLCJkZXNjcmlwdGlvbiIsIm1hcmtlcnMiLCJiZWhhdmlvciIsIm51bVBlb3BsZSIsInR5cGUiLCJhbGxvd2VkVmFsdWVzIiwiZGVmYXVsdFZhbHVlIiwidHJhY2tlciIsImF0dGFjaFNjaGVtYSIsInVzZXJQdWJsaWNhdGlvbk5hbWUiLCJhZG1pblB1YmxpY2F0aW9uTmFtZSIsIk1ldGVvciIsIkFjY291bnRzIiwiUm9sZXMiLCJjcmVhdGVVc2VyIiwiZW1haWwiLCJwYXNzd29yZCIsInJvbGUiLCJjb25zb2xlIiwibG9nIiwidXNlcklEIiwidXNlcm5hbWUiLCJjcmVhdGVSb2xlIiwidW5sZXNzRXhpc3RzIiwiYWRkVXNlcnNUb1JvbGVzIiwidXNlcnMiLCJmaW5kIiwiY291bnQiLCJzZXR0aW5ncyIsImRlZmF1bHRBY2NvdW50cyIsIm1hcCIsImFkZERhdGEiLCJkYXRhIiwiaW5zZXJ0IiwiZGVmYXVsdERhdGEiLCJwdWJsaXNoIiwidXNlcklkIiwiZmluZE9uZSIsInJlYWR5IiwidXNlcklzSW5Sb2xlIiwicm9sZUFzc2lnbm1lbnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUFBLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUNDLFFBQU0sRUFBQyxNQUFJQTtBQUFaLENBQWQ7QUFBbUMsSUFBSUMsS0FBSjtBQUFVSCxNQUFNLENBQUNJLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNELE9BQUssQ0FBQ0UsQ0FBRCxFQUFHO0FBQUNGLFNBQUssR0FBQ0UsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJQyxZQUFKO0FBQWlCTixNQUFNLENBQUNJLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNHLFNBQU8sQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNDLGdCQUFZLEdBQUNELENBQWI7QUFBZTs7QUFBM0IsQ0FBM0IsRUFBd0QsQ0FBeEQ7QUFBMkQsSUFBSUcsT0FBSjtBQUFZUixNQUFNLENBQUNJLElBQVAsQ0FBWSxnQkFBWixFQUE2QjtBQUFDSSxTQUFPLENBQUNILENBQUQsRUFBRztBQUFDRyxXQUFPLEdBQUNILENBQVI7QUFBVTs7QUFBdEIsQ0FBN0IsRUFBcUQsQ0FBckQ7QUFBd0QsSUFBSUksU0FBSjtBQUFjVCxNQUFNLENBQUNJLElBQVAsQ0FBWSxZQUFaLEVBQXlCO0FBQUNHLFNBQU8sQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNJLGFBQVMsR0FBQ0osQ0FBVjtBQUFZOztBQUF4QixDQUF6QixFQUFtRCxDQUFuRDs7QUFNN1A7QUFDQTtBQUNBO0FBQ0EsTUFBTUssZ0JBQU4sQ0FBdUI7QUFDckJDLGFBQVcsR0FBRztBQUNaO0FBQ0EsU0FBS0MsSUFBTCxHQUFZLGtCQUFaLENBRlksQ0FHWjs7QUFDQSxTQUFLQyxVQUFMLEdBQWtCLElBQUlWLEtBQUssQ0FBQ1csVUFBVixDQUFxQixLQUFLRixJQUExQixDQUFsQixDQUpZLENBS1o7O0FBQ0EsU0FBS0csTUFBTCxHQUFjLElBQUlULFlBQUosQ0FBaUI7QUFDN0JNLFVBQUksRUFBRUksTUFEdUI7QUFFN0JDLFdBQUssRUFBRUQsTUFGc0I7QUFHN0JFLFdBQUssRUFBRUYsTUFIc0I7QUFJN0JHLGNBQVEsRUFBRUgsTUFKbUI7QUFLN0JJLGlCQUFXLEVBQUVKLE1BTGdCO0FBTTdCSyxhQUFPLEVBQUVMLE1BTm9CO0FBTzdCTSxjQUFRLEVBQUVOLE1BUG1CO0FBUTdCTyxlQUFTLEVBQUU7QUFDVEMsWUFBSSxFQUFFUixNQURHO0FBRVRTLHFCQUFhLEVBQUUsQ0FBQyxRQUFELEVBQVcsU0FBWCxFQUFzQixVQUF0QixFQUFrQyxPQUFsQyxDQUZOO0FBR1RDLG9CQUFZLEVBQUU7QUFITDtBQVJrQixLQUFqQixFQWFYO0FBQUVDLGFBQU8sRUFBRW5CO0FBQVgsS0FiVyxDQUFkLENBTlksQ0FvQlo7O0FBQ0EsU0FBS0ssVUFBTCxDQUFnQmUsWUFBaEIsQ0FBNkIsS0FBS2IsTUFBbEMsRUFyQlksQ0FzQlo7O0FBQ0EsU0FBS2MsbUJBQUwsYUFBOEIsS0FBS2pCLElBQW5DO0FBQ0EsU0FBS2tCLG9CQUFMLGFBQStCLEtBQUtsQixJQUFwQztBQUNEOztBQTFCb0I7QUE2QnZCO0FBQ0E7QUFDQTtBQUNBOzs7QUFDTyxNQUFNVixNQUFNLEdBQUcsSUFBSVEsZ0JBQUosRUFBZixDOzs7Ozs7Ozs7OztBQzFDUCxJQUFJcUIsTUFBSjtBQUFXL0IsTUFBTSxDQUFDSSxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDMkIsUUFBTSxDQUFDMUIsQ0FBRCxFQUFHO0FBQUMwQixVQUFNLEdBQUMxQixDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUkyQixRQUFKO0FBQWFoQyxNQUFNLENBQUNJLElBQVAsQ0FBWSxzQkFBWixFQUFtQztBQUFDNEIsVUFBUSxDQUFDM0IsQ0FBRCxFQUFHO0FBQUMyQixZQUFRLEdBQUMzQixDQUFUO0FBQVc7O0FBQXhCLENBQW5DLEVBQTZELENBQTdEO0FBQWdFLElBQUk0QixLQUFKO0FBQVVqQyxNQUFNLENBQUNJLElBQVAsQ0FBWSx1QkFBWixFQUFvQztBQUFDNkIsT0FBSyxDQUFDNUIsQ0FBRCxFQUFHO0FBQUM0QixTQUFLLEdBQUM1QixDQUFOO0FBQVE7O0FBQWxCLENBQXBDLEVBQXdELENBQXhEOztBQUl2SjtBQUVBLFNBQVM2QixVQUFULENBQW9CQyxLQUFwQixFQUEyQkMsUUFBM0IsRUFBcUNDLElBQXJDLEVBQTJDO0FBQ3pDQyxTQUFPLENBQUNDLEdBQVIsMkJBQStCSixLQUEvQjtBQUNBLFFBQU1LLE1BQU0sR0FBR1IsUUFBUSxDQUFDRSxVQUFULENBQW9CO0FBQ2pDTyxZQUFRLEVBQUVOLEtBRHVCO0FBRWpDQSxTQUFLLEVBQUVBLEtBRjBCO0FBR2pDQyxZQUFRLEVBQUVBO0FBSHVCLEdBQXBCLENBQWY7O0FBS0EsTUFBSUMsSUFBSSxLQUFLLE9BQWIsRUFBc0I7QUFDcEJKLFNBQUssQ0FBQ1MsVUFBTixDQUFpQkwsSUFBakIsRUFBdUI7QUFBRU0sa0JBQVksRUFBRTtBQUFoQixLQUF2QjtBQUNBVixTQUFLLENBQUNXLGVBQU4sQ0FBc0JKLE1BQXRCLEVBQThCLE9BQTlCO0FBQ0Q7QUFDRixDLENBRUQ7OztBQUNBLElBQUlULE1BQU0sQ0FBQ2MsS0FBUCxDQUFhQyxJQUFiLEdBQW9CQyxLQUFwQixPQUFnQyxDQUFwQyxFQUF1QztBQUNyQyxNQUFJaEIsTUFBTSxDQUFDaUIsUUFBUCxDQUFnQkMsZUFBcEIsRUFBcUM7QUFDbkNYLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLDhCQUFaO0FBQ0FSLFVBQU0sQ0FBQ2lCLFFBQVAsQ0FBZ0JDLGVBQWhCLENBQWdDQyxHQUFoQyxDQUFvQztBQUFBLFVBQUM7QUFBRWYsYUFBRjtBQUFTQyxnQkFBVDtBQUFtQkM7QUFBbkIsT0FBRDtBQUFBLGFBQStCSCxVQUFVLENBQUNDLEtBQUQsRUFBUUMsUUFBUixFQUFrQkMsSUFBbEIsQ0FBekM7QUFBQSxLQUFwQztBQUNELEdBSEQsTUFHTztBQUNMQyxXQUFPLENBQUNDLEdBQVIsQ0FBWSw2RUFBWjtBQUNEO0FBQ0YsQzs7Ozs7Ozs7Ozs7QUMzQkQsSUFBSVIsTUFBSjtBQUFXL0IsTUFBTSxDQUFDSSxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDMkIsUUFBTSxDQUFDMUIsQ0FBRCxFQUFHO0FBQUMwQixVQUFNLEdBQUMxQixDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlILE1BQUo7QUFBV0YsTUFBTSxDQUFDSSxJQUFQLENBQVksMEJBQVosRUFBdUM7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQXZDLEVBQTZELENBQTdEOztBQUczRTtBQUVBO0FBQ0EsU0FBUzhDLE9BQVQsQ0FBaUJDLElBQWpCLEVBQXVCO0FBQ3JCZCxTQUFPLENBQUNDLEdBQVIscUJBQXlCYSxJQUFJLENBQUN4QyxJQUE5QixlQUF1Q3dDLElBQUksQ0FBQ2xDLEtBQTVDO0FBQ0FoQixRQUFNLENBQUNXLFVBQVAsQ0FBa0J3QyxNQUFsQixDQUF5QkQsSUFBekI7QUFDRCxDLENBRUQ7OztBQUNBLElBQUlsRCxNQUFNLENBQUNXLFVBQVAsQ0FBa0JpQyxJQUFsQixHQUF5QkMsS0FBekIsT0FBcUMsQ0FBekMsRUFBNEM7QUFDMUMsTUFBSWhCLE1BQU0sQ0FBQ2lCLFFBQVAsQ0FBZ0JNLFdBQXBCLEVBQWlDO0FBQy9CaEIsV0FBTyxDQUFDQyxHQUFSLENBQVksd0JBQVo7QUFDQVIsVUFBTSxDQUFDaUIsUUFBUCxDQUFnQk0sV0FBaEIsQ0FBNEJKLEdBQTVCLENBQWdDRSxJQUFJLElBQUlELE9BQU8sQ0FBQ0MsSUFBRCxDQUEvQztBQUNEO0FBQ0YsQzs7Ozs7Ozs7Ozs7QUNqQkQsSUFBSXJCLE1BQUo7QUFBVy9CLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQzJCLFFBQU0sQ0FBQzFCLENBQUQsRUFBRztBQUFDMEIsVUFBTSxHQUFDMUIsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJNEIsS0FBSjtBQUFVakMsTUFBTSxDQUFDSSxJQUFQLENBQVksdUJBQVosRUFBb0M7QUFBQzZCLE9BQUssQ0FBQzVCLENBQUQsRUFBRztBQUFDNEIsU0FBSyxHQUFDNUIsQ0FBTjtBQUFROztBQUFsQixDQUFwQyxFQUF3RCxDQUF4RDtBQUEyRCxJQUFJSCxNQUFKO0FBQVdGLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLHVCQUFaLEVBQW9DO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUFwQyxFQUEwRCxDQUExRDtBQUloSjtBQUNBO0FBQ0EwQixNQUFNLENBQUN3QixPQUFQLENBQWVyRCxNQUFNLENBQUMyQixtQkFBdEIsRUFBMkMsWUFBWTtBQUNyRCxNQUFJLEtBQUsyQixNQUFULEVBQWlCO0FBQ2YsVUFBTWYsUUFBUSxHQUFHVixNQUFNLENBQUNjLEtBQVAsQ0FBYVksT0FBYixDQUFxQixLQUFLRCxNQUExQixFQUFrQ2YsUUFBbkQ7QUFDQSxXQUFPdkMsTUFBTSxDQUFDVyxVQUFQLENBQWtCaUMsSUFBbEIsQ0FBdUI7QUFBRTVCLFdBQUssRUFBRXVCO0FBQVQsS0FBdkIsQ0FBUDtBQUNEOztBQUNELFNBQU8sS0FBS2lCLEtBQUwsRUFBUDtBQUNELENBTkQsRSxDQVFBO0FBQ0E7O0FBQ0EzQixNQUFNLENBQUN3QixPQUFQLENBQWVyRCxNQUFNLENBQUM0QixvQkFBdEIsRUFBNEMsWUFBWTtBQUN0RCxNQUFJLEtBQUswQixNQUFMLElBQWV2QixLQUFLLENBQUMwQixZQUFOLENBQW1CLEtBQUtILE1BQXhCLEVBQWdDLE9BQWhDLENBQW5CLEVBQTZEO0FBQzNELFdBQU90RCxNQUFNLENBQUNXLFVBQVAsQ0FBa0JpQyxJQUFsQixFQUFQO0FBQ0Q7O0FBQ0QsU0FBTyxLQUFLWSxLQUFMLEVBQVA7QUFDRCxDQUxELEUsQ0FPQTtBQUNBOztBQUNBM0IsTUFBTSxDQUFDd0IsT0FBUCxDQUFlLElBQWYsRUFBcUIsWUFBWTtBQUMvQixNQUFJLEtBQUtDLE1BQVQsRUFBaUI7QUFDZixXQUFPekIsTUFBTSxDQUFDNkIsY0FBUCxDQUFzQmQsSUFBdEIsQ0FBMkI7QUFBRSxrQkFBWSxLQUFLVTtBQUFuQixLQUEzQixDQUFQO0FBQ0Q7O0FBQ0QsU0FBTyxLQUFLRSxLQUFMLEVBQVA7QUFDRCxDQUxELEU7Ozs7Ozs7Ozs7O0FDekJBMUQsTUFBTSxDQUFDSSxJQUFQLENBQVksa0NBQVo7QUFBZ0RKLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLHNDQUFaO0FBQW9ESixNQUFNLENBQUNJLElBQVAsQ0FBWSwrQkFBWixFIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJztcbmltcG9ydCB7IFRyYWNrZXIgfSBmcm9tICdtZXRlb3IvdHJhY2tlcic7XG5pbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnO1xuXG4vKipcbiAqIFRoZSBTdHVmZnNDb2xsZWN0aW9uLiBJdCBlbmNhcHN1bGF0ZXMgc3RhdGUgYW5kIHZhcmlhYmxlIHZhbHVlcyBmb3Igc3R1ZmYuXG4gKi9cbmNsYXNzIFN0dWZmc0NvbGxlY3Rpb24ge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICAvLyBUaGUgbmFtZSBvZiB0aGlzIGNvbGxlY3Rpb24uXG4gICAgdGhpcy5uYW1lID0gJ1N0dWZmc0NvbGxlY3Rpb24nO1xuICAgIC8vIERlZmluZSB0aGUgTW9uZ28gY29sbGVjdGlvbi5cbiAgICB0aGlzLmNvbGxlY3Rpb24gPSBuZXcgTW9uZ28uQ29sbGVjdGlvbih0aGlzLm5hbWUpO1xuICAgIC8vIERlZmluZSB0aGUgc3RydWN0dXJlIG9mIGVhY2ggZG9jdW1lbnQgaW4gdGhlIGNvbGxlY3Rpb24uXG4gICAgdGhpcy5zY2hlbWEgPSBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgICAgIG5hbWU6IFN0cmluZyxcbiAgICAgIHBob25lOiBTdHJpbmcsXG4gICAgICBvd25lcjogU3RyaW5nLFxuICAgICAgbG9jYXRpb246IFN0cmluZyxcbiAgICAgIGRlc2NyaXB0aW9uOiBTdHJpbmcsXG4gICAgICBtYXJrZXJzOiBTdHJpbmcsXG4gICAgICBiZWhhdmlvcjogU3RyaW5nLFxuICAgICAgbnVtUGVvcGxlOiB7XG4gICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgYWxsb3dlZFZhbHVlczogWycwIC0gMjUnLCAnMjYgLSA1MCcsICc1MSAtIDEwMCcsICcxMDAgKyddLFxuICAgICAgICBkZWZhdWx0VmFsdWU6ICcwIC0gMjUnLFxuICAgICAgfSxcbiAgICB9LCB7IHRyYWNrZXI6IFRyYWNrZXIgfSk7XG4gICAgLy8gQXR0YWNoIHRoZSBzY2hlbWEgdG8gdGhlIGNvbGxlY3Rpb24sIHNvIGFsbCBhdHRlbXB0cyB0byBpbnNlcnQgYSBkb2N1bWVudCBhcmUgY2hlY2tlZCBhZ2FpbnN0IHNjaGVtYS5cbiAgICB0aGlzLmNvbGxlY3Rpb24uYXR0YWNoU2NoZW1hKHRoaXMuc2NoZW1hKTtcbiAgICAvLyBEZWZpbmUgbmFtZXMgZm9yIHB1YmxpY2F0aW9ucyBhbmQgc3Vic2NyaXB0aW9uc1xuICAgIHRoaXMudXNlclB1YmxpY2F0aW9uTmFtZSA9IGAke3RoaXMubmFtZX0ucHVibGljYXRpb24udXNlcmA7XG4gICAgdGhpcy5hZG1pblB1YmxpY2F0aW9uTmFtZSA9IGAke3RoaXMubmFtZX0ucHVibGljYXRpb24uYWRtaW5gO1xuICB9XG59XG5cbi8qKlxuICogVGhlIHNpbmdsZXRvbiBpbnN0YW5jZSBvZiB0aGUgU3R1ZmZzQ29sbGVjdGlvbi5cbiAqIEB0eXBlIHtTdHVmZnNDb2xsZWN0aW9ufVxuICovXG5leHBvcnQgY29uc3QgU3R1ZmZzID0gbmV3IFN0dWZmc0NvbGxlY3Rpb24oKTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgQWNjb3VudHMgfSBmcm9tICdtZXRlb3IvYWNjb3VudHMtYmFzZSc7XG5pbXBvcnQgeyBSb2xlcyB9IGZyb20gJ21ldGVvci9hbGFubmluZzpyb2xlcyc7XG5cbi8qIGVzbGludC1kaXNhYmxlIG5vLWNvbnNvbGUgKi9cblxuZnVuY3Rpb24gY3JlYXRlVXNlcihlbWFpbCwgcGFzc3dvcmQsIHJvbGUpIHtcbiAgY29uc29sZS5sb2coYCAgQ3JlYXRpbmcgdXNlciAke2VtYWlsfS5gKTtcbiAgY29uc3QgdXNlcklEID0gQWNjb3VudHMuY3JlYXRlVXNlcih7XG4gICAgdXNlcm5hbWU6IGVtYWlsLFxuICAgIGVtYWlsOiBlbWFpbCxcbiAgICBwYXNzd29yZDogcGFzc3dvcmQsXG4gIH0pO1xuICBpZiAocm9sZSA9PT0gJ2FkbWluJykge1xuICAgIFJvbGVzLmNyZWF0ZVJvbGUocm9sZSwgeyB1bmxlc3NFeGlzdHM6IHRydWUgfSk7XG4gICAgUm9sZXMuYWRkVXNlcnNUb1JvbGVzKHVzZXJJRCwgJ2FkbWluJyk7XG4gIH1cbn1cblxuLy8gV2hlbiBydW5uaW5nIGFwcCBmb3IgZmlyc3QgdGltZSwgcGFzcyBhIHNldHRpbmdzIGZpbGUgdG8gc2V0IHVwIGEgZGVmYXVsdCB1c2VyIGFjY291bnQuXG5pZiAoTWV0ZW9yLnVzZXJzLmZpbmQoKS5jb3VudCgpID09PSAwKSB7XG4gIGlmIChNZXRlb3Iuc2V0dGluZ3MuZGVmYXVsdEFjY291bnRzKSB7XG4gICAgY29uc29sZS5sb2coJ0NyZWF0aW5nIHRoZSBkZWZhdWx0IHVzZXIocyknKTtcbiAgICBNZXRlb3Iuc2V0dGluZ3MuZGVmYXVsdEFjY291bnRzLm1hcCgoeyBlbWFpbCwgcGFzc3dvcmQsIHJvbGUgfSkgPT4gY3JlYXRlVXNlcihlbWFpbCwgcGFzc3dvcmQsIHJvbGUpKTtcbiAgfSBlbHNlIHtcbiAgICBjb25zb2xlLmxvZygnQ2Fubm90IGluaXRpYWxpemUgdGhlIGRhdGFiYXNlISAgUGxlYXNlIGludm9rZSBtZXRlb3Igd2l0aCBhIHNldHRpbmdzIGZpbGUuJyk7XG4gIH1cbn1cbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgU3R1ZmZzIH0gZnJvbSAnLi4vLi4vYXBpL3N0dWZmL1N0dWZmLmpzJztcblxuLyogZXNsaW50LWRpc2FibGUgbm8tY29uc29sZSAqL1xuXG4vLyBJbml0aWFsaXplIHRoZSBkYXRhYmFzZSB3aXRoIGEgZGVmYXVsdCBkYXRhIGRvY3VtZW50LlxuZnVuY3Rpb24gYWRkRGF0YShkYXRhKSB7XG4gIGNvbnNvbGUubG9nKGAgIEFkZGluZzogJHtkYXRhLm5hbWV9ICgke2RhdGEub3duZXJ9KWApO1xuICBTdHVmZnMuY29sbGVjdGlvbi5pbnNlcnQoZGF0YSk7XG59XG5cbi8vIEluaXRpYWxpemUgdGhlIFN0dWZmc0NvbGxlY3Rpb24gaWYgZW1wdHkuXG5pZiAoU3R1ZmZzLmNvbGxlY3Rpb24uZmluZCgpLmNvdW50KCkgPT09IDApIHtcbiAgaWYgKE1ldGVvci5zZXR0aW5ncy5kZWZhdWx0RGF0YSkge1xuICAgIGNvbnNvbGUubG9nKCdDcmVhdGluZyBkZWZhdWx0IGRhdGEuJyk7XG4gICAgTWV0ZW9yLnNldHRpbmdzLmRlZmF1bHREYXRhLm1hcChkYXRhID0+IGFkZERhdGEoZGF0YSkpO1xuICB9XG59XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IFJvbGVzIH0gZnJvbSAnbWV0ZW9yL2FsYW5uaW5nOnJvbGVzJztcbmltcG9ydCB7IFN0dWZmcyB9IGZyb20gJy4uLy4uL2FwaS9zdHVmZi9TdHVmZic7XG5cbi8vIFVzZXItbGV2ZWwgcHVibGljYXRpb24uXG4vLyBJZiBsb2dnZWQgaW4sIHRoZW4gcHVibGlzaCBkb2N1bWVudHMgb3duZWQgYnkgdGhpcyB1c2VyLiBPdGhlcndpc2UgcHVibGlzaCBub3RoaW5nLlxuTWV0ZW9yLnB1Ymxpc2goU3R1ZmZzLnVzZXJQdWJsaWNhdGlvbk5hbWUsIGZ1bmN0aW9uICgpIHtcbiAgaWYgKHRoaXMudXNlcklkKSB7XG4gICAgY29uc3QgdXNlcm5hbWUgPSBNZXRlb3IudXNlcnMuZmluZE9uZSh0aGlzLnVzZXJJZCkudXNlcm5hbWU7XG4gICAgcmV0dXJuIFN0dWZmcy5jb2xsZWN0aW9uLmZpbmQoeyBvd25lcjogdXNlcm5hbWUgfSk7XG4gIH1cbiAgcmV0dXJuIHRoaXMucmVhZHkoKTtcbn0pO1xuXG4vLyBBZG1pbi1sZXZlbCBwdWJsaWNhdGlvbi5cbi8vIElmIGxvZ2dlZCBpbiBhbmQgd2l0aCBhZG1pbiByb2xlLCB0aGVuIHB1Ymxpc2ggYWxsIGRvY3VtZW50cyBmcm9tIGFsbCB1c2Vycy4gT3RoZXJ3aXNlIHB1Ymxpc2ggbm90aGluZy5cbk1ldGVvci5wdWJsaXNoKFN0dWZmcy5hZG1pblB1YmxpY2F0aW9uTmFtZSwgZnVuY3Rpb24gKCkge1xuICBpZiAodGhpcy51c2VySWQgJiYgUm9sZXMudXNlcklzSW5Sb2xlKHRoaXMudXNlcklkLCAnYWRtaW4nKSkge1xuICAgIHJldHVybiBTdHVmZnMuY29sbGVjdGlvbi5maW5kKCk7XG4gIH1cbiAgcmV0dXJuIHRoaXMucmVhZHkoKTtcbn0pO1xuXG4vLyBhbGFubmluZzpyb2xlcyBwdWJsaWNhdGlvblxuLy8gUmVjb21tZW5kZWQgY29kZSB0byBwdWJsaXNoIHJvbGVzIGZvciBlYWNoIHVzZXIuXG5NZXRlb3IucHVibGlzaChudWxsLCBmdW5jdGlvbiAoKSB7XG4gIGlmICh0aGlzLnVzZXJJZCkge1xuICAgIHJldHVybiBNZXRlb3Iucm9sZUFzc2lnbm1lbnQuZmluZCh7ICd1c2VyLl9pZCc6IHRoaXMudXNlcklkIH0pO1xuICB9XG4gIHJldHVybiB0aGlzLnJlYWR5KCk7XG59KTtcbiIsImltcG9ydCAnL2ltcG9ydHMvc3RhcnR1cC9zZXJ2ZXIvQWNjb3VudHMnO1xuaW1wb3J0ICcvaW1wb3J0cy9zdGFydHVwL3NlcnZlci9QdWJsaWNhdGlvbnMnO1xuaW1wb3J0ICcvaW1wb3J0cy9zdGFydHVwL3NlcnZlci9Nb25nbyc7XG4iXX0=
