(function () {



/* Exports */
Package._define("zodern:standard-minifier-js");

})();
