(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var MeteorX = Package['montiapm:meteorx'].MeteorX;
var LocalCollection = Package.minimongo.LocalCollection;
var Minimongo = Package.minimongo.Minimongo;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var EJSON = Package.ejson.EJSON;
var DDPCommon = Package['ddp-common'].DDPCommon;
var _ = Package.underscore._;
var Random = Package.random.Random;
var WebApp = Package.webapp.WebApp;
var WebAppInternals = Package.webapp.WebAppInternals;
var main = Package.webapp.main;
var ECMAScript = Package.ecmascript.ECMAScript;
var Email = Package.email.Email;
var EmailInternals = Package.email.EmailInternals;
var HTTP = Package.http.HTTP;
var HTTPInternals = Package.http.HTTPInternals;
var meteorInstall = Package.modules.meteorInstall;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var getClientArchVersion, Kadira, Monti, BaseErrorModel, Retry, HaveAsyncCallback, UniqueId, DefaultUniqueId, CreateUserStack, OptimizedApply, getClientVersions, countKeys, iterate, getProperty, Ntp, handleApiResponse, WaitTimeBuilder, OplogCheck, Tracer, TracerStore, kind, KadiraModel, MethodsModel, PubsubModel, SystemModel, ErrorModel, DocSzCache, DocSzCacheItem, wrapServer, wrapSession, wrapSubscription, wrapOplogObserveDriver, wrapPollingObserveDriver, wrapMultiplexer, wrapForCountingObservers, wrapStringifyDDP, hijackDBOps, TrackUncaughtExceptions, TrackUnhandledRejections, TrackMeteorDebug, setLabels, MAX_BODY_SIZE, MAX_STRINGIFIED_BODY_SIZE;

var require = meteorInstall({"node_modules":{"meteor":{"montiapm:agent":{"lib":{"common":{"utils.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/common/utils.js                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
getClientArchVersion = function (arch) {
  const autoupdate = __meteor_runtime_config__.autoupdate;

  if (autoupdate) {
    return autoupdate.versions[arch] ? autoupdate.versions[arch].version : 'none';
  } // Meteor 1.7 and older did not have an `autoupdate` object.


  switch (arch) {
    case 'cordova.web':
      return __meteor_runtime_config__.autoupdateVersionCordova;

    case 'web.browser':
    case 'web.browser.legacy':
      // Meteor 1.7 always used the web.browser.legacy version
      return __meteor_runtime_config__.autoupdateVersion;

    default:
      return 'none';
  }
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"unify.js":function module(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/common/unify.js                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Kadira = {};
Kadira.options = {};
Monti = Kadira;

if (Meteor.wrapAsync) {
  Kadira._wrapAsync = Meteor.wrapAsync;
} else {
  Kadira._wrapAsync = Meteor._wrapAsync;
}

if (Meteor.isServer) {
  var EventEmitter = Npm.require('events').EventEmitter;

  var eventBus = new EventEmitter();
  eventBus.setMaxListeners(0);

  var buildArgs = function (args) {
    var eventName = args[0] + '-' + args[1];
    var args = args.slice(2);
    args.unshift(eventName);
    return args;
  };

  Kadira.EventBus = {};
  ['on', 'emit', 'removeListener', 'removeAllListeners'].forEach(function (m) {
    Kadira.EventBus[m] = function () {
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      var args = buildArgs(args);
      return eventBus[m].apply(eventBus, args);
    };
  });
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"default_error_filters.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/common/default_error_filters.js                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var commonErrRegExps = [/connection timeout\. no (\w*) heartbeat received/i, /INVALID_STATE_ERR/i];
Kadira.errorFilters = {
  filterValidationErrors: function (type, message, err) {
    if (err && err instanceof Meteor.Error) {
      return false;
    } else {
      return true;
    }
  },
  filterCommonMeteorErrors: function (type, message) {
    for (var lc = 0; lc < commonErrRegExps.length; lc++) {
      var regExp = commonErrRegExps[lc];

      if (regExp.test(message)) {
        return false;
      }
    }

    return true;
  }
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"send.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/common/send.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Kadira.send = function (payload, path, callback) {
  if (!Kadira.connected) {
    throw new Error("You need to connect with Kadira first, before sending messages!");
  }

  path = path.substr(0, 1) != '/' ? "/" + path : path;
  var endpoint = Kadira.options.endpoint + path;
  var retryCount = 0;
  var retry = new Retry({
    minCount: 1,
    minTimeout: 0,
    baseTimeout: 1000 * 5,
    maxTimeout: 1000 * 60
  });

  var sendFunction = Kadira._getSendFunction();

  tryToSend();

  function tryToSend(err) {
    if (retryCount < 5) {
      retry.retryLater(retryCount++, send);
    } else {
      console.warn('Error sending error traces to Monti APM server');
      if (callback) callback(err);
    }
  }

  function send() {
    sendFunction(endpoint, payload, function (err, res) {
      if (err && !res) {
        tryToSend(err);
      } else if (res.statusCode == 200) {
        if (callback) callback(null, res.data);
      } else {
        if (callback) callback(new Meteor.Error(res.statusCode, res.content));
      }
    });
  }
};

Kadira._getSendFunction = function () {
  return Meteor.isServer ? Kadira._serverSend : Kadira._clientSend;
};

Kadira._clientSend = function (endpoint, payload, callback) {
  httpRequest('POST', endpoint, {
    headers: {
      'Content-Type': 'application/json'
    },
    content: JSON.stringify(payload)
  }, callback);
};

Kadira._serverSend = function () {
  throw new Error('Kadira._serverSend is not supported. Use coreApi instead.');
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"models":{"base_error.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/models/base_error.js                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
BaseErrorModel = function (options) {
  this._filters = [];
};

BaseErrorModel.prototype.addFilter = function (filter) {
  if (typeof filter === 'function') {
    this._filters.push(filter);
  } else {
    throw new Error("Error filter must be a function");
  }
};

BaseErrorModel.prototype.removeFilter = function (filter) {
  var index = this._filters.indexOf(filter);

  if (index >= 0) {
    this._filters.splice(index, 1);
  }
};

BaseErrorModel.prototype.applyFilters = function (type, message, error, subType) {
  for (var lc = 0; lc < this._filters.length; lc++) {
    var filter = this._filters[lc];

    try {
      var validated = filter(type, message, error, subType);
      if (!validated) return false;
    } catch (ex) {
      // we need to remove this filter
      // we may ended up in a error cycle
      this._filters.splice(lc, 1);

      throw new Error("an error thrown from a filter you've suplied", ex.message);
    }
  }

  return true;
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"0model.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/models/0model.js                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
KadiraModel = function () {};

KadiraModel.prototype._getDateId = function (timestamp) {
  var remainder = timestamp % (1000 * 60);
  var dateId = timestamp - remainder;
  return dateId;
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function module(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/models/methods.js                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
const {
  DDSketch
} = require('monti-apm-sketches-js');

var METHOD_METRICS_FIELDS = ['wait', 'db', 'http', 'email', 'async', 'compute', 'total'];

MethodsModel = function (metricsThreshold) {
  this.methodMetricsByMinute = Object.create(null);
  this.errorMap = Object.create(null);
  this._metricsThreshold = _.extend({
    "wait": 100,
    "db": 100,
    "http": 1000,
    "email": 100,
    "async": 100,
    "compute": 100,
    "total": 200
  }, metricsThreshold || Object.create(null)); //store max time elapsed methods for each method, event(metrics-field)

  this.maxEventTimesForMethods = Object.create(null);
  this.tracerStore = new TracerStore({
    interval: 1000 * 60,
    //process traces every minute
    maxTotalPoints: 30,
    //for 30 minutes
    archiveEvery: 5 //always trace for every 5 minutes,

  });
  this.tracerStore.start();
};

_.extend(MethodsModel.prototype, KadiraModel.prototype);

MethodsModel.prototype._getMetrics = function (timestamp, method) {
  var dateId = this._getDateId(timestamp);

  if (!this.methodMetricsByMinute[dateId]) {
    this.methodMetricsByMinute[dateId] = {
      methods: Object.create(null)
    };
  }

  var methods = this.methodMetricsByMinute[dateId].methods; //initialize method

  if (!methods[method]) {
    methods[method] = {
      count: 0,
      errors: 0,
      fetchedDocSize: 0,
      sentMsgSize: 0,
      histogram: new DDSketch({
        alpha: 0.02
      })
    };
    METHOD_METRICS_FIELDS.forEach(function (field) {
      methods[method][field] = 0;
    });
  }

  return this.methodMetricsByMinute[dateId].methods[method];
};

MethodsModel.prototype.setStartTime = function (timestamp) {
  this.metricsByMinute[dateId].startTime = timestamp;
};

MethodsModel.prototype.processMethod = function (methodTrace) {
  var dateId = this._getDateId(methodTrace.at); //append metrics to previous values


  this._appendMetrics(dateId, methodTrace);

  if (methodTrace.errored) {
    this.methodMetricsByMinute[dateId].methods[methodTrace.name].errors++;
  }

  this.tracerStore.addTrace(methodTrace);
};

MethodsModel.prototype._appendMetrics = function (id, methodTrace) {
  var methodMetrics = this._getMetrics(id, methodTrace.name); // startTime needs to be converted into serverTime before sending


  if (!this.methodMetricsByMinute[id].startTime) {
    this.methodMetricsByMinute[id].startTime = methodTrace.at;
  } //merge


  METHOD_METRICS_FIELDS.forEach(function (field) {
    var value = methodTrace.metrics[field];

    if (value > 0) {
      methodMetrics[field] += value;
    }
  });
  methodMetrics.count++;
  methodMetrics.histogram.add(methodTrace.metrics.total);
  this.methodMetricsByMinute[id].endTime = methodTrace.metrics.at;
};

MethodsModel.prototype.trackDocSize = function (method, size) {
  var timestamp = Ntp._now();

  var dateId = this._getDateId(timestamp);

  var methodMetrics = this._getMetrics(dateId, method);

  methodMetrics.fetchedDocSize += size;
};

MethodsModel.prototype.trackMsgSize = function (method, size) {
  var timestamp = Ntp._now();

  var dateId = this._getDateId(timestamp);

  var methodMetrics = this._getMetrics(dateId, method);

  methodMetrics.sentMsgSize += size;
};
/*
  There are two types of data

  1. methodMetrics - metrics about the methods (for every 10 secs)
  2. methodRequests - raw method request. normally max, min for every 1 min and errors always
*/


MethodsModel.prototype.buildPayload = function (buildDetailedInfo) {
  var payload = {
    methodMetrics: [],
    methodRequests: []
  }; //handling metrics

  var methodMetricsByMinute = this.methodMetricsByMinute;
  this.methodMetricsByMinute = Object.create(null); //create final paylod for methodMetrics

  for (var key in methodMetricsByMinute) {
    var methodMetrics = methodMetricsByMinute[key]; // converting startTime into the actual serverTime

    var startTime = methodMetrics.startTime;
    methodMetrics.startTime = Kadira.syncedDate.syncTime(startTime);

    for (var methodName in methodMetrics.methods) {
      METHOD_METRICS_FIELDS.forEach(function (field) {
        methodMetrics.methods[methodName][field] /= methodMetrics.methods[methodName].count;
      });
    }

    payload.methodMetrics.push(methodMetricsByMinute[key]);
  } //collect traces and send them with the payload


  payload.methodRequests = this.tracerStore.collectTraces();
  return payload;
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"pubsub.js":function module(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/models/pubsub.js                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var logger = Npm.require('debug')('kadira:pubsub');

const {
  DDSketch
} = require('monti-apm-sketches-js');

PubsubModel = function () {
  this.metricsByMinute = Object.create(null);
  this.subscriptions = Object.create(null);
  this.tracerStore = new TracerStore({
    interval: 1000 * 60,
    //process traces every minute
    maxTotalPoints: 30,
    //for 30 minutes
    archiveEvery: 5 //always trace for every 5 minutes,

  });
  this.tracerStore.start();
};

PubsubModel.prototype._trackSub = function (session, msg) {
  logger('SUB:', session.id, msg.id, msg.name, msg.params);

  var publication = this._getPublicationName(msg.name);

  var subscriptionId = msg.id;

  var timestamp = Ntp._now();

  var metrics = this._getMetrics(timestamp, publication);

  metrics.subs++;
  this.subscriptions[msg.id] = {
    // We use localTime here, because when we used synedTime we might get
    // minus or more than we've expected
    //   (before serverTime diff changed overtime)
    startTime: timestamp,
    publication: publication,
    params: msg.params,
    id: msg.id
  }; //set session startedTime

  session._startTime = session._startTime || timestamp;
};

_.extend(PubsubModel.prototype, KadiraModel.prototype);

PubsubModel.prototype._trackUnsub = function (session, sub) {
  logger('UNSUB:', session.id, sub._subscriptionId);

  var publication = this._getPublicationName(sub._name);

  var subscriptionId = sub._subscriptionId;
  var subscriptionState = this.subscriptions[subscriptionId];
  var startTime = null; //sometime, we don't have these states

  if (subscriptionState) {
    startTime = subscriptionState.startTime;
  } else {
    //if this is null subscription, which is started automatically
    //hence, we don't have a state
    startTime = session._startTime;
  } //in case, we can't get the startTime


  if (startTime) {
    var timestamp = Ntp._now();

    var metrics = this._getMetrics(timestamp, publication); //track the count


    if (sub._name != null) {
      // we can't track subs for `null` publications.
      // so we should not track unsubs too
      metrics.unsubs++;
    } //use the current date to get the lifeTime of the subscription


    metrics.lifeTime += timestamp - startTime; //this is place we can clean the subscriptionState if exists

    delete this.subscriptions[subscriptionId];
  }
};

PubsubModel.prototype._trackReady = function (session, sub, trace) {
  logger('READY:', session.id, sub._subscriptionId); //use the current time to track the response time

  var publication = this._getPublicationName(sub._name);

  var subscriptionId = sub._subscriptionId;

  var timestamp = Ntp._now();

  var metrics = this._getMetrics(timestamp, publication);

  var subscriptionState = this.subscriptions[subscriptionId];

  if (subscriptionState && !subscriptionState.readyTracked) {
    var resTime = timestamp - subscriptionState.startTime;
    metrics.resTime += resTime;
    subscriptionState.readyTracked = true;
    metrics.histogram.add(resTime);
  }

  if (trace) {
    this.tracerStore.addTrace(trace);
  }
};

PubsubModel.prototype._trackError = function (session, sub, trace) {
  logger('ERROR:', session.id, sub._subscriptionId); //use the current time to track the response time

  var publication = this._getPublicationName(sub._name);

  var subscriptionId = sub._subscriptionId;

  var timestamp = Ntp._now();

  var metrics = this._getMetrics(timestamp, publication);

  metrics.errors++;

  if (trace) {
    this.tracerStore.addTrace(trace);
  }
};

PubsubModel.prototype._getMetrics = function (timestamp, publication) {
  var dateId = this._getDateId(timestamp);

  if (!this.metricsByMinute[dateId]) {
    this.metricsByMinute[dateId] = {
      // startTime needs to be convert to serverTime before sending to the server
      startTime: timestamp,
      pubs: Object.create(null)
    };
  }

  if (!this.metricsByMinute[dateId].pubs[publication]) {
    this.metricsByMinute[dateId].pubs[publication] = {
      subs: 0,
      unsubs: 0,
      resTime: 0,
      activeSubs: 0,
      activeDocs: 0,
      lifeTime: 0,
      totalObservers: 0,
      cachedObservers: 0,
      createdObservers: 0,
      deletedObservers: 0,
      errors: 0,
      observerLifetime: 0,
      polledDocuments: 0,
      oplogUpdatedDocuments: 0,
      oplogInsertedDocuments: 0,
      oplogDeletedDocuments: 0,
      initiallyAddedDocuments: 0,
      liveAddedDocuments: 0,
      liveChangedDocuments: 0,
      liveRemovedDocuments: 0,
      polledDocSize: 0,
      fetchedDocSize: 0,
      initiallyFetchedDocSize: 0,
      liveFetchedDocSize: 0,
      initiallySentMsgSize: 0,
      liveSentMsgSize: 0,
      histogram: new DDSketch({
        alpha: 0.02
      })
    };
  }

  return this.metricsByMinute[dateId].pubs[publication];
};

PubsubModel.prototype._getPublicationName = function (name) {
  return name || "null(autopublish)";
};

PubsubModel.prototype._getSubscriptionInfo = function () {
  var self = this;
  var activeSubs = Object.create(null);
  var activeDocs = Object.create(null);
  var totalDocsSent = Object.create(null);
  var totalDataSent = Object.create(null);
  var totalObservers = Object.create(null);
  var cachedObservers = Object.create(null);
  iterate(Meteor.server.sessions, session => {
    iterate(session._namedSubs, countSubData);
    iterate(session._universalSubs, countSubData);
  });
  var avgObserverReuse = Object.create(null);

  _.each(totalObservers, function (value, publication) {
    avgObserverReuse[publication] = cachedObservers[publication] / totalObservers[publication];
  });

  return {
    activeSubs: activeSubs,
    activeDocs: activeDocs,
    avgObserverReuse: avgObserverReuse
  };

  function countSubData(sub) {
    var publication = self._getPublicationName(sub._name);

    countSubscriptions(sub, publication);
    countDocuments(sub, publication);
    countObservers(sub, publication);
  }

  function countSubscriptions(sub, publication) {
    activeSubs[publication] = activeSubs[publication] || 0;
    activeSubs[publication]++;
  }

  function countDocuments(sub, publication) {
    activeDocs[publication] = activeDocs[publication] || 0;
    iterate(sub._documents, collection => {
      activeDocs[publication] += countKeys(collection);
    });
  }

  function countObservers(sub, publication) {
    totalObservers[publication] = totalObservers[publication] || 0;
    cachedObservers[publication] = cachedObservers[publication] || 0;
    totalObservers[publication] += sub._totalObservers;
    cachedObservers[publication] += sub._cachedObservers;
  }
};

PubsubModel.prototype.buildPayload = function (buildDetailInfo) {
  var metricsByMinute = this.metricsByMinute;
  this.metricsByMinute = Object.create(null);
  var payload = {
    pubMetrics: []
  };

  var subscriptionData = this._getSubscriptionInfo();

  var activeSubs = subscriptionData.activeSubs;
  var activeDocs = subscriptionData.activeDocs;
  var avgObserverReuse = subscriptionData.avgObserverReuse; //to the averaging

  for (var dateId in metricsByMinute) {
    var dateMetrics = metricsByMinute[dateId]; // We need to convert startTime into actual serverTime

    dateMetrics.startTime = Kadira.syncedDate.syncTime(dateMetrics.startTime);

    for (var publication in metricsByMinute[dateId].pubs) {
      var singlePubMetrics = metricsByMinute[dateId].pubs[publication]; // We only calculate resTime for new subscriptions

      singlePubMetrics.resTime /= singlePubMetrics.subs;
      singlePubMetrics.resTime = singlePubMetrics.resTime || 0; // We only track lifeTime in the unsubs

      singlePubMetrics.lifeTime /= singlePubMetrics.unsubs;
      singlePubMetrics.lifeTime = singlePubMetrics.lifeTime || 0; // Count the average for observer lifetime

      if (singlePubMetrics.deletedObservers > 0) {
        singlePubMetrics.observerLifetime /= singlePubMetrics.deletedObservers;
      } // If there are two ore more dateIds, we will be using the currentCount for all of them.
      // We can come up with a better solution later on.


      singlePubMetrics.activeSubs = activeSubs[publication] || 0;
      singlePubMetrics.activeDocs = activeDocs[publication] || 0;
      singlePubMetrics.avgObserverReuse = avgObserverReuse[publication] || 0;
    }

    payload.pubMetrics.push(metricsByMinute[dateId]);
  } //collect traces and send them with the payload


  payload.pubRequests = this.tracerStore.collectTraces();
  return payload;
};

PubsubModel.prototype.incrementHandleCount = function (trace, isCached) {
  var timestamp = Ntp._now();

  var publicationName = this._getPublicationName(trace.name);

  var publication = this._getMetrics(timestamp, publicationName);

  var session = getProperty(Meteor.server.sessions, trace.session);

  if (session) {
    var sub = getProperty(session._namedSubs, trace.id);

    if (sub) {
      sub._totalObservers = sub._totalObservers || 0;
      sub._cachedObservers = sub._cachedObservers || 0;
    }
  } // not sure, we need to do this? But I don't need to break the however


  sub = sub || {
    _totalObservers: 0,
    _cachedObservers: 0
  };
  publication.totalObservers++;
  sub._totalObservers++;

  if (isCached) {
    publication.cachedObservers++;
    sub._cachedObservers++;
  }
};

PubsubModel.prototype.trackCreatedObserver = function (info) {
  var timestamp = Ntp._now();

  var publicationName = this._getPublicationName(info.name);

  var publication = this._getMetrics(timestamp, publicationName);

  publication.createdObservers++;
};

PubsubModel.prototype.trackDeletedObserver = function (info) {
  var timestamp = Ntp._now();

  var publicationName = this._getPublicationName(info.name);

  var publication = this._getMetrics(timestamp, publicationName);

  publication.deletedObservers++;
  publication.observerLifetime += new Date().getTime() - info.startTime;
};

PubsubModel.prototype.trackDocumentChanges = function (info, op) {
  // It's possibel that info to be null
  // Specially when getting changes at the very begining.
  // This may be false, but nice to have a check
  if (!info) {
    return;
  }

  var timestamp = Ntp._now();

  var publicationName = this._getPublicationName(info.name);

  var publication = this._getMetrics(timestamp, publicationName);

  if (op.op === "d") {
    publication.oplogDeletedDocuments++;
  } else if (op.op === "i") {
    publication.oplogInsertedDocuments++;
  } else if (op.op === "u") {
    publication.oplogUpdatedDocuments++;
  }
};

PubsubModel.prototype.trackPolledDocuments = function (info, count) {
  var timestamp = Ntp._now();

  var publicationName = this._getPublicationName(info.name);

  var publication = this._getMetrics(timestamp, publicationName);

  publication.polledDocuments += count;
};

PubsubModel.prototype.trackLiveUpdates = function (info, type, count) {
  var timestamp = Ntp._now();

  var publicationName = this._getPublicationName(info.name);

  var publication = this._getMetrics(timestamp, publicationName);

  if (type === "_addPublished") {
    publication.liveAddedDocuments += count;
  } else if (type === "_removePublished") {
    publication.liveRemovedDocuments += count;
  } else if (type === "_changePublished") {
    publication.liveChangedDocuments += count;
  } else if (type === "_initialAdds") {
    publication.initiallyAddedDocuments += count;
  } else {
    throw new Error("Kadira: Unknown live update type");
  }
};

PubsubModel.prototype.trackDocSize = function (name, type, size) {
  var timestamp = Ntp._now();

  var publicationName = this._getPublicationName(name);

  var publication = this._getMetrics(timestamp, publicationName);

  if (type === "polledFetches") {
    publication.polledDocSize += size;
  } else if (type === "liveFetches") {
    publication.liveFetchedDocSize += size;
  } else if (type === "cursorFetches") {
    publication.fetchedDocSize += size;
  } else if (type === "initialFetches") {
    publication.initiallyFetchedDocSize += size;
  } else {
    throw new Error("Kadira: Unknown docs fetched type");
  }
};

PubsubModel.prototype.trackMsgSize = function (name, type, size) {
  var timestamp = Ntp._now();

  var publicationName = this._getPublicationName(name);

  var publication = this._getMetrics(timestamp, publicationName);

  if (type === "liveSent") {
    publication.liveSentMsgSize += size;
  } else if (type === "initialSent") {
    publication.initiallySentMsgSize += size;
  } else {
    throw new Error("Kadira: Unknown docs fetched type");
  }
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"system.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/models/system.js                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let createHistogram;
module.link("../utils.js", {
  createHistogram(v) {
    createHistogram = v;
  }

}, 0);
let GCMetrics;
module.link("../hijack/gc.js", {
  default(v) {
    GCMetrics = v;
  }

}, 1);
let getFiberMetrics, resetFiberMetrics;
module.link("../hijack/async.js", {
  getFiberMetrics(v) {
    getFiberMetrics = v;
  },

  resetFiberMetrics(v) {
    resetFiberMetrics = v;
  }

}, 2);
let getMongoDriverStats, resetMongoDriverStats;
module.link("../hijack/mongo-driver-events.js", {
  getMongoDriverStats(v) {
    getMongoDriverStats = v;
  },

  resetMongoDriverStats(v) {
    resetMongoDriverStats = v;
  }

}, 3);

var EventLoopMonitor = Npm.require('evloop-monitor');

SystemModel = function () {
  this.startTime = Ntp._now();
  this.newSessions = 0;
  this.sessionTimeout = 1000 * 60 * 30; //30 min

  this.evloopHistogram = createHistogram();
  this.evloopMonitor = new EventLoopMonitor(200);
  this.evloopMonitor.start();
  this.evloopMonitor.on('lag', lag => {
    // store as microsecond
    this.evloopHistogram.add(lag * 1000);
  });
  this.gcMetrics = new GCMetrics();
  this.gcMetrics.start();
  this.cpuTime = process.hrtime();
  this.previousCpuUsage = process.cpuUsage();
  this.cpuHistory = [];
  this.currentCpuUsage = 0;
  setInterval(() => {
    this.cpuUsage();
  }, 2000);
};

_.extend(SystemModel.prototype, KadiraModel.prototype);

SystemModel.prototype.buildPayload = function () {
  var metrics = {};

  var now = Ntp._now();

  metrics.startTime = Kadira.syncedDate.syncTime(this.startTime);
  metrics.endTime = Kadira.syncedDate.syncTime(now);
  metrics.sessions = countKeys(Meteor.server.sessions);
  let memoryUsage = process.memoryUsage();
  metrics.memory = memoryUsage.rss / (1024 * 1024);
  metrics.memoryArrayBuffers = (memoryUsage.arrayBuffers || 0) / (1024 * 1024);
  metrics.memoryExternal = memoryUsage.external / (1024 * 1024);
  metrics.memoryHeapUsed = memoryUsage.heapUsed / (1024 * 1024);
  metrics.memoryHeapTotal = memoryUsage.heapTotal / (1024 * 1024);
  metrics.newSessions = this.newSessions;
  this.newSessions = 0;
  metrics.activeRequests = process._getActiveRequests().length;
  metrics.activeHandles = process._getActiveHandles().length; // track eventloop metrics

  metrics.pctEvloopBlock = this.evloopMonitor.status().pctBlock;
  metrics.evloopHistogram = this.evloopHistogram;
  this.evloopHistogram = createHistogram();
  metrics.gcMajorDuration = this.gcMetrics.metrics.gcMajor;
  metrics.gcMinorDuration = this.gcMetrics.metrics.gcMinor;
  metrics.gcIncrementalDuration = this.gcMetrics.metrics.gcIncremental;
  metrics.gcWeakCBDuration = this.gcMetrics.metrics.gcWeakCB;
  this.gcMetrics.reset();
  const driverMetrics = getMongoDriverStats();
  resetMongoDriverStats();
  metrics.mongoPoolSize = driverMetrics.poolSize;
  metrics.mongoPoolPrimaryCheckouts = driverMetrics.primaryCheckouts;
  metrics.mongoPoolOtherCheckouts = driverMetrics.otherCheckouts;
  metrics.mongoPoolCheckoutTime = driverMetrics.checkoutTime;
  metrics.mongoPoolMaxCheckoutTime = driverMetrics.maxCheckoutTime;
  metrics.mongoPoolPending = driverMetrics.pending;
  metrics.mongoPoolCheckedOutConnections = driverMetrics.checkedOut;
  metrics.mongoPoolCreatedConnections = driverMetrics.created;
  const fiberMetrics = getFiberMetrics();
  resetFiberMetrics();
  metrics.createdFibers = fiberMetrics.created;
  metrics.activeFibers = fiberMetrics.active;
  metrics.fiberPoolSize = fiberMetrics.poolSize;
  metrics.pcpu = 0;
  metrics.pcpuUser = 0;
  metrics.pcpuSystem = 0;

  if (this.cpuHistory.length > 0) {
    let lastCpuUsage = this.cpuHistory[this.cpuHistory.length - 1];
    metrics.pcpu = lastCpuUsage.usage * 100;
    metrics.pcpuUser = lastCpuUsage.user * 100;
    metrics.pcpuSystem = lastCpuUsage.sys * 100;
  }

  metrics.cpuHistory = this.cpuHistory.map(entry => {
    return {
      time: Kadira.syncedDate.syncTime(entry.time),
      usage: entry.usage,
      sys: entry.sys,
      user: entry.user
    };
  });
  this.cpuHistory = [];
  this.startTime = now;
  return {
    systemMetrics: [metrics]
  };
};

function hrtimeToMS(hrtime) {
  return hrtime[0] * 1000 + hrtime[1] / 1000000;
}

SystemModel.prototype.cpuUsage = function () {
  var elapTimeMS = hrtimeToMS(process.hrtime(this.cpuTime));
  var elapUsage = process.cpuUsage(this.previousCpuUsage);
  var elapUserMS = elapUsage.user / 1000;
  var elapSystMS = elapUsage.system / 1000;
  var totalUsageMS = elapUserMS + elapSystMS;
  var totalUsagePercent = totalUsageMS / elapTimeMS;
  this.cpuHistory.push({
    time: Ntp._now(),
    usage: totalUsagePercent,
    user: elapUserMS / elapTimeMS,
    sys: elapSystMS / elapUsage.system
  });
  this.currentCpuUsage = totalUsagePercent * 100;
  Kadira.docSzCache.setPcpu(this.currentCpuUsage);
  this.cpuTime = process.hrtime();
  this.previousCpuUsage = process.cpuUsage();
};

SystemModel.prototype.handleSessionActivity = function (msg, session) {
  if (msg.msg === 'connect' && !msg.session) {
    this.countNewSession(session);
  } else if (['sub', 'method'].indexOf(msg.msg) != -1) {
    if (!this.isSessionActive(session)) {
      this.countNewSession(session);
    }
  }

  session._activeAt = Date.now();
};

SystemModel.prototype.countNewSession = function (session) {
  if (!isLocalAddress(session.socket)) {
    this.newSessions++;
  }
};

SystemModel.prototype.isSessionActive = function (session) {
  var inactiveTime = Date.now() - session._activeAt;

  return inactiveTime < this.sessionTimeout;
}; // ------------------------------------------------------------------------- //
// http://regex101.com/r/iF3yR3/2


var isLocalHostRegex = /^(?:.*\.local|localhost)(?:\:\d+)?|127(?:\.\d{1,3}){3}|192\.168(?:\.\d{1,3}){2}|10(?:\.\d{1,3}){3}|172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2}$/; // http://regex101.com/r/hM5gD8/1

var isLocalAddressRegex = /^127(?:\.\d{1,3}){3}|192\.168(?:\.\d{1,3}){2}|10(?:\.\d{1,3}){3}|172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2}$/;

function isLocalAddress(socket) {
  var host = socket.headers['host'];
  if (host) return isLocalHostRegex.test(host);
  var address = socket.headers['x-forwarded-for'] || socket.remoteAddress;
  if (address) return isLocalAddressRegex.test(address);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"errors.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/models/errors.js                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
ErrorModel = function (appId) {
  BaseErrorModel.call(this);
  var self = this;
  this.appId = appId;
  this.errors = {};
  this.startTime = Date.now();
  this.maxErrors = 10;
};

Object.assign(ErrorModel.prototype, KadiraModel.prototype);
Object.assign(ErrorModel.prototype, BaseErrorModel.prototype);

ErrorModel.prototype.buildPayload = function () {
  var metrics = _.values(this.errors);

  this.startTime = Ntp._now();
  metrics.forEach(function (metric) {
    metric.startTime = Kadira.syncedDate.syncTime(metric.startTime);
  });
  this.errors = {};
  return {
    errors: metrics
  };
};

ErrorModel.prototype.errorCount = function () {
  return _.values(this.errors).length;
};

ErrorModel.prototype.trackError = function (ex, trace) {
  var key = trace.type + ':' + ex.message;

  if (this.errors[key]) {
    this.errors[key].count++;
  } else if (this.errorCount() < this.maxErrors) {
    var errorDef = this._formatError(ex, trace);

    if (this.applyFilters(errorDef.type, errorDef.name, ex, errorDef.subType)) {
      this.errors[key] = this._formatError(ex, trace);
    }
  }
};

ErrorModel.prototype._formatError = function (ex, trace) {
  var time = Date.now();
  var stack = ex.stack; // to get Meteor's Error details

  if (ex.details) {
    stack = "Details: " + ex.details + "\r\n" + stack;
  } // Update trace's error event with the next stack


  var errorEvent = trace.events && trace.events[trace.events.length - 1];
  var errorObject = errorEvent && errorEvent[2] && errorEvent[2].error;

  if (errorObject) {
    errorObject.stack = stack;
  }

  return {
    appId: this.appId,
    name: ex.message,
    type: trace.type,
    startTime: time,
    subType: trace.subType || trace.name,
    trace: trace,
    stacks: [{
      stack: stack
    }],
    count: 1
  };
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"http.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/models/http.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
const {
  DDSketch
} = require('monti-apm-sketches-js');

const METHOD_METRICS_FIELDS = ['db', 'http', 'email', 'async', 'compute', 'total', 'fs'];

const HttpModel = function () {
  this.metricsByMinute = Object.create(null);
  this.tracerStore = new TracerStore({
    interval: 1000 * 10,
    maxTotalPoints: 30,
    archiveEvery: 10
  });
  this.tracerStore.start();
};

_.extend(HttpModel.prototype, KadiraModel.prototype);

HttpModel.prototype.processRequest = function (trace, req, res) {
  const dateId = this._getDateId(trace.at);

  this._appendMetrics(dateId, trace, res);

  this.tracerStore.addTrace(trace);
};

HttpModel.prototype._getMetrics = function (timestamp, routeId) {
  const dateId = this._getDateId(timestamp);

  if (!this.metricsByMinute[dateId]) {
    this.metricsByMinute[dateId] = {
      routes: Object.create(null)
    };
  }

  const routes = this.metricsByMinute[dateId].routes;

  if (!routes[routeId]) {
    routes[routeId] = {
      histogram: new DDSketch({
        alpha: 0.02
      }),
      count: 0,
      errors: 0,
      statusCodes: Object.create(null)
    };
    METHOD_METRICS_FIELDS.forEach(function (field) {
      routes[routeId][field] = 0;
    });
  }

  return this.metricsByMinute[dateId].routes[routeId];
};

HttpModel.prototype._appendMetrics = function (dateId, trace, res) {
  var requestMetrics = this._getMetrics(dateId, trace.name);

  if (!this.metricsByMinute[dateId].startTime) {
    this.metricsByMinute[dateId].startTime = trace.at;
  } // merge


  METHOD_METRICS_FIELDS.forEach(field => {
    var value = trace.metrics[field];

    if (value > 0) {
      requestMetrics[field] += value;
    }
  });
  const statusCode = res.statusCode;
  let statusMetric;

  if (statusCode < 200) {
    statusMetric = '1xx';
  } else if (statusCode < 300) {
    statusMetric = '2xx';
  } else if (statusCode < 400) {
    statusMetric = '3xx';
  } else if (statusCode < 500) {
    statusMetric = '4xx';
  } else if (statusCode < 600) {
    statusMetric = '5xx';
  }

  requestMetrics.statusCodes[statusMetric] = requestMetrics.statusCodes[statusMetric] || 0;
  requestMetrics.statusCodes[statusMetric] += 1;
  requestMetrics.count += 1;
  requestMetrics.histogram.add(trace.metrics.total);
  this.metricsByMinute[dateId].endTime = trace.metrics.at;
};

HttpModel.prototype.buildPayload = function () {
  var payload = {
    httpMetrics: [],
    httpRequests: []
  };
  var metricsByMinute = this.metricsByMinute;
  this.metricsByMinute = Object.create(null);

  for (var key in metricsByMinute) {
    var metrics = metricsByMinute[key]; // convert startTime into the actual serverTime

    var startTime = metrics.startTime;
    metrics.startTime = Kadira.syncedDate.syncTime(startTime);

    for (var requestName in metrics.routes) {
      METHOD_METRICS_FIELDS.forEach(function (field) {
        metrics.routes[requestName][field] /= metrics.routes[requestName].count;
      });
    }

    payload.httpMetrics.push(metricsByMinute[key]);
  }

  payload.httpRequests = this.tracerStore.collectTraces();
  return payload;
};

module.exportDefault(HttpModel);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"jobs.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/jobs.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Jobs = Kadira.Jobs = {};

Jobs.getAsync = function (id, callback) {
  Kadira.coreApi.getJob(id).then(function (data) {
    callback(null, data);
  }).catch(function (err) {
    callback(err);
  });
};

Jobs.setAsync = function (id, changes, callback) {
  Kadira.coreApi.updateJob(id, changes).then(function (data) {
    callback(null, data);
  }).catch(function (err) {
    callback(err);
  });
};

Jobs.set = Kadira._wrapAsync(Jobs.setAsync);
Jobs.get = Kadira._wrapAsync(Jobs.getAsync);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"retry.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/retry.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// Retry logic with an exponential backoff.
//
// options:
//  baseTimeout: time for initial reconnect attempt (ms).
//  exponent: exponential factor to increase timeout each attempt.
//  maxTimeout: maximum time between retries (ms).
//  minCount: how many times to reconnect "instantly".
//  minTimeout: time to wait for the first `minCount` retries (ms).
//  fuzz: factor to randomize retry times by (to avoid retry storms).
//TODO: remove this class and use Meteor Retry in a later version of meteor.
Retry = class {
  constructor() {
    let {
      baseTimeout = 1000,
      // 1 second
      exponent = 2.2,
      // The default is high-ish to ensure a server can recover from a
      // failure caused by load.
      maxTimeout = 5 * 60000,
      // 5 minutes
      minTimeout = 10,
      minCount = 2,
      fuzz = 0.5 // +- 25%

    } = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    this.baseTimeout = baseTimeout;
    this.exponent = exponent;
    this.maxTimeout = maxTimeout;
    this.minTimeout = minTimeout;
    this.minCount = minCount;
    this.fuzz = fuzz;
    this.retryTimer = null;
  } // Reset a pending retry, if any.


  clear() {
    if (this.retryTimer) clearTimeout(this.retryTimer);
    this.retryTimer = null;
  } // Calculate how long to wait in milliseconds to retry, based on the
  // `count` of which retry this is.


  _timeout(count) {
    if (count < this.minCount) return this.minTimeout;
    let timeout = Math.min(this.maxTimeout, this.baseTimeout * Math.pow(this.exponent, count)); // fuzz the timeout randomly, to avoid reconnect storms when a
    // server goes down.

    timeout = timeout * (Random.fraction() * this.fuzz + (1 - this.fuzz / 2));
    return Math.ceil(timeout);
  } // Call `fn` after a delay, based on the `count` of which retry this is.


  retryLater(count, fn) {
    const timeout = this._timeout(count);

    if (this.retryTimer) clearTimeout(this.retryTimer);
    this.retryTimer = setTimeout(fn, timeout);
    return timeout;
  }

};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"utils.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/utils.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  createHistogram: () => createHistogram
});

const {
  DDSketch
} = require('monti-apm-sketches-js');

HaveAsyncCallback = function (args) {
  var lastArg = args[args.length - 1];
  return typeof lastArg == 'function';
};

UniqueId = function (start) {
  this.id = 0;
};

UniqueId.prototype.get = function () {
  return "" + this.id++;
};

DefaultUniqueId = new UniqueId(); // creates a stack trace, removing frames in montiapm:agent's code

CreateUserStack = function (error) {
  const stack = (error || new Error()).stack.split('\n');
  let toRemove = 1; // Find how many frames need to be removed
  // to make the user's code the first frame

  for (; toRemove < stack.length; toRemove++) {
    if (stack[toRemove].indexOf('montiapm:agent') === -1) {
      break;
    }
  }

  return stack.slice(toRemove).join('\n');
}; // Optimized version of apply which tries to call as possible as it can
// Then fall back to apply
// This is because, v8 is very slow to invoke apply.


OptimizedApply = function OptimizedApply(context, fn, args) {
  var a = args;

  switch (a.length) {
    case 0:
      return fn.call(context);

    case 1:
      return fn.call(context, a[0]);

    case 2:
      return fn.call(context, a[0], a[1]);

    case 3:
      return fn.call(context, a[0], a[1], a[2]);

    case 4:
      return fn.call(context, a[0], a[1], a[2], a[3]);

    case 5:
      return fn.call(context, a[0], a[1], a[2], a[3], a[4]);

    default:
      return fn.apply(context, a);
  }
};

getClientVersions = function () {
  return {
    'web.cordova': getClientArchVersion('web.cordova'),
    'web.browser': getClientArchVersion('web.browser'),
    'web.browser.legacy': getClientArchVersion('web.browser.legacy')
  };
}; // Returns number of keys of an object, or size of a Map or Set


countKeys = function (obj) {
  if (obj instanceof Map || obj instanceof Set) {
    return obj.size;
  }

  return Object.keys(obj).length;
}; // Iterates objects and maps.
// Callback is called with a value and key


iterate = function (obj, callback) {
  if (obj instanceof Map) {
    return obj.forEach(callback);
  }

  for (var key in obj) {
    var value = obj[key];
    callback(value, key);
  }
}; // Returns a property from an object, or an entry from a map


getProperty = function (obj, key) {
  if (obj instanceof Map) {
    return obj.get(key);
  }

  return obj[key];
};

function createHistogram() {
  return new DDSketch({
    alpha: 0.02
  });
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"ntp.js":function module(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/ntp.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var logger = getLogger();

Ntp = function (endpoint) {
  this.path = '/simplentp/sync';
  this.setEndpoint(endpoint);
  this.diff = 0;
  this.synced = false;
  this.reSyncCount = 0;
  this.reSync = new Retry({
    baseTimeout: 1000 * 60,
    maxTimeout: 1000 * 60 * 10,
    minCount: 0
  });
};

Ntp._now = function () {
  var now = Date.now();

  if (typeof now == 'number') {
    return now;
  } else if (now instanceof Date) {
    // some extenal JS libraries override Date.now and returns a Date object
    // which directly affect us. So we need to prepare for that
    return now.getTime();
  } else {
    // trust me. I've seen now === undefined
    return new Date().getTime();
  }
};

Ntp.prototype.setEndpoint = function (endpoint) {
  this.endpoint = endpoint ? endpoint + this.path : null;
};

Ntp.prototype.getTime = function () {
  return Ntp._now() + Math.round(this.diff);
};

Ntp.prototype.syncTime = function (localTime) {
  return localTime + Math.ceil(this.diff);
};

Ntp.prototype.sync = function () {
  if (this.endpoint === null) {
    return;
  }

  logger('init sync');
  var self = this;
  var retryCount = 0;
  var retry = new Retry({
    baseTimeout: 1000 * 20,
    maxTimeout: 1000 * 60,
    minCount: 1,
    minTimeout: 0
  });
  syncTime();

  function syncTime() {
    if (retryCount < 5) {
      logger('attempt time sync with server', retryCount); // if we send 0 to the retryLater, cacheDns will run immediately

      retry.retryLater(retryCount++, cacheDns);
    } else {
      logger('maximum retries reached');
      self.reSync.retryLater(self.reSyncCount++, function () {
        var args = [].slice.call(arguments);
        self.sync.apply(self, args);
      });
    }
  } // first attempt is to cache dns. So, calculation does not
  // include DNS resolution time


  function cacheDns() {
    self.getServerTime(function (err) {
      if (!err) {
        calculateTimeDiff();
      } else {
        syncTime();
      }
    });
  }

  function calculateTimeDiff() {
    var clientStartTime = new Date().getTime();
    self.getServerTime(function (err, serverTime) {
      if (!err && serverTime) {
        // (Date.now() + clientStartTime)/2 : Midpoint between req and res
        var networkTime = (new Date().getTime() - clientStartTime) / 2;
        var serverStartTime = serverTime - networkTime;
        self.diff = serverStartTime - clientStartTime;
        self.synced = true; // we need to send 1 into retryLater.

        self.reSync.retryLater(self.reSyncCount++, function () {
          var args = [].slice.call(arguments);
          self.sync.apply(self, args);
        });
        logger('successfully updated diff value', self.diff);
      } else {
        syncTime();
      }
    });
  }
};

Ntp.prototype.getServerTime = function (callback) {
  var self = this;

  if (self.endpoint === null) {
    throw new Error('getServerTime requires the endpoint to be set');
  }

  if (Meteor.isServer) {
    Kadira.coreApi.get(self.path, {
      noRetries: true
    }).then(content => {
      var serverTime = parseInt(content);
      callback(null, serverTime);
    }).catch(err => {
      callback(err);
    });
  } else {
    httpRequest('GET', self.endpoint + "?noCache=".concat(new Date().getTime(), "-").concat(Math.random()), function (err, res) {
      if (err) {
        callback(err);
      } else {
        var serverTime = parseInt(res.content);
        callback(null, serverTime);
      }
    });
  }
};

function getLogger() {
  if (Meteor.isServer) {
    return Npm.require('debug')("kadira:ntp");
  } else {
    return function (message) {
      var canLogKadira = Meteor._localStorage.getItem('LOG_KADIRA') !== null && typeof console !== 'undefined';

      if (canLogKadira) {
        if (message) {
          message = "kadira:ntp " + message;
          arguments[0] = message;
        }

        console.log.apply(console, arguments);
      }
    };
  }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"sourcemaps.js":function module(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/sourcemaps.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var url = Npm.require('url');

var path = Npm.require('path');

var fs = Npm.require('fs');

var logger = Npm.require('debug')('kadira:apm:sourcemaps'); // Meteor 1.7 and older used clientPaths


var clientPaths = __meteor_bootstrap__.configJson.clientPaths;
var clientArchs = __meteor_bootstrap__.configJson.clientArchs;
var serverDir = __meteor_bootstrap__.serverDir;
var absClientPaths;

if (clientArchs) {
  absClientPaths = clientArchs.reduce((result, arch) => {
    result[arch] = path.resolve(path.dirname(serverDir), arch);
    return result;
  }, {});
} else {
  absClientPaths = Object.keys(clientPaths).reduce((result, key) => {
    result[key] = path.resolve(serverDir, path.dirname(clientPaths[key]));
    return result;
  }, {});
}

handleApiResponse = function () {
  let body = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  var unavailable = [];

  if (typeof body === 'string') {
    try {
      body = JSON.parse(body);
    } catch (e) {
      logger('failed parsing body', e, body);
      return;
    }
  }

  var neededSourcemaps = body.neededSourcemaps || [];
  logger('body', neededSourcemaps);
  var promises = neededSourcemaps.map(sourcemap => {
    if (!Kadira.options.uploadSourceMaps) {
      return unavailable.push(sourcemap);
    }

    return getSourcemapPath(sourcemap.arch, sourcemap.file.path).then(function (sourceMapPath) {
      if (sourceMapPath === null) {
        unavailable.push(sourcemap);
      } else {
        sendSourcemap(sourcemap, sourceMapPath);
      }
    });
  });
  Promise.all(promises).then(function () {
    if (unavailable.length > 0) {
      logger('sending unavailable sourcemaps', unavailable);
      Kadira.coreApi.sendData({
        unavailableSourcemaps: unavailable
      }).then(function (body) {
        handleApiResponse(body);
      }).catch(function (err) {
        console.log('Monti APM: unable to send data', err);
      });
    }
  });
};

function sendSourcemap(sourcemap, sourcemapPath) {
  logger('Sending sourcemap', sourcemap, sourcemapPath);
  var stream = fs.createReadStream(sourcemapPath);
  stream.on('error', err => {
    console.log('Monti APM: error while uploading sourcemap', err);
  });
  var arch = sourcemap.arch;
  var archVersion = sourcemap.archVersion;
  var file = encodeURIComponent(sourcemap.file.path);
  Kadira.coreApi.sendStream("/sourcemap?arch=".concat(arch, "&archVersion=").concat(archVersion, "&file=").concat(file), stream).catch(function (err) {
    console.log('Monti APM: error uploading sourcemap', err);
  });
}

function preparePath(urlPath) {
  urlPath = path.posix.normalize(urlPath);

  if (urlPath[0] === '/') {
    urlPath = urlPath.slice(1);
  }

  return urlPath;
}

function checkForDynamicImport(arch, urlPath) {
  const filePath = preparePath(urlPath);
  return new Promise(function (resolve) {
    const archPath = absClientPaths[arch];
    const dynamicPath = path.join(archPath, 'dynamic', filePath) + '.map';
    fs.stat(dynamicPath, function (err) {
      resolve(err ? null : dynamicPath);
    });
  });
}

function getSourcemapPath(arch, urlPath) {
  return new Promise((resolve, reject) => {
    var clientProgram = WebApp.clientPrograms[arch];

    if (!clientProgram || !clientProgram.manifest) {
      return resolve(null);
    }

    var fileInfo = clientProgram.manifest.find(file => {
      return file.url && file.url.startsWith(urlPath);
    });

    if (fileInfo && fileInfo.sourceMap) {
      return resolve(path.join(absClientPaths[arch], fileInfo.sourceMap));
    }

    checkForDynamicImport(arch, urlPath).then(resolve).catch(reject);
  });
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wait_time_builder.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/wait_time_builder.js                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var WAITON_MESSAGE_FIELDS = ['msg', 'id', 'method', 'name', 'waitTime']; // This is way how we can build waitTime and it's breakdown

WaitTimeBuilder = function () {
  this._waitListStore = {};
  this._currentProcessingMessages = {};
  this._messageCache = {};
};

WaitTimeBuilder.prototype.register = function (session, msgId) {
  var self = this;

  var mainKey = self._getMessageKey(session.id, msgId);

  var inQueue = session.inQueue || [];

  if (typeof inQueue.toArray === 'function') {
    // latest version of Meteor uses a double-ended-queue for the inQueue
    // info: https://www.npmjs.com/package/double-ended-queue
    inQueue = inQueue.toArray();
  }

  var waitList = inQueue.map(function (msg) {
    var key = self._getMessageKey(session.id, msg.id);

    return self._getCacheMessage(key, msg);
  });
  waitList = waitList || []; //add currently processing ddp message if exists

  var currentlyProcessingMessage = this._currentProcessingMessages[session.id];

  if (currentlyProcessingMessage) {
    var key = self._getMessageKey(session.id, currentlyProcessingMessage.id);

    waitList.unshift(this._getCacheMessage(key, currentlyProcessingMessage));
  }

  this._waitListStore[mainKey] = waitList;
};

WaitTimeBuilder.prototype.build = function (session, msgId) {
  var mainKey = this._getMessageKey(session.id, msgId);

  var waitList = this._waitListStore[mainKey] || [];
  delete this._waitListStore[mainKey];
  var filteredWaitList = waitList.map(this._cleanCacheMessage.bind(this));
  return filteredWaitList;
};

WaitTimeBuilder.prototype._getMessageKey = function (sessionId, msgId) {
  return sessionId + "::" + msgId;
};

WaitTimeBuilder.prototype._getCacheMessage = function (key, msg) {
  var self = this;
  var cachedMessage = self._messageCache[key];

  if (!cachedMessage) {
    self._messageCache[key] = cachedMessage = _.pick(msg, WAITON_MESSAGE_FIELDS);
    cachedMessage._key = key;
    cachedMessage._registered = 1;
  } else {
    cachedMessage._registered++;
  }

  return cachedMessage;
};

WaitTimeBuilder.prototype._cleanCacheMessage = function (msg) {
  msg._registered--;

  if (msg._registered == 0) {
    delete this._messageCache[msg._key];
  } // need to send a clean set of objects
  // otherwise register can go with this


  return _.pick(msg, WAITON_MESSAGE_FIELDS);
};

WaitTimeBuilder.prototype.trackWaitTime = function (session, msg, unblock) {
  var self = this;
  var started = Date.now();
  self._currentProcessingMessages[session.id] = msg;
  var unblocked = false;

  var wrappedUnblock = function () {
    if (!unblocked) {
      var waitTime = Date.now() - started;

      var key = self._getMessageKey(session.id, msg.id);

      var cachedMessage = self._messageCache[key];

      if (cachedMessage) {
        cachedMessage.waitTime = waitTime;
      }

      delete self._currentProcessingMessages[session.id];
      unblocked = true;
      unblock();
    }
  };

  return wrappedUnblock;
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"check_for_oplog.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/check_for_oplog.js                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// expose for testing purpose
OplogCheck = {};

OplogCheck._070 = function (cursorDescription) {
  var options = cursorDescription.options;

  if (options.limit) {
    return {
      code: "070_LIMIT_NOT_SUPPORTED",
      reason: "Meteor 0.7.0 does not support limit with oplog.",
      solution: "Upgrade your app to Meteor version 0.7.2 or later."
    };
  }

  ;

  var exists$ = _.any(cursorDescription.selector, function (value, field) {
    if (field.substr(0, 1) === '$') return true;
  });

  if (exists$) {
    return {
      code: "070_$_NOT_SUPPORTED",
      reason: "Meteor 0.7.0 supports only equal checks with oplog.",
      solution: "Upgrade your app to Meteor version 0.7.2 or later."
    };
  }

  ;

  var onlyScalers = _.all(cursorDescription.selector, function (value, field) {
    return typeof value === "string" || typeof value === "number" || typeof value === "boolean" || value === null || value instanceof Meteor.Collection.ObjectID;
  });

  if (!onlyScalers) {
    return {
      code: "070_ONLY_SCALERS",
      reason: "Meteor 0.7.0 only supports scalers as comparators.",
      solution: "Upgrade your app to Meteor version 0.7.2 or later."
    };
  }

  return true;
};

OplogCheck._071 = function (cursorDescription) {
  var options = cursorDescription.options;
  var matcher = new Minimongo.Matcher(cursorDescription.selector);

  if (options.limit) {
    return {
      code: "071_LIMIT_NOT_SUPPORTED",
      reason: "Meteor 0.7.1 does not support limit with oplog.",
      solution: "Upgrade your app to Meteor version 0.7.2 or later."
    };
  }

  ;
  return true;
};

OplogCheck.env = function () {
  if (!process.env.MONGO_OPLOG_URL) {
    return {
      code: "NO_ENV",
      reason: "You haven't added oplog support for your the Meteor app.",
      solution: "Add oplog support for your Meteor app. see: http://goo.gl/Co1jJc"
    };
  } else {
    return true;
  }
};

OplogCheck.disableOplog = function (cursorDescription) {
  if (cursorDescription.options._disableOplog) {
    return {
      code: "DISABLE_OPLOG",
      reason: "You've disable oplog for this cursor explicitly with _disableOplog option."
    };
  } else {
    return true;
  }
}; // when creating Minimongo.Matcher object, if that's throws an exception
// meteor won't do the oplog support


OplogCheck.miniMongoMatcher = function (cursorDescription) {
  if (Minimongo.Matcher) {
    try {
      var matcher = new Minimongo.Matcher(cursorDescription.selector);
      return true;
    } catch (ex) {
      return {
        code: "MINIMONGO_MATCHER_ERROR",
        reason: "There's something wrong in your mongo query: " + ex.message,
        solution: "Check your selector and change it accordingly."
      };
    }
  } else {
    // If there is no Minimongo.Matcher, we don't need to check this
    return true;
  }
};

OplogCheck.miniMongoSorter = function (cursorDescription) {
  var matcher = new Minimongo.Matcher(cursorDescription.selector);

  if (Minimongo.Sorter && cursorDescription.options.sort) {
    try {
      var sorter = new Minimongo.Sorter(cursorDescription.options.sort, {
        matcher: matcher
      });
      return true;
    } catch (ex) {
      return {
        code: "MINIMONGO_SORTER_ERROR",
        reason: "Some of your sort specifiers are not supported: " + ex.message,
        solution: "Check your sort specifiers and chage them accordingly."
      };
    }
  } else {
    return true;
  }
};

OplogCheck.fields = function (cursorDescription) {
  var options = cursorDescription.options;

  if (options.fields) {
    try {
      LocalCollection._checkSupportedProjection(options.fields);

      return true;
    } catch (e) {
      if (e.name === "MinimongoError") {
        return {
          code: "NOT_SUPPORTED_FIELDS",
          reason: "Some of the field filters are not supported: " + e.message,
          solution: "Try removing those field filters."
        };
      } else {
        throw e;
      }
    }
  }

  return true;
};

OplogCheck.skip = function (cursorDescription) {
  if (cursorDescription.options.skip) {
    return {
      code: "SKIP_NOT_SUPPORTED",
      reason: "Skip does not support with oplog.",
      solution: "Try to avoid using skip. Use range queries instead: http://goo.gl/b522Av"
    };
  }

  return true;
};

OplogCheck.where = function (cursorDescription) {
  var matcher = new Minimongo.Matcher(cursorDescription.selector);

  if (matcher.hasWhere()) {
    return {
      code: "WHERE_NOT_SUPPORTED",
      reason: "Meteor does not support queries with $where.",
      solution: "Try to remove $where from your query. Use some alternative."
    };
  }

  ;
  return true;
};

OplogCheck.geo = function (cursorDescription) {
  var matcher = new Minimongo.Matcher(cursorDescription.selector);

  if (matcher.hasGeoQuery()) {
    return {
      code: "GEO_NOT_SUPPORTED",
      reason: "Meteor does not support queries with geo partial operators.",
      solution: "Try to remove geo partial operators from your query if possible."
    };
  }

  ;
  return true;
};

OplogCheck.limitButNoSort = function (cursorDescription) {
  var options = cursorDescription.options;

  if (options.limit && !options.sort) {
    return {
      code: "LIMIT_NO_SORT",
      reason: "Meteor oplog implementation does not support limit without a sort specifier.",
      solution: "Try adding a sort specifier."
    };
  }

  ;
  return true;
};

OplogCheck.olderVersion = function (cursorDescription, driver) {
  if (driver && !driver.constructor.cursorSupported) {
    return {
      code: "OLDER_VERSION",
      reason: "Your Meteor version does not have oplog support.",
      solution: "Upgrade your app to Meteor version 0.7.2 or later."
    };
  }

  return true;
};

OplogCheck.gitCheckout = function (cursorDescription, driver) {
  if (!Meteor.release) {
    return {
      code: "GIT_CHECKOUT",
      reason: "Seems like your Meteor version is based on a Git checkout and it doesn't have the oplog support.",
      solution: "Try to upgrade your Meteor version."
    };
  }

  return true;
};

var preRunningMatchers = [OplogCheck.env, OplogCheck.disableOplog, OplogCheck.miniMongoMatcher];
var globalMatchers = [OplogCheck.fields, OplogCheck.skip, OplogCheck.where, OplogCheck.geo, OplogCheck.limitButNoSort, OplogCheck.miniMongoSorter, OplogCheck.olderVersion, OplogCheck.gitCheckout];
var versionMatchers = [[/^0\.7\.1/, OplogCheck._071], [/^0\.7\.0/, OplogCheck._070]];

Kadira.checkWhyNoOplog = function (cursorDescription, observerDriver) {
  if (typeof Minimongo == 'undefined') {
    return {
      code: "CANNOT_DETECT",
      reason: "You are running an older Meteor version and Kadira can't check oplog state.",
      solution: "Try updating your Meteor app"
    };
  }

  var result = runMatchers(preRunningMatchers, cursorDescription, observerDriver);

  if (result !== true) {
    return result;
  }

  var meteorVersion = Meteor.release;

  for (var lc = 0; lc < versionMatchers.length; lc++) {
    var matcherInfo = versionMatchers[lc];

    if (matcherInfo[0].test(meteorVersion)) {
      var matched = matcherInfo[1](cursorDescription, observerDriver);

      if (matched !== true) {
        return matched;
      }
    }
  }

  result = runMatchers(globalMatchers, cursorDescription, observerDriver);

  if (result !== true) {
    return result;
  }

  return {
    code: "OPLOG_SUPPORTED",
    reason: "This query should support oplog. It's weird if it's not.",
    solution: "Please contact Kadira support and let's discuss."
  };
};

function runMatchers(matcherList, cursorDescription, observerDriver) {
  for (var lc = 0; lc < matcherList.length; lc++) {
    var matcher = matcherList[lc];
    var matched = matcher(cursorDescription, observerDriver);

    if (matched !== true) {
      return matched;
    }
  }

  return true;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"tracer":{"tracer.js":function module(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/tracer/tracer.js                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var eventLogger = Npm.require('debug')('kadira:tracer');

var REPETITIVE_EVENTS = {
  'db': true,
  'http': true,
  'email': true,
  'wait': true,
  'async': true,
  'custom': true,
  'fs': true
};
var TRACE_TYPES = ['sub', 'method', 'http'];
var MAX_TRACE_EVENTS = 1500;

Tracer = function Tracer() {
  this._filters = [];
  this._filterFields = ['password'];
  this.maxArrayItemsToFilter = 20;
}; //In the future, we might wan't to track inner fiber events too.
//Then we can't serialize the object with methods
//That's why we use this method of returning the data


Tracer.prototype.start = function (name, type) {
  let {
    sessionId,
    msgId,
    userId
  } = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

  // for backward compatibility
  if (typeof name === 'object' && typeof type === 'object') {
    let session = name;
    let msg = type;
    sessionId = session.id;
    msgId = msg.id;
    userId = session.userId;

    if (msg.msg == 'method') {
      type = 'method';
      name = msg.method;
    } else if (msg.msg == 'sub') {
      type = 'sub';
      name = msg.name;
    } else {
      return null;
    }
  }

  if (TRACE_TYPES.indexOf(type) === -1) {
    console.warn("Monti APM: unknown trace type \"".concat(type, "\""));
    return null;
  }

  var traceInfo = {
    _id: "".concat(sessionId, "::").concat(msgId || DefaultUniqueId.get()),
    type,
    name,
    session: sessionId,
    id: msgId,
    events: [],
    userId
  };
  return traceInfo;
};

Tracer.prototype.event = function (traceInfo, type, data, metaData) {
  // do not allow to proceed, if already completed or errored
  var lastEvent = this.getLastEvent(traceInfo);

  if ( // trace completed but has not been processed
  lastEvent && ['complete', 'error'].indexOf(lastEvent.type) >= 0 || // trace completed and processed.
  traceInfo.isEventsProcessed) {
    return false;
  }

  var event = {
    type,
    at: Ntp._now(),
    endAt: null,
    nested: []
  }; // special handling for events that are not repetitive

  if (!REPETITIVE_EVENTS[type]) {
    event.endAt = event.at;
  }

  if (data) {
    var info = _.pick(traceInfo, 'type', 'name');

    event.data = this._applyFilters(type, data, info, "start");
  }

  if (metaData && metaData.name) {
    event.name = metaData.name;
  }

  if (Kadira.options.eventStackTrace) {
    event.stack = CreateUserStack();
  }

  eventLogger("%s %s", type, traceInfo._id);

  if (lastEvent && !lastEvent.endAt) {
    if (!lastEvent.nested) {
      console.error('Monti: invalid trace. Please share the trace below at');
      console.error('Monti: https://github.com/monti-apm/monti-apm-agent/issues/14');
      console.dir(traceInfo, {
        depth: 10
      });
    }

    var lastNested = lastEvent.nested[lastEvent.nested.length - 1]; // Only nest one level

    if (!lastNested || lastNested.endAt) {
      lastEvent.nested.push(event);
      return event;
    }

    return false;
  }

  traceInfo.events.push(event);
  return event;
};

Tracer.prototype.eventEnd = function (traceInfo, event, data) {
  if (event.endAt) {
    // Event already ended or is not a repititive event
    return false;
  }

  event.endAt = Ntp._now();

  if (data) {
    var info = _.pick(traceInfo, 'type', 'name');

    event.data = Object.assign(event.data || {}, this._applyFilters("".concat(event.type, "end"), data, info, 'end'));
  }

  eventLogger("%s %s", event.type + 'end', traceInfo._id);
  return true;
};

Tracer.prototype.getLastEvent = function (traceInfo) {
  return traceInfo.events[traceInfo.events.length - 1];
};

Tracer.prototype.endLastEvent = function (traceInfo) {
  var lastEvent = this.getLastEvent(traceInfo);

  if (!lastEvent.endAt) {
    this.eventEnd(traceInfo, lastEvent);
    lastEvent.forcedEnd = true;
    return true;
  }

  return false;
}; // Most of the time, all of the nested events are async
// which is not helpful. This returns true if
// there are nested events other than async.


Tracer.prototype._hasUsefulNested = function (event) {
  return !event.nested.every(event => {
    return event.type === 'async';
  });
};

Tracer.prototype.buildEvent = function (event) {
  let depth = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
  let trace = arguments.length > 2 ? arguments[2] : undefined;
  var elapsedTimeForEvent = event.endAt - event.at;
  var builtEvent = [event.type];
  var nested = [];
  builtEvent.push(elapsedTimeForEvent);
  builtEvent.push(event.data || {});

  if (event.nested.length && this._hasUsefulNested(event)) {
    let prevEnd = event.at;

    for (let i = 0; i < event.nested.length; i++) {
      var nestedEvent = event.nested[i];

      if (!nestedEvent.endAt) {
        this.eventEnd(trace, nestedEvent);
        nestedEvent.forcedEnd = true;
      }

      var computeTime = nestedEvent.at - prevEnd;

      if (computeTime > 0) {
        nested.push(['compute', computeTime]);
      }

      nested.push(this.buildEvent(nestedEvent, depth + 1, trace));
      prevEnd = nestedEvent.endAt;
    }
  }

  if (nested.length || event.stack || event.forcedEnd || event.name) {
    builtEvent.push({
      stack: event.stack,
      nested: nested.length ? nested : undefined,
      forcedEnd: event.forcedEnd,
      name: event.name
    });
  }

  return builtEvent;
};

Tracer.prototype.buildTrace = function (traceInfo) {
  var firstEvent = traceInfo.events[0];
  var lastEvent = traceInfo.events[traceInfo.events.length - 1];
  var processedEvents = [];

  if (firstEvent.type !== 'start') {
    console.warn('Monti APM: trace has not started yet');
    return null;
  } else if (lastEvent.type !== 'complete' && lastEvent.type !== 'error') {
    //trace is not completed or errored yet
    console.warn('Monti APM: trace has not completed or errored yet');
    return null;
  } else {
    //build the metrics
    traceInfo.errored = lastEvent.type === 'error';
    traceInfo.at = firstEvent.at;
    var metrics = {
      total: lastEvent.at - firstEvent.at
    };
    var totalNonCompute = 0;
    firstEvent = ['start', 0];

    if (traceInfo.events[0].data) {
      firstEvent.push(traceInfo.events[0].data);
    }

    processedEvents.push(firstEvent);

    for (var lc = 1; lc < traceInfo.events.length - 1; lc += 1) {
      var prevEvent = traceInfo.events[lc - 1];
      var event = traceInfo.events[lc];

      if (!event.endAt) {
        console.error('Monti APM: no end event for type: ', event.type);
        return null;
      }

      var computeTime = event.at - prevEvent.endAt;

      if (computeTime > 0) {
        processedEvents.push(['compute', computeTime]);
      }

      var builtEvent = this.buildEvent(event, 0, traceInfo);
      processedEvents.push(builtEvent);
      metrics[event.type] = metrics[event.type] || 0;
      metrics[event.type] += builtEvent[1];
      totalNonCompute += builtEvent[1];
    }
  }

  computeTime = lastEvent.at - traceInfo.events[traceInfo.events.length - 2].endAt;
  if (computeTime > 0) processedEvents.push(['compute', computeTime]);
  var lastEventData = [lastEvent.type, 0];
  if (lastEvent.data) lastEventData.push(lastEvent.data);
  processedEvents.push(lastEventData);

  if (processedEvents.length > MAX_TRACE_EVENTS) {
    const removeCount = processedEvents.length - MAX_TRACE_EVENTS;
    processedEvents.splice(MAX_TRACE_EVENTS, removeCount);
  }

  metrics.compute = metrics.total - totalNonCompute;
  traceInfo.metrics = metrics;
  traceInfo.events = processedEvents;
  traceInfo.isEventsProcessed = true;
  return traceInfo;
};

Tracer.prototype.addFilter = function (filterFn) {
  this._filters.push(filterFn);
};

Tracer.prototype.redactField = function (field) {
  this._filterFields.push(field);
};

Tracer.prototype._applyFilters = function (eventType, data, info) {
  this._filters.forEach(function (filterFn) {
    data = filterFn(eventType, _.clone(data), info);
  });

  return data;
};

Tracer.prototype._applyObjectFilters = function (toFilter) {
  const filterObject = obj => {
    let cloned;

    this._filterFields.forEach(function (field) {
      if (field in obj) {
        cloned = cloned || Object.assign({}, obj);
        cloned[field] = 'Monti: redacted';
      }
    });

    return cloned;
  };

  if (Array.isArray(toFilter)) {
    let cloned; // There could be thousands or more items in the array, and this usually runs
    // before the data is validated. For performance reasons we limit how
    // many to check

    let length = Math.min(toFilter.length, this.maxArrayItemsToFilter);

    for (let i = 0; i < length; i++) {
      if (typeof toFilter[i] === 'object' && toFilter[i] !== null) {
        let result = filterObject(toFilter[i]);

        if (result) {
          cloned = cloned || [...toFilter];
          cloned[i] = result;
        }
      }
    }

    return cloned || toFilter;
  }

  return filterObject(toFilter) || toFilter;
};

Kadira.tracer = new Tracer(); // need to expose Tracer to provide default set of filters

Kadira.Tracer = Tracer;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"default_filters.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/tracer/default_filters.js                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// strip sensitive data sent to Monti APM engine.
// possible to limit types by providing an array of types to strip
// possible types are: "start", "db", "http", "email"
Tracer.stripSensitive = function stripSensitive(typesToStrip, receiverType, name) {
  typesToStrip = typesToStrip || [];
  var strippedTypes = {};
  typesToStrip.forEach(function (type) {
    strippedTypes[type] = true;
  });
  return function (type, data, info) {
    if (typesToStrip.length > 0 && !strippedTypes[type]) return data;
    if (receiverType && receiverType != info.type) return data;
    if (name && name != info.name) return data;

    if (type == "start") {
      if (data.params) {
        data.params = "[stripped]";
      }

      if (data.headers) {
        data.headers = "[stripped]";
      }

      if (data.body) {
        data.body = "[stripped]";
      }
    } else if (type == "db") {
      data.selector = "[stripped]";
    } else if (type == "http") {
      data.url = "[stripped]";
    } else if (type == "email") {
      ["from", "to", "cc", "bcc", "replyTo"].forEach(function (item) {
        if (data[item]) {
          data[item] = "[stripped]";
        }
      });
    }

    return data;
  };
}; // Strip sensitive data sent to Monti APM engine.
// In contrast to stripSensitive, this one has an allow list of what to keep
// to guard against forgetting to strip new fields
// In the future this one might replace Tracer.stripSensitive
// options


Tracer.stripSensitiveThorough = function stripSensitive() {
  return function (type, data) {
    let fieldsToKeep = [];

    if (type == "start") {
      fieldsToKeep = ['userId'];
    } else if (type === 'waitend') {
      fieldsToKeep = ['waitOn'];
    } else if (type == "db") {
      fieldsToKeep = ['coll', 'func', 'cursor', 'limit', 'docsFetched', 'docSize', 'oplog', 'fields', 'wasMultiplexerReady', 'queueLength', 'elapsedPollingTime', 'noOfCachedDocs'];
    } else if (type == "http") {
      fieldsToKeep = ['method', 'statusCode'];
    } else if (type == "email") {
      fieldsToKeep = [];
    } else if (type === 'custom') {
      // This is supplied by the user so we assume they are only giving data that can be sent
      fieldsToKeep = Object.keys(data);
    } else if (type === 'error') {
      fieldsToKeep = ['error'];
    }

    Object.keys(data).forEach(key => {
      if (fieldsToKeep.indexOf(key) === -1) {
        data[key] = '[stripped]';
      }
    });
    return data;
  };
}; // strip selectors only from the given list of collection names


Tracer.stripSelectors = function stripSelectors(collectionList, receiverType, name) {
  collectionList = collectionList || [];
  var collMap = {};
  collectionList.forEach(function (collName) {
    collMap[collName] = true;
  });
  return function (type, data, info) {
    if (type != "db" || data && !collMap[data.coll]) {
      return data;
    }

    if (receiverType && receiverType != info.type) return data;
    if (name && name != info.name) return data;
    data.selector = "[stripped]";
    return data;
  };
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"tracer_store.js":function module(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/tracer/tracer_store.js                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var logger = Npm.require('debug')('kadira:ts');

TracerStore = function TracerStore(options) {
  options = options || {};
  this.maxTotalPoints = options.maxTotalPoints || 30;
  this.interval = options.interval || 1000 * 60;
  this.archiveEvery = options.archiveEvery || this.maxTotalPoints / 6; //store max total on the past 30 minutes (or past 30 items)

  this.maxTotals = Object.create(null); //store the max trace of the current interval

  this.currentMaxTrace = Object.create(null); //archive for the traces

  this.traceArchive = [];
  this.processedCnt = Object.create(null); //group errors by messages between an interval

  this.errorMap = Object.create(null);
};

TracerStore.prototype.addTrace = function (trace) {
  var kind = [trace.type, trace.name].join('::');

  if (!this.currentMaxTrace[kind]) {
    this.currentMaxTrace[kind] = EJSON.clone(trace);
  } else if (this.currentMaxTrace[kind].metrics.total < trace.metrics.total) {
    this.currentMaxTrace[kind] = EJSON.clone(trace);
  } else if (trace.errored) {
    this._handleErrors(trace);
  }
};

TracerStore.prototype.collectTraces = function () {
  var traces = this.traceArchive;
  this.traceArchive = []; // convert at(timestamp) into the actual serverTime

  traces.forEach(function (trace) {
    trace.at = Kadira.syncedDate.syncTime(trace.at);
  });
  return traces;
};

TracerStore.prototype.start = function () {
  this._timeoutHandler = setInterval(this.processTraces.bind(this), this.interval);
};

TracerStore.prototype.stop = function () {
  if (this._timeoutHandler) {
    clearInterval(this._timeoutHandler);
  }
};

TracerStore.prototype._handleErrors = function (trace) {
  // sending error requests as it is
  var lastEvent = trace.events[trace.events.length - 1];

  if (lastEvent && lastEvent[2]) {
    var error = lastEvent[2].error; // grouping errors occured (reset after processTraces)

    var errorKey = [trace.type, trace.name, error.message].join("::");

    if (!this.errorMap[errorKey]) {
      var erroredTrace = EJSON.clone(trace);
      this.errorMap[errorKey] = erroredTrace;
      this.traceArchive.push(erroredTrace);
    }
  } else {
    logger('last events is not an error: ', JSON.stringify(trace.events));
  }
};

TracerStore.prototype.processTraces = function () {
  var self = this;
  let kinds = new Set();
  Object.keys(this.maxTotals).forEach(key => {
    kinds.add(key);
  });
  Object.keys(this.currentMaxTrace).forEach(key => {
    kinds.add(key);
  });

  for (kind of kinds) {
    self.processedCnt[kind] = self.processedCnt[kind] || 0;
    var currentMaxTrace = self.currentMaxTrace[kind];
    var currentMaxTotal = currentMaxTrace ? currentMaxTrace.metrics.total : 0;
    self.maxTotals[kind] = self.maxTotals[kind] || []; //add the current maxPoint

    self.maxTotals[kind].push(currentMaxTotal);
    var exceedingPoints = self.maxTotals[kind].length - self.maxTotalPoints;

    if (exceedingPoints > 0) {
      self.maxTotals[kind].splice(0, exceedingPoints);
    }

    var archiveDefault = self.processedCnt[kind] % self.archiveEvery == 0;
    self.processedCnt[kind]++;

    var canArchive = archiveDefault || self._isTraceOutlier(kind, currentMaxTrace);

    if (canArchive && currentMaxTrace) {
      self.traceArchive.push(currentMaxTrace);
    } //reset currentMaxTrace


    self.currentMaxTrace[kind] = null;
  }

  ; //reset the errorMap

  self.errorMap = Object.create(null);
};

TracerStore.prototype._isTraceOutlier = function (kind, trace) {
  if (trace) {
    var dataSet = this.maxTotals[kind];
    return this._isOutlier(dataSet, trace.metrics.total, 3);
  } else {
    return false;
  }
};
/*
  Data point must exists in the dataSet
*/


TracerStore.prototype._isOutlier = function (dataSet, dataPoint, maxMadZ) {
  var median = this._getMedian(dataSet);

  var mad = this._calculateMad(dataSet, median);

  var madZ = this._funcMedianDeviation(median)(dataPoint) / mad;
  return madZ > maxMadZ;
};

TracerStore.prototype._getMedian = function (dataSet) {
  var sortedDataSet = _.clone(dataSet).sort(function (a, b) {
    return a - b;
  });

  return this._pickQuartile(sortedDataSet, 2);
};

TracerStore.prototype._pickQuartile = function (dataSet, num) {
  var pos = (dataSet.length + 1) * num / 4;

  if (pos % 1 == 0) {
    return dataSet[pos - 1];
  } else {
    pos = pos - pos % 1;
    return (dataSet[pos - 1] + dataSet[pos]) / 2;
  }
};

TracerStore.prototype._calculateMad = function (dataSet, median) {
  var medianDeviations = _.map(dataSet, this._funcMedianDeviation(median));

  var mad = this._getMedian(medianDeviations);

  return mad;
};

TracerStore.prototype._funcMedianDeviation = function (median) {
  return function (x) {
    return Math.abs(median - x);
  };
};

TracerStore.prototype._getMean = function (dataPoints) {
  if (dataPoints.length > 0) {
    var total = 0;
    dataPoints.forEach(function (point) {
      total += point;
    });
    return total / dataPoints.length;
  } else {
    return 0;
  }
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"docsize_cache.js":function module(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/docsize_cache.js                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var LRU = Npm.require('lru-cache');

var crypto = Npm.require('crypto');

var jsonStringify = Npm.require('json-stringify-safe');

DocSzCache = function (maxItems, maxValues) {
  this.items = new LRU({
    max: maxItems
  });
  this.maxValues = maxValues;
  this.cpuUsage = 0;
}; // This is called from SystemModel.prototype.cpuUsage and saves cpu usage.


DocSzCache.prototype.setPcpu = function (pcpu) {
  this.cpuUsage = pcpu;
};

DocSzCache.prototype.getSize = function (coll, query, opts, data) {
  // If the dataset is null or empty we can't calculate the size
  // Do not process this data and return 0 as the document size.
  if (!(data && (data.length || typeof data.size === 'function' && data.size()))) {
    return 0;
  }

  var key = this.getKey(coll, query, opts);
  var item = this.items.get(key);

  if (!item) {
    item = new DocSzCacheItem(this.maxValues);
    this.items.set(key, item);
  }

  if (this.needsUpdate(item)) {
    var doc = {};

    if (typeof data.get === 'function') {
      // This is an IdMap
      data.forEach(function (element) {
        doc = element;
        return false; // return false to stop loop. We only need one doc.
      });
    } else {
      doc = data[0];
    }

    var size = Buffer.byteLength(jsonStringify(doc), 'utf8');
    item.addData(size);
  }

  return item.getValue();
};

DocSzCache.prototype.getKey = function (coll, query, opts) {
  return jsonStringify([coll, query, opts]);
}; // returns a score between 0 and 1 for a cache item
// this score is determined by:
//  * available cache item slots
//  * time since last updated
//  * cpu usage of the application


DocSzCache.prototype.getItemScore = function (item) {
  return [(item.maxValues - item.values.length) / item.maxValues, (Date.now() - item.updated) / 60000, (100 - this.cpuUsage) / 100].map(function (score) {
    return score > 1 ? 1 : score;
  }).reduce(function (total, score) {
    return (total || 0) + score;
  }) / 3;
};

DocSzCache.prototype.needsUpdate = function (item) {
  // handle newly made items
  if (!item.values.length) {
    return true;
  }

  var currentTime = Date.now();
  var timeSinceUpdate = currentTime - item.updated;

  if (timeSinceUpdate > 1000 * 60) {
    return true;
  }

  return this.getItemScore(item) > 0.5;
};

DocSzCacheItem = function (maxValues) {
  this.maxValues = maxValues;
  this.updated = 0;
  this.values = [];
};

DocSzCacheItem.prototype.addData = function (value) {
  this.values.push(value);
  this.updated = Date.now();

  if (this.values.length > this.maxValues) {
    this.values.shift();
  }
};

DocSzCacheItem.prototype.getValue = function () {
  function sortNumber(a, b) {
    return a - b;
  }

  var sorted = this.values.sort(sortNumber);
  var median = 0;

  if (sorted.length % 2 === 0) {
    var idx = sorted.length / 2;
    median = (sorted[idx] + sorted[idx - 1]) / 2;
  } else {
    var idx = Math.floor(sorted.length / 2);
    median = sorted[idx];
  }

  return median;
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"kadira.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/kadira.js                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let HttpModel;
module.link("./models/http", {
  default(v) {
    HttpModel = v;
  }

}, 0);
let packageMap;
module.link("./.meteor-package-versions", {
  default(v) {
    packageMap = v;
  }

}, 1);

var hostname = Npm.require('os').hostname();

var logger = Npm.require('debug')('kadira:apm');

var Fibers = Npm.require('fibers');

var KadiraCore = Npm.require('monti-apm-core').Kadira;

Kadira.models = {};
Kadira.options = {};
Kadira.env = {
  currentSub: null,
  // keep current subscription inside ddp
  kadiraInfo: new Meteor.EnvironmentVariable()
};
Kadira.waitTimeBuilder = new WaitTimeBuilder();
Kadira.errors = [];
Kadira.errors.addFilter = Kadira.errors.push.bind(Kadira.errors);
Kadira.models.methods = new MethodsModel();
Kadira.models.pubsub = new PubsubModel();
Kadira.models.system = new SystemModel();
Kadira.models.http = new HttpModel();
Kadira.docSzCache = new DocSzCache(100000, 10);
Kadira.syncedDate = new Ntp(); // If the agent is not connected, we still want to build the payload occasionally
// since building the payload does some cleanup to prevent memory leaks
// Once connected, this interval is cleared

let buildInterval = Meteor.setInterval(() => {
  Kadira._buildPayload();
}, 1000 * 60);

Kadira.connect = function (appId, appSecret, options) {
  options = options || {};
  options.appId = appId;
  options.appSecret = appSecret;
  options.payloadTimeout = options.payloadTimeout || 1000 * 20;
  options.endpoint = options.endpoint || "https://engine.montiapm.com";
  options.clientEngineSyncDelay = options.clientEngineSyncDelay || 10000;
  options.thresholds = options.thresholds || {};
  options.isHostNameSet = !!options.hostname;
  options.hostname = options.hostname || hostname;
  options.proxy = options.proxy || null;
  options.recordIPAddress = options.recordIPAddress || 'full';
  options.eventStackTrace = options.eventStackTrace || false;

  if (options.documentSizeCacheSize) {
    Kadira.docSzCache = new DocSzCache(options.documentSizeCacheSize, 10);
  } // remove trailing slash from endpoint url (if any)


  if (_.last(options.endpoint) === '/') {
    options.endpoint = options.endpoint.substr(0, options.endpoint.length - 1);
  } // error tracking is enabled by default


  if (options.enableErrorTracking === undefined) {
    options.enableErrorTracking = true;
  } // uploading sourcemaps is enabled by default in production


  if (options.uploadSourceMaps === undefined && Meteor.isProduction) {
    options.uploadSourceMaps = true;
  }

  Kadira.options = options;
  Kadira.options.authHeaders = {
    'KADIRA-APP-ID': Kadira.options.appId,
    'KADIRA-APP-SECRET': Kadira.options.appSecret
  };

  if (appId && appSecret) {
    options.appId = options.appId.trim();
    options.appSecret = options.appSecret.trim();
    Kadira.coreApi = new KadiraCore({
      appId: options.appId,
      appSecret: options.appSecret,
      endpoint: options.endpoint,
      hostname: options.hostname,
      agentVersion: packageMap['montiapm:agent'] || '<unknown>'
    });

    Kadira.coreApi._checkAuth().then(function () {
      logger('connected to app: ', appId);
      console.log('Monti APM: Successfully connected');

      Kadira._sendAppStats();

      Kadira._schedulePayloadSend();
    }).catch(function (err) {
      if (err.message === "Unauthorized") {
        console.log('Monti APM: authentication failed - check your appId & appSecret');
      } else {
        console.log('Monti APM: unable to connect. ' + err.message);
      }
    });
  } else {
    throw new Error('Monti APM: required appId and appSecret');
  }

  Kadira.syncedDate = new Ntp(options.endpoint);
  Kadira.syncedDate.sync();
  Kadira.models.error = new ErrorModel(appId); // handle pre-added filters

  var addFilterFn = Kadira.models.error.addFilter.bind(Kadira.models.error);
  Kadira.errors.forEach(addFilterFn);
  Kadira.errors = Kadira.models.error; // setting runtime info, which will be sent to kadira

  __meteor_runtime_config__.kadira = {
    appId: appId,
    endpoint: options.endpoint,
    clientEngineSyncDelay: options.clientEngineSyncDelay,
    recordIPAddress: options.recordIPAddress
  };

  if (options.enableErrorTracking) {
    Kadira.enableErrorTracking();
  } else {
    Kadira.disableErrorTracking();
  } // start tracking errors


  Meteor.startup(function () {
    TrackUncaughtExceptions();
    TrackUnhandledRejections();
    TrackMeteorDebug();
  });
  Meteor.publish(null, function () {
    var options = __meteor_runtime_config__.kadira;
    this.added('kadira_settings', Random.id(), options);
    this.ready();
  }); // notify we've connected

  Kadira.connected = true;
}; //track how many times we've sent the data (once per minute)


Kadira._buildPayload = function () {
  var payload = {
    host: Kadira.options.hostname,
    clientVersions: getClientVersions()
  };

  var buildDetailedInfo = Kadira._isDetailedInfo();

  _.extend(payload, Kadira.models.methods.buildPayload(buildDetailedInfo));

  _.extend(payload, Kadira.models.pubsub.buildPayload(buildDetailedInfo));

  _.extend(payload, Kadira.models.system.buildPayload());

  _.extend(payload, Kadira.models.http.buildPayload());

  if (Kadira.options.enableErrorTracking) {
    _.extend(payload, Kadira.models.error.buildPayload());
  }

  return payload;
};

Kadira._countDataSent = 0;
Kadira._detailInfoSentInterval = Math.ceil(1000 * 60 / Kadira.options.payloadTimeout);

Kadira._isDetailedInfo = function () {
  return Kadira._countDataSent++ % Kadira._detailInfoSentInterval == 0;
};

Kadira._sendAppStats = function () {
  var appStats = {};
  appStats.release = Meteor.release;
  appStats.protocolVersion = '1.0.0';
  appStats.packageVersions = [];
  appStats.clientVersions = getClientVersions();

  _.each(Package, function (v, name) {
    appStats.packageVersions.push({
      name: name,
      version: packageMap[name] || null
    });
  });

  Kadira.coreApi.sendData({
    startTime: new Date(),
    appStats: appStats
  }).then(function (body) {
    handleApiResponse(body);
  }).catch(function (err) {
    console.error('Monti APM Error on sending appStats:', err.message);
  });
};

Kadira._schedulePayloadSend = function () {
  clearInterval(buildInterval);
  setTimeout(function () {
    Kadira._schedulePayloadSend();

    Kadira._sendPayload();
  }, Kadira.options.payloadTimeout);
};

Kadira._sendPayload = function () {
  new Fibers(function () {
    var payload = Kadira._buildPayload();

    Kadira.coreApi.sendData(payload).then(function (body) {
      handleApiResponse(body);
    }).catch(function (err) {
      console.log('Monti APM Error:', err.message);
    });
  }).run();
}; // this return the __kadiraInfo from the current Fiber by default
// if called with 2nd argument as true, it will get the kadira info from
// Meteor.EnvironmentVariable
//
// WARNNING: returned info object is the reference object.
//  Changing it might cause issues when building traces. So use with care


Kadira._getInfo = function (currentFiber, useEnvironmentVariable) {
  currentFiber = currentFiber || Fibers.current;

  if (currentFiber) {
    if (useEnvironmentVariable) {
      return Kadira.env.kadiraInfo.get();
    }

    return currentFiber.__kadiraInfo;
  }
}; // this does not clone the info object. So, use with care


Kadira._setInfo = function (info) {
  Fibers.current.__kadiraInfo = info;
};

Kadira.startContinuousProfiling = function () {
  MontiProfiler.startContinuous(function onProfile(_ref) {
    let {
      profile,
      startTime,
      endTime
    } = _ref;

    if (!Kadira.connected) {
      return;
    }

    Kadira.coreApi.sendData({
      profiles: [{
        profile,
        startTime,
        endTime
      }]
    }).catch(e => console.log('Monti: err sending cpu profile', e));
  });
};

Kadira.enableErrorTracking = function () {
  __meteor_runtime_config__.kadira.enableErrorTracking = true;
  Kadira.options.enableErrorTracking = true;
};

Kadira.disableErrorTracking = function () {
  __meteor_runtime_config__.kadira.enableErrorTracking = false;
  Kadira.options.enableErrorTracking = false;
};

Kadira.trackError = function (type, message, options) {
  if (Kadira.options.enableErrorTracking && type && message) {
    options = options || {};
    options.subType = options.subType || 'server';
    options.stacks = options.stacks || '';
    var error = {
      message: message,
      stack: options.stacks
    };
    var trace = {
      type: type,
      subType: options.subType,
      name: message,
      errored: true,
      at: Kadira.syncedDate.getTime(),
      events: [['start', 0, {}], ['error', 0, {
        error: error
      }]],
      metrics: {
        total: 0
      }
    };
    Kadira.models.error.trackError(error, trace);
  }
};

Kadira.ignoreErrorTracking = function (err) {
  err._skipKadira = true;
};

Kadira.startEvent = function (name) {
  let data = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

  var kadiraInfo = Kadira._getInfo();

  if (kadiraInfo) {
    return Kadira.tracer.event(kadiraInfo.trace, 'custom', data, {
      name
    });
  }

  return false;
};

Kadira.endEvent = function (event, data) {
  var kadiraInfo = Kadira._getInfo(); // The event could be false if it could not be started.
  // Handle it here instead of requiring the app to.


  if (kadiraInfo && event) {
    Kadira.tracer.eventEnd(kadiraInfo.trace, event, data);
  }
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"hijack":{"wrap_server.js":function module(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/hijack/wrap_server.js                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Fiber = Npm.require('fibers');

wrapServer = function (serverProto) {
  var originalHandleConnect = serverProto._handleConnect;

  serverProto._handleConnect = function (socket, msg) {
    originalHandleConnect.call(this, socket, msg);
    var session = socket._meteorSession; // sometimes it is possible for _meteorSession to be undefined
    // one such reason would be if DDP versions are not matching
    // if then, we should not process it

    if (!session) {
      return;
    }

    Kadira.EventBus.emit('system', 'createSession', msg, socket._meteorSession);

    if (Kadira.connected) {
      Kadira.models.system.handleSessionActivity(msg, socket._meteorSession);
    }
  };
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wrap_session.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/hijack/wrap_session.js                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let MeteorDebugIgnore;
module.link("./error", {
  MeteorDebugIgnore(v) {
    MeteorDebugIgnore = v;
  }

}, 0);
const MAX_PARAMS_LENGTH = 4000;

wrapSession = function (sessionProto) {
  var originalProcessMessage = sessionProto.processMessage;

  sessionProto.processMessage = function (msg) {
    if (true) {
      var kadiraInfo = {
        session: this.id,
        userId: this.userId
      };

      if (msg.msg == 'method' || msg.msg == 'sub') {
        kadiraInfo.trace = Kadira.tracer.start(this, msg);
        Kadira.waitTimeBuilder.register(this, msg.id);

        let params = Kadira.tracer._applyObjectFilters(msg.params || []); // use JSON instead of EJSON to save the CPU


        let stringifiedParams = JSON.stringify(params); // The params could be several mb or larger.
        // Truncate if it is large

        if (stringifiedParams.length > MAX_PARAMS_LENGTH) {
          stringifiedParams = "Monti APM: params are too big. First ".concat(MAX_PARAMS_LENGTH, " characters: ").concat(stringifiedParams.slice(0, MAX_PARAMS_LENGTH));
        }

        var startData = {
          userId: this.userId,
          params: stringifiedParams
        };
        Kadira.tracer.event(kadiraInfo.trace, 'start', startData);
        var waitEventId = Kadira.tracer.event(kadiraInfo.trace, 'wait', {}, kadiraInfo);
        msg._waitEventId = waitEventId;
        msg.__kadiraInfo = kadiraInfo;

        if (msg.msg == 'sub') {
          // start tracking inside processMessage allows us to indicate
          // wait time as well
          Kadira.EventBus.emit('pubsub', 'subReceived', this, msg);

          Kadira.models.pubsub._trackSub(this, msg);
        }
      } // Update session last active time


      Kadira.EventBus.emit('system', 'ddpMessageReceived', this, msg);
      Kadira.models.system.handleSessionActivity(msg, this);
    }

    return originalProcessMessage.call(this, msg);
  }; // adding the method context to the current fiber


  var originalMethodHandler = sessionProto.protocol_handlers.method;

  sessionProto.protocol_handlers.method = function (msg, unblock) {
    var self = this; //add context

    var kadiraInfo = msg.__kadiraInfo;

    if (kadiraInfo) {
      Kadira._setInfo(kadiraInfo); // end wait event


      var waitList = Kadira.waitTimeBuilder.build(this, msg.id);
      Kadira.tracer.eventEnd(kadiraInfo.trace, msg._waitEventId, {
        waitOn: waitList
      });
      unblock = Kadira.waitTimeBuilder.trackWaitTime(this, msg, unblock);
      var response = Kadira.env.kadiraInfo.withValue(kadiraInfo, function () {
        return originalMethodHandler.call(self, msg, unblock);
      });
      unblock();
    } else {
      var response = originalMethodHandler.call(self, msg, unblock);
    }

    return response;
  }; //to capture the currently processing message


  var orginalSubHandler = sessionProto.protocol_handlers.sub;

  sessionProto.protocol_handlers.sub = function (msg, unblock) {
    var self = this; //add context

    var kadiraInfo = msg.__kadiraInfo;

    if (kadiraInfo) {
      Kadira._setInfo(kadiraInfo); // end wait event


      var waitList = Kadira.waitTimeBuilder.build(this, msg.id);
      Kadira.tracer.eventEnd(kadiraInfo.trace, msg._waitEventId, {
        waitOn: waitList
      });
      unblock = Kadira.waitTimeBuilder.trackWaitTime(this, msg, unblock);
      var response = Kadira.env.kadiraInfo.withValue(kadiraInfo, function () {
        return orginalSubHandler.call(self, msg, unblock);
      });
      unblock();
    } else {
      var response = orginalSubHandler.call(self, msg, unblock);
    }

    return response;
  }; //to capture the currently processing message


  var orginalUnSubHandler = sessionProto.protocol_handlers.unsub;

  sessionProto.protocol_handlers.unsub = function (msg, unblock) {
    unblock = Kadira.waitTimeBuilder.trackWaitTime(this, msg, unblock);
    var response = orginalUnSubHandler.call(this, msg, unblock);
    unblock();
    return response;
  }; //track method ending (to get the result of error)


  var originalSend = sessionProto.send;

  sessionProto.send = function (msg) {
    if (msg.msg == 'result') {
      var kadiraInfo = Kadira._getInfo();

      if (kadiraInfo) {
        if (msg.error) {
          var error = _.pick(msg.error, ['message', 'stack', 'details']); // pick the error from the wrapped method handler


          if (kadiraInfo && kadiraInfo.currentError) {
            // the error stack is wrapped so Meteor._debug can identify
            // this as a method error.
            error = _.pick(kadiraInfo.currentError, ['message', 'stack', 'details']); // see wrapMethodHanderForErrors() method def for more info

            if (error.stack && error.stack.stack) {
              error.stack = error.stack.stack;
            }
          }

          Kadira.tracer.endLastEvent(kadiraInfo.trace);
          Kadira.tracer.event(kadiraInfo.trace, 'error', {
            error: error
          });
        } else {
          Kadira.tracer.endLastEvent(kadiraInfo.trace);
          Kadira.tracer.event(kadiraInfo.trace, 'complete');
        } //processing the message


        var trace = Kadira.tracer.buildTrace(kadiraInfo.trace);
        Kadira.EventBus.emit('method', 'methodCompleted', trace, this);
        Kadira.models.methods.processMethod(trace); // error may or may not exist and error tracking can be disabled

        if (error && Kadira.options.enableErrorTracking) {
          Kadira.models.error.trackError(error, trace);
        } //clean and make sure, fiber is clean
        //not sure we need to do this, but a preventive measure


        Kadira._setInfo(null);
      }
    }

    return originalSend.call(this, msg);
  };
}; // wrap existing method handlers for capturing errors


_.each(Meteor.server.method_handlers, function (handler, name) {
  wrapMethodHanderForErrors(name, handler, Meteor.server.method_handlers);
}); // wrap future method handlers for capturing errors


var originalMeteorMethods = Meteor.methods;

Meteor.methods = function (methodMap) {
  _.each(methodMap, function (handler, name) {
    wrapMethodHanderForErrors(name, handler, methodMap);
  });

  originalMeteorMethods(methodMap);
};

function wrapMethodHanderForErrors(name, originalHandler, methodMap) {
  methodMap[name] = function () {
    try {
      return originalHandler.apply(this, arguments);
    } catch (ex) {
      if (ex && Kadira._getInfo()) {
        // sometimes error may be just an string or a primitive
        // in that case, we need to make it a psuedo error
        if (typeof ex !== 'object') {
          ex = {
            message: ex,
            stack: ex
          };
        } // Now we are marking this error to get tracked via methods
        // But, this also triggers a Meteor.debug call and
        // it only gets the stack
        // We also track Meteor.debug errors and want to stop
        // tracking this error. That's why we do this
        // See Meteor.debug error tracking code for more
        // If error tracking is disabled, we do not modify the stack since
        // it would be shown as an object in the logs


        if (Kadira.options.enableErrorTracking) {
          ex.stack = {
            stack: ex.stack,
            source: 'method',
            [MeteorDebugIgnore]: true
          };
          Kadira._getInfo().currentError = ex;
        }
      }

      throw ex;
    }
  };
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wrap_subscription.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/hijack/wrap_subscription.js                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let MeteorDebugIgnore;
module.link("./error", {
  MeteorDebugIgnore(v) {
    MeteorDebugIgnore = v;
  }

}, 0);

wrapSubscription = function (subscriptionProto) {
  // If the ready event runs outside the Fiber, Kadira._getInfo() doesn't work.
  // we need some other way to store kadiraInfo so we can use it at ready hijack.
  var originalRunHandler = subscriptionProto._runHandler;

  subscriptionProto._runHandler = function () {
    var kadiraInfo = Kadira._getInfo();

    if (kadiraInfo) {
      this.__kadiraInfo = kadiraInfo;
    }

    ;
    originalRunHandler.call(this);
  };

  var originalReady = subscriptionProto.ready;

  subscriptionProto.ready = function () {
    // meteor has a field called `_ready` which tracks this
    // but we need to make it future proof
    if (!this._apmReadyTracked) {
      var kadiraInfo = Kadira._getInfo() || this.__kadiraInfo;

      delete this.__kadiraInfo; //sometime .ready can be called in the context of the method
      //then we have some problems, that's why we are checking this
      //eg:- Accounts.createUser
      // Also, when the subscription is created by fast render, _subscriptionId and
      // the trace.id are both undefined but we don't want to complete the HTTP trace here

      if (kadiraInfo && this._subscriptionId && this._subscriptionId == kadiraInfo.trace.id) {
        Kadira.tracer.endLastEvent(kadiraInfo.trace);
        Kadira.tracer.event(kadiraInfo.trace, 'complete');
        var trace = Kadira.tracer.buildTrace(kadiraInfo.trace);
      }

      Kadira.EventBus.emit('pubsub', 'subCompleted', trace, this._session, this);

      Kadira.models.pubsub._trackReady(this._session, this, trace);

      this._apmReadyTracked = true;
    } // we still pass the control to the original implementation
    // since multiple ready calls are handled by itself


    originalReady.call(this);
  };

  var originalError = subscriptionProto.error;

  subscriptionProto.error = function (err) {
    if (typeof err === 'string') {
      err = {
        message: err
      };
    }

    var kadiraInfo = Kadira._getInfo();

    if (kadiraInfo && this._subscriptionId && this._subscriptionId == kadiraInfo.trace.id) {
      Kadira.tracer.endLastEvent(kadiraInfo.trace);

      var errorForApm = _.pick(err, 'message', 'stack');

      Kadira.tracer.event(kadiraInfo.trace, 'error', {
        error: errorForApm
      });
      var trace = Kadira.tracer.buildTrace(kadiraInfo.trace);

      Kadira.models.pubsub._trackError(this._session, this, trace); // error tracking can be disabled and if there is a trace
      // trace should be available all the time, but it won't
      // if something wrong happened on the trace building


      if (Kadira.options.enableErrorTracking && trace) {
        Kadira.models.error.trackError(err, trace);
      }
    } // wrap error stack so Meteor._debug can identify and ignore it
    // it is not wrapped when error tracking is disabled since it
    // would be shown as an object in the logs


    if (Kadira.options.enableErrorTracking) {
      err.stack = {
        stack: err.stack,
        source: 'subscription',
        [MeteorDebugIgnore]: true
      };
    }

    originalError.call(this, err);
  };

  var originalDeactivate = subscriptionProto._deactivate;

  subscriptionProto._deactivate = function () {
    Kadira.EventBus.emit('pubsub', 'subDeactivated', this._session, this);

    Kadira.models.pubsub._trackUnsub(this._session, this);

    originalDeactivate.call(this);
  }; //adding the currenSub env variable


  ['added', 'changed', 'removed'].forEach(function (funcName) {
    var originalFunc = subscriptionProto[funcName];

    subscriptionProto[funcName] = function (collectionName, id, fields) {
      var self = this; // we need to run this code in a fiber and that's how we track
      // subscription info. May be we can figure out, some other way to do this
      // We use this currently to get the publication info when tracking message
      // sizes at wrap_ddp_stringify.js

      Kadira.env.currentSub = self;
      var res = originalFunc.call(self, collectionName, id, fields);
      Kadira.env.currentSub = null;
      return res;
    };
  });
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wrap_observers.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/hijack/wrap_observers.js                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
wrapOplogObserveDriver = function (proto) {
  // Track the polled documents. This is reflect to the RAM size and
  // for the CPU usage directly
  var originalPublishNewResults = proto._publishNewResults;

  proto._publishNewResults = function (newResults, newBuffer) {
    var coll = this._cursorDescription.collectionName;
    var query = this._cursorDescription.selector;
    var opts = this._cursorDescription.options;
    var docSize = Kadira.docSzCache.getSize(coll, query, opts, newResults);
    var docSize = Kadira.docSzCache.getSize(coll, query, opts, newBuffer);
    var count = newResults.size() + newBuffer.size();

    if (this._ownerInfo) {
      Kadira.models.pubsub.trackPolledDocuments(this._ownerInfo, count);
      Kadira.models.pubsub.trackDocSize(this._ownerInfo.name, "polledFetches", docSize * count);
    } else {
      this._polledDocuments = count;
      this._docSize = {
        polledFetches: docSize * count
      };
    }

    return originalPublishNewResults.call(this, newResults, newBuffer);
  };

  var originalHandleOplogEntryQuerying = proto._handleOplogEntryQuerying;

  proto._handleOplogEntryQuerying = function (op) {
    Kadira.models.pubsub.trackDocumentChanges(this._ownerInfo, op);
    return originalHandleOplogEntryQuerying.call(this, op);
  };

  var originalHandleOplogEntrySteadyOrFetching = proto._handleOplogEntrySteadyOrFetching;

  proto._handleOplogEntrySteadyOrFetching = function (op) {
    Kadira.models.pubsub.trackDocumentChanges(this._ownerInfo, op);
    return originalHandleOplogEntrySteadyOrFetching.call(this, op);
  }; // track live updates


  ['_addPublished', '_removePublished', '_changePublished'].forEach(function (fnName) {
    var originalFn = proto[fnName];

    proto[fnName] = function (a, b, c) {
      if (this._ownerInfo) {
        Kadira.models.pubsub.trackLiveUpdates(this._ownerInfo, fnName, 1);

        if (fnName === "_addPublished") {
          var coll = this._cursorDescription.collectionName;
          var query = this._cursorDescription.selector;
          var opts = this._cursorDescription.options;
          var docSize = Kadira.docSzCache.getSize(coll, query, opts, [b]);
          Kadira.models.pubsub.trackDocSize(this._ownerInfo.name, "liveFetches", docSize);
        }
      } else {
        // If there is no ownerInfo, that means this is the initial adds
        if (!this._liveUpdatesCounts) {
          this._liveUpdatesCounts = {
            _initialAdds: 0
          };
        }

        this._liveUpdatesCounts._initialAdds++;

        if (fnName === "_addPublished") {
          if (!this._docSize) {
            this._docSize = {
              initialFetches: 0
            };
          }

          if (!this._docSize.initialFetches) {
            this._docSize.initialFetches = 0;
          }

          var coll = this._cursorDescription.collectionName;
          var query = this._cursorDescription.selector;
          var opts = this._cursorDescription.options;
          var docSize = Kadira.docSzCache.getSize(coll, query, opts, [b]);
          this._docSize.initialFetches += docSize;
        }
      }

      return originalFn.call(this, a, b, c);
    };
  });
  var originalStop = proto.stop;

  proto.stop = function () {
    if (this._ownerInfo && this._ownerInfo.type === 'sub') {
      Kadira.EventBus.emit('pubsub', 'observerDeleted', this._ownerInfo);
      Kadira.models.pubsub.trackDeletedObserver(this._ownerInfo);
    }

    return originalStop.call(this);
  };
};

wrapPollingObserveDriver = function (proto) {
  var originalPollMongo = proto._pollMongo;

  proto._pollMongo = function () {
    var start = Date.now();
    originalPollMongo.call(this); // Current result is stored in the following variable.
    // So, we can use that
    // Sometimes, it's possible to get size as undefined.
    // May be something with different version. We don't need to worry about
    // this now

    var count = 0;
    var docSize = 0;

    if (this._results && this._results.size) {
      count = this._results.size() || 0;
      var coll = this._cursorDescription.collectionName;
      var query = this._cursorDescription.selector;
      var opts = this._cursorDescription.options;
      docSize = Kadira.docSzCache.getSize(coll, query, opts, this._results._map) * count;
    }

    if (this._ownerInfo) {
      Kadira.models.pubsub.trackPolledDocuments(this._ownerInfo, count);
      Kadira.models.pubsub.trackDocSize(this._ownerInfo.name, "polledFetches", docSize);
    } else {
      this._polledDocuments = count;
      this._polledDocSize = docSize;
    }
  };

  var originalStop = proto.stop;

  proto.stop = function () {
    if (this._ownerInfo && this._ownerInfo.type === 'sub') {
      Kadira.EventBus.emit('pubsub', 'observerDeleted', this._ownerInfo);
      Kadira.models.pubsub.trackDeletedObserver(this._ownerInfo);
    }

    return originalStop.call(this);
  };
};

wrapMultiplexer = function (proto) {
  var originalInitalAdd = proto.addHandleAndSendInitialAdds;

  proto.addHandleAndSendInitialAdds = function (handle) {
    if (!this._firstInitialAddTime) {
      this._firstInitialAddTime = Date.now();
    }

    handle._wasMultiplexerReady = this._ready();
    handle._queueLength = this._queue._taskHandles.length;

    if (!handle._wasMultiplexerReady) {
      handle._elapsedPollingTime = Date.now() - this._firstInitialAddTime;
    }

    return originalInitalAdd.call(this, handle);
  };
};

wrapForCountingObservers = function () {
  // to count observers
  var mongoConnectionProto = MeteorX.MongoConnection.prototype;
  var originalObserveChanges = mongoConnectionProto._observeChanges;

  mongoConnectionProto._observeChanges = function (cursorDescription, ordered, callbacks) {
    var ret = originalObserveChanges.call(this, cursorDescription, ordered, callbacks); // get the Kadira Info via the Meteor.EnvironmentalVariable

    var kadiraInfo = Kadira._getInfo(null, true);

    if (kadiraInfo && ret._multiplexer) {
      if (!ret._multiplexer.__kadiraTracked) {
        // new multiplexer
        ret._multiplexer.__kadiraTracked = true;
        Kadira.EventBus.emit('pubsub', 'newSubHandleCreated', kadiraInfo.trace);
        Kadira.models.pubsub.incrementHandleCount(kadiraInfo.trace, false);

        if (kadiraInfo.trace.type == 'sub') {
          var ownerInfo = {
            type: kadiraInfo.trace.type,
            name: kadiraInfo.trace.name,
            startTime: new Date().getTime()
          };
          var observerDriver = ret._multiplexer._observeDriver;
          observerDriver._ownerInfo = ownerInfo;
          Kadira.EventBus.emit('pubsub', 'observerCreated', ownerInfo);
          Kadira.models.pubsub.trackCreatedObserver(ownerInfo); // We need to send initially polled documents if there are

          if (observerDriver._polledDocuments) {
            Kadira.models.pubsub.trackPolledDocuments(ownerInfo, observerDriver._polledDocuments);
            observerDriver._polledDocuments = 0;
          } // We need to send initially polled documents if there are


          if (observerDriver._polledDocSize) {
            Kadira.models.pubsub.trackDocSize(ownerInfo.name, "polledFetches", observerDriver._polledDocSize);
            observerDriver._polledDocSize = 0;
          } // Process _liveUpdatesCounts


          _.each(observerDriver._liveUpdatesCounts, function (count, key) {
            Kadira.models.pubsub.trackLiveUpdates(ownerInfo, key, count);
          }); // Process docSize


          _.each(observerDriver._docSize, function (count, key) {
            Kadira.models.pubsub.trackDocSize(ownerInfo.name, key, count);
          });
        }
      } else {
        Kadira.EventBus.emit('pubsub', 'cachedSubHandleCreated', kadiraInfo.trace);
        Kadira.models.pubsub.incrementHandleCount(kadiraInfo.trace, true);
      }
    }

    return ret;
  };
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wrap_ddp_stringify.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/hijack/wrap_ddp_stringify.js                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
wrapStringifyDDP = function () {
  var originalStringifyDDP = DDPCommon.stringifyDDP;

  DDPCommon.stringifyDDP = function (msg) {
    var msgString = originalStringifyDDP(msg);
    var msgSize = Buffer.byteLength(msgString, 'utf8');

    var kadiraInfo = Kadira._getInfo(null, true);

    if (kadiraInfo && !Kadira.env.currentSub) {
      if (kadiraInfo.trace.type === 'method') {
        Kadira.models.methods.trackMsgSize(kadiraInfo.trace.name, msgSize);
      }

      return msgString;
    } // 'currentSub' is set when we wrap Subscription object and override
    // handlers for 'added', 'changed', 'removed' events. (see lib/hijack/wrap_subscription.js)


    if (Kadira.env.currentSub) {
      if (Kadira.env.currentSub.__kadiraInfo) {
        Kadira.models.pubsub.trackMsgSize(Kadira.env.currentSub._name, "initialSent", msgSize);
        return msgString;
      }

      Kadira.models.pubsub.trackMsgSize(Kadira.env.currentSub._name, "liveSent", msgSize);
      return msgString;
    }

    Kadira.models.methods.trackMsgSize("<not-a-method-or-a-pub>", msgSize);
    return msgString;
  };
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"instrument.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/hijack/instrument.js                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let wrapWebApp;
module.link("./wrap_webapp.js", {
  wrapWebApp(v) {
    wrapWebApp = v;
  }

}, 0);
let wrapFastRender;
module.link("./fast_render.js", {
  wrapFastRender(v) {
    wrapFastRender = v;
  }

}, 1);
let wrapFs;
module.link("./fs.js", {
  wrapFs(v) {
    wrapFs = v;
  }

}, 2);
let wrapPicker;
module.link("./picker.js", {
  wrapPicker(v) {
    wrapPicker = v;
  }

}, 3);
let wrapRouters;
module.link("./wrap_routers.js", {
  wrapRouters(v) {
    wrapRouters = v;
  }

}, 4);
let wrapFibers;
module.link("./async.js", {
  wrapFibers(v) {
    wrapFibers = v;
  }

}, 5);
var instrumented = false;

Kadira._startInstrumenting = function (callback) {
  if (instrumented) {
    callback();
    return;
  }

  instrumented = true;
  wrapFibers();
  wrapStringifyDDP();
  wrapWebApp();
  wrapFastRender();
  wrapPicker();
  wrapFs();
  wrapRouters();
  MeteorX.onReady(function () {
    //instrumenting session
    wrapServer(MeteorX.Server.prototype);
    wrapSession(MeteorX.Session.prototype);
    wrapSubscription(MeteorX.Subscription.prototype);

    if (MeteorX.MongoOplogDriver) {
      wrapOplogObserveDriver(MeteorX.MongoOplogDriver.prototype);
    }

    if (MeteorX.MongoPollingDriver) {
      wrapPollingObserveDriver(MeteorX.MongoPollingDriver.prototype);
    }

    if (MeteorX.Multiplexer) {
      wrapMultiplexer(MeteorX.Multiplexer.prototype);
    }

    wrapForCountingObservers();
    hijackDBOps();
    setLabels();
    callback();
  });
}; // We need to instrument this right away and it's okay
// One reason for this is to call `setLables()` function
// Otherwise, CPU profile can't see all our custom labeling


Kadira._startInstrumenting(function () {
  console.log('Monti APM: completed instrumenting the app');
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"db.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/hijack/db.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// This hijack is important to make sure, collections created before
// we hijack dbOps, even gets tracked.
//  Meteor does not simply expose MongoConnection object to the client
//  It picks methods which are necessory and make a binded object and
//  assigned to the Mongo.Collection
//  so, even we updated prototype, we can't track those collections
//  but, this will fix it.
var originalOpen = MongoInternals.RemoteCollectionDriver.prototype.open;

MongoInternals.RemoteCollectionDriver.prototype.open = function open(name) {
  var self = this;
  var ret = originalOpen.call(self, name);

  _.each(ret, function (fn, m) {
    // make sure, it's in the actual mongo connection object
    // meteorhacks:mongo-collection-utils package add some arbitary methods
    // which does not exist in the mongo connection
    if (self.mongo[m]) {
      ret[m] = function () {
        Array.prototype.unshift.call(arguments, name);
        return OptimizedApply(self.mongo, self.mongo[m], arguments);
      };
    }
  });

  return ret;
}; // TODO: this should be added to Meteorx


function getSyncronousCursor() {
  const MongoColl = typeof Mongo !== "undefined" ? Mongo.Collection : Meteor.Collection;
  const coll = new MongoColl("__dummy_coll_" + Random.id()); // we need to wait until the db is connected with meteor. findOne does that

  coll.findOne();
  const cursor = coll.find();
  cursor.fetch();
  return cursor._synchronousCursor.constructor;
}

hijackDBOps = function hijackDBOps() {
  var mongoConnectionProto = MeteorX.MongoConnection.prototype; //findOne is handled by find - so no need to track it
  //upsert is handles by update

  ['find', 'update', 'remove', 'insert', '_ensureIndex', '_dropIndex'].forEach(function (func) {
    var originalFunc = mongoConnectionProto[func];

    mongoConnectionProto[func] = function (collName, selector, mod, options) {
      var payload = {
        coll: collName,
        func: func
      };

      if (func == 'insert') {//add nothing more to the payload
      } else if (func == '_ensureIndex' || func == '_dropIndex') {
        //add index
        payload.index = JSON.stringify(selector);
      } else if (func == 'update' && options && options.upsert) {
        payload.func = 'upsert';
        payload.selector = JSON.stringify(selector);
      } else {
        //all the other functions have selectors
        payload.selector = JSON.stringify(selector);
      }

      var kadiraInfo = Kadira._getInfo();

      if (kadiraInfo) {
        var eventId = Kadira.tracer.event(kadiraInfo.trace, 'db', payload);
      } //this cause V8 to avoid any performance optimizations, but this is must to use
      //otherwise, if the error adds try catch block our logs get messy and didn't work
      //see: issue #6


      try {
        var ret = originalFunc.apply(this, arguments); //handling functions which can be triggered with an asyncCallback

        var endOptions = {};

        if (HaveAsyncCallback(arguments)) {
          endOptions.async = true;
        }

        if (func == 'update') {
          // upsert only returns an object when called `upsert` directly
          // otherwise it only act an update command
          if (options && options.upsert && typeof ret == 'object') {
            endOptions.updatedDocs = ret.numberAffected;
            endOptions.insertedId = ret.insertedId;
          } else {
            endOptions.updatedDocs = ret;
          }
        } else if (func == 'remove') {
          endOptions.removedDocs = ret;
        }

        if (eventId) {
          Kadira.tracer.eventEnd(kadiraInfo.trace, eventId, endOptions);
        }
      } catch (ex) {
        if (eventId) {
          Kadira.tracer.eventEnd(kadiraInfo.trace, eventId, {
            err: ex.message
          });
        }

        throw ex;
      }

      return ret;
    };
  });
  var cursorProto = MeteorX.MongoCursor.prototype;
  ['forEach', 'map', 'fetch', 'count', 'observeChanges', 'observe'].forEach(function (type) {
    var originalFunc = cursorProto[type];

    cursorProto[type] = function () {
      var cursorDescription = this._cursorDescription;
      var payload = Object.assign(Object.create(null), {
        coll: cursorDescription.collectionName,
        selector: JSON.stringify(cursorDescription.selector),
        func: type,
        cursor: true
      });

      if (cursorDescription.options) {
        var cursorOptions = _.pick(cursorDescription.options, ['fields', 'sort', 'limit']);

        for (var field in cursorOptions) {
          var value = cursorOptions[field];

          if (typeof value == 'object') {
            value = JSON.stringify(value);
          }

          payload[field] = value;
        }
      }

      var kadiraInfo = Kadira._getInfo();

      var previousTrackNextObject;

      if (kadiraInfo) {
        var eventId = Kadira.tracer.event(kadiraInfo.trace, 'db', payload);
        previousTrackNextObject = kadiraInfo.trackNextObject;

        if (type === 'forEach' || type === 'map') {
          kadiraInfo.trackNextObject = true;
        }
      }

      try {
        var ret = originalFunc.apply(this, arguments);
        var endData = {};

        if (type == 'observeChanges' || type == 'observe') {
          var observerDriver;
          endData.oplog = false; // get data written by the multiplexer

          endData.wasMultiplexerReady = ret._wasMultiplexerReady;
          endData.queueLength = ret._queueLength;
          endData.elapsedPollingTime = ret._elapsedPollingTime;

          if (ret._multiplexer) {
            // older meteor versions done not have an _multiplexer value
            observerDriver = ret._multiplexer._observeDriver;

            if (observerDriver) {
              observerDriver = ret._multiplexer._observeDriver;
              var observerDriverClass = observerDriver.constructor;
              var usesOplog = typeof observerDriverClass.cursorSupported == 'function';
              endData.oplog = usesOplog;
              var size = 0;

              ret._multiplexer._cache.docs.forEach(function () {
                size++;
              });

              endData.noOfCachedDocs = size; // if multiplexerWasNotReady, we need to get the time spend for the polling

              if (!ret._wasMultiplexerReady) {
                endData.initialPollingTime = observerDriver._lastPollTime;
              }
            }
          }

          if (!endData.oplog) {
            // let's try to find the reason
            var reasonInfo = Kadira.checkWhyNoOplog(cursorDescription, observerDriver);
            endData.noOplogCode = reasonInfo.code;
            endData.noOplogReason = reasonInfo.reason;
            endData.noOplogSolution = reasonInfo.solution;
          }
        } else if (type == 'fetch' || type == 'map') {
          //for other cursor operation
          endData.docsFetched = ret.length;

          if (type == 'fetch') {
            var coll = cursorDescription.collectionName;
            var query = cursorDescription.selector;
            var opts = cursorDescription.options;
            var docSize = Kadira.docSzCache.getSize(coll, query, opts, ret) * ret.length;
            endData.docSize = docSize;

            if (kadiraInfo) {
              if (kadiraInfo.trace.type === 'method') {
                Kadira.models.methods.trackDocSize(kadiraInfo.trace.name, docSize);
              } else if (kadiraInfo.trace.type === 'sub') {
                Kadira.models.pubsub.trackDocSize(kadiraInfo.trace.name, "cursorFetches", docSize);
              }

              kadiraInfo.trackNextObject = previousTrackNextObject;
            } else {
              // Fetch with no kadira info are tracked as from a null method
              Kadira.models.methods.trackDocSize("<not-a-method-or-a-pub>", docSize);
            } // TODO: Add doc size tracking to `map` as well.

          }
        }

        if (eventId) {
          Kadira.tracer.eventEnd(kadiraInfo.trace, eventId, endData);
        }

        return ret;
      } catch (ex) {
        if (eventId) {
          Kadira.tracer.eventEnd(kadiraInfo.trace, eventId, {
            err: ex.message
          });
        }

        throw ex;
      }
    };
  });
  const SyncronousCursor = getSyncronousCursor();
  var origNextObject = SyncronousCursor.prototype._nextObject;

  SyncronousCursor.prototype._nextObject = function () {
    var kadiraInfo = Kadira._getInfo();

    var shouldTrack = kadiraInfo && kadiraInfo.trackNextObject;

    if (shouldTrack) {
      var event = Kadira.tracer.event(kadiraInfo.trace, 'db', {
        func: '_nextObject',
        coll: this._cursorDescription.collectionName
      });
    }

    var result = origNextObject.call(this);

    if (shouldTrack) {
      Kadira.tracer.eventEnd(kadiraInfo.trace, event);
    }

    return result;
  };
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"http.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/hijack/http.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var originalCall = HTTP.call;

HTTP.call = function (method, url) {
  var kadiraInfo = Kadira._getInfo();

  if (kadiraInfo) {
    var eventId = Kadira.tracer.event(kadiraInfo.trace, 'http', {
      method: method,
      url: url
    });
  }

  try {
    var response = originalCall.apply(this, arguments); //if the user supplied an asynCallback, we don't have a response object and it handled asynchronously
    //we need to track it down to prevent issues like: #3

    var endOptions = HaveAsyncCallback(arguments) ? {
      async: true
    } : {
      statusCode: response.statusCode
    };

    if (eventId) {
      Kadira.tracer.eventEnd(kadiraInfo.trace, eventId, endOptions);
    }

    return response;
  } catch (ex) {
    if (eventId) {
      Kadira.tracer.eventEnd(kadiraInfo.trace, eventId, {
        err: ex.message
      });
    }

    throw ex;
  }
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"email.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/hijack/email.js                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var originalSend = Email.send;

Email.send = function (options) {
  var kadiraInfo = Kadira._getInfo();

  if (kadiraInfo) {
    var data = _.pick(options, 'from', 'to', 'cc', 'bcc', 'replyTo');

    var eventId = Kadira.tracer.event(kadiraInfo.trace, 'email', data);
  }

  try {
    var ret = originalSend.call(this, options);

    if (eventId) {
      Kadira.tracer.eventEnd(kadiraInfo.trace, eventId);
    }

    return ret;
  } catch (ex) {
    if (eventId) {
      Kadira.tracer.eventEnd(kadiraInfo.trace, eventId, {
        err: ex.message
      });
    }

    throw ex;
  }
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"async.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/hijack/async.js                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  wrapFibers: () => wrapFibers,
  getFiberMetrics: () => getFiberMetrics,
  resetFiberMetrics: () => resetFiberMetrics
});

var Fibers = Npm.require('fibers');

var EventSymbol = Symbol();
var StartTracked = Symbol();
var activeFibers = 0;
var wrapped = false;

function wrapFibers() {
  if (wrapped) {
    return;
  }

  wrapped = true;
  var originalYield = Fibers.yield;

  Fibers.yield = function () {
    var kadiraInfo = Kadira._getInfo();

    if (kadiraInfo) {
      var eventId = Kadira.tracer.event(kadiraInfo.trace, 'async');

      if (eventId) {
        // The event unique to this fiber
        // Using a symbol since Meteor doesn't copy symbols to new fibers created
        // for promises. This is needed so the correct event is ended when a fiber runs after being yielded.
        Fibers.current[EventSymbol] = eventId;
      }
    }

    return originalYield();
  };

  var originalRun = Fibers.prototype.run;
  var originalThrowInto = Fibers.prototype.throwInto;

  function ensureFiberCounted(fiber) {
    // If fiber.started is true, and StartTracked is false
    // then the fiber was probably initially ran before we wrapped Fibers.run
    if (!fiber.started || !fiber[StartTracked]) {
      activeFibers += 1;
      fiber[StartTracked] = true;
    }
  }

  Fibers.prototype.run = function (val) {
    ensureFiberCounted(this);

    if (this[EventSymbol]) {
      var kadiraInfo = Kadira._getInfo(this);

      if (kadiraInfo) {
        Kadira.tracer.eventEnd(kadiraInfo.trace, this[EventSymbol]);
        this[EventSymbol] = null;
      }
    } else if (!this.__kadiraInfo && Fibers.current && Fibers.current.__kadiraInfo) {
      // Copy kadiraInfo when packages or user code creates a new fiber
      // Done by many apps and packages in connect middleware since older
      // versions of Meteor did not do it automatically
      this.__kadiraInfo = Fibers.current.__kadiraInfo;
    }

    let result;

    try {
      result = originalRun.call(this, val);
    } finally {
      if (!this.started) {
        activeFibers -= 1;
        this[StartTracked] = false;
      }
    }

    return result;
  };

  Fibers.prototype.throwInto = function (val) {
    ensureFiberCounted(this); // TODO: this should probably end the current async event since in some places
    // Meteor calls throwInto instead of run after a fiber is yielded. For example,
    // when a promise is awaited and rejects an error.

    let result;

    try {
      result = originalThrowInto.call(this, val);
    } finally {
      if (!this.started) {
        activeFibers -= 1;
        this[StartTracked] = false;
      }
    }

    return result;
  };
}

let activeFiberTotal = 0;
let activeFiberCount = 0;
let previousTotalCreated = 0;
setInterval(() => {
  activeFiberTotal += activeFibers;
  activeFiberCount += 1;
}, 1000);

function getFiberMetrics() {
  return {
    created: Fibers.fibersCreated - previousTotalCreated,
    active: activeFiberTotal / activeFiberCount,
    poolSize: Fibers.poolSize
  };
}

function resetFiberMetrics() {
  activeFiberTotal = 0;
  activeFiberCount = 0;
  previousTotalCreated = Fibers.fibersCreated;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"error.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/hijack/error.js                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  MeteorDebugIgnore: () => MeteorDebugIgnore
});
const MeteorDebugIgnore = Symbol();

TrackUncaughtExceptions = function () {
  process.on('uncaughtException', function (err) {
    // skip errors with `_skipKadira` flag
    if (err._skipKadira) {
      return;
    } // let the server crash normally if error tracking is disabled


    if (!Kadira.options.enableErrorTracking) {
      printErrorAndKill(err);
    } // looking for already tracked errors and throw them immediately
    // throw error immediately if kadira is not ready


    if (err._tracked || !Kadira.connected) {
      printErrorAndKill(err);
    }

    var trace = getTrace(err, 'server-crash', 'uncaughtException');
    Kadira.models.error.trackError(err, trace);

    Kadira._sendPayload(function () {
      clearTimeout(timer);
      throwError(err);
    });

    var timer = setTimeout(function () {
      throwError(err);
    }, 1000 * 10);

    function throwError(err) {
      // sometimes error came back from a fiber.
      // But we don't fibers to track that error for us
      // That's why we throw the error on the nextTick
      process.nextTick(function () {
        // we need to mark this error where we really need to throw
        err._tracked = true;
        printErrorAndKill(err);
      });
    }
  });

  function printErrorAndKill(err) {
    // since we are capturing error, we are also on the error message.
    // so developers think we are also reponsible for the error.
    // But we are not. This will fix that.
    console.error(err.stack);
    process.exit(7);
  }
};

TrackUnhandledRejections = function () {
  process.on('unhandledRejection', function (reason) {
    // skip errors with `_skipKadira` flag
    if (reason._skipKadira || !Kadira.options.enableErrorTracking) {
      return;
    }

    var trace = getTrace(reason, 'server-internal', 'unhandledRejection');
    Kadira.models.error.trackError(reason, trace); // TODO: we should respect the --unhandled-rejections option
    // message taken from 
    // https://github.com/nodejs/node/blob/f4797ff1ef7304659d747d181ec1e7afac408d50/lib/internal/process/promises.js#L243-L248

    const message = 'This error originated either by ' + 'throwing inside of an async function without a catch block, ' + 'or by rejecting a promise which was not handled with .catch().' + ' The promise rejected with the reason: '; // We could emit a warning instead like Node does internally
    // but it requires Node 8 or newer

    console.warn(message);
    console.error(reason && reason.stack ? reason.stack : reason);
  });
};

TrackMeteorDebug = function () {
  var originalMeteorDebug = Meteor._debug;

  Meteor._debug = function (message, stack) {
    // Sometimes Meteor calls Meteor._debug with no arguments
    // to log an empty line
    const isArgs = message !== undefined || stack !== undefined; // We've changed `stack` into an object at method and sub handlers so we can
    // detect the error here. These errors are already tracked so don't track them again.

    var alreadyTracked = false; // Some Meteor versions pass the error, and other versions pass the error stack
    // Restore so origionalMeteorDebug shows the stack as a string instead as an object

    if (stack && stack[MeteorDebugIgnore]) {
      alreadyTracked = true;
      arguments[1] = stack.stack;
    } else if (stack && stack.stack && stack.stack[MeteorDebugIgnore]) {
      alreadyTracked = true;
      arguments[1] = stack.stack.stack;
    } // only send to the server if connected to kadira


    if (Kadira.options.enableErrorTracking && isArgs && !alreadyTracked && Kadira.connected) {
      let errorMessage = message;

      if (typeof message == 'string' && stack instanceof Error) {
        const separator = message.endsWith(':') ? '' : ':';
        errorMessage = "".concat(message).concat(separator, " ").concat(stack.message);
      }

      let error = new Error(errorMessage);

      if (stack instanceof Error) {
        error.stack = stack.stack;
      } else if (stack) {
        error.stack = stack;
      } else {
        error.stack = CreateUserStack(error);
      }

      var trace = getTrace(error, 'server-internal', 'Meteor._debug');
      Kadira.models.error.trackError(error, trace);
    }

    return originalMeteorDebug.apply(this, arguments);
  };
};

function getTrace(err, type, subType) {
  return {
    type: type,
    subType: subType,
    name: err.message,
    errored: true,
    at: Kadira.syncedDate.getTime(),
    events: [['start', 0, {}], ['error', 0, {
      error: {
        message: err.message,
        stack: err.stack
      }
    }]],
    metrics: {
      total: 0
    }
  };
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"set_labels.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/hijack/set_labels.js                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
setLabels = function () {
  // name Session.prototype.send
  var originalSend = MeteorX.Session.prototype.send;

  MeteorX.Session.prototype.send = function kadira_Session_send(msg) {
    return originalSend.call(this, msg);
  }; // name Multiplexer initial adds
  // Multiplexer is undefined in rocket chat


  if (MeteorX.Multiplexer) {
    var originalSendAdds = MeteorX.Multiplexer.prototype._sendAdds;

    MeteorX.Multiplexer.prototype._sendAdds = function kadira_Multiplexer_sendAdds(handle) {
      return originalSendAdds.call(this, handle);
    };
  } // name MongoConnection insert


  var originalMongoInsert = MeteorX.MongoConnection.prototype._insert;

  MeteorX.MongoConnection.prototype._insert = function kadira_MongoConnection_insert(coll, doc, cb) {
    return originalMongoInsert.call(this, coll, doc, cb);
  }; // name MongoConnection update


  var originalMongoUpdate = MeteorX.MongoConnection.prototype._update;

  MeteorX.MongoConnection.prototype._update = function kadira_MongoConnection_update(coll, selector, mod, options, cb) {
    return originalMongoUpdate.call(this, coll, selector, mod, options, cb);
  }; // name MongoConnection remove


  var originalMongoRemove = MeteorX.MongoConnection.prototype._remove;

  MeteorX.MongoConnection.prototype._remove = function kadira_MongoConnection_remove(coll, selector, cb) {
    return originalMongoRemove.call(this, coll, selector, cb);
  }; // name Pubsub added


  var originalPubsubAdded = MeteorX.Session.prototype.sendAdded;

  MeteorX.Session.prototype.sendAdded = function kadira_Session_sendAdded(coll, id, fields) {
    return originalPubsubAdded.call(this, coll, id, fields);
  }; // name Pubsub changed


  var originalPubsubChanged = MeteorX.Session.prototype.sendChanged;

  MeteorX.Session.prototype.sendChanged = function kadira_Session_sendChanged(coll, id, fields) {
    return originalPubsubChanged.call(this, coll, id, fields);
  }; // name Pubsub removed


  var originalPubsubRemoved = MeteorX.Session.prototype.sendRemoved;

  MeteorX.Session.prototype.sendRemoved = function kadira_Session_sendRemoved(coll, id) {
    return originalPubsubRemoved.call(this, coll, id);
  }; // name MongoCursor forEach


  var originalCursorForEach = MeteorX.MongoCursor.prototype.forEach;

  MeteorX.MongoCursor.prototype.forEach = function kadira_Cursor_forEach() {
    return originalCursorForEach.apply(this, arguments);
  }; // name MongoCursor map


  var originalCursorMap = MeteorX.MongoCursor.prototype.map;

  MeteorX.MongoCursor.prototype.map = function kadira_Cursor_map() {
    return originalCursorMap.apply(this, arguments);
  }; // name MongoCursor fetch


  var originalCursorFetch = MeteorX.MongoCursor.prototype.fetch;

  MeteorX.MongoCursor.prototype.fetch = function kadira_Cursor_fetch() {
    return originalCursorFetch.apply(this, arguments);
  }; // name MongoCursor count


  var originalCursorCount = MeteorX.MongoCursor.prototype.count;

  MeteorX.MongoCursor.prototype.count = function kadira_Cursor_count() {
    return originalCursorCount.apply(this, arguments);
  }; // name MongoCursor observeChanges


  var originalCursorObserveChanges = MeteorX.MongoCursor.prototype.observeChanges;

  MeteorX.MongoCursor.prototype.observeChanges = function kadira_Cursor_observeChanges() {
    return originalCursorObserveChanges.apply(this, arguments);
  }; // name MongoCursor observe


  var originalCursorObserve = MeteorX.MongoCursor.prototype.observe;

  MeteorX.MongoCursor.prototype.observe = function kadira_Cursor_observe() {
    return originalCursorObserve.apply(this, arguments);
  }; // name CrossBar listen


  var originalCrossbarListen = DDPServer._Crossbar.prototype.listen;

  DDPServer._Crossbar.prototype.listen = function kadira_Crossbar_listen(trigger, callback) {
    return originalCrossbarListen.call(this, trigger, callback);
  }; // name CrossBar fire


  var originalCrossbarFire = DDPServer._Crossbar.prototype.fire;

  DDPServer._Crossbar.prototype.fire = function kadira_Crossbar_fire(notification) {
    return originalCrossbarFire.call(this, notification);
  };
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"fast_render.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/hijack/fast_render.js                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  wrapFastRender: () => wrapFastRender
});

function wrapFastRender() {
  Meteor.startup(() => {
    if (Package['staringatlights:fast-render']) {
      const FastRender = Package['staringatlights:fast-render'].FastRender; // Flow Router doesn't call FastRender.route until after all
      // Meteor.startup callbacks finish

      let origRoute = FastRender.route;

      FastRender.route = function (path, _callback) {
        let callback = function () {
          const info = Kadira._getInfo();

          if (info) {
            info.suggestedRouteName = path;
          }

          return _callback.apply(this, arguments);
        };

        return origRoute.call(FastRender, path, callback);
      };
    }
  });
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"fs.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/hijack/fs.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  handleErrorEvent: () => handleErrorEvent,
  wrapFs: () => wrapFs
});
let fs;
module.link("fs", {
  default(v) {
    fs = v;
  }

}, 0);

const Fibers = require('fibers');

function wrapCallback(args, createWrapper) {
  if (typeof args[args.length - 1] === 'function') {
    args[args.length - 1] = createWrapper(args[args.length - 1]);
  }
}

function handleErrorEvent(eventEmitter, trace, event) {
  function handler(error) {
    if (trace && event) {
      Kadira.tracer.eventEnd(trace, event, {
        error: error
      });
    } // Node throws the error if there are no listeners
    // We want it to behave as if we are not listening to it


    if (eventEmitter.listenerCount('error') === 1) {
      eventEmitter.removeListener('error', handler);
      eventEmitter.emit('error', error);
    }
  }

  eventEmitter.on('error', handler);
}

function wrapFs() {
  // Some npm packages will do fs calls in the
  // callback of another fs call.
  // This variable is set with the kadiraInfo while
  // a callback is run so we can track other fs calls
  let fsKadiraInfo = null;
  let originalStat = fs.stat;

  fs.stat = function () {
    const kadiraInfo = Kadira._getInfo() || fsKadiraInfo;

    if (kadiraInfo) {
      let event = Kadira.tracer.event(kadiraInfo.trace, 'fs', {
        func: 'stat',
        path: arguments[0],
        options: typeof arguments[1] === 'object' ? arguments[1] : undefined
      });
      wrapCallback(arguments, cb => {
        return function () {
          Kadira.tracer.eventEnd(kadiraInfo.trace, event);

          if (!Fibers.current) {
            fsKadiraInfo = kadiraInfo;
          }

          try {
            cb.apply(null, arguments);
          } finally {
            fsKadiraInfo = null;
          }
        };
      });
    }

    return originalStat.apply(fs, arguments);
  };

  let originalCreateReadStream = fs.createReadStream;

  fs.createReadStream = function () {
    const kadiraInfo = Kadira._getInfo() || fsKadiraInfo;
    let stream = originalCreateReadStream.apply(this, arguments);

    if (kadiraInfo) {
      const event = Kadira.tracer.event(kadiraInfo.trace, 'fs', {
        func: 'createReadStream',
        path: arguments[0],
        options: JSON.stringify(arguments[1])
      });
      stream.on('end', () => {
        Kadira.tracer.eventEnd(kadiraInfo.trace, event);
      });
      handleErrorEvent(stream, kadiraInfo.trace, event);
    }

    return stream;
  };
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"gc.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/hijack/gc.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  default: () => GCMetrics
});
let PerformanceObserver;
let constants;
let performance;

try {
  // Only available in Node 8.5 and newer
  ({
    PerformanceObserver,
    constants,
    performance
  } = require('perf_hooks'));
} catch (e) {}

class GCMetrics {
  constructor() {
    this._observer = null;
    this.started = false;
    this.metrics = {};
    this.reset();
  }

  start() {
    if (this.started) {
      return false;
    }

    if (!PerformanceObserver || !constants) {
      // The node version is too old to have PerformanceObserver
      return false;
    }

    this.started = true;
    this.observer = new PerformanceObserver(list => {
      list.getEntries().forEach(entry => {
        let metric = this._mapKindToMetric(entry.kind);

        this.metrics[metric] += entry.duration;
      }); // The function was removed in Node 10 since it stopped storing old
      // entries

      if (typeof performance.clearGC === 'function') {
        performance.clearGC();
      }
    });
    this.observer.observe({
      entryTypes: ['gc'],
      buffered: false
    });
  }

  _mapKindToMetric(gcKind) {
    switch (gcKind) {
      case constants.NODE_PERFORMANCE_GC_MAJOR:
        return 'gcMajor';

      case constants.NODE_PERFORMANCE_GC_MINOR:
        return 'gcMinor';

      case constants.NODE_PERFORMANCE_GC_INCREMENTAL:
        return 'gcIncremental';

      case constants.NODE_PERFORMANCE_GC_WEAKCB:
        return 'gcWeakCB';

      default:
        console.log("Monti APM: Unrecognized GC Kind: ".concat(gcKind));
    }
  }

  reset() {
    this.metrics = {
      gcMajor: 0,
      gcMinor: 0,
      gcIncremental: 0,
      gcWeakCB: 0
    };
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mongo-driver-events.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/hijack/mongo-driver-events.js                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  getMongoDriverStats: () => getMongoDriverStats,
  resetMongoDriverStats: () => resetMongoDriverStats
});
var client;
var serverStatus = Object.create(null);
var otherCheckouts = 0; // These metrics are only for the mongo pool for the primary Mongo server

var primaryCheckouts = 0;
var totalCheckoutTime = 0;
var maxCheckoutTime = 0;
var created = 0;
var measurementCount = 0;
var pendingTotal = 0;
var checkedOutTotal = 0;
setInterval(() => {
  let status = getServerStatus(getPrimary(), true);

  if (status) {
    pendingTotal += status.pending.length;
    checkedOutTotal += status.checkedOut.size;
    measurementCount += 1;
  }
}, 1000); // the pool defaults to 100, though usually the default isn't used

var DEFAULT_MAX_POOL_SIZE = 100;

function getPoolSize() {
  if (client && client.topology && client.topology.s && client.topology.s.options) {
    return client.topology.s.options.maxPoolSize || DEFAULT_MAX_POOL_SIZE;
  }

  return 0;
}

function getMongoDriverStats() {
  return {
    poolSize: getPoolSize(),
    primaryCheckouts,
    otherCheckouts,
    checkoutTime: totalCheckoutTime,
    maxCheckoutTime,
    pending: pendingTotal / measurementCount,
    checkedOut: checkedOutTotal / measurementCount,
    created
  };
}

;

function resetMongoDriverStats() {
  primaryCheckouts = 0;
  otherCheckouts = 0;
  totalCheckoutTime = 0;
  maxCheckoutTime = 0;
  pendingTotal = 0;
  checkedOutTotal = 0;
  measurementCount = 0;
  primaryCheckouts = 0;
  created = 0;
}

Meteor.startup(() => {
  let _client = MongoInternals.defaultRemoteCollectionDriver().mongo.client;

  if (!_client || !_client.s) {
    // Old version of agent
    return;
  }

  let options = _client.s.options;

  if (!options || !options.useUnifiedTopology) {
    // CMAP and topology monitoring requires useUnifiedTopology
    return;
  }

  client = _client; // Get the number of connections already created

  let primaryDescription = getServerDescription(getPrimary());

  if (primaryDescription && primaryDescription.s && primaryDescription.s.pool) {
    let pool = primaryDescription.s.pool;
    let totalConnections = pool.totalConnectionCount;
    let availableConnections = pool.availableConnectionCount; // totalConnectionCount counts available connections twice

    created += totalConnections - availableConnections;
  }

  client.on('connectionCreated', event => {
    let primary = getPrimary();

    if (primary === event.address) {
      created += 1;
    }
  });
  client.on('connectionClosed', event => {
    let status = getServerStatus(event.address, true);

    if (status) {
      status.checkedOut.delete(event.connectionId);
    }
  });
  client.on('connectionCheckOutStarted', event => {
    let status = getServerStatus(event.address);
    status.pending.push(event.time);
  });
  client.on('connectionCheckOutFailed', event => {
    let status = getServerStatus(event.address, true);

    if (status) {
      status.pending.shift();
    }
  });
  client.on('connectionCheckedOut', event => {
    let status = getServerStatus(event.address);
    let start = status.pending.shift();
    let primary = getPrimary();

    if (start && primary === event.address) {
      let checkoutDuration = event.time.getTime() - start.getTime();
      primaryCheckouts += 1;
      totalCheckoutTime += checkoutDuration;

      if (checkoutDuration > maxCheckoutTime) {
        maxCheckoutTime = checkoutDuration;
      }
    } else {
      otherCheckouts += 1;
    }

    status.checkedOut.add(event.connectionId);
  });
  client.on('connectionCheckedIn', event => {
    let status = getServerStatus(event.address, true);

    if (status) {
      status.checkedOut.delete(event.connectionId);
    }
  });
  client.on('serverClosed', function (event) {
    delete serverStatus[event.address];
  });
});

function getServerStatus(address, disableCreate) {
  if (typeof address !== 'string') {
    return null;
  }

  if (address in serverStatus) {
    return serverStatus[address];
  }

  if (disableCreate) {
    return null;
  }

  serverStatus[address] = {
    pending: [],
    checkedOut: new Set()
  };
  return serverStatus[address];
}

function getPrimary() {
  if (!client || !client.topology) {
    return null;
  }

  let server = client.topology.lastIsMaster();

  if (server.type === 'Standalone') {
    return server.address;
  }

  if (!server || !server.primary) {
    return null;
  }

  return server.primary;
}

function getServerDescription(address) {
  if (!client || !client.topology || !client.topology.s || !client.topology.s.servers) {
    return null;
  }

  let description = client.topology.s.servers.get(address);
  return description || null;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"picker.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/hijack/picker.js                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  wrapPicker: () => wrapPicker
});
let Fiber;
module.link("fibers", {
  default(v) {
    Fiber = v;
  }

}, 0);

function wrapPicker() {
  Meteor.startup(() => {
    if (!Package['meteorhacks:picker']) {
      return;
    }

    const Picker = Package['meteorhacks:picker'].Picker; // Wrap Picker._processRoute to make sure it runs the
    // handler in a Fiber with __kadiraInfo set
    // Needed if any previous middleware called `next` outside of a fiber.

    const origProcessRoute = Picker.constructor.prototype._processRoute;

    Picker.constructor.prototype._processRoute = function (callback, params, req) {
      const args = arguments;

      if (!Fiber.current) {
        return new Fiber(() => {
          Kadira._setInfo(req.__kadiraInfo);

          return origProcessRoute.apply(this, args);
        }).run();
      }

      if (req.__kadiraInfo) {
        Kadira._setInfo(req.__kadiraInfo);
      }

      return origProcessRoute.apply(this, args);
    };
  });
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wrap_routers.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/hijack/wrap_routers.js                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  wrapRouters: () => wrapRouters
});
let Fibers;
module.link("fibers", {
  default(v) {
    Fibers = v;
  }

}, 0);

function wrapRouters() {
  let connectRoutes = [];

  try {
    connectRoutes.push(require('connect-route'));
  } catch (e) {// We can ignore errors
  }

  try {
    if (Package['simple:json-routes']) {
      // Relative from .npm/node_modules/meteor/montiapm_agent/node_modules
      // Npm.require is less strict on what paths you use than require
      connectRoutes.push(Npm.require('../../simple_json-routes/node_modules/connect-route'));
    }
  } catch (e) {// we can ignore errors
  }

  connectRoutes.forEach(connectRoute => {
    if (typeof connectRoute !== 'function') {
      return;
    }

    connectRoute(router => {
      const oldAdd = router.constructor.prototype.add;

      router.constructor.prototype.add = function (method, route, handler) {
        // Unlike most routers, connect-route doesn't look at the arguments length
        oldAdd.call(this, method, route, function () {
          if (arguments[0] && arguments[0].__kadiraInfo) {
            arguments[0].__kadiraInfo.suggestedRouteName = route;
          }

          handler.apply(null, arguments);
        });
      };
    });
  });
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wrap_webapp.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/hijack/wrap_webapp.js                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  checkHandlersInFiber: () => checkHandlersInFiber,
  wrapWebApp: () => wrapWebApp
});
let WebAppInternals, WebApp;
module.link("meteor/webapp", {
  WebAppInternals(v) {
    WebAppInternals = v;
  },

  WebApp(v) {
    WebApp = v;
  }

}, 0);
let Fibers;
module.link("fibers", {
  default(v) {
    Fibers = v;
  }

}, 1);
// Maximum content-length size
MAX_BODY_SIZE = 8000; // Maximum characters for stringified body

MAX_STRINGIFIED_BODY_SIZE = 4000;
const canWrapStaticHandler = !!WebAppInternals.staticFilesByArch; // This checks if running on a version of Meteor that
// wraps connect handlers in a fiber.
// This check is dependant on Meteor's implementation of `use`,
// which wraps every handler in a new fiber.
// This will need to be updated if Meteor starts reusing
// fibers when they exist.

function checkHandlersInFiber() {
  const handlersLength = WebApp.rawConnectHandlers.stack.length;
  let inFiber = false;
  let outsideFiber = Fibers.current;
  WebApp.rawConnectHandlers.use((_req, _res, next) => {
    inFiber = Fibers.current && Fibers.current !== outsideFiber; // in case we didn't successfully remove this handler
    // and it is a real request

    next();
  });

  if (WebApp.rawConnectHandlers.stack[handlersLength]) {
    let handler = WebApp.rawConnectHandlers.stack[handlersLength].handle; // remove the newly added handler
    // We remove it immediately so there is no opportunity for
    // other code to add handlers first if the current fiber is yielded
    // while running the handler

    while (WebApp.rawConnectHandlers.stack.length > handlersLength) {
      WebApp.rawConnectHandlers.stack.pop();
    }

    handler({}, {}, () => {});
  }

  return inFiber;
}

const InfoSymbol = Symbol();

function wrapWebApp() {
  return Promise.asyncApply(() => {
    if (!checkHandlersInFiber() || !canWrapStaticHandler) {
      return;
    }

    const parseUrl = require('parseurl');

    WebAppInternals.registerBoilerplateDataCallback('__montiApmRouteName', function (request) {
      // TODO: record in trace which arch is used
      if (request[InfoSymbol]) {
        request[InfoSymbol].isAppRoute = true;
      } // Let WebApp know we didn't make changes
      // so it can use a cache


      return false;
    }); // We want the request object returned by categorizeRequest to have
    // __kadiraInfo

    let origCategorizeRequest = WebApp.categorizeRequest;

    WebApp.categorizeRequest = function (req) {
      let result = origCategorizeRequest.apply(this, arguments);

      if (result && req.__kadiraInfo) {
        result[InfoSymbol] = req.__kadiraInfo;
      }

      return result;
    }; // Adding the handler directly to the stack
    // to force it to be the first one to run


    WebApp.rawConnectHandlers.stack.unshift({
      route: '',
      handle: (req, res, next) => {
        const name = parseUrl(req).pathname;
        const trace = Kadira.tracer.start("".concat(req.method, "-").concat(name), 'http');

        const headers = Kadira.tracer._applyObjectFilters(req.headers);

        Kadira.tracer.event(trace, 'start', {
          url: req.url,
          method: req.method,
          headers: JSON.stringify(headers)
        });
        req.__kadiraInfo = {
          trace
        };
        res.on('finish', () => {
          if (req.__kadiraInfo.asyncEvent) {
            Kadira.tracer.eventEnd(trace, req.__kadiraInfo.asyncEvent);
          }

          Kadira.tracer.endLastEvent(trace);

          if (req.__kadiraInfo.isStatic) {
            trace.name = "".concat(req.method, "-<static file>");
          } else if (req.__kadiraInfo.suggestedRouteName) {
            trace.name = "".concat(req.method, "-").concat(req.__kadiraInfo.suggestedRouteName);
          } else if (req.__kadiraInfo.isAppRoute) {
            trace.name = "".concat(req.method, "-<app>");
          }

          const isJson = req.headers['content-type'] === 'application/json';
          const hasSmallBody = req.headers['content-length'] > 0 && req.headers['content-length'] < MAX_BODY_SIZE; // Check after all middleware have run to see if any of them
          // set req.body
          // Technically bodies can be used with any method, but since many load balancers and
          // other software only support bodies for POST requests, we are
          // not recording the body for other methods.

          if (req.method === 'POST' && req.body && isJson && hasSmallBody) {
            try {
              let body = JSON.stringify(req.body); // Check the body size again in case it is much
              // larger than what was in the content-length header

              if (body.length < MAX_STRINGIFIED_BODY_SIZE) {
                trace.events[0].data.body = body;
              }
            } catch (e) {// It is okay if this fails
            }
          } // TODO: record status code


          Kadira.tracer.event(trace, 'complete');
          let built = Kadira.tracer.buildTrace(trace);
          Kadira.models.http.processRequest(built, req, res);
        });
        next();
      }
    });

    function wrapHandler(handler) {
      // connect identifies error handles by them accepting
      // four arguments
      let errorHandler = handler.length === 4;

      function wrapper(req, res, next) {
        let error;

        if (errorHandler) {
          error = req;
          req = res;
          res = next;
          next = arguments[3];
        }

        const kadiraInfo = req.__kadiraInfo;

        Kadira._setInfo(kadiraInfo);

        let nextCalled = false; // TODO: track errors passed to next or thrown

        function wrappedNext() {
          if (kadiraInfo && kadiraInfo.asyncEvent) {
            Kadira.tracer.eventEnd(req.__kadiraInfo.trace, req.__kadiraInfo.asyncEvent);
            req.__kadiraInfo.asyncEvent = null;
          }

          nextCalled = true;
          next(...arguments);
        }

        let potentialPromise;

        if (errorHandler) {
          potentialPromise = handler.call(this, error, req, res, wrappedNext);
        } else {
          potentialPromise = handler.call(this, req, res, wrappedNext);
        }

        if (potentialPromise && typeof potentialPromise.then === 'function') {
          potentialPromise.then(() => {
            // res.finished is depreciated in Node 13, but it is the only option
            // for Node 12.9 and older.
            if (kadiraInfo && !res.finished && !nextCalled) {
              const lastEvent = Kadira.tracer.getLastEvent(kadiraInfo.trace);

              if (lastEvent.endAt) {
                // req is not done, and next has not been called
                // create an async event that will end when either of those happens
                kadiraInfo.asyncEvent = Kadira.tracer.event(kadiraInfo.trace, 'async');
              }
            }
          });
        }

        return potentialPromise;
      }

      if (errorHandler) {
        return function (error, req, res, next) {
          return wrapper(error, req, res, next);
        };
      } else {
        return function (req, res, next) {
          return wrapper(req, res, next);
        };
      }
    }

    function wrapConnect(app, wrapStack) {
      let oldUse = app.use;

      if (wrapStack) {
        // We need to set kadiraInfo on the Fiber the handler will run in.
        // Meteor has already wrapped the handler to run it in a new Fiber
        // by using Promise.asyncApply so we are not able to directly set it
        // on that Fiber. 
        // Meteor's promise library copies properties from the current fiber to
        // the new fiber, so we can wrap it in another Fiber with kadiraInfo set
        // and Meteor will copy kadiraInfo to the new Fiber.
        // It will only create the additional Fiber if it isn't already running in a Fiber
        app.stack.forEach(entry => {
          let wrappedHandler = wrapHandler(entry.handle);

          if (entry.handle.length >= 4) {
            entry.handle = function (error, req, res, next) {
              return Promise.asyncApply(wrappedHandler, this, arguments, true);
            };
          } else {
            entry.handle = function (req, res, next) {
              return Promise.asyncApply(wrappedHandler, this, arguments, true);
            };
          }
        });
      }

      app.use = function () {
        for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
          args[_key] = arguments[_key];
        }

        args[args.length - 1] = wrapHandler(args[args.length - 1]);
        return oldUse.apply(app, args);
      };
    }

    wrapConnect(WebApp.rawConnectHandlers, false);
    wrapConnect(WebAppInternals.meteorInternalHandlers, false); // The oauth package and other core packages might have already added their middleware,
    // so we need to wrap the existing middleware

    wrapConnect(WebApp.connectHandlers, true);
    wrapConnect(WebApp.connectApp, false);
    let oldStaticFilesMiddleware = WebAppInternals.staticFilesMiddleware;
    const staticHandler = wrapHandler(oldStaticFilesMiddleware.bind(WebAppInternals, WebAppInternals.staticFilesByArch));

    WebAppInternals.staticFilesMiddleware = function (_staticFiles, req, res, next) {
      if (req.__kadiraInfo) {
        req.__kadiraInfo.isStatic = true;
      }

      return staticHandler(req, res, function () {
        // if the request is for a static file, the static handler will end the response
        // instead of calling next
        req.__kadiraInfo.isStatic = false;
        return next.apply(this, arguments);
      });
    };
  });
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"environment_variables.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/environment_variables.js                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
function normalizedPrefix(name) {
  return name.replace('KADIRA_', 'MONTI_');
}

Kadira._parseEnv = function (env) {
  var options = {};

  for (var name in env) {
    var value = env[name];
    var normalizedName = normalizedPrefix(name);
    var info = Kadira._parseEnv._options[normalizedName];

    if (info && value) {
      options[info.name] = info.parser(value);
    }
  }

  return options;
};

Kadira._parseEnv.parseInt = function (str) {
  var num = parseInt(str);
  if (num || num === 0) return num;
  throw new Error('Kadira: Match Error: "' + num + '" is not a number');
};

Kadira._parseEnv.parseBool = function (str) {
  str = str.toLowerCase();
  if (str === 'true') return true;
  if (str === 'false') return false;
  throw new Error('Kadira: Match Error: ' + str + ' is not a boolean');
};

Kadira._parseEnv.parseUrl = function (str) {
  return str;
};

Kadira._parseEnv.parseString = function (str) {
  return str;
};

Kadira._parseEnv._options = {
  // auth
  MONTI_APP_ID: {
    name: 'appId',
    parser: Kadira._parseEnv.parseString
  },
  MONTI_APP_SECRET: {
    name: 'appSecret',
    parser: Kadira._parseEnv.parseString
  },
  // delay to send the initial ping to the kadira engine after page loads
  MONTI_OPTIONS_CLIENT_ENGINE_SYNC_DELAY: {
    name: 'clientEngineSyncDelay',
    parser: Kadira._parseEnv.parseInt
  },
  // time between sending errors to the engine
  MONTI_OPTIONS_ERROR_DUMP_INTERVAL: {
    name: 'errorDumpInterval',
    parser: Kadira._parseEnv.parseInt
  },
  // no of errors allowed in a given interval
  MONTI_OPTIONS_MAX_ERRORS_PER_INTERVAL: {
    name: 'maxErrorsPerInterval',
    parser: Kadira._parseEnv.parseInt
  },
  // a zone.js specific option to collect the full stack trace(which is not much useful)
  MONTI_OPTIONS_COLLECT_ALL_STACKS: {
    name: 'collectAllStacks',
    parser: Kadira._parseEnv.parseBool
  },
  // enable error tracking (which is turned on by default)
  MONTI_OPTIONS_ENABLE_ERROR_TRACKING: {
    name: 'enableErrorTracking',
    parser: Kadira._parseEnv.parseBool
  },
  // kadira engine endpoint
  MONTI_OPTIONS_ENDPOINT: {
    name: 'endpoint',
    parser: Kadira._parseEnv.parseUrl
  },
  // define the hostname of the current running process
  MONTI_OPTIONS_HOSTNAME: {
    name: 'hostname',
    parser: Kadira._parseEnv.parseString
  },
  // interval between sending data to the kadira engine from the server
  MONTI_OPTIONS_PAYLOAD_TIMEOUT: {
    name: 'payloadTimeout',
    parser: Kadira._parseEnv.parseInt
  },
  // set HTTP/HTTPS proxy
  MONTI_OPTIONS_PROXY: {
    name: 'proxy',
    parser: Kadira._parseEnv.parseUrl
  },
  // number of items cached for tracking document size
  MONTI_OPTIONS_DOCUMENT_SIZE_CACHE_SIZE: {
    name: 'documentSizeCacheSize',
    parser: Kadira._parseEnv.parseInt
  },
  // enable uploading sourcemaps
  MONTI_UPLOAD_SOURCE_MAPS: {
    name: 'uploadSourceMaps',
    parser: Kadira._parseEnv.parseBool
  },
  MONTI_RECORD_IP_ADDRESS: {
    name: 'recordIPAddress',
    parser: Kadira._parseEnv.parseString
  },
  MONTI_EVENT_STACK_TRACE: {
    name: 'eventStackTrace',
    parser: Kadira._parseEnv.parseBool
  }
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"auto_connect.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/auto_connect.js                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Kadira._connectWithEnv = function () {
  var options = Kadira._parseEnv(process.env);

  if (options.appId && options.appSecret) {
    Kadira.connect(options.appId, options.appSecret, options);

    Kadira.connect = function () {
      throw new Error('Kadira has been already connected using credentials from Environment Variables');
    };
  }
};

Kadira._connectWithSettings = function () {
  var montiSettings = Meteor.settings.monti || Meteor.settings.kadira;

  if (montiSettings && montiSettings.appId && montiSettings.appSecret) {
    Kadira.connect(montiSettings.appId, montiSettings.appSecret, montiSettings.options || {});

    Kadira.connect = function () {
      throw new Error('Kadira has been already connected using credentials from Meteor.settings');
    };
  }
}; // Try to connect automatically


Kadira._connectWithEnv();

Kadira._connectWithSettings();
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"conflicting_agents.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/conflicting_agents.js                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
const conflictingPackages = ['mdg:meteor-apm-agent', 'lmachens:kadira', 'meteorhacks:kadira'];
Meteor.startup(() => {
  conflictingPackages.forEach(name => {
    if (name in Package) {
      console.log("Monti APM: your app is using the ".concat(name, " package. Using more than one APM agent in an app can cause unexpected problems."));
    }
  });
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},".meteor-package-versions":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/montiapm_agent/lib/.meteor-package-versions                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.exports = {"accounts-base":"2.2.0","accounts-password":"2.2.0","alanning:roles":"3.4.0","aldeed:collection2":"3.5.0","aldeed:schema-index":"3.0.0","allow-deny":"1.1.0","autoupdate":"1.8.0","babel-compiler":"7.7.0","babel-runtime":"1.5.0","base64":"1.0.12","binary-heap":"1.0.11","blaze-tools":"1.1.2","boilerplate-generator":"1.7.1","caching-compiler":"1.2.2","caching-html-compiler":"1.2.1","callback-hook":"1.4.0","check":"1.3.1","ddp":"1.4.0","ddp-client":"2.5.0","ddp-common":"1.4.0","ddp-rate-limiter":"1.1.0","ddp-server":"2.5.0","diff-sequence":"1.1.1","dynamic-import":"0.7.2","ecmascript":"0.16.0","ecmascript-runtime":"0.8.0","ecmascript-runtime-client":"0.12.1","ecmascript-runtime-server":"0.11.0","ejson":"1.1.1","email":"2.2.0","es5-shim":"4.8.0","fetch":"0.1.1","geojson-utils":"1.0.10","hot-code-push":"1.0.4","html-tools":"1.1.2","htmljs":"1.1.1","http":"2.0.0","id-map":"1.1.1","insecure":"1.0.7","inter-process-messaging":"0.1.1","launch-screen":"1.3.0","livedata":"1.0.18","localstorage":"1.2.0","logging":"1.3.1","meteor":"1.10.0","meteor-base":"1.5.1","minifier-css":"1.6.0","minimongo":"1.7.0","mobile-experience":"1.1.0","mobile-status-bar":"1.1.0","modern-browsers":"0.1.7","modules":"0.17.0","modules-runtime":"0.12.0","mongo":"1.13.0","mongo-decimal":"0.1.2","mongo-dev-server":"1.1.0","mongo-id":"1.0.8","mongo-livedata":"1.0.12","montiapm:agent":"2.44.2","montiapm:meteorx":"2.2.0","npm-mongo":"3.9.1","ordered-dict":"1.1.0","promise":"0.12.0","raix:eventemitter":"1.0.0","random":"1.2.0","rate-limit":"1.0.9","react-fast-refresh":"0.2.0","react-meteor-data":"2.3.3","reactive-var":"1.0.11","reload":"1.3.1","retry":"1.1.0","routepolicy":"1.1.1","service-configuration":"1.3.0","sha":"1.0.9","shell-server":"0.5.0","socket-stream-client":"0.4.0","spacebars-compiler":"1.3.0","standard-minifier-css":"1.7.4","static-html":"1.3.2","templating-tools":"1.2.1","tmeasday:check-npm-versions":"1.0.2","tracker":"1.2.0","typescript":"4.4.0","underscore":"1.0.10","url":"1.3.2","webapp":"1.13.0","webapp-hashing":"1.1.0","zodern:caching-minifier":"0.4.0","zodern:hide-production-sourcemaps":"1.2.0","zodern:meteor-package-versions":"0.2.1","zodern:minifier-js":"4.0.0","zodern:standard-minifier-js":"4.0.0"}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"node_modules":{"monti-apm-sketches-js":{"package.json":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// node_modules/meteor/montiapm_agent/node_modules/monti-apm-sketches-js/package.json                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.exports = {
  "name": "monti-apm-sketches-js",
  "version": "0.0.3",
  "main": "index.js"
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// node_modules/meteor/montiapm_agent/node_modules/monti-apm-sketches-js/index.js                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.useNode();
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"parseurl":{"package.json":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// node_modules/meteor/montiapm_agent/node_modules/parseurl/package.json                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.exports = {
  "name": "parseurl",
  "version": "1.3.3"
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// node_modules/meteor/montiapm_agent/node_modules/parseurl/index.js                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.useNode();
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

require("/node_modules/meteor/montiapm:agent/lib/common/utils.js");
require("/node_modules/meteor/montiapm:agent/lib/common/unify.js");
require("/node_modules/meteor/montiapm:agent/lib/models/base_error.js");
require("/node_modules/meteor/montiapm:agent/lib/jobs.js");
require("/node_modules/meteor/montiapm:agent/lib/retry.js");
require("/node_modules/meteor/montiapm:agent/lib/utils.js");
require("/node_modules/meteor/montiapm:agent/lib/ntp.js");
require("/node_modules/meteor/montiapm:agent/lib/sourcemaps.js");
require("/node_modules/meteor/montiapm:agent/lib/wait_time_builder.js");
require("/node_modules/meteor/montiapm:agent/lib/check_for_oplog.js");
require("/node_modules/meteor/montiapm:agent/lib/tracer/tracer.js");
require("/node_modules/meteor/montiapm:agent/lib/tracer/default_filters.js");
require("/node_modules/meteor/montiapm:agent/lib/tracer/tracer_store.js");
require("/node_modules/meteor/montiapm:agent/lib/models/0model.js");
require("/node_modules/meteor/montiapm:agent/lib/models/methods.js");
require("/node_modules/meteor/montiapm:agent/lib/models/pubsub.js");
require("/node_modules/meteor/montiapm:agent/lib/models/system.js");
require("/node_modules/meteor/montiapm:agent/lib/models/errors.js");
require("/node_modules/meteor/montiapm:agent/lib/docsize_cache.js");
require("/node_modules/meteor/montiapm:agent/lib/kadira.js");
require("/node_modules/meteor/montiapm:agent/lib/hijack/wrap_server.js");
require("/node_modules/meteor/montiapm:agent/lib/hijack/wrap_session.js");
require("/node_modules/meteor/montiapm:agent/lib/hijack/wrap_subscription.js");
require("/node_modules/meteor/montiapm:agent/lib/hijack/wrap_observers.js");
require("/node_modules/meteor/montiapm:agent/lib/hijack/wrap_ddp_stringify.js");
require("/node_modules/meteor/montiapm:agent/lib/hijack/instrument.js");
require("/node_modules/meteor/montiapm:agent/lib/hijack/db.js");
require("/node_modules/meteor/montiapm:agent/lib/hijack/http.js");
require("/node_modules/meteor/montiapm:agent/lib/hijack/email.js");
require("/node_modules/meteor/montiapm:agent/lib/hijack/async.js");
require("/node_modules/meteor/montiapm:agent/lib/hijack/error.js");
require("/node_modules/meteor/montiapm:agent/lib/hijack/set_labels.js");
require("/node_modules/meteor/montiapm:agent/lib/environment_variables.js");
require("/node_modules/meteor/montiapm:agent/lib/auto_connect.js");
require("/node_modules/meteor/montiapm:agent/lib/conflicting_agents.js");
require("/node_modules/meteor/montiapm:agent/lib/common/default_error_filters.js");
require("/node_modules/meteor/montiapm:agent/lib/common/send.js");

/* Exports */
Package._define("montiapm:agent", {
  Kadira: Kadira,
  Monti: Monti
});

})();

//# sourceURL=meteor://💻app/packages/montiapm_agent.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvbW9udGlhcG06YWdlbnQvbGliL2NvbW1vbi91dGlscy5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvbW9udGlhcG06YWdlbnQvbGliL2NvbW1vbi91bmlmeS5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvbW9udGlhcG06YWdlbnQvbGliL2NvbW1vbi9kZWZhdWx0X2Vycm9yX2ZpbHRlcnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL21vbnRpYXBtOmFnZW50L2xpYi9jb21tb24vc2VuZC5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvbW9udGlhcG06YWdlbnQvbGliL21vZGVscy9iYXNlX2Vycm9yLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9tb250aWFwbTphZ2VudC9saWIvbW9kZWxzLzBtb2RlbC5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvbW9udGlhcG06YWdlbnQvbGliL21vZGVscy9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9tb250aWFwbTphZ2VudC9saWIvbW9kZWxzL3B1YnN1Yi5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvbW9udGlhcG06YWdlbnQvbGliL21vZGVscy9zeXN0ZW0uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL21vbnRpYXBtOmFnZW50L2xpYi9tb2RlbHMvZXJyb3JzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9tb250aWFwbTphZ2VudC9saWIvbW9kZWxzL2h0dHAuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL21vbnRpYXBtOmFnZW50L2xpYi9qb2JzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9tb250aWFwbTphZ2VudC9saWIvcmV0cnkuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL21vbnRpYXBtOmFnZW50L2xpYi91dGlscy5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvbW9udGlhcG06YWdlbnQvbGliL250cC5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvbW9udGlhcG06YWdlbnQvbGliL3NvdXJjZW1hcHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL21vbnRpYXBtOmFnZW50L2xpYi93YWl0X3RpbWVfYnVpbGRlci5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvbW9udGlhcG06YWdlbnQvbGliL2NoZWNrX2Zvcl9vcGxvZy5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvbW9udGlhcG06YWdlbnQvbGliL3RyYWNlci90cmFjZXIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL21vbnRpYXBtOmFnZW50L2xpYi90cmFjZXIvZGVmYXVsdF9maWx0ZXJzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9tb250aWFwbTphZ2VudC9saWIvdHJhY2VyL3RyYWNlcl9zdG9yZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvbW9udGlhcG06YWdlbnQvbGliL2RvY3NpemVfY2FjaGUuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL21vbnRpYXBtOmFnZW50L2xpYi9rYWRpcmEuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL21vbnRpYXBtOmFnZW50L2xpYi9oaWphY2svd3JhcF9zZXJ2ZXIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL21vbnRpYXBtOmFnZW50L2xpYi9oaWphY2svd3JhcF9zZXNzaW9uLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9tb250aWFwbTphZ2VudC9saWIvaGlqYWNrL3dyYXBfc3Vic2NyaXB0aW9uLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9tb250aWFwbTphZ2VudC9saWIvaGlqYWNrL3dyYXBfb2JzZXJ2ZXJzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9tb250aWFwbTphZ2VudC9saWIvaGlqYWNrL3dyYXBfZGRwX3N0cmluZ2lmeS5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvbW9udGlhcG06YWdlbnQvbGliL2hpamFjay9pbnN0cnVtZW50LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9tb250aWFwbTphZ2VudC9saWIvaGlqYWNrL2RiLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9tb250aWFwbTphZ2VudC9saWIvaGlqYWNrL2h0dHAuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL21vbnRpYXBtOmFnZW50L2xpYi9oaWphY2svZW1haWwuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL21vbnRpYXBtOmFnZW50L2xpYi9oaWphY2svYXN5bmMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL21vbnRpYXBtOmFnZW50L2xpYi9oaWphY2svZXJyb3IuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL21vbnRpYXBtOmFnZW50L2xpYi9oaWphY2svc2V0X2xhYmVscy5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvbW9udGlhcG06YWdlbnQvbGliL2hpamFjay9mYXN0X3JlbmRlci5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvbW9udGlhcG06YWdlbnQvbGliL2hpamFjay9mcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvbW9udGlhcG06YWdlbnQvbGliL2hpamFjay9nYy5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvbW9udGlhcG06YWdlbnQvbGliL2hpamFjay9tb25nby1kcml2ZXItZXZlbnRzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9tb250aWFwbTphZ2VudC9saWIvaGlqYWNrL3BpY2tlci5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvbW9udGlhcG06YWdlbnQvbGliL2hpamFjay93cmFwX3JvdXRlcnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL21vbnRpYXBtOmFnZW50L2xpYi9oaWphY2svd3JhcF93ZWJhcHAuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL21vbnRpYXBtOmFnZW50L2xpYi9lbnZpcm9ubWVudF92YXJpYWJsZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL21vbnRpYXBtOmFnZW50L2xpYi9hdXRvX2Nvbm5lY3QuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL21vbnRpYXBtOmFnZW50L2xpYi9jb25mbGljdGluZ19hZ2VudHMuanMiXSwibmFtZXMiOlsiZ2V0Q2xpZW50QXJjaFZlcnNpb24iLCJhcmNoIiwiYXV0b3VwZGF0ZSIsIl9fbWV0ZW9yX3J1bnRpbWVfY29uZmlnX18iLCJ2ZXJzaW9ucyIsInZlcnNpb24iLCJhdXRvdXBkYXRlVmVyc2lvbkNvcmRvdmEiLCJhdXRvdXBkYXRlVmVyc2lvbiIsIkthZGlyYSIsIm9wdGlvbnMiLCJNb250aSIsIk1ldGVvciIsIndyYXBBc3luYyIsIl93cmFwQXN5bmMiLCJpc1NlcnZlciIsIkV2ZW50RW1pdHRlciIsIk5wbSIsInJlcXVpcmUiLCJldmVudEJ1cyIsInNldE1heExpc3RlbmVycyIsImJ1aWxkQXJncyIsImFyZ3MiLCJldmVudE5hbWUiLCJzbGljZSIsInVuc2hpZnQiLCJFdmVudEJ1cyIsImZvckVhY2giLCJtIiwiYXBwbHkiLCJjb21tb25FcnJSZWdFeHBzIiwiZXJyb3JGaWx0ZXJzIiwiZmlsdGVyVmFsaWRhdGlvbkVycm9ycyIsInR5cGUiLCJtZXNzYWdlIiwiZXJyIiwiRXJyb3IiLCJmaWx0ZXJDb21tb25NZXRlb3JFcnJvcnMiLCJsYyIsImxlbmd0aCIsInJlZ0V4cCIsInRlc3QiLCJzZW5kIiwicGF5bG9hZCIsInBhdGgiLCJjYWxsYmFjayIsImNvbm5lY3RlZCIsInN1YnN0ciIsImVuZHBvaW50IiwicmV0cnlDb3VudCIsInJldHJ5IiwiUmV0cnkiLCJtaW5Db3VudCIsIm1pblRpbWVvdXQiLCJiYXNlVGltZW91dCIsIm1heFRpbWVvdXQiLCJzZW5kRnVuY3Rpb24iLCJfZ2V0U2VuZEZ1bmN0aW9uIiwidHJ5VG9TZW5kIiwicmV0cnlMYXRlciIsImNvbnNvbGUiLCJ3YXJuIiwicmVzIiwic3RhdHVzQ29kZSIsImRhdGEiLCJjb250ZW50IiwiX3NlcnZlclNlbmQiLCJfY2xpZW50U2VuZCIsImh0dHBSZXF1ZXN0IiwiaGVhZGVycyIsIkpTT04iLCJzdHJpbmdpZnkiLCJCYXNlRXJyb3JNb2RlbCIsIl9maWx0ZXJzIiwicHJvdG90eXBlIiwiYWRkRmlsdGVyIiwiZmlsdGVyIiwicHVzaCIsInJlbW92ZUZpbHRlciIsImluZGV4IiwiaW5kZXhPZiIsInNwbGljZSIsImFwcGx5RmlsdGVycyIsImVycm9yIiwic3ViVHlwZSIsInZhbGlkYXRlZCIsImV4IiwiS2FkaXJhTW9kZWwiLCJfZ2V0RGF0ZUlkIiwidGltZXN0YW1wIiwicmVtYWluZGVyIiwiZGF0ZUlkIiwiRERTa2V0Y2giLCJNRVRIT0RfTUVUUklDU19GSUVMRFMiLCJNZXRob2RzTW9kZWwiLCJtZXRyaWNzVGhyZXNob2xkIiwibWV0aG9kTWV0cmljc0J5TWludXRlIiwiT2JqZWN0IiwiY3JlYXRlIiwiZXJyb3JNYXAiLCJfbWV0cmljc1RocmVzaG9sZCIsIl8iLCJleHRlbmQiLCJtYXhFdmVudFRpbWVzRm9yTWV0aG9kcyIsInRyYWNlclN0b3JlIiwiVHJhY2VyU3RvcmUiLCJpbnRlcnZhbCIsIm1heFRvdGFsUG9pbnRzIiwiYXJjaGl2ZUV2ZXJ5Iiwic3RhcnQiLCJfZ2V0TWV0cmljcyIsIm1ldGhvZCIsIm1ldGhvZHMiLCJjb3VudCIsImVycm9ycyIsImZldGNoZWREb2NTaXplIiwic2VudE1zZ1NpemUiLCJoaXN0b2dyYW0iLCJhbHBoYSIsImZpZWxkIiwic2V0U3RhcnRUaW1lIiwibWV0cmljc0J5TWludXRlIiwic3RhcnRUaW1lIiwicHJvY2Vzc01ldGhvZCIsIm1ldGhvZFRyYWNlIiwiYXQiLCJfYXBwZW5kTWV0cmljcyIsImVycm9yZWQiLCJuYW1lIiwiYWRkVHJhY2UiLCJpZCIsIm1ldGhvZE1ldHJpY3MiLCJ2YWx1ZSIsIm1ldHJpY3MiLCJhZGQiLCJ0b3RhbCIsImVuZFRpbWUiLCJ0cmFja0RvY1NpemUiLCJzaXplIiwiTnRwIiwiX25vdyIsInRyYWNrTXNnU2l6ZSIsImJ1aWxkUGF5bG9hZCIsImJ1aWxkRGV0YWlsZWRJbmZvIiwibWV0aG9kUmVxdWVzdHMiLCJrZXkiLCJzeW5jZWREYXRlIiwic3luY1RpbWUiLCJtZXRob2ROYW1lIiwiY29sbGVjdFRyYWNlcyIsImxvZ2dlciIsIlB1YnN1Yk1vZGVsIiwic3Vic2NyaXB0aW9ucyIsIl90cmFja1N1YiIsInNlc3Npb24iLCJtc2ciLCJwYXJhbXMiLCJwdWJsaWNhdGlvbiIsIl9nZXRQdWJsaWNhdGlvbk5hbWUiLCJzdWJzY3JpcHRpb25JZCIsInN1YnMiLCJfc3RhcnRUaW1lIiwiX3RyYWNrVW5zdWIiLCJzdWIiLCJfc3Vic2NyaXB0aW9uSWQiLCJfbmFtZSIsInN1YnNjcmlwdGlvblN0YXRlIiwidW5zdWJzIiwibGlmZVRpbWUiLCJfdHJhY2tSZWFkeSIsInRyYWNlIiwicmVhZHlUcmFja2VkIiwicmVzVGltZSIsIl90cmFja0Vycm9yIiwicHVicyIsImFjdGl2ZVN1YnMiLCJhY3RpdmVEb2NzIiwidG90YWxPYnNlcnZlcnMiLCJjYWNoZWRPYnNlcnZlcnMiLCJjcmVhdGVkT2JzZXJ2ZXJzIiwiZGVsZXRlZE9ic2VydmVycyIsIm9ic2VydmVyTGlmZXRpbWUiLCJwb2xsZWREb2N1bWVudHMiLCJvcGxvZ1VwZGF0ZWREb2N1bWVudHMiLCJvcGxvZ0luc2VydGVkRG9jdW1lbnRzIiwib3Bsb2dEZWxldGVkRG9jdW1lbnRzIiwiaW5pdGlhbGx5QWRkZWREb2N1bWVudHMiLCJsaXZlQWRkZWREb2N1bWVudHMiLCJsaXZlQ2hhbmdlZERvY3VtZW50cyIsImxpdmVSZW1vdmVkRG9jdW1lbnRzIiwicG9sbGVkRG9jU2l6ZSIsImluaXRpYWxseUZldGNoZWREb2NTaXplIiwibGl2ZUZldGNoZWREb2NTaXplIiwiaW5pdGlhbGx5U2VudE1zZ1NpemUiLCJsaXZlU2VudE1zZ1NpemUiLCJfZ2V0U3Vic2NyaXB0aW9uSW5mbyIsInNlbGYiLCJ0b3RhbERvY3NTZW50IiwidG90YWxEYXRhU2VudCIsIml0ZXJhdGUiLCJzZXJ2ZXIiLCJzZXNzaW9ucyIsIl9uYW1lZFN1YnMiLCJjb3VudFN1YkRhdGEiLCJfdW5pdmVyc2FsU3VicyIsImF2Z09ic2VydmVyUmV1c2UiLCJlYWNoIiwiY291bnRTdWJzY3JpcHRpb25zIiwiY291bnREb2N1bWVudHMiLCJjb3VudE9ic2VydmVycyIsIl9kb2N1bWVudHMiLCJjb2xsZWN0aW9uIiwiY291bnRLZXlzIiwiX3RvdGFsT2JzZXJ2ZXJzIiwiX2NhY2hlZE9ic2VydmVycyIsImJ1aWxkRGV0YWlsSW5mbyIsInB1Yk1ldHJpY3MiLCJzdWJzY3JpcHRpb25EYXRhIiwiZGF0ZU1ldHJpY3MiLCJzaW5nbGVQdWJNZXRyaWNzIiwicHViUmVxdWVzdHMiLCJpbmNyZW1lbnRIYW5kbGVDb3VudCIsImlzQ2FjaGVkIiwicHVibGljYXRpb25OYW1lIiwiZ2V0UHJvcGVydHkiLCJ0cmFja0NyZWF0ZWRPYnNlcnZlciIsImluZm8iLCJ0cmFja0RlbGV0ZWRPYnNlcnZlciIsIkRhdGUiLCJnZXRUaW1lIiwidHJhY2tEb2N1bWVudENoYW5nZXMiLCJvcCIsInRyYWNrUG9sbGVkRG9jdW1lbnRzIiwidHJhY2tMaXZlVXBkYXRlcyIsImNyZWF0ZUhpc3RvZ3JhbSIsIm1vZHVsZSIsImxpbmsiLCJ2IiwiR0NNZXRyaWNzIiwiZGVmYXVsdCIsImdldEZpYmVyTWV0cmljcyIsInJlc2V0RmliZXJNZXRyaWNzIiwiZ2V0TW9uZ29Ecml2ZXJTdGF0cyIsInJlc2V0TW9uZ29Ecml2ZXJTdGF0cyIsIkV2ZW50TG9vcE1vbml0b3IiLCJTeXN0ZW1Nb2RlbCIsIm5ld1Nlc3Npb25zIiwic2Vzc2lvblRpbWVvdXQiLCJldmxvb3BIaXN0b2dyYW0iLCJldmxvb3BNb25pdG9yIiwib24iLCJsYWciLCJnY01ldHJpY3MiLCJjcHVUaW1lIiwicHJvY2VzcyIsImhydGltZSIsInByZXZpb3VzQ3B1VXNhZ2UiLCJjcHVVc2FnZSIsImNwdUhpc3RvcnkiLCJjdXJyZW50Q3B1VXNhZ2UiLCJzZXRJbnRlcnZhbCIsIm5vdyIsIm1lbW9yeVVzYWdlIiwibWVtb3J5IiwicnNzIiwibWVtb3J5QXJyYXlCdWZmZXJzIiwiYXJyYXlCdWZmZXJzIiwibWVtb3J5RXh0ZXJuYWwiLCJleHRlcm5hbCIsIm1lbW9yeUhlYXBVc2VkIiwiaGVhcFVzZWQiLCJtZW1vcnlIZWFwVG90YWwiLCJoZWFwVG90YWwiLCJhY3RpdmVSZXF1ZXN0cyIsIl9nZXRBY3RpdmVSZXF1ZXN0cyIsImFjdGl2ZUhhbmRsZXMiLCJfZ2V0QWN0aXZlSGFuZGxlcyIsInBjdEV2bG9vcEJsb2NrIiwic3RhdHVzIiwicGN0QmxvY2siLCJnY01ham9yRHVyYXRpb24iLCJnY01ham9yIiwiZ2NNaW5vckR1cmF0aW9uIiwiZ2NNaW5vciIsImdjSW5jcmVtZW50YWxEdXJhdGlvbiIsImdjSW5jcmVtZW50YWwiLCJnY1dlYWtDQkR1cmF0aW9uIiwiZ2NXZWFrQ0IiLCJyZXNldCIsImRyaXZlck1ldHJpY3MiLCJtb25nb1Bvb2xTaXplIiwicG9vbFNpemUiLCJtb25nb1Bvb2xQcmltYXJ5Q2hlY2tvdXRzIiwicHJpbWFyeUNoZWNrb3V0cyIsIm1vbmdvUG9vbE90aGVyQ2hlY2tvdXRzIiwib3RoZXJDaGVja291dHMiLCJtb25nb1Bvb2xDaGVja291dFRpbWUiLCJjaGVja291dFRpbWUiLCJtb25nb1Bvb2xNYXhDaGVja291dFRpbWUiLCJtYXhDaGVja291dFRpbWUiLCJtb25nb1Bvb2xQZW5kaW5nIiwicGVuZGluZyIsIm1vbmdvUG9vbENoZWNrZWRPdXRDb25uZWN0aW9ucyIsImNoZWNrZWRPdXQiLCJtb25nb1Bvb2xDcmVhdGVkQ29ubmVjdGlvbnMiLCJjcmVhdGVkIiwiZmliZXJNZXRyaWNzIiwiY3JlYXRlZEZpYmVycyIsImFjdGl2ZUZpYmVycyIsImFjdGl2ZSIsImZpYmVyUG9vbFNpemUiLCJwY3B1IiwicGNwdVVzZXIiLCJwY3B1U3lzdGVtIiwibGFzdENwdVVzYWdlIiwidXNhZ2UiLCJ1c2VyIiwic3lzIiwibWFwIiwiZW50cnkiLCJ0aW1lIiwic3lzdGVtTWV0cmljcyIsImhydGltZVRvTVMiLCJlbGFwVGltZU1TIiwiZWxhcFVzYWdlIiwiZWxhcFVzZXJNUyIsImVsYXBTeXN0TVMiLCJzeXN0ZW0iLCJ0b3RhbFVzYWdlTVMiLCJ0b3RhbFVzYWdlUGVyY2VudCIsImRvY1N6Q2FjaGUiLCJzZXRQY3B1IiwiaGFuZGxlU2Vzc2lvbkFjdGl2aXR5IiwiY291bnROZXdTZXNzaW9uIiwiaXNTZXNzaW9uQWN0aXZlIiwiX2FjdGl2ZUF0IiwiaXNMb2NhbEFkZHJlc3MiLCJzb2NrZXQiLCJpbmFjdGl2ZVRpbWUiLCJpc0xvY2FsSG9zdFJlZ2V4IiwiaXNMb2NhbEFkZHJlc3NSZWdleCIsImhvc3QiLCJhZGRyZXNzIiwicmVtb3RlQWRkcmVzcyIsIkVycm9yTW9kZWwiLCJhcHBJZCIsImNhbGwiLCJtYXhFcnJvcnMiLCJhc3NpZ24iLCJ2YWx1ZXMiLCJtZXRyaWMiLCJlcnJvckNvdW50IiwidHJhY2tFcnJvciIsImVycm9yRGVmIiwiX2Zvcm1hdEVycm9yIiwic3RhY2siLCJkZXRhaWxzIiwiZXJyb3JFdmVudCIsImV2ZW50cyIsImVycm9yT2JqZWN0Iiwic3RhY2tzIiwiSHR0cE1vZGVsIiwicHJvY2Vzc1JlcXVlc3QiLCJyZXEiLCJyb3V0ZUlkIiwicm91dGVzIiwic3RhdHVzQ29kZXMiLCJyZXF1ZXN0TWV0cmljcyIsInN0YXR1c01ldHJpYyIsImh0dHBNZXRyaWNzIiwiaHR0cFJlcXVlc3RzIiwicmVxdWVzdE5hbWUiLCJleHBvcnREZWZhdWx0IiwiSm9icyIsImdldEFzeW5jIiwiY29yZUFwaSIsImdldEpvYiIsInRoZW4iLCJjYXRjaCIsInNldEFzeW5jIiwiY2hhbmdlcyIsInVwZGF0ZUpvYiIsInNldCIsImdldCIsImNvbnN0cnVjdG9yIiwiZXhwb25lbnQiLCJmdXp6IiwicmV0cnlUaW1lciIsImNsZWFyIiwiY2xlYXJUaW1lb3V0IiwiX3RpbWVvdXQiLCJ0aW1lb3V0IiwiTWF0aCIsIm1pbiIsInBvdyIsIlJhbmRvbSIsImZyYWN0aW9uIiwiY2VpbCIsImZuIiwic2V0VGltZW91dCIsImV4cG9ydCIsIkhhdmVBc3luY0NhbGxiYWNrIiwibGFzdEFyZyIsIlVuaXF1ZUlkIiwiRGVmYXVsdFVuaXF1ZUlkIiwiQ3JlYXRlVXNlclN0YWNrIiwic3BsaXQiLCJ0b1JlbW92ZSIsImpvaW4iLCJPcHRpbWl6ZWRBcHBseSIsImNvbnRleHQiLCJhIiwiZ2V0Q2xpZW50VmVyc2lvbnMiLCJvYmoiLCJNYXAiLCJTZXQiLCJrZXlzIiwiZ2V0TG9nZ2VyIiwic2V0RW5kcG9pbnQiLCJkaWZmIiwic3luY2VkIiwicmVTeW5jQ291bnQiLCJyZVN5bmMiLCJyb3VuZCIsImxvY2FsVGltZSIsInN5bmMiLCJjYWNoZURucyIsImFyZ3VtZW50cyIsImdldFNlcnZlclRpbWUiLCJjYWxjdWxhdGVUaW1lRGlmZiIsImNsaWVudFN0YXJ0VGltZSIsInNlcnZlclRpbWUiLCJuZXR3b3JrVGltZSIsInNlcnZlclN0YXJ0VGltZSIsIm5vUmV0cmllcyIsInBhcnNlSW50IiwicmFuZG9tIiwiY2FuTG9nS2FkaXJhIiwiX2xvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJsb2ciLCJ1cmwiLCJmcyIsImNsaWVudFBhdGhzIiwiX19tZXRlb3JfYm9vdHN0cmFwX18iLCJjb25maWdKc29uIiwiY2xpZW50QXJjaHMiLCJzZXJ2ZXJEaXIiLCJhYnNDbGllbnRQYXRocyIsInJlZHVjZSIsInJlc3VsdCIsInJlc29sdmUiLCJkaXJuYW1lIiwiaGFuZGxlQXBpUmVzcG9uc2UiLCJib2R5IiwidW5hdmFpbGFibGUiLCJwYXJzZSIsImUiLCJuZWVkZWRTb3VyY2VtYXBzIiwicHJvbWlzZXMiLCJzb3VyY2VtYXAiLCJ1cGxvYWRTb3VyY2VNYXBzIiwiZ2V0U291cmNlbWFwUGF0aCIsImZpbGUiLCJzb3VyY2VNYXBQYXRoIiwic2VuZFNvdXJjZW1hcCIsIlByb21pc2UiLCJhbGwiLCJzZW5kRGF0YSIsInVuYXZhaWxhYmxlU291cmNlbWFwcyIsInNvdXJjZW1hcFBhdGgiLCJzdHJlYW0iLCJjcmVhdGVSZWFkU3RyZWFtIiwiYXJjaFZlcnNpb24iLCJlbmNvZGVVUklDb21wb25lbnQiLCJzZW5kU3RyZWFtIiwicHJlcGFyZVBhdGgiLCJ1cmxQYXRoIiwicG9zaXgiLCJub3JtYWxpemUiLCJjaGVja0ZvckR5bmFtaWNJbXBvcnQiLCJmaWxlUGF0aCIsImFyY2hQYXRoIiwiZHluYW1pY1BhdGgiLCJzdGF0IiwicmVqZWN0IiwiY2xpZW50UHJvZ3JhbSIsIldlYkFwcCIsImNsaWVudFByb2dyYW1zIiwibWFuaWZlc3QiLCJmaWxlSW5mbyIsImZpbmQiLCJzdGFydHNXaXRoIiwic291cmNlTWFwIiwiV0FJVE9OX01FU1NBR0VfRklFTERTIiwiV2FpdFRpbWVCdWlsZGVyIiwiX3dhaXRMaXN0U3RvcmUiLCJfY3VycmVudFByb2Nlc3NpbmdNZXNzYWdlcyIsIl9tZXNzYWdlQ2FjaGUiLCJyZWdpc3RlciIsIm1zZ0lkIiwibWFpbktleSIsIl9nZXRNZXNzYWdlS2V5IiwiaW5RdWV1ZSIsInRvQXJyYXkiLCJ3YWl0TGlzdCIsIl9nZXRDYWNoZU1lc3NhZ2UiLCJjdXJyZW50bHlQcm9jZXNzaW5nTWVzc2FnZSIsImJ1aWxkIiwiZmlsdGVyZWRXYWl0TGlzdCIsIl9jbGVhbkNhY2hlTWVzc2FnZSIsImJpbmQiLCJzZXNzaW9uSWQiLCJjYWNoZWRNZXNzYWdlIiwicGljayIsIl9rZXkiLCJfcmVnaXN0ZXJlZCIsInRyYWNrV2FpdFRpbWUiLCJ1bmJsb2NrIiwic3RhcnRlZCIsInVuYmxvY2tlZCIsIndyYXBwZWRVbmJsb2NrIiwid2FpdFRpbWUiLCJPcGxvZ0NoZWNrIiwiXzA3MCIsImN1cnNvckRlc2NyaXB0aW9uIiwibGltaXQiLCJjb2RlIiwicmVhc29uIiwic29sdXRpb24iLCJleGlzdHMkIiwiYW55Iiwic2VsZWN0b3IiLCJvbmx5U2NhbGVycyIsIkNvbGxlY3Rpb24iLCJPYmplY3RJRCIsIl8wNzEiLCJtYXRjaGVyIiwiTWluaW1vbmdvIiwiTWF0Y2hlciIsImVudiIsIk1PTkdPX09QTE9HX1VSTCIsImRpc2FibGVPcGxvZyIsIl9kaXNhYmxlT3Bsb2ciLCJtaW5pTW9uZ29NYXRjaGVyIiwibWluaU1vbmdvU29ydGVyIiwiU29ydGVyIiwic29ydCIsInNvcnRlciIsImZpZWxkcyIsIkxvY2FsQ29sbGVjdGlvbiIsIl9jaGVja1N1cHBvcnRlZFByb2plY3Rpb24iLCJza2lwIiwid2hlcmUiLCJoYXNXaGVyZSIsImdlbyIsImhhc0dlb1F1ZXJ5IiwibGltaXRCdXROb1NvcnQiLCJvbGRlclZlcnNpb24iLCJkcml2ZXIiLCJjdXJzb3JTdXBwb3J0ZWQiLCJnaXRDaGVja291dCIsInJlbGVhc2UiLCJwcmVSdW5uaW5nTWF0Y2hlcnMiLCJnbG9iYWxNYXRjaGVycyIsInZlcnNpb25NYXRjaGVycyIsImNoZWNrV2h5Tm9PcGxvZyIsIm9ic2VydmVyRHJpdmVyIiwicnVuTWF0Y2hlcnMiLCJtZXRlb3JWZXJzaW9uIiwibWF0Y2hlckluZm8iLCJtYXRjaGVkIiwibWF0Y2hlckxpc3QiLCJldmVudExvZ2dlciIsIlJFUEVUSVRJVkVfRVZFTlRTIiwiVFJBQ0VfVFlQRVMiLCJNQVhfVFJBQ0VfRVZFTlRTIiwiVHJhY2VyIiwiX2ZpbHRlckZpZWxkcyIsIm1heEFycmF5SXRlbXNUb0ZpbHRlciIsInVzZXJJZCIsInRyYWNlSW5mbyIsIl9pZCIsImV2ZW50IiwibWV0YURhdGEiLCJsYXN0RXZlbnQiLCJnZXRMYXN0RXZlbnQiLCJpc0V2ZW50c1Byb2Nlc3NlZCIsImVuZEF0IiwibmVzdGVkIiwiX2FwcGx5RmlsdGVycyIsImV2ZW50U3RhY2tUcmFjZSIsImRpciIsImRlcHRoIiwibGFzdE5lc3RlZCIsImV2ZW50RW5kIiwiZW5kTGFzdEV2ZW50IiwiZm9yY2VkRW5kIiwiX2hhc1VzZWZ1bE5lc3RlZCIsImV2ZXJ5IiwiYnVpbGRFdmVudCIsImVsYXBzZWRUaW1lRm9yRXZlbnQiLCJidWlsdEV2ZW50IiwicHJldkVuZCIsImkiLCJuZXN0ZWRFdmVudCIsImNvbXB1dGVUaW1lIiwidW5kZWZpbmVkIiwiYnVpbGRUcmFjZSIsImZpcnN0RXZlbnQiLCJwcm9jZXNzZWRFdmVudHMiLCJ0b3RhbE5vbkNvbXB1dGUiLCJwcmV2RXZlbnQiLCJsYXN0RXZlbnREYXRhIiwicmVtb3ZlQ291bnQiLCJjb21wdXRlIiwiZmlsdGVyRm4iLCJyZWRhY3RGaWVsZCIsImV2ZW50VHlwZSIsImNsb25lIiwiX2FwcGx5T2JqZWN0RmlsdGVycyIsInRvRmlsdGVyIiwiZmlsdGVyT2JqZWN0IiwiY2xvbmVkIiwiQXJyYXkiLCJpc0FycmF5IiwidHJhY2VyIiwic3RyaXBTZW5zaXRpdmUiLCJ0eXBlc1RvU3RyaXAiLCJyZWNlaXZlclR5cGUiLCJzdHJpcHBlZFR5cGVzIiwiaXRlbSIsInN0cmlwU2Vuc2l0aXZlVGhvcm91Z2giLCJmaWVsZHNUb0tlZXAiLCJzdHJpcFNlbGVjdG9ycyIsImNvbGxlY3Rpb25MaXN0IiwiY29sbE1hcCIsImNvbGxOYW1lIiwiY29sbCIsIm1heFRvdGFscyIsImN1cnJlbnRNYXhUcmFjZSIsInRyYWNlQXJjaGl2ZSIsInByb2Nlc3NlZENudCIsImtpbmQiLCJFSlNPTiIsIl9oYW5kbGVFcnJvcnMiLCJ0cmFjZXMiLCJfdGltZW91dEhhbmRsZXIiLCJwcm9jZXNzVHJhY2VzIiwic3RvcCIsImNsZWFySW50ZXJ2YWwiLCJlcnJvcktleSIsImVycm9yZWRUcmFjZSIsImtpbmRzIiwiY3VycmVudE1heFRvdGFsIiwiZXhjZWVkaW5nUG9pbnRzIiwiYXJjaGl2ZURlZmF1bHQiLCJjYW5BcmNoaXZlIiwiX2lzVHJhY2VPdXRsaWVyIiwiZGF0YVNldCIsIl9pc091dGxpZXIiLCJkYXRhUG9pbnQiLCJtYXhNYWRaIiwibWVkaWFuIiwiX2dldE1lZGlhbiIsIm1hZCIsIl9jYWxjdWxhdGVNYWQiLCJtYWRaIiwiX2Z1bmNNZWRpYW5EZXZpYXRpb24iLCJzb3J0ZWREYXRhU2V0IiwiYiIsIl9waWNrUXVhcnRpbGUiLCJudW0iLCJwb3MiLCJtZWRpYW5EZXZpYXRpb25zIiwieCIsImFicyIsIl9nZXRNZWFuIiwiZGF0YVBvaW50cyIsInBvaW50IiwiTFJVIiwiY3J5cHRvIiwianNvblN0cmluZ2lmeSIsIkRvY1N6Q2FjaGUiLCJtYXhJdGVtcyIsIm1heFZhbHVlcyIsIml0ZW1zIiwibWF4IiwiZ2V0U2l6ZSIsInF1ZXJ5Iiwib3B0cyIsImdldEtleSIsIkRvY1N6Q2FjaGVJdGVtIiwibmVlZHNVcGRhdGUiLCJkb2MiLCJlbGVtZW50IiwiQnVmZmVyIiwiYnl0ZUxlbmd0aCIsImFkZERhdGEiLCJnZXRWYWx1ZSIsImdldEl0ZW1TY29yZSIsInVwZGF0ZWQiLCJzY29yZSIsImN1cnJlbnRUaW1lIiwidGltZVNpbmNlVXBkYXRlIiwic2hpZnQiLCJzb3J0TnVtYmVyIiwic29ydGVkIiwiaWR4IiwiZmxvb3IiLCJwYWNrYWdlTWFwIiwiaG9zdG5hbWUiLCJGaWJlcnMiLCJLYWRpcmFDb3JlIiwibW9kZWxzIiwiY3VycmVudFN1YiIsImthZGlyYUluZm8iLCJFbnZpcm9ubWVudFZhcmlhYmxlIiwid2FpdFRpbWVCdWlsZGVyIiwicHVic3ViIiwiaHR0cCIsImJ1aWxkSW50ZXJ2YWwiLCJfYnVpbGRQYXlsb2FkIiwiY29ubmVjdCIsImFwcFNlY3JldCIsInBheWxvYWRUaW1lb3V0IiwiY2xpZW50RW5naW5lU3luY0RlbGF5IiwidGhyZXNob2xkcyIsImlzSG9zdE5hbWVTZXQiLCJwcm94eSIsInJlY29yZElQQWRkcmVzcyIsImRvY3VtZW50U2l6ZUNhY2hlU2l6ZSIsImxhc3QiLCJlbmFibGVFcnJvclRyYWNraW5nIiwiaXNQcm9kdWN0aW9uIiwiYXV0aEhlYWRlcnMiLCJ0cmltIiwiYWdlbnRWZXJzaW9uIiwiX2NoZWNrQXV0aCIsIl9zZW5kQXBwU3RhdHMiLCJfc2NoZWR1bGVQYXlsb2FkU2VuZCIsImFkZEZpbHRlckZuIiwia2FkaXJhIiwiZGlzYWJsZUVycm9yVHJhY2tpbmciLCJzdGFydHVwIiwiVHJhY2tVbmNhdWdodEV4Y2VwdGlvbnMiLCJUcmFja1VuaGFuZGxlZFJlamVjdGlvbnMiLCJUcmFja01ldGVvckRlYnVnIiwicHVibGlzaCIsImFkZGVkIiwicmVhZHkiLCJjbGllbnRWZXJzaW9ucyIsIl9pc0RldGFpbGVkSW5mbyIsIl9jb3VudERhdGFTZW50IiwiX2RldGFpbEluZm9TZW50SW50ZXJ2YWwiLCJhcHBTdGF0cyIsInByb3RvY29sVmVyc2lvbiIsInBhY2thZ2VWZXJzaW9ucyIsIlBhY2thZ2UiLCJfc2VuZFBheWxvYWQiLCJydW4iLCJfZ2V0SW5mbyIsImN1cnJlbnRGaWJlciIsInVzZUVudmlyb25tZW50VmFyaWFibGUiLCJjdXJyZW50IiwiX19rYWRpcmFJbmZvIiwiX3NldEluZm8iLCJzdGFydENvbnRpbnVvdXNQcm9maWxpbmciLCJNb250aVByb2ZpbGVyIiwic3RhcnRDb250aW51b3VzIiwib25Qcm9maWxlIiwicHJvZmlsZSIsInByb2ZpbGVzIiwiaWdub3JlRXJyb3JUcmFja2luZyIsIl9za2lwS2FkaXJhIiwic3RhcnRFdmVudCIsImVuZEV2ZW50IiwiRmliZXIiLCJ3cmFwU2VydmVyIiwic2VydmVyUHJvdG8iLCJvcmlnaW5hbEhhbmRsZUNvbm5lY3QiLCJfaGFuZGxlQ29ubmVjdCIsIl9tZXRlb3JTZXNzaW9uIiwiZW1pdCIsIk1ldGVvckRlYnVnSWdub3JlIiwiTUFYX1BBUkFNU19MRU5HVEgiLCJ3cmFwU2Vzc2lvbiIsInNlc3Npb25Qcm90byIsIm9yaWdpbmFsUHJvY2Vzc01lc3NhZ2UiLCJwcm9jZXNzTWVzc2FnZSIsInN0cmluZ2lmaWVkUGFyYW1zIiwic3RhcnREYXRhIiwid2FpdEV2ZW50SWQiLCJfd2FpdEV2ZW50SWQiLCJvcmlnaW5hbE1ldGhvZEhhbmRsZXIiLCJwcm90b2NvbF9oYW5kbGVycyIsIndhaXRPbiIsInJlc3BvbnNlIiwid2l0aFZhbHVlIiwib3JnaW5hbFN1YkhhbmRsZXIiLCJvcmdpbmFsVW5TdWJIYW5kbGVyIiwidW5zdWIiLCJvcmlnaW5hbFNlbmQiLCJjdXJyZW50RXJyb3IiLCJtZXRob2RfaGFuZGxlcnMiLCJoYW5kbGVyIiwid3JhcE1ldGhvZEhhbmRlckZvckVycm9ycyIsIm9yaWdpbmFsTWV0ZW9yTWV0aG9kcyIsIm1ldGhvZE1hcCIsIm9yaWdpbmFsSGFuZGxlciIsInNvdXJjZSIsIndyYXBTdWJzY3JpcHRpb24iLCJzdWJzY3JpcHRpb25Qcm90byIsIm9yaWdpbmFsUnVuSGFuZGxlciIsIl9ydW5IYW5kbGVyIiwib3JpZ2luYWxSZWFkeSIsIl9hcG1SZWFkeVRyYWNrZWQiLCJfc2Vzc2lvbiIsIm9yaWdpbmFsRXJyb3IiLCJlcnJvckZvckFwbSIsIm9yaWdpbmFsRGVhY3RpdmF0ZSIsIl9kZWFjdGl2YXRlIiwiZnVuY05hbWUiLCJvcmlnaW5hbEZ1bmMiLCJjb2xsZWN0aW9uTmFtZSIsIndyYXBPcGxvZ09ic2VydmVEcml2ZXIiLCJwcm90byIsIm9yaWdpbmFsUHVibGlzaE5ld1Jlc3VsdHMiLCJfcHVibGlzaE5ld1Jlc3VsdHMiLCJuZXdSZXN1bHRzIiwibmV3QnVmZmVyIiwiX2N1cnNvckRlc2NyaXB0aW9uIiwiZG9jU2l6ZSIsIl9vd25lckluZm8iLCJfcG9sbGVkRG9jdW1lbnRzIiwiX2RvY1NpemUiLCJwb2xsZWRGZXRjaGVzIiwib3JpZ2luYWxIYW5kbGVPcGxvZ0VudHJ5UXVlcnlpbmciLCJfaGFuZGxlT3Bsb2dFbnRyeVF1ZXJ5aW5nIiwib3JpZ2luYWxIYW5kbGVPcGxvZ0VudHJ5U3RlYWR5T3JGZXRjaGluZyIsIl9oYW5kbGVPcGxvZ0VudHJ5U3RlYWR5T3JGZXRjaGluZyIsImZuTmFtZSIsIm9yaWdpbmFsRm4iLCJjIiwiX2xpdmVVcGRhdGVzQ291bnRzIiwiX2luaXRpYWxBZGRzIiwiaW5pdGlhbEZldGNoZXMiLCJvcmlnaW5hbFN0b3AiLCJ3cmFwUG9sbGluZ09ic2VydmVEcml2ZXIiLCJvcmlnaW5hbFBvbGxNb25nbyIsIl9wb2xsTW9uZ28iLCJfcmVzdWx0cyIsIl9tYXAiLCJfcG9sbGVkRG9jU2l6ZSIsIndyYXBNdWx0aXBsZXhlciIsIm9yaWdpbmFsSW5pdGFsQWRkIiwiYWRkSGFuZGxlQW5kU2VuZEluaXRpYWxBZGRzIiwiaGFuZGxlIiwiX2ZpcnN0SW5pdGlhbEFkZFRpbWUiLCJfd2FzTXVsdGlwbGV4ZXJSZWFkeSIsIl9yZWFkeSIsIl9xdWV1ZUxlbmd0aCIsIl9xdWV1ZSIsIl90YXNrSGFuZGxlcyIsIl9lbGFwc2VkUG9sbGluZ1RpbWUiLCJ3cmFwRm9yQ291bnRpbmdPYnNlcnZlcnMiLCJtb25nb0Nvbm5lY3Rpb25Qcm90byIsIk1ldGVvclgiLCJNb25nb0Nvbm5lY3Rpb24iLCJvcmlnaW5hbE9ic2VydmVDaGFuZ2VzIiwiX29ic2VydmVDaGFuZ2VzIiwib3JkZXJlZCIsImNhbGxiYWNrcyIsInJldCIsIl9tdWx0aXBsZXhlciIsIl9fa2FkaXJhVHJhY2tlZCIsIm93bmVySW5mbyIsIl9vYnNlcnZlRHJpdmVyIiwid3JhcFN0cmluZ2lmeUREUCIsIm9yaWdpbmFsU3RyaW5naWZ5RERQIiwiRERQQ29tbW9uIiwic3RyaW5naWZ5RERQIiwibXNnU3RyaW5nIiwibXNnU2l6ZSIsIndyYXBXZWJBcHAiLCJ3cmFwRmFzdFJlbmRlciIsIndyYXBGcyIsIndyYXBQaWNrZXIiLCJ3cmFwUm91dGVycyIsIndyYXBGaWJlcnMiLCJpbnN0cnVtZW50ZWQiLCJfc3RhcnRJbnN0cnVtZW50aW5nIiwib25SZWFkeSIsIlNlcnZlciIsIlNlc3Npb24iLCJTdWJzY3JpcHRpb24iLCJNb25nb09wbG9nRHJpdmVyIiwiTW9uZ29Qb2xsaW5nRHJpdmVyIiwiTXVsdGlwbGV4ZXIiLCJoaWphY2tEQk9wcyIsInNldExhYmVscyIsIm9yaWdpbmFsT3BlbiIsIk1vbmdvSW50ZXJuYWxzIiwiUmVtb3RlQ29sbGVjdGlvbkRyaXZlciIsIm9wZW4iLCJtb25nbyIsImdldFN5bmNyb25vdXNDdXJzb3IiLCJNb25nb0NvbGwiLCJNb25nbyIsImZpbmRPbmUiLCJjdXJzb3IiLCJmZXRjaCIsIl9zeW5jaHJvbm91c0N1cnNvciIsImZ1bmMiLCJtb2QiLCJ1cHNlcnQiLCJldmVudElkIiwiZW5kT3B0aW9ucyIsImFzeW5jIiwidXBkYXRlZERvY3MiLCJudW1iZXJBZmZlY3RlZCIsImluc2VydGVkSWQiLCJyZW1vdmVkRG9jcyIsImN1cnNvclByb3RvIiwiTW9uZ29DdXJzb3IiLCJjdXJzb3JPcHRpb25zIiwicHJldmlvdXNUcmFja05leHRPYmplY3QiLCJ0cmFja05leHRPYmplY3QiLCJlbmREYXRhIiwib3Bsb2ciLCJ3YXNNdWx0aXBsZXhlclJlYWR5IiwicXVldWVMZW5ndGgiLCJlbGFwc2VkUG9sbGluZ1RpbWUiLCJvYnNlcnZlckRyaXZlckNsYXNzIiwidXNlc09wbG9nIiwiX2NhY2hlIiwiZG9jcyIsIm5vT2ZDYWNoZWREb2NzIiwiaW5pdGlhbFBvbGxpbmdUaW1lIiwiX2xhc3RQb2xsVGltZSIsInJlYXNvbkluZm8iLCJub09wbG9nQ29kZSIsIm5vT3Bsb2dSZWFzb24iLCJub09wbG9nU29sdXRpb24iLCJkb2NzRmV0Y2hlZCIsIlN5bmNyb25vdXNDdXJzb3IiLCJvcmlnTmV4dE9iamVjdCIsIl9uZXh0T2JqZWN0Iiwic2hvdWxkVHJhY2siLCJvcmlnaW5hbENhbGwiLCJIVFRQIiwiRW1haWwiLCJFdmVudFN5bWJvbCIsIlN5bWJvbCIsIlN0YXJ0VHJhY2tlZCIsIndyYXBwZWQiLCJvcmlnaW5hbFlpZWxkIiwieWllbGQiLCJvcmlnaW5hbFJ1biIsIm9yaWdpbmFsVGhyb3dJbnRvIiwidGhyb3dJbnRvIiwiZW5zdXJlRmliZXJDb3VudGVkIiwiZmliZXIiLCJ2YWwiLCJhY3RpdmVGaWJlclRvdGFsIiwiYWN0aXZlRmliZXJDb3VudCIsInByZXZpb3VzVG90YWxDcmVhdGVkIiwiZmliZXJzQ3JlYXRlZCIsInByaW50RXJyb3JBbmRLaWxsIiwiX3RyYWNrZWQiLCJnZXRUcmFjZSIsInRpbWVyIiwidGhyb3dFcnJvciIsIm5leHRUaWNrIiwiZXhpdCIsIm9yaWdpbmFsTWV0ZW9yRGVidWciLCJfZGVidWciLCJpc0FyZ3MiLCJhbHJlYWR5VHJhY2tlZCIsImVycm9yTWVzc2FnZSIsInNlcGFyYXRvciIsImVuZHNXaXRoIiwia2FkaXJhX1Nlc3Npb25fc2VuZCIsIm9yaWdpbmFsU2VuZEFkZHMiLCJfc2VuZEFkZHMiLCJrYWRpcmFfTXVsdGlwbGV4ZXJfc2VuZEFkZHMiLCJvcmlnaW5hbE1vbmdvSW5zZXJ0IiwiX2luc2VydCIsImthZGlyYV9Nb25nb0Nvbm5lY3Rpb25faW5zZXJ0IiwiY2IiLCJvcmlnaW5hbE1vbmdvVXBkYXRlIiwiX3VwZGF0ZSIsImthZGlyYV9Nb25nb0Nvbm5lY3Rpb25fdXBkYXRlIiwib3JpZ2luYWxNb25nb1JlbW92ZSIsIl9yZW1vdmUiLCJrYWRpcmFfTW9uZ29Db25uZWN0aW9uX3JlbW92ZSIsIm9yaWdpbmFsUHVic3ViQWRkZWQiLCJzZW5kQWRkZWQiLCJrYWRpcmFfU2Vzc2lvbl9zZW5kQWRkZWQiLCJvcmlnaW5hbFB1YnN1YkNoYW5nZWQiLCJzZW5kQ2hhbmdlZCIsImthZGlyYV9TZXNzaW9uX3NlbmRDaGFuZ2VkIiwib3JpZ2luYWxQdWJzdWJSZW1vdmVkIiwic2VuZFJlbW92ZWQiLCJrYWRpcmFfU2Vzc2lvbl9zZW5kUmVtb3ZlZCIsIm9yaWdpbmFsQ3Vyc29yRm9yRWFjaCIsImthZGlyYV9DdXJzb3JfZm9yRWFjaCIsIm9yaWdpbmFsQ3Vyc29yTWFwIiwia2FkaXJhX0N1cnNvcl9tYXAiLCJvcmlnaW5hbEN1cnNvckZldGNoIiwia2FkaXJhX0N1cnNvcl9mZXRjaCIsIm9yaWdpbmFsQ3Vyc29yQ291bnQiLCJrYWRpcmFfQ3Vyc29yX2NvdW50Iiwib3JpZ2luYWxDdXJzb3JPYnNlcnZlQ2hhbmdlcyIsIm9ic2VydmVDaGFuZ2VzIiwia2FkaXJhX0N1cnNvcl9vYnNlcnZlQ2hhbmdlcyIsIm9yaWdpbmFsQ3Vyc29yT2JzZXJ2ZSIsIm9ic2VydmUiLCJrYWRpcmFfQ3Vyc29yX29ic2VydmUiLCJvcmlnaW5hbENyb3NzYmFyTGlzdGVuIiwiRERQU2VydmVyIiwiX0Nyb3NzYmFyIiwibGlzdGVuIiwia2FkaXJhX0Nyb3NzYmFyX2xpc3RlbiIsInRyaWdnZXIiLCJvcmlnaW5hbENyb3NzYmFyRmlyZSIsImZpcmUiLCJrYWRpcmFfQ3Jvc3NiYXJfZmlyZSIsIm5vdGlmaWNhdGlvbiIsIkZhc3RSZW5kZXIiLCJvcmlnUm91dGUiLCJyb3V0ZSIsIl9jYWxsYmFjayIsInN1Z2dlc3RlZFJvdXRlTmFtZSIsImhhbmRsZUVycm9yRXZlbnQiLCJ3cmFwQ2FsbGJhY2siLCJjcmVhdGVXcmFwcGVyIiwiZXZlbnRFbWl0dGVyIiwibGlzdGVuZXJDb3VudCIsInJlbW92ZUxpc3RlbmVyIiwiZnNLYWRpcmFJbmZvIiwib3JpZ2luYWxTdGF0Iiwib3JpZ2luYWxDcmVhdGVSZWFkU3RyZWFtIiwiUGVyZm9ybWFuY2VPYnNlcnZlciIsImNvbnN0YW50cyIsInBlcmZvcm1hbmNlIiwiX29ic2VydmVyIiwib2JzZXJ2ZXIiLCJsaXN0IiwiZ2V0RW50cmllcyIsIl9tYXBLaW5kVG9NZXRyaWMiLCJkdXJhdGlvbiIsImNsZWFyR0MiLCJlbnRyeVR5cGVzIiwiYnVmZmVyZWQiLCJnY0tpbmQiLCJOT0RFX1BFUkZPUk1BTkNFX0dDX01BSk9SIiwiTk9ERV9QRVJGT1JNQU5DRV9HQ19NSU5PUiIsIk5PREVfUEVSRk9STUFOQ0VfR0NfSU5DUkVNRU5UQUwiLCJOT0RFX1BFUkZPUk1BTkNFX0dDX1dFQUtDQiIsImNsaWVudCIsInNlcnZlclN0YXR1cyIsInRvdGFsQ2hlY2tvdXRUaW1lIiwibWVhc3VyZW1lbnRDb3VudCIsInBlbmRpbmdUb3RhbCIsImNoZWNrZWRPdXRUb3RhbCIsImdldFNlcnZlclN0YXR1cyIsImdldFByaW1hcnkiLCJERUZBVUxUX01BWF9QT09MX1NJWkUiLCJnZXRQb29sU2l6ZSIsInRvcG9sb2d5IiwicyIsIm1heFBvb2xTaXplIiwiX2NsaWVudCIsImRlZmF1bHRSZW1vdGVDb2xsZWN0aW9uRHJpdmVyIiwidXNlVW5pZmllZFRvcG9sb2d5IiwicHJpbWFyeURlc2NyaXB0aW9uIiwiZ2V0U2VydmVyRGVzY3JpcHRpb24iLCJwb29sIiwidG90YWxDb25uZWN0aW9ucyIsInRvdGFsQ29ubmVjdGlvbkNvdW50IiwiYXZhaWxhYmxlQ29ubmVjdGlvbnMiLCJhdmFpbGFibGVDb25uZWN0aW9uQ291bnQiLCJwcmltYXJ5IiwiZGVsZXRlIiwiY29ubmVjdGlvbklkIiwiY2hlY2tvdXREdXJhdGlvbiIsImRpc2FibGVDcmVhdGUiLCJsYXN0SXNNYXN0ZXIiLCJzZXJ2ZXJzIiwiZGVzY3JpcHRpb24iLCJQaWNrZXIiLCJvcmlnUHJvY2Vzc1JvdXRlIiwiX3Byb2Nlc3NSb3V0ZSIsImNvbm5lY3RSb3V0ZXMiLCJjb25uZWN0Um91dGUiLCJyb3V0ZXIiLCJvbGRBZGQiLCJjaGVja0hhbmRsZXJzSW5GaWJlciIsIldlYkFwcEludGVybmFscyIsIk1BWF9CT0RZX1NJWkUiLCJNQVhfU1RSSU5HSUZJRURfQk9EWV9TSVpFIiwiY2FuV3JhcFN0YXRpY0hhbmRsZXIiLCJzdGF0aWNGaWxlc0J5QXJjaCIsImhhbmRsZXJzTGVuZ3RoIiwicmF3Q29ubmVjdEhhbmRsZXJzIiwiaW5GaWJlciIsIm91dHNpZGVGaWJlciIsInVzZSIsIl9yZXEiLCJfcmVzIiwibmV4dCIsInBvcCIsIkluZm9TeW1ib2wiLCJwYXJzZVVybCIsInJlZ2lzdGVyQm9pbGVycGxhdGVEYXRhQ2FsbGJhY2siLCJyZXF1ZXN0IiwiaXNBcHBSb3V0ZSIsIm9yaWdDYXRlZ29yaXplUmVxdWVzdCIsImNhdGVnb3JpemVSZXF1ZXN0IiwicGF0aG5hbWUiLCJhc3luY0V2ZW50IiwiaXNTdGF0aWMiLCJpc0pzb24iLCJoYXNTbWFsbEJvZHkiLCJidWlsdCIsIndyYXBIYW5kbGVyIiwiZXJyb3JIYW5kbGVyIiwid3JhcHBlciIsIm5leHRDYWxsZWQiLCJ3cmFwcGVkTmV4dCIsInBvdGVudGlhbFByb21pc2UiLCJmaW5pc2hlZCIsIndyYXBDb25uZWN0IiwiYXBwIiwid3JhcFN0YWNrIiwib2xkVXNlIiwid3JhcHBlZEhhbmRsZXIiLCJhc3luY0FwcGx5IiwibWV0ZW9ySW50ZXJuYWxIYW5kbGVycyIsImNvbm5lY3RIYW5kbGVycyIsImNvbm5lY3RBcHAiLCJvbGRTdGF0aWNGaWxlc01pZGRsZXdhcmUiLCJzdGF0aWNGaWxlc01pZGRsZXdhcmUiLCJzdGF0aWNIYW5kbGVyIiwiX3N0YXRpY0ZpbGVzIiwibm9ybWFsaXplZFByZWZpeCIsInJlcGxhY2UiLCJfcGFyc2VFbnYiLCJub3JtYWxpemVkTmFtZSIsIl9vcHRpb25zIiwicGFyc2VyIiwic3RyIiwicGFyc2VCb29sIiwidG9Mb3dlckNhc2UiLCJwYXJzZVN0cmluZyIsIk1PTlRJX0FQUF9JRCIsIk1PTlRJX0FQUF9TRUNSRVQiLCJNT05USV9PUFRJT05TX0NMSUVOVF9FTkdJTkVfU1lOQ19ERUxBWSIsIk1PTlRJX09QVElPTlNfRVJST1JfRFVNUF9JTlRFUlZBTCIsIk1PTlRJX09QVElPTlNfTUFYX0VSUk9SU19QRVJfSU5URVJWQUwiLCJNT05USV9PUFRJT05TX0NPTExFQ1RfQUxMX1NUQUNLUyIsIk1PTlRJX09QVElPTlNfRU5BQkxFX0VSUk9SX1RSQUNLSU5HIiwiTU9OVElfT1BUSU9OU19FTkRQT0lOVCIsIk1PTlRJX09QVElPTlNfSE9TVE5BTUUiLCJNT05USV9PUFRJT05TX1BBWUxPQURfVElNRU9VVCIsIk1PTlRJX09QVElPTlNfUFJPWFkiLCJNT05USV9PUFRJT05TX0RPQ1VNRU5UX1NJWkVfQ0FDSEVfU0laRSIsIk1PTlRJX1VQTE9BRF9TT1VSQ0VfTUFQUyIsIk1PTlRJX1JFQ09SRF9JUF9BRERSRVNTIiwiTU9OVElfRVZFTlRfU1RBQ0tfVFJBQ0UiLCJfY29ubmVjdFdpdGhFbnYiLCJfY29ubmVjdFdpdGhTZXR0aW5ncyIsIm1vbnRpU2V0dGluZ3MiLCJzZXR0aW5ncyIsIm1vbnRpIiwiY29uZmxpY3RpbmdQYWNrYWdlcyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLG9CQUFvQixHQUFHLFVBQVVDLElBQVYsRUFBZ0I7QUFDckMsUUFBTUMsVUFBVSxHQUFHQyx5QkFBeUIsQ0FBQ0QsVUFBN0M7O0FBRUEsTUFBSUEsVUFBSixFQUFnQjtBQUNkLFdBQU9BLFVBQVUsQ0FBQ0UsUUFBWCxDQUFvQkgsSUFBcEIsSUFBNEJDLFVBQVUsQ0FBQ0UsUUFBWCxDQUFvQkgsSUFBcEIsRUFBMEJJLE9BQXRELEdBQWdFLE1BQXZFO0FBQ0QsR0FMb0MsQ0FPckM7OztBQUNBLFVBQVFKLElBQVI7QUFDRSxTQUFLLGFBQUw7QUFDRSxhQUFPRSx5QkFBeUIsQ0FBQ0csd0JBQWpDOztBQUNGLFNBQUssYUFBTDtBQUNBLFNBQUssb0JBQUw7QUFDRTtBQUNBLGFBQU9ILHlCQUF5QixDQUFDSSxpQkFBakM7O0FBRUY7QUFDRSxhQUFPLE1BQVA7QUFUSjtBQVdELENBbkJELEM7Ozs7Ozs7Ozs7O0FDQUFDLE1BQU0sR0FBRyxFQUFUO0FBQ0FBLE1BQU0sQ0FBQ0MsT0FBUCxHQUFpQixFQUFqQjtBQUVBQyxLQUFLLEdBQUdGLE1BQVI7O0FBRUEsSUFBR0csTUFBTSxDQUFDQyxTQUFWLEVBQXFCO0FBQ25CSixRQUFNLENBQUNLLFVBQVAsR0FBb0JGLE1BQU0sQ0FBQ0MsU0FBM0I7QUFDRCxDQUZELE1BRU87QUFDTEosUUFBTSxDQUFDSyxVQUFQLEdBQW9CRixNQUFNLENBQUNFLFVBQTNCO0FBQ0Q7O0FBRUQsSUFBR0YsTUFBTSxDQUFDRyxRQUFWLEVBQW9CO0FBQ2xCLE1BQUlDLFlBQVksR0FBR0MsR0FBRyxDQUFDQyxPQUFKLENBQVksUUFBWixFQUFzQkYsWUFBekM7O0FBQ0EsTUFBSUcsUUFBUSxHQUFHLElBQUlILFlBQUosRUFBZjtBQUNBRyxVQUFRLENBQUNDLGVBQVQsQ0FBeUIsQ0FBekI7O0FBRUEsTUFBSUMsU0FBUyxHQUFHLFVBQVNDLElBQVQsRUFBZTtBQUM3QixRQUFJQyxTQUFTLEdBQUdELElBQUksQ0FBQyxDQUFELENBQUosR0FBVSxHQUFWLEdBQWdCQSxJQUFJLENBQUMsQ0FBRCxDQUFwQztBQUNBLFFBQUlBLElBQUksR0FBR0EsSUFBSSxDQUFDRSxLQUFMLENBQVcsQ0FBWCxDQUFYO0FBQ0FGLFFBQUksQ0FBQ0csT0FBTCxDQUFhRixTQUFiO0FBQ0EsV0FBT0QsSUFBUDtBQUNELEdBTEQ7O0FBT0FiLFFBQU0sQ0FBQ2lCLFFBQVAsR0FBa0IsRUFBbEI7QUFDQSxHQUFDLElBQUQsRUFBTyxNQUFQLEVBQWUsZ0JBQWYsRUFBaUMsb0JBQWpDLEVBQXVEQyxPQUF2RCxDQUErRCxVQUFTQyxDQUFULEVBQVk7QUFDekVuQixVQUFNLENBQUNpQixRQUFQLENBQWdCRSxDQUFoQixJQUFxQixZQUFrQjtBQUFBLHdDQUFOTixJQUFNO0FBQU5BLFlBQU07QUFBQTs7QUFDckMsVUFBSUEsSUFBSSxHQUFHRCxTQUFTLENBQUNDLElBQUQsQ0FBcEI7QUFDQSxhQUFPSCxRQUFRLENBQUNTLENBQUQsQ0FBUixDQUFZQyxLQUFaLENBQWtCVixRQUFsQixFQUE0QkcsSUFBNUIsQ0FBUDtBQUNELEtBSEQ7QUFJRCxHQUxEO0FBTUQsQzs7Ozs7Ozs7Ozs7QUM5QkQsSUFBSVEsZ0JBQWdCLEdBQUcsQ0FDckIsbURBRHFCLEVBRXJCLG9CQUZxQixDQUF2QjtBQUtBckIsTUFBTSxDQUFDc0IsWUFBUCxHQUFzQjtBQUNwQkMsd0JBQXNCLEVBQUUsVUFBU0MsSUFBVCxFQUFlQyxPQUFmLEVBQXdCQyxHQUF4QixFQUE2QjtBQUNuRCxRQUFHQSxHQUFHLElBQUlBLEdBQUcsWUFBWXZCLE1BQU0sQ0FBQ3dCLEtBQWhDLEVBQXVDO0FBQ3JDLGFBQU8sS0FBUDtBQUNELEtBRkQsTUFFTztBQUNMLGFBQU8sSUFBUDtBQUNEO0FBQ0YsR0FQbUI7QUFTcEJDLDBCQUF3QixFQUFFLFVBQVNKLElBQVQsRUFBZUMsT0FBZixFQUF3QjtBQUNoRCxTQUFJLElBQUlJLEVBQUUsR0FBQyxDQUFYLEVBQWNBLEVBQUUsR0FBQ1IsZ0JBQWdCLENBQUNTLE1BQWxDLEVBQTBDRCxFQUFFLEVBQTVDLEVBQWdEO0FBQzlDLFVBQUlFLE1BQU0sR0FBR1YsZ0JBQWdCLENBQUNRLEVBQUQsQ0FBN0I7O0FBQ0EsVUFBR0UsTUFBTSxDQUFDQyxJQUFQLENBQVlQLE9BQVosQ0FBSCxFQUF5QjtBQUN2QixlQUFPLEtBQVA7QUFDRDtBQUNGOztBQUNELFdBQU8sSUFBUDtBQUNEO0FBakJtQixDQUF0QixDOzs7Ozs7Ozs7OztBQ0xBekIsTUFBTSxDQUFDaUMsSUFBUCxHQUFjLFVBQVVDLE9BQVYsRUFBbUJDLElBQW5CLEVBQXlCQyxRQUF6QixFQUFtQztBQUMvQyxNQUFHLENBQUNwQyxNQUFNLENBQUNxQyxTQUFYLEVBQXVCO0FBQ3JCLFVBQU0sSUFBSVYsS0FBSixDQUFVLGlFQUFWLENBQU47QUFDRDs7QUFFRFEsTUFBSSxHQUFJQSxJQUFJLENBQUNHLE1BQUwsQ0FBWSxDQUFaLEVBQWUsQ0FBZixLQUFxQixHQUF0QixHQUE0QixNQUFNSCxJQUFsQyxHQUF5Q0EsSUFBaEQ7QUFDQSxNQUFJSSxRQUFRLEdBQUd2QyxNQUFNLENBQUNDLE9BQVAsQ0FBZXNDLFFBQWYsR0FBMEJKLElBQXpDO0FBQ0EsTUFBSUssVUFBVSxHQUFHLENBQWpCO0FBQ0EsTUFBSUMsS0FBSyxHQUFHLElBQUlDLEtBQUosQ0FBVTtBQUNwQkMsWUFBUSxFQUFFLENBRFU7QUFFcEJDLGNBQVUsRUFBRSxDQUZRO0FBR3BCQyxlQUFXLEVBQUUsT0FBSyxDQUhFO0FBSXBCQyxjQUFVLEVBQUUsT0FBSztBQUpHLEdBQVYsQ0FBWjs7QUFPQSxNQUFJQyxZQUFZLEdBQUcvQyxNQUFNLENBQUNnRCxnQkFBUCxFQUFuQjs7QUFDQUMsV0FBUzs7QUFFVCxXQUFTQSxTQUFULENBQW1CdkIsR0FBbkIsRUFBd0I7QUFDdEIsUUFBR2MsVUFBVSxHQUFHLENBQWhCLEVBQW1CO0FBQ2pCQyxXQUFLLENBQUNTLFVBQU4sQ0FBaUJWLFVBQVUsRUFBM0IsRUFBK0JQLElBQS9CO0FBQ0QsS0FGRCxNQUVPO0FBQ0xrQixhQUFPLENBQUNDLElBQVIsQ0FBYSxnREFBYjtBQUNBLFVBQUdoQixRQUFILEVBQWFBLFFBQVEsQ0FBQ1YsR0FBRCxDQUFSO0FBQ2Q7QUFDRjs7QUFFRCxXQUFTTyxJQUFULEdBQWdCO0FBQ2RjLGdCQUFZLENBQUNSLFFBQUQsRUFBV0wsT0FBWCxFQUFvQixVQUFTUixHQUFULEVBQWMyQixHQUFkLEVBQW1CO0FBQ2pELFVBQUczQixHQUFHLElBQUksQ0FBQzJCLEdBQVgsRUFBZ0I7QUFDZEosaUJBQVMsQ0FBQ3ZCLEdBQUQsQ0FBVDtBQUNELE9BRkQsTUFFTyxJQUFHMkIsR0FBRyxDQUFDQyxVQUFKLElBQWtCLEdBQXJCLEVBQTBCO0FBQy9CLFlBQUdsQixRQUFILEVBQWFBLFFBQVEsQ0FBQyxJQUFELEVBQU9pQixHQUFHLENBQUNFLElBQVgsQ0FBUjtBQUNkLE9BRk0sTUFFQTtBQUNMLFlBQUduQixRQUFILEVBQWFBLFFBQVEsQ0FBQyxJQUFJakMsTUFBTSxDQUFDd0IsS0FBWCxDQUFpQjBCLEdBQUcsQ0FBQ0MsVUFBckIsRUFBaUNELEdBQUcsQ0FBQ0csT0FBckMsQ0FBRCxDQUFSO0FBQ2Q7QUFDRixLQVJXLENBQVo7QUFTRDtBQUNGLENBdENEOztBQXdDQXhELE1BQU0sQ0FBQ2dELGdCQUFQLEdBQTBCLFlBQVc7QUFDbkMsU0FBUTdDLE1BQU0sQ0FBQ0csUUFBUixHQUFtQk4sTUFBTSxDQUFDeUQsV0FBMUIsR0FBd0N6RCxNQUFNLENBQUMwRCxXQUF0RDtBQUNELENBRkQ7O0FBSUExRCxNQUFNLENBQUMwRCxXQUFQLEdBQXFCLFVBQVVuQixRQUFWLEVBQW9CTCxPQUFwQixFQUE2QkUsUUFBN0IsRUFBdUM7QUFDMUR1QixhQUFXLENBQUMsTUFBRCxFQUFTcEIsUUFBVCxFQUFtQjtBQUM1QnFCLFdBQU8sRUFBRTtBQUNQLHNCQUFnQjtBQURULEtBRG1CO0FBSTVCSixXQUFPLEVBQUVLLElBQUksQ0FBQ0MsU0FBTCxDQUFlNUIsT0FBZjtBQUptQixHQUFuQixFQUtSRSxRQUxRLENBQVg7QUFNRCxDQVBEOztBQVNBcEMsTUFBTSxDQUFDeUQsV0FBUCxHQUFxQixZQUFZO0FBQy9CLFFBQU0sSUFBSTlCLEtBQUosQ0FBVSwyREFBVixDQUFOO0FBQ0QsQ0FGRCxDOzs7Ozs7Ozs7OztBQ3JEQW9DLGNBQWMsR0FBRyxVQUFTOUQsT0FBVCxFQUFrQjtBQUNqQyxPQUFLK0QsUUFBTCxHQUFnQixFQUFoQjtBQUNELENBRkQ7O0FBSUFELGNBQWMsQ0FBQ0UsU0FBZixDQUF5QkMsU0FBekIsR0FBcUMsVUFBU0MsTUFBVCxFQUFpQjtBQUNwRCxNQUFHLE9BQU9BLE1BQVAsS0FBa0IsVUFBckIsRUFBaUM7QUFDL0IsU0FBS0gsUUFBTCxDQUFjSSxJQUFkLENBQW1CRCxNQUFuQjtBQUNELEdBRkQsTUFFTztBQUNMLFVBQU0sSUFBSXhDLEtBQUosQ0FBVSxpQ0FBVixDQUFOO0FBQ0Q7QUFDRixDQU5EOztBQVFBb0MsY0FBYyxDQUFDRSxTQUFmLENBQXlCSSxZQUF6QixHQUF3QyxVQUFTRixNQUFULEVBQWlCO0FBQ3ZELE1BQUlHLEtBQUssR0FBRyxLQUFLTixRQUFMLENBQWNPLE9BQWQsQ0FBc0JKLE1BQXRCLENBQVo7O0FBQ0EsTUFBR0csS0FBSyxJQUFJLENBQVosRUFBZTtBQUNiLFNBQUtOLFFBQUwsQ0FBY1EsTUFBZCxDQUFxQkYsS0FBckIsRUFBNEIsQ0FBNUI7QUFDRDtBQUNGLENBTEQ7O0FBT0FQLGNBQWMsQ0FBQ0UsU0FBZixDQUF5QlEsWUFBekIsR0FBd0MsVUFBU2pELElBQVQsRUFBZUMsT0FBZixFQUF3QmlELEtBQXhCLEVBQStCQyxPQUEvQixFQUF3QztBQUM5RSxPQUFJLElBQUk5QyxFQUFFLEdBQUMsQ0FBWCxFQUFjQSxFQUFFLEdBQUMsS0FBS21DLFFBQUwsQ0FBY2xDLE1BQS9CLEVBQXVDRCxFQUFFLEVBQXpDLEVBQTZDO0FBQzNDLFFBQUlzQyxNQUFNLEdBQUcsS0FBS0gsUUFBTCxDQUFjbkMsRUFBZCxDQUFiOztBQUNBLFFBQUk7QUFDRixVQUFJK0MsU0FBUyxHQUFHVCxNQUFNLENBQUMzQyxJQUFELEVBQU9DLE9BQVAsRUFBZ0JpRCxLQUFoQixFQUF1QkMsT0FBdkIsQ0FBdEI7QUFDQSxVQUFHLENBQUNDLFNBQUosRUFBZSxPQUFPLEtBQVA7QUFDaEIsS0FIRCxDQUdFLE9BQU9DLEVBQVAsRUFBVztBQUNYO0FBQ0E7QUFDQSxXQUFLYixRQUFMLENBQWNRLE1BQWQsQ0FBcUIzQyxFQUFyQixFQUF5QixDQUF6Qjs7QUFDQSxZQUFNLElBQUlGLEtBQUosQ0FBVSw4Q0FBVixFQUEwRGtELEVBQUUsQ0FBQ3BELE9BQTdELENBQU47QUFDRDtBQUNGOztBQUVELFNBQU8sSUFBUDtBQUNELENBZkQsQzs7Ozs7Ozs7Ozs7QUNuQkFxRCxXQUFXLEdBQUcsWUFBVyxDQUV4QixDQUZEOztBQUlBQSxXQUFXLENBQUNiLFNBQVosQ0FBc0JjLFVBQXRCLEdBQW1DLFVBQVNDLFNBQVQsRUFBb0I7QUFDckQsTUFBSUMsU0FBUyxHQUFHRCxTQUFTLElBQUksT0FBTyxFQUFYLENBQXpCO0FBQ0EsTUFBSUUsTUFBTSxHQUFHRixTQUFTLEdBQUdDLFNBQXpCO0FBQ0EsU0FBT0MsTUFBUDtBQUNELENBSkQsQzs7Ozs7Ozs7Ozs7QUNKQSxNQUFNO0FBQUVDO0FBQUYsSUFBZTFFLE9BQU8sQ0FBQyx1QkFBRCxDQUE1Qjs7QUFFQSxJQUFJMkUscUJBQXFCLEdBQUcsQ0FBQyxNQUFELEVBQVMsSUFBVCxFQUFlLE1BQWYsRUFBdUIsT0FBdkIsRUFBZ0MsT0FBaEMsRUFBeUMsU0FBekMsRUFBb0QsT0FBcEQsQ0FBNUI7O0FBRUFDLFlBQVksR0FBRyxVQUFVQyxnQkFBVixFQUE0QjtBQUN6QyxPQUFLQyxxQkFBTCxHQUE2QkMsTUFBTSxDQUFDQyxNQUFQLENBQWMsSUFBZCxDQUE3QjtBQUNBLE9BQUtDLFFBQUwsR0FBZ0JGLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjLElBQWQsQ0FBaEI7QUFFQSxPQUFLRSxpQkFBTCxHQUF5QkMsQ0FBQyxDQUFDQyxNQUFGLENBQVM7QUFDaEMsWUFBUSxHQUR3QjtBQUVoQyxVQUFNLEdBRjBCO0FBR2hDLFlBQVEsSUFId0I7QUFJaEMsYUFBUyxHQUp1QjtBQUtoQyxhQUFTLEdBTHVCO0FBTWhDLGVBQVcsR0FOcUI7QUFPaEMsYUFBUztBQVB1QixHQUFULEVBUXRCUCxnQkFBZ0IsSUFBSUUsTUFBTSxDQUFDQyxNQUFQLENBQWMsSUFBZCxDQVJFLENBQXpCLENBSnlDLENBY3pDOztBQUNBLE9BQUtLLHVCQUFMLEdBQStCTixNQUFNLENBQUNDLE1BQVAsQ0FBYyxJQUFkLENBQS9CO0FBRUEsT0FBS00sV0FBTCxHQUFtQixJQUFJQyxXQUFKLENBQWdCO0FBQ2pDQyxZQUFRLEVBQUUsT0FBTyxFQURnQjtBQUNaO0FBQ3JCQyxrQkFBYyxFQUFFLEVBRmlCO0FBRWI7QUFDcEJDLGdCQUFZLEVBQUUsQ0FIbUIsQ0FHakI7O0FBSGlCLEdBQWhCLENBQW5CO0FBTUEsT0FBS0osV0FBTCxDQUFpQkssS0FBakI7QUFDRCxDQXhCRDs7QUEwQkFSLENBQUMsQ0FBQ0MsTUFBRixDQUFTUixZQUFZLENBQUNwQixTQUF0QixFQUFpQ2EsV0FBVyxDQUFDYixTQUE3Qzs7QUFFQW9CLFlBQVksQ0FBQ3BCLFNBQWIsQ0FBdUJvQyxXQUF2QixHQUFxQyxVQUFTckIsU0FBVCxFQUFvQnNCLE1BQXBCLEVBQTRCO0FBQy9ELE1BQUlwQixNQUFNLEdBQUcsS0FBS0gsVUFBTCxDQUFnQkMsU0FBaEIsQ0FBYjs7QUFFQSxNQUFHLENBQUMsS0FBS08scUJBQUwsQ0FBMkJMLE1BQTNCLENBQUosRUFBd0M7QUFDdEMsU0FBS0sscUJBQUwsQ0FBMkJMLE1BQTNCLElBQXFDO0FBQ25DcUIsYUFBTyxFQUFFZixNQUFNLENBQUNDLE1BQVAsQ0FBYyxJQUFkO0FBRDBCLEtBQXJDO0FBR0Q7O0FBRUQsTUFBSWMsT0FBTyxHQUFHLEtBQUtoQixxQkFBTCxDQUEyQkwsTUFBM0IsRUFBbUNxQixPQUFqRCxDQVQrRCxDQVcvRDs7QUFDQSxNQUFHLENBQUNBLE9BQU8sQ0FBQ0QsTUFBRCxDQUFYLEVBQXFCO0FBQ25CQyxXQUFPLENBQUNELE1BQUQsQ0FBUCxHQUFrQjtBQUNoQkUsV0FBSyxFQUFFLENBRFM7QUFFaEJDLFlBQU0sRUFBRSxDQUZRO0FBR2hCQyxvQkFBYyxFQUFFLENBSEE7QUFJaEJDLGlCQUFXLEVBQUUsQ0FKRztBQUtoQkMsZUFBUyxFQUFFLElBQUl6QixRQUFKLENBQWE7QUFDdEIwQixhQUFLLEVBQUU7QUFEZSxPQUFiO0FBTEssS0FBbEI7QUFVQXpCLHlCQUFxQixDQUFDbEUsT0FBdEIsQ0FBOEIsVUFBUzRGLEtBQVQsRUFBZ0I7QUFDNUNQLGFBQU8sQ0FBQ0QsTUFBRCxDQUFQLENBQWdCUSxLQUFoQixJQUF5QixDQUF6QjtBQUNELEtBRkQ7QUFHRDs7QUFFRCxTQUFPLEtBQUt2QixxQkFBTCxDQUEyQkwsTUFBM0IsRUFBbUNxQixPQUFuQyxDQUEyQ0QsTUFBM0MsQ0FBUDtBQUNELENBN0JEOztBQStCQWpCLFlBQVksQ0FBQ3BCLFNBQWIsQ0FBdUI4QyxZQUF2QixHQUFzQyxVQUFTL0IsU0FBVCxFQUFvQjtBQUN4RCxPQUFLZ0MsZUFBTCxDQUFxQjlCLE1BQXJCLEVBQTZCK0IsU0FBN0IsR0FBeUNqQyxTQUF6QztBQUNELENBRkQ7O0FBSUFLLFlBQVksQ0FBQ3BCLFNBQWIsQ0FBdUJpRCxhQUF2QixHQUF1QyxVQUFTQyxXQUFULEVBQXNCO0FBQzNELE1BQUlqQyxNQUFNLEdBQUcsS0FBS0gsVUFBTCxDQUFnQm9DLFdBQVcsQ0FBQ0MsRUFBNUIsQ0FBYixDQUQyRCxDQUczRDs7O0FBQ0EsT0FBS0MsY0FBTCxDQUFvQm5DLE1BQXBCLEVBQTRCaUMsV0FBNUI7O0FBQ0EsTUFBR0EsV0FBVyxDQUFDRyxPQUFmLEVBQXdCO0FBQ3RCLFNBQUsvQixxQkFBTCxDQUEyQkwsTUFBM0IsRUFBbUNxQixPQUFuQyxDQUEyQ1ksV0FBVyxDQUFDSSxJQUF2RCxFQUE2RGQsTUFBN0Q7QUFDRDs7QUFFRCxPQUFLVixXQUFMLENBQWlCeUIsUUFBakIsQ0FBMEJMLFdBQTFCO0FBQ0QsQ0FWRDs7QUFZQTlCLFlBQVksQ0FBQ3BCLFNBQWIsQ0FBdUJvRCxjQUF2QixHQUF3QyxVQUFTSSxFQUFULEVBQWFOLFdBQWIsRUFBMEI7QUFDaEUsTUFBSU8sYUFBYSxHQUFHLEtBQUtyQixXQUFMLENBQWlCb0IsRUFBakIsRUFBcUJOLFdBQVcsQ0FBQ0ksSUFBakMsQ0FBcEIsQ0FEZ0UsQ0FHaEU7OztBQUNBLE1BQUcsQ0FBQyxLQUFLaEMscUJBQUwsQ0FBMkJrQyxFQUEzQixFQUErQlIsU0FBbkMsRUFBNkM7QUFDM0MsU0FBSzFCLHFCQUFMLENBQTJCa0MsRUFBM0IsRUFBK0JSLFNBQS9CLEdBQTJDRSxXQUFXLENBQUNDLEVBQXZEO0FBQ0QsR0FOK0QsQ0FRaEU7OztBQUNBaEMsdUJBQXFCLENBQUNsRSxPQUF0QixDQUE4QixVQUFTNEYsS0FBVCxFQUFnQjtBQUM1QyxRQUFJYSxLQUFLLEdBQUdSLFdBQVcsQ0FBQ1MsT0FBWixDQUFvQmQsS0FBcEIsQ0FBWjs7QUFDQSxRQUFHYSxLQUFLLEdBQUcsQ0FBWCxFQUFjO0FBQ1pELG1CQUFhLENBQUNaLEtBQUQsQ0FBYixJQUF3QmEsS0FBeEI7QUFDRDtBQUNGLEdBTEQ7QUFPQUQsZUFBYSxDQUFDbEIsS0FBZDtBQUNBa0IsZUFBYSxDQUFDZCxTQUFkLENBQXdCaUIsR0FBeEIsQ0FBNEJWLFdBQVcsQ0FBQ1MsT0FBWixDQUFvQkUsS0FBaEQ7QUFDQSxPQUFLdkMscUJBQUwsQ0FBMkJrQyxFQUEzQixFQUErQk0sT0FBL0IsR0FBeUNaLFdBQVcsQ0FBQ1MsT0FBWixDQUFvQlIsRUFBN0Q7QUFDRCxDQW5CRDs7QUFxQkEvQixZQUFZLENBQUNwQixTQUFiLENBQXVCK0QsWUFBdkIsR0FBc0MsVUFBUzFCLE1BQVQsRUFBaUIyQixJQUFqQixFQUF1QjtBQUMzRCxNQUFJakQsU0FBUyxHQUFHa0QsR0FBRyxDQUFDQyxJQUFKLEVBQWhCOztBQUNBLE1BQUlqRCxNQUFNLEdBQUcsS0FBS0gsVUFBTCxDQUFnQkMsU0FBaEIsQ0FBYjs7QUFFQSxNQUFJMEMsYUFBYSxHQUFHLEtBQUtyQixXQUFMLENBQWlCbkIsTUFBakIsRUFBeUJvQixNQUF6QixDQUFwQjs7QUFDQW9CLGVBQWEsQ0FBQ2hCLGNBQWQsSUFBZ0N1QixJQUFoQztBQUNELENBTkQ7O0FBUUE1QyxZQUFZLENBQUNwQixTQUFiLENBQXVCbUUsWUFBdkIsR0FBc0MsVUFBUzlCLE1BQVQsRUFBaUIyQixJQUFqQixFQUF1QjtBQUMzRCxNQUFJakQsU0FBUyxHQUFHa0QsR0FBRyxDQUFDQyxJQUFKLEVBQWhCOztBQUNBLE1BQUlqRCxNQUFNLEdBQUcsS0FBS0gsVUFBTCxDQUFnQkMsU0FBaEIsQ0FBYjs7QUFFQSxNQUFJMEMsYUFBYSxHQUFHLEtBQUtyQixXQUFMLENBQWlCbkIsTUFBakIsRUFBeUJvQixNQUF6QixDQUFwQjs7QUFDQW9CLGVBQWEsQ0FBQ2YsV0FBZCxJQUE2QnNCLElBQTdCO0FBQ0QsQ0FORDtBQVFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0E1QyxZQUFZLENBQUNwQixTQUFiLENBQXVCb0UsWUFBdkIsR0FBc0MsVUFBU0MsaUJBQVQsRUFBNEI7QUFDaEUsTUFBSXBHLE9BQU8sR0FBRztBQUNad0YsaUJBQWEsRUFBRSxFQURIO0FBRVphLGtCQUFjLEVBQUU7QUFGSixHQUFkLENBRGdFLENBTWhFOztBQUNBLE1BQUloRCxxQkFBcUIsR0FBRyxLQUFLQSxxQkFBakM7QUFDQSxPQUFLQSxxQkFBTCxHQUE2QkMsTUFBTSxDQUFDQyxNQUFQLENBQWMsSUFBZCxDQUE3QixDQVJnRSxDQVVoRTs7QUFDQSxPQUFJLElBQUkrQyxHQUFSLElBQWVqRCxxQkFBZixFQUFzQztBQUNwQyxRQUFJbUMsYUFBYSxHQUFHbkMscUJBQXFCLENBQUNpRCxHQUFELENBQXpDLENBRG9DLENBRXBDOztBQUNBLFFBQUl2QixTQUFTLEdBQUdTLGFBQWEsQ0FBQ1QsU0FBOUI7QUFDQVMsaUJBQWEsQ0FBQ1QsU0FBZCxHQUEwQmpILE1BQU0sQ0FBQ3lJLFVBQVAsQ0FBa0JDLFFBQWxCLENBQTJCekIsU0FBM0IsQ0FBMUI7O0FBRUEsU0FBSSxJQUFJMEIsVUFBUixJQUFzQmpCLGFBQWEsQ0FBQ25CLE9BQXBDLEVBQTZDO0FBQzNDbkIsMkJBQXFCLENBQUNsRSxPQUF0QixDQUE4QixVQUFTNEYsS0FBVCxFQUFnQjtBQUM1Q1kscUJBQWEsQ0FBQ25CLE9BQWQsQ0FBc0JvQyxVQUF0QixFQUFrQzdCLEtBQWxDLEtBQ0VZLGFBQWEsQ0FBQ25CLE9BQWQsQ0FBc0JvQyxVQUF0QixFQUFrQ25DLEtBRHBDO0FBRUQsT0FIRDtBQUlEOztBQUVEdEUsV0FBTyxDQUFDd0YsYUFBUixDQUFzQnRELElBQXRCLENBQTJCbUIscUJBQXFCLENBQUNpRCxHQUFELENBQWhEO0FBQ0QsR0F6QitELENBMkJoRTs7O0FBQ0F0RyxTQUFPLENBQUNxRyxjQUFSLEdBQXlCLEtBQUt4QyxXQUFMLENBQWlCNkMsYUFBakIsRUFBekI7QUFFQSxTQUFPMUcsT0FBUDtBQUNELENBL0JELEM7Ozs7Ozs7Ozs7O0FDMUhBLElBQUkyRyxNQUFNLEdBQUdySSxHQUFHLENBQUNDLE9BQUosQ0FBWSxPQUFaLEVBQXFCLGVBQXJCLENBQWI7O0FBQ0EsTUFBTTtBQUFFMEU7QUFBRixJQUFlMUUsT0FBTyxDQUFDLHVCQUFELENBQTVCOztBQUVBcUksV0FBVyxHQUFHLFlBQVc7QUFDdkIsT0FBSzlCLGVBQUwsR0FBdUJ4QixNQUFNLENBQUNDLE1BQVAsQ0FBYyxJQUFkLENBQXZCO0FBQ0EsT0FBS3NELGFBQUwsR0FBcUJ2RCxNQUFNLENBQUNDLE1BQVAsQ0FBYyxJQUFkLENBQXJCO0FBRUEsT0FBS00sV0FBTCxHQUFtQixJQUFJQyxXQUFKLENBQWdCO0FBQ2pDQyxZQUFRLEVBQUUsT0FBTyxFQURnQjtBQUNaO0FBQ3JCQyxrQkFBYyxFQUFFLEVBRmlCO0FBRWI7QUFDcEJDLGdCQUFZLEVBQUUsQ0FIbUIsQ0FHakI7O0FBSGlCLEdBQWhCLENBQW5CO0FBTUEsT0FBS0osV0FBTCxDQUFpQkssS0FBakI7QUFDRCxDQVhEOztBQWFBMEMsV0FBVyxDQUFDN0UsU0FBWixDQUFzQitFLFNBQXRCLEdBQWtDLFVBQVNDLE9BQVQsRUFBa0JDLEdBQWxCLEVBQXVCO0FBQ3ZETCxRQUFNLENBQUMsTUFBRCxFQUFTSSxPQUFPLENBQUN4QixFQUFqQixFQUFxQnlCLEdBQUcsQ0FBQ3pCLEVBQXpCLEVBQTZCeUIsR0FBRyxDQUFDM0IsSUFBakMsRUFBdUMyQixHQUFHLENBQUNDLE1BQTNDLENBQU47O0FBQ0EsTUFBSUMsV0FBVyxHQUFHLEtBQUtDLG1CQUFMLENBQXlCSCxHQUFHLENBQUMzQixJQUE3QixDQUFsQjs7QUFDQSxNQUFJK0IsY0FBYyxHQUFHSixHQUFHLENBQUN6QixFQUF6Qjs7QUFDQSxNQUFJekMsU0FBUyxHQUFHa0QsR0FBRyxDQUFDQyxJQUFKLEVBQWhCOztBQUNBLE1BQUlQLE9BQU8sR0FBRyxLQUFLdkIsV0FBTCxDQUFpQnJCLFNBQWpCLEVBQTRCb0UsV0FBNUIsQ0FBZDs7QUFFQXhCLFNBQU8sQ0FBQzJCLElBQVI7QUFDQSxPQUFLUixhQUFMLENBQW1CRyxHQUFHLENBQUN6QixFQUF2QixJQUE2QjtBQUMzQjtBQUNBO0FBQ0E7QUFDQVIsYUFBUyxFQUFFakMsU0FKZ0I7QUFLM0JvRSxlQUFXLEVBQUVBLFdBTGM7QUFNM0JELFVBQU0sRUFBRUQsR0FBRyxDQUFDQyxNQU5lO0FBTzNCMUIsTUFBRSxFQUFFeUIsR0FBRyxDQUFDekI7QUFQbUIsR0FBN0IsQ0FSdUQsQ0FrQnZEOztBQUNBd0IsU0FBTyxDQUFDTyxVQUFSLEdBQXFCUCxPQUFPLENBQUNPLFVBQVIsSUFBc0J4RSxTQUEzQztBQUNELENBcEJEOztBQXNCQVksQ0FBQyxDQUFDQyxNQUFGLENBQVNpRCxXQUFXLENBQUM3RSxTQUFyQixFQUFnQ2EsV0FBVyxDQUFDYixTQUE1Qzs7QUFFQTZFLFdBQVcsQ0FBQzdFLFNBQVosQ0FBc0J3RixXQUF0QixHQUFvQyxVQUFTUixPQUFULEVBQWtCUyxHQUFsQixFQUF1QjtBQUN6RGIsUUFBTSxDQUFDLFFBQUQsRUFBV0ksT0FBTyxDQUFDeEIsRUFBbkIsRUFBdUJpQyxHQUFHLENBQUNDLGVBQTNCLENBQU47O0FBQ0EsTUFBSVAsV0FBVyxHQUFHLEtBQUtDLG1CQUFMLENBQXlCSyxHQUFHLENBQUNFLEtBQTdCLENBQWxCOztBQUNBLE1BQUlOLGNBQWMsR0FBR0ksR0FBRyxDQUFDQyxlQUF6QjtBQUNBLE1BQUlFLGlCQUFpQixHQUFHLEtBQUtkLGFBQUwsQ0FBbUJPLGNBQW5CLENBQXhCO0FBRUEsTUFBSXJDLFNBQVMsR0FBRyxJQUFoQixDQU55RCxDQU96RDs7QUFDQSxNQUFHNEMsaUJBQUgsRUFBc0I7QUFDcEI1QyxhQUFTLEdBQUc0QyxpQkFBaUIsQ0FBQzVDLFNBQTlCO0FBQ0QsR0FGRCxNQUVPO0FBQ0w7QUFDQTtBQUNBQSxhQUFTLEdBQUdnQyxPQUFPLENBQUNPLFVBQXBCO0FBQ0QsR0Fkd0QsQ0FnQnpEOzs7QUFDQSxNQUFHdkMsU0FBSCxFQUFjO0FBQ1osUUFBSWpDLFNBQVMsR0FBR2tELEdBQUcsQ0FBQ0MsSUFBSixFQUFoQjs7QUFDQSxRQUFJUCxPQUFPLEdBQUcsS0FBS3ZCLFdBQUwsQ0FBaUJyQixTQUFqQixFQUE0Qm9FLFdBQTVCLENBQWQsQ0FGWSxDQUdaOzs7QUFDQSxRQUFHTSxHQUFHLENBQUNFLEtBQUosSUFBYSxJQUFoQixFQUFzQjtBQUNwQjtBQUNBO0FBQ0FoQyxhQUFPLENBQUNrQyxNQUFSO0FBQ0QsS0FSVyxDQVNaOzs7QUFDQWxDLFdBQU8sQ0FBQ21DLFFBQVIsSUFBb0IvRSxTQUFTLEdBQUdpQyxTQUFoQyxDQVZZLENBV1o7O0FBQ0EsV0FBTyxLQUFLOEIsYUFBTCxDQUFtQk8sY0FBbkIsQ0FBUDtBQUNEO0FBQ0YsQ0EvQkQ7O0FBaUNBUixXQUFXLENBQUM3RSxTQUFaLENBQXNCK0YsV0FBdEIsR0FBb0MsVUFBU2YsT0FBVCxFQUFrQlMsR0FBbEIsRUFBdUJPLEtBQXZCLEVBQThCO0FBQ2hFcEIsUUFBTSxDQUFDLFFBQUQsRUFBV0ksT0FBTyxDQUFDeEIsRUFBbkIsRUFBdUJpQyxHQUFHLENBQUNDLGVBQTNCLENBQU4sQ0FEZ0UsQ0FFaEU7O0FBQ0EsTUFBSVAsV0FBVyxHQUFHLEtBQUtDLG1CQUFMLENBQXlCSyxHQUFHLENBQUNFLEtBQTdCLENBQWxCOztBQUNBLE1BQUlOLGNBQWMsR0FBR0ksR0FBRyxDQUFDQyxlQUF6Qjs7QUFDQSxNQUFJM0UsU0FBUyxHQUFHa0QsR0FBRyxDQUFDQyxJQUFKLEVBQWhCOztBQUNBLE1BQUlQLE9BQU8sR0FBRyxLQUFLdkIsV0FBTCxDQUFpQnJCLFNBQWpCLEVBQTRCb0UsV0FBNUIsQ0FBZDs7QUFFQSxNQUFJUyxpQkFBaUIsR0FBRyxLQUFLZCxhQUFMLENBQW1CTyxjQUFuQixDQUF4Qjs7QUFDQSxNQUFHTyxpQkFBaUIsSUFBSSxDQUFDQSxpQkFBaUIsQ0FBQ0ssWUFBM0MsRUFBeUQ7QUFDdkQsUUFBSUMsT0FBTyxHQUFHbkYsU0FBUyxHQUFHNkUsaUJBQWlCLENBQUM1QyxTQUE1QztBQUNBVyxXQUFPLENBQUN1QyxPQUFSLElBQW1CQSxPQUFuQjtBQUNBTixxQkFBaUIsQ0FBQ0ssWUFBbEIsR0FBaUMsSUFBakM7QUFDQXRDLFdBQU8sQ0FBQ2hCLFNBQVIsQ0FBa0JpQixHQUFsQixDQUFzQnNDLE9BQXRCO0FBQ0Q7O0FBRUQsTUFBR0YsS0FBSCxFQUFVO0FBQ1IsU0FBS2xFLFdBQUwsQ0FBaUJ5QixRQUFqQixDQUEwQnlDLEtBQTFCO0FBQ0Q7QUFDRixDQW5CRDs7QUFxQkFuQixXQUFXLENBQUM3RSxTQUFaLENBQXNCbUcsV0FBdEIsR0FBb0MsVUFBU25CLE9BQVQsRUFBa0JTLEdBQWxCLEVBQXVCTyxLQUF2QixFQUE4QjtBQUNoRXBCLFFBQU0sQ0FBQyxRQUFELEVBQVdJLE9BQU8sQ0FBQ3hCLEVBQW5CLEVBQXVCaUMsR0FBRyxDQUFDQyxlQUEzQixDQUFOLENBRGdFLENBRWhFOztBQUNBLE1BQUlQLFdBQVcsR0FBRyxLQUFLQyxtQkFBTCxDQUF5QkssR0FBRyxDQUFDRSxLQUE3QixDQUFsQjs7QUFDQSxNQUFJTixjQUFjLEdBQUdJLEdBQUcsQ0FBQ0MsZUFBekI7O0FBQ0EsTUFBSTNFLFNBQVMsR0FBR2tELEdBQUcsQ0FBQ0MsSUFBSixFQUFoQjs7QUFDQSxNQUFJUCxPQUFPLEdBQUcsS0FBS3ZCLFdBQUwsQ0FBaUJyQixTQUFqQixFQUE0Qm9FLFdBQTVCLENBQWQ7O0FBRUF4QixTQUFPLENBQUNuQixNQUFSOztBQUVBLE1BQUd3RCxLQUFILEVBQVU7QUFDUixTQUFLbEUsV0FBTCxDQUFpQnlCLFFBQWpCLENBQTBCeUMsS0FBMUI7QUFDRDtBQUNGLENBYkQ7O0FBZUFuQixXQUFXLENBQUM3RSxTQUFaLENBQXNCb0MsV0FBdEIsR0FBb0MsVUFBU3JCLFNBQVQsRUFBb0JvRSxXQUFwQixFQUFpQztBQUNuRSxNQUFJbEUsTUFBTSxHQUFHLEtBQUtILFVBQUwsQ0FBZ0JDLFNBQWhCLENBQWI7O0FBRUEsTUFBRyxDQUFDLEtBQUtnQyxlQUFMLENBQXFCOUIsTUFBckIsQ0FBSixFQUFrQztBQUNoQyxTQUFLOEIsZUFBTCxDQUFxQjlCLE1BQXJCLElBQStCO0FBQzdCO0FBQ0ErQixlQUFTLEVBQUVqQyxTQUZrQjtBQUc3QnFGLFVBQUksRUFBRTdFLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjLElBQWQ7QUFIdUIsS0FBL0I7QUFLRDs7QUFFRCxNQUFHLENBQUMsS0FBS3VCLGVBQUwsQ0FBcUI5QixNQUFyQixFQUE2Qm1GLElBQTdCLENBQWtDakIsV0FBbEMsQ0FBSixFQUFvRDtBQUNsRCxTQUFLcEMsZUFBTCxDQUFxQjlCLE1BQXJCLEVBQTZCbUYsSUFBN0IsQ0FBa0NqQixXQUFsQyxJQUFpRDtBQUMvQ0csVUFBSSxFQUFFLENBRHlDO0FBRS9DTyxZQUFNLEVBQUUsQ0FGdUM7QUFHL0NLLGFBQU8sRUFBRSxDQUhzQztBQUkvQ0csZ0JBQVUsRUFBRSxDQUptQztBQUsvQ0MsZ0JBQVUsRUFBRSxDQUxtQztBQU0vQ1IsY0FBUSxFQUFFLENBTnFDO0FBTy9DUyxvQkFBYyxFQUFFLENBUCtCO0FBUS9DQyxxQkFBZSxFQUFFLENBUjhCO0FBUy9DQyxzQkFBZ0IsRUFBRSxDQVQ2QjtBQVUvQ0Msc0JBQWdCLEVBQUUsQ0FWNkI7QUFXL0NsRSxZQUFNLEVBQUUsQ0FYdUM7QUFZL0NtRSxzQkFBZ0IsRUFBRSxDQVo2QjtBQWEvQ0MscUJBQWUsRUFBRSxDQWI4QjtBQWMvQ0MsMkJBQXFCLEVBQUUsQ0Fkd0I7QUFlL0NDLDRCQUFzQixFQUFFLENBZnVCO0FBZ0IvQ0MsMkJBQXFCLEVBQUUsQ0FoQndCO0FBaUIvQ0MsNkJBQXVCLEVBQUUsQ0FqQnNCO0FBa0IvQ0Msd0JBQWtCLEVBQUUsQ0FsQjJCO0FBbUIvQ0MsMEJBQW9CLEVBQUUsQ0FuQnlCO0FBb0IvQ0MsMEJBQW9CLEVBQUUsQ0FwQnlCO0FBcUIvQ0MsbUJBQWEsRUFBRSxDQXJCZ0M7QUFzQi9DM0Usb0JBQWMsRUFBRSxDQXRCK0I7QUF1Qi9DNEUsNkJBQXVCLEVBQUUsQ0F2QnNCO0FBd0IvQ0Msd0JBQWtCLEVBQUUsQ0F4QjJCO0FBeUIvQ0MsMEJBQW9CLEVBQUUsQ0F6QnlCO0FBMEIvQ0MscUJBQWUsRUFBRSxDQTFCOEI7QUEyQi9DN0UsZUFBUyxFQUFFLElBQUl6QixRQUFKLENBQWE7QUFDdEIwQixhQUFLLEVBQUU7QUFEZSxPQUFiO0FBM0JvQyxLQUFqRDtBQStCRDs7QUFFRCxTQUFPLEtBQUtHLGVBQUwsQ0FBcUI5QixNQUFyQixFQUE2Qm1GLElBQTdCLENBQWtDakIsV0FBbEMsQ0FBUDtBQUNELENBOUNEOztBQWdEQU4sV0FBVyxDQUFDN0UsU0FBWixDQUFzQm9GLG1CQUF0QixHQUE0QyxVQUFTOUIsSUFBVCxFQUFlO0FBQ3pELFNBQU9BLElBQUksSUFBSSxtQkFBZjtBQUNELENBRkQ7O0FBSUF1QixXQUFXLENBQUM3RSxTQUFaLENBQXNCeUgsb0JBQXRCLEdBQTZDLFlBQVc7QUFDdEQsTUFBSUMsSUFBSSxHQUFHLElBQVg7QUFDQSxNQUFJckIsVUFBVSxHQUFHOUUsTUFBTSxDQUFDQyxNQUFQLENBQWMsSUFBZCxDQUFqQjtBQUNBLE1BQUk4RSxVQUFVLEdBQUcvRSxNQUFNLENBQUNDLE1BQVAsQ0FBYyxJQUFkLENBQWpCO0FBQ0EsTUFBSW1HLGFBQWEsR0FBR3BHLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjLElBQWQsQ0FBcEI7QUFDQSxNQUFJb0csYUFBYSxHQUFHckcsTUFBTSxDQUFDQyxNQUFQLENBQWMsSUFBZCxDQUFwQjtBQUNBLE1BQUkrRSxjQUFjLEdBQUdoRixNQUFNLENBQUNDLE1BQVAsQ0FBYyxJQUFkLENBQXJCO0FBQ0EsTUFBSWdGLGVBQWUsR0FBR2pGLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjLElBQWQsQ0FBdEI7QUFFQXFHLFNBQU8sQ0FBQzNMLE1BQU0sQ0FBQzRMLE1BQVAsQ0FBY0MsUUFBZixFQUF5Qi9DLE9BQU8sSUFBSTtBQUN6QzZDLFdBQU8sQ0FBQzdDLE9BQU8sQ0FBQ2dELFVBQVQsRUFBcUJDLFlBQXJCLENBQVA7QUFDQUosV0FBTyxDQUFDN0MsT0FBTyxDQUFDa0QsY0FBVCxFQUF5QkQsWUFBekIsQ0FBUDtBQUNELEdBSE0sQ0FBUDtBQUtBLE1BQUlFLGdCQUFnQixHQUFHNUcsTUFBTSxDQUFDQyxNQUFQLENBQWMsSUFBZCxDQUF2Qjs7QUFDQUcsR0FBQyxDQUFDeUcsSUFBRixDQUFPN0IsY0FBUCxFQUF1QixVQUFTN0MsS0FBVCxFQUFnQnlCLFdBQWhCLEVBQTZCO0FBQ2xEZ0Qsb0JBQWdCLENBQUNoRCxXQUFELENBQWhCLEdBQWdDcUIsZUFBZSxDQUFDckIsV0FBRCxDQUFmLEdBQStCb0IsY0FBYyxDQUFDcEIsV0FBRCxDQUE3RTtBQUNELEdBRkQ7O0FBSUEsU0FBTztBQUNMa0IsY0FBVSxFQUFFQSxVQURQO0FBRUxDLGNBQVUsRUFBRUEsVUFGUDtBQUdMNkIsb0JBQWdCLEVBQUVBO0FBSGIsR0FBUDs7QUFNQSxXQUFTRixZQUFULENBQXVCeEMsR0FBdkIsRUFBNEI7QUFDMUIsUUFBSU4sV0FBVyxHQUFHdUMsSUFBSSxDQUFDdEMsbUJBQUwsQ0FBeUJLLEdBQUcsQ0FBQ0UsS0FBN0IsQ0FBbEI7O0FBQ0EwQyxzQkFBa0IsQ0FBQzVDLEdBQUQsRUFBTU4sV0FBTixDQUFsQjtBQUNBbUQsa0JBQWMsQ0FBQzdDLEdBQUQsRUFBTU4sV0FBTixDQUFkO0FBQ0FvRCxrQkFBYyxDQUFDOUMsR0FBRCxFQUFNTixXQUFOLENBQWQ7QUFDRDs7QUFFRCxXQUFTa0Qsa0JBQVQsQ0FBNkI1QyxHQUE3QixFQUFrQ04sV0FBbEMsRUFBK0M7QUFDN0NrQixjQUFVLENBQUNsQixXQUFELENBQVYsR0FBMEJrQixVQUFVLENBQUNsQixXQUFELENBQVYsSUFBMkIsQ0FBckQ7QUFDQWtCLGNBQVUsQ0FBQ2xCLFdBQUQsQ0FBVjtBQUNEOztBQUVELFdBQVNtRCxjQUFULENBQXlCN0MsR0FBekIsRUFBOEJOLFdBQTlCLEVBQTJDO0FBQ3pDbUIsY0FBVSxDQUFDbkIsV0FBRCxDQUFWLEdBQTBCbUIsVUFBVSxDQUFDbkIsV0FBRCxDQUFWLElBQTJCLENBQXJEO0FBQ0EwQyxXQUFPLENBQUNwQyxHQUFHLENBQUMrQyxVQUFMLEVBQWlCQyxVQUFVLElBQUk7QUFDcENuQyxnQkFBVSxDQUFDbkIsV0FBRCxDQUFWLElBQTJCdUQsU0FBUyxDQUFDRCxVQUFELENBQXBDO0FBQ0QsS0FGTSxDQUFQO0FBR0Q7O0FBRUQsV0FBU0YsY0FBVCxDQUF3QjlDLEdBQXhCLEVBQTZCTixXQUE3QixFQUEwQztBQUN4Q29CLGtCQUFjLENBQUNwQixXQUFELENBQWQsR0FBOEJvQixjQUFjLENBQUNwQixXQUFELENBQWQsSUFBK0IsQ0FBN0Q7QUFDQXFCLG1CQUFlLENBQUNyQixXQUFELENBQWYsR0FBK0JxQixlQUFlLENBQUNyQixXQUFELENBQWYsSUFBZ0MsQ0FBL0Q7QUFFQW9CLGtCQUFjLENBQUNwQixXQUFELENBQWQsSUFBK0JNLEdBQUcsQ0FBQ2tELGVBQW5DO0FBQ0FuQyxtQkFBZSxDQUFDckIsV0FBRCxDQUFmLElBQWdDTSxHQUFHLENBQUNtRCxnQkFBcEM7QUFDRDtBQUNGLENBbkREOztBQXFEQS9ELFdBQVcsQ0FBQzdFLFNBQVosQ0FBc0JvRSxZQUF0QixHQUFxQyxVQUFTeUUsZUFBVCxFQUEwQjtBQUM3RCxNQUFJOUYsZUFBZSxHQUFHLEtBQUtBLGVBQTNCO0FBQ0EsT0FBS0EsZUFBTCxHQUF1QnhCLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjLElBQWQsQ0FBdkI7QUFFQSxNQUFJdkQsT0FBTyxHQUFHO0FBQ1o2SyxjQUFVLEVBQUU7QUFEQSxHQUFkOztBQUlBLE1BQUlDLGdCQUFnQixHQUFHLEtBQUt0QixvQkFBTCxFQUF2Qjs7QUFDQSxNQUFJcEIsVUFBVSxHQUFHMEMsZ0JBQWdCLENBQUMxQyxVQUFsQztBQUNBLE1BQUlDLFVBQVUsR0FBR3lDLGdCQUFnQixDQUFDekMsVUFBbEM7QUFDQSxNQUFJNkIsZ0JBQWdCLEdBQUdZLGdCQUFnQixDQUFDWixnQkFBeEMsQ0FYNkQsQ0FhN0Q7O0FBQ0EsT0FBSSxJQUFJbEgsTUFBUixJQUFrQjhCLGVBQWxCLEVBQW1DO0FBQ2pDLFFBQUlpRyxXQUFXLEdBQUdqRyxlQUFlLENBQUM5QixNQUFELENBQWpDLENBRGlDLENBRWpDOztBQUNBK0gsZUFBVyxDQUFDaEcsU0FBWixHQUF3QmpILE1BQU0sQ0FBQ3lJLFVBQVAsQ0FBa0JDLFFBQWxCLENBQTJCdUUsV0FBVyxDQUFDaEcsU0FBdkMsQ0FBeEI7O0FBRUEsU0FBSSxJQUFJbUMsV0FBUixJQUF1QnBDLGVBQWUsQ0FBQzlCLE1BQUQsQ0FBZixDQUF3Qm1GLElBQS9DLEVBQXFEO0FBQ25ELFVBQUk2QyxnQkFBZ0IsR0FBR2xHLGVBQWUsQ0FBQzlCLE1BQUQsQ0FBZixDQUF3Qm1GLElBQXhCLENBQTZCakIsV0FBN0IsQ0FBdkIsQ0FEbUQsQ0FFbkQ7O0FBQ0E4RCxzQkFBZ0IsQ0FBQy9DLE9BQWpCLElBQTRCK0MsZ0JBQWdCLENBQUMzRCxJQUE3QztBQUNBMkQsc0JBQWdCLENBQUMvQyxPQUFqQixHQUEyQitDLGdCQUFnQixDQUFDL0MsT0FBakIsSUFBNEIsQ0FBdkQsQ0FKbUQsQ0FLbkQ7O0FBQ0ErQyxzQkFBZ0IsQ0FBQ25ELFFBQWpCLElBQTZCbUQsZ0JBQWdCLENBQUNwRCxNQUE5QztBQUNBb0Qsc0JBQWdCLENBQUNuRCxRQUFqQixHQUE0Qm1ELGdCQUFnQixDQUFDbkQsUUFBakIsSUFBNkIsQ0FBekQsQ0FQbUQsQ0FTbkQ7O0FBQ0EsVUFBR21ELGdCQUFnQixDQUFDdkMsZ0JBQWpCLEdBQW9DLENBQXZDLEVBQTBDO0FBQ3hDdUMsd0JBQWdCLENBQUN0QyxnQkFBakIsSUFBcUNzQyxnQkFBZ0IsQ0FBQ3ZDLGdCQUF0RDtBQUNELE9BWmtELENBY25EO0FBQ0E7OztBQUNBdUMsc0JBQWdCLENBQUM1QyxVQUFqQixHQUE4QkEsVUFBVSxDQUFDbEIsV0FBRCxDQUFWLElBQTJCLENBQXpEO0FBQ0E4RCxzQkFBZ0IsQ0FBQzNDLFVBQWpCLEdBQThCQSxVQUFVLENBQUNuQixXQUFELENBQVYsSUFBMkIsQ0FBekQ7QUFDQThELHNCQUFnQixDQUFDZCxnQkFBakIsR0FBb0NBLGdCQUFnQixDQUFDaEQsV0FBRCxDQUFoQixJQUFpQyxDQUFyRTtBQUNEOztBQUVEbEgsV0FBTyxDQUFDNkssVUFBUixDQUFtQjNJLElBQW5CLENBQXdCNEMsZUFBZSxDQUFDOUIsTUFBRCxDQUF2QztBQUNELEdBekM0RCxDQTJDN0Q7OztBQUNBaEQsU0FBTyxDQUFDaUwsV0FBUixHQUFzQixLQUFLcEgsV0FBTCxDQUFpQjZDLGFBQWpCLEVBQXRCO0FBRUEsU0FBTzFHLE9BQVA7QUFDRCxDQS9DRDs7QUFpREE0RyxXQUFXLENBQUM3RSxTQUFaLENBQXNCbUosb0JBQXRCLEdBQTZDLFVBQVNuRCxLQUFULEVBQWdCb0QsUUFBaEIsRUFBMEI7QUFDckUsTUFBSXJJLFNBQVMsR0FBR2tELEdBQUcsQ0FBQ0MsSUFBSixFQUFoQjs7QUFDQSxNQUFJbUYsZUFBZSxHQUFHLEtBQUtqRSxtQkFBTCxDQUF5QlksS0FBSyxDQUFDMUMsSUFBL0IsQ0FBdEI7O0FBQ0EsTUFBSTZCLFdBQVcsR0FBRyxLQUFLL0MsV0FBTCxDQUFpQnJCLFNBQWpCLEVBQTRCc0ksZUFBNUIsQ0FBbEI7O0FBRUEsTUFBSXJFLE9BQU8sR0FBR3NFLFdBQVcsQ0FBQ3BOLE1BQU0sQ0FBQzRMLE1BQVAsQ0FBY0MsUUFBZixFQUF5Qi9CLEtBQUssQ0FBQ2hCLE9BQS9CLENBQXpCOztBQUNBLE1BQUdBLE9BQUgsRUFBWTtBQUNWLFFBQUlTLEdBQUcsR0FBRzZELFdBQVcsQ0FBQ3RFLE9BQU8sQ0FBQ2dELFVBQVQsRUFBcUJoQyxLQUFLLENBQUN4QyxFQUEzQixDQUFyQjs7QUFDQSxRQUFHaUMsR0FBSCxFQUFRO0FBQ05BLFNBQUcsQ0FBQ2tELGVBQUosR0FBc0JsRCxHQUFHLENBQUNrRCxlQUFKLElBQXVCLENBQTdDO0FBQ0FsRCxTQUFHLENBQUNtRCxnQkFBSixHQUF1Qm5ELEdBQUcsQ0FBQ21ELGdCQUFKLElBQXdCLENBQS9DO0FBQ0Q7QUFDRixHQVpvRSxDQWFyRTs7O0FBQ0FuRCxLQUFHLEdBQUdBLEdBQUcsSUFBSTtBQUFDa0QsbUJBQWUsRUFBQyxDQUFqQjtBQUFxQkMsb0JBQWdCLEVBQUU7QUFBdkMsR0FBYjtBQUVBekQsYUFBVyxDQUFDb0IsY0FBWjtBQUNBZCxLQUFHLENBQUNrRCxlQUFKOztBQUNBLE1BQUdTLFFBQUgsRUFBYTtBQUNYakUsZUFBVyxDQUFDcUIsZUFBWjtBQUNBZixPQUFHLENBQUNtRCxnQkFBSjtBQUNEO0FBQ0YsQ0F0QkQ7O0FBd0JBL0QsV0FBVyxDQUFDN0UsU0FBWixDQUFzQnVKLG9CQUF0QixHQUE2QyxVQUFTQyxJQUFULEVBQWU7QUFDMUQsTUFBSXpJLFNBQVMsR0FBR2tELEdBQUcsQ0FBQ0MsSUFBSixFQUFoQjs7QUFDQSxNQUFJbUYsZUFBZSxHQUFHLEtBQUtqRSxtQkFBTCxDQUF5Qm9FLElBQUksQ0FBQ2xHLElBQTlCLENBQXRCOztBQUNBLE1BQUk2QixXQUFXLEdBQUcsS0FBSy9DLFdBQUwsQ0FBaUJyQixTQUFqQixFQUE0QnNJLGVBQTVCLENBQWxCOztBQUNBbEUsYUFBVyxDQUFDc0IsZ0JBQVo7QUFDRCxDQUxEOztBQU9BNUIsV0FBVyxDQUFDN0UsU0FBWixDQUFzQnlKLG9CQUF0QixHQUE2QyxVQUFTRCxJQUFULEVBQWU7QUFDMUQsTUFBSXpJLFNBQVMsR0FBR2tELEdBQUcsQ0FBQ0MsSUFBSixFQUFoQjs7QUFDQSxNQUFJbUYsZUFBZSxHQUFHLEtBQUtqRSxtQkFBTCxDQUF5Qm9FLElBQUksQ0FBQ2xHLElBQTlCLENBQXRCOztBQUNBLE1BQUk2QixXQUFXLEdBQUcsS0FBSy9DLFdBQUwsQ0FBaUJyQixTQUFqQixFQUE0QnNJLGVBQTVCLENBQWxCOztBQUNBbEUsYUFBVyxDQUFDdUIsZ0JBQVo7QUFDQXZCLGFBQVcsQ0FBQ3dCLGdCQUFaLElBQWlDLElBQUkrQyxJQUFKLEVBQUQsQ0FBYUMsT0FBYixLQUF5QkgsSUFBSSxDQUFDeEcsU0FBOUQ7QUFDRCxDQU5EOztBQVFBNkIsV0FBVyxDQUFDN0UsU0FBWixDQUFzQjRKLG9CQUF0QixHQUE2QyxVQUFTSixJQUFULEVBQWVLLEVBQWYsRUFBbUI7QUFDOUQ7QUFDQTtBQUNBO0FBQ0EsTUFBRyxDQUFDTCxJQUFKLEVBQVU7QUFDUjtBQUNEOztBQUVELE1BQUl6SSxTQUFTLEdBQUdrRCxHQUFHLENBQUNDLElBQUosRUFBaEI7O0FBQ0EsTUFBSW1GLGVBQWUsR0FBRyxLQUFLakUsbUJBQUwsQ0FBeUJvRSxJQUFJLENBQUNsRyxJQUE5QixDQUF0Qjs7QUFDQSxNQUFJNkIsV0FBVyxHQUFHLEtBQUsvQyxXQUFMLENBQWlCckIsU0FBakIsRUFBNEJzSSxlQUE1QixDQUFsQjs7QUFDQSxNQUFHUSxFQUFFLENBQUNBLEVBQUgsS0FBVSxHQUFiLEVBQWtCO0FBQ2hCMUUsZUFBVyxDQUFDNEIscUJBQVo7QUFDRCxHQUZELE1BRU8sSUFBRzhDLEVBQUUsQ0FBQ0EsRUFBSCxLQUFVLEdBQWIsRUFBa0I7QUFDdkIxRSxlQUFXLENBQUMyQixzQkFBWjtBQUNELEdBRk0sTUFFQSxJQUFHK0MsRUFBRSxDQUFDQSxFQUFILEtBQVUsR0FBYixFQUFrQjtBQUN2QjFFLGVBQVcsQ0FBQzBCLHFCQUFaO0FBQ0Q7QUFDRixDQWxCRDs7QUFvQkFoQyxXQUFXLENBQUM3RSxTQUFaLENBQXNCOEosb0JBQXRCLEdBQTZDLFVBQVNOLElBQVQsRUFBZWpILEtBQWYsRUFBc0I7QUFDakUsTUFBSXhCLFNBQVMsR0FBR2tELEdBQUcsQ0FBQ0MsSUFBSixFQUFoQjs7QUFDQSxNQUFJbUYsZUFBZSxHQUFHLEtBQUtqRSxtQkFBTCxDQUF5Qm9FLElBQUksQ0FBQ2xHLElBQTlCLENBQXRCOztBQUNBLE1BQUk2QixXQUFXLEdBQUcsS0FBSy9DLFdBQUwsQ0FBaUJyQixTQUFqQixFQUE0QnNJLGVBQTVCLENBQWxCOztBQUNBbEUsYUFBVyxDQUFDeUIsZUFBWixJQUErQnJFLEtBQS9CO0FBQ0QsQ0FMRDs7QUFPQXNDLFdBQVcsQ0FBQzdFLFNBQVosQ0FBc0IrSixnQkFBdEIsR0FBeUMsVUFBU1AsSUFBVCxFQUFlak0sSUFBZixFQUFxQmdGLEtBQXJCLEVBQTRCO0FBQ25FLE1BQUl4QixTQUFTLEdBQUdrRCxHQUFHLENBQUNDLElBQUosRUFBaEI7O0FBQ0EsTUFBSW1GLGVBQWUsR0FBRyxLQUFLakUsbUJBQUwsQ0FBeUJvRSxJQUFJLENBQUNsRyxJQUE5QixDQUF0Qjs7QUFDQSxNQUFJNkIsV0FBVyxHQUFHLEtBQUsvQyxXQUFMLENBQWlCckIsU0FBakIsRUFBNEJzSSxlQUE1QixDQUFsQjs7QUFFQSxNQUFHOUwsSUFBSSxLQUFLLGVBQVosRUFBNkI7QUFDM0I0SCxlQUFXLENBQUM4QixrQkFBWixJQUFrQzFFLEtBQWxDO0FBQ0QsR0FGRCxNQUVPLElBQUdoRixJQUFJLEtBQUssa0JBQVosRUFBZ0M7QUFDckM0SCxlQUFXLENBQUNnQyxvQkFBWixJQUFvQzVFLEtBQXBDO0FBQ0QsR0FGTSxNQUVBLElBQUdoRixJQUFJLEtBQUssa0JBQVosRUFBZ0M7QUFDckM0SCxlQUFXLENBQUMrQixvQkFBWixJQUFvQzNFLEtBQXBDO0FBQ0QsR0FGTSxNQUVBLElBQUdoRixJQUFJLEtBQUssY0FBWixFQUE0QjtBQUNqQzRILGVBQVcsQ0FBQzZCLHVCQUFaLElBQXVDekUsS0FBdkM7QUFDRCxHQUZNLE1BRUE7QUFDTCxVQUFNLElBQUk3RSxLQUFKLENBQVUsa0NBQVYsQ0FBTjtBQUNEO0FBQ0YsQ0FoQkQ7O0FBa0JBbUgsV0FBVyxDQUFDN0UsU0FBWixDQUFzQitELFlBQXRCLEdBQXFDLFVBQVNULElBQVQsRUFBZS9GLElBQWYsRUFBcUJ5RyxJQUFyQixFQUEyQjtBQUM5RCxNQUFJakQsU0FBUyxHQUFHa0QsR0FBRyxDQUFDQyxJQUFKLEVBQWhCOztBQUNBLE1BQUltRixlQUFlLEdBQUcsS0FBS2pFLG1CQUFMLENBQXlCOUIsSUFBekIsQ0FBdEI7O0FBQ0EsTUFBSTZCLFdBQVcsR0FBRyxLQUFLL0MsV0FBTCxDQUFpQnJCLFNBQWpCLEVBQTRCc0ksZUFBNUIsQ0FBbEI7O0FBRUEsTUFBRzlMLElBQUksS0FBSyxlQUFaLEVBQTZCO0FBQzNCNEgsZUFBVyxDQUFDaUMsYUFBWixJQUE2QnBELElBQTdCO0FBQ0QsR0FGRCxNQUVPLElBQUd6RyxJQUFJLEtBQUssYUFBWixFQUEyQjtBQUNoQzRILGVBQVcsQ0FBQ21DLGtCQUFaLElBQWtDdEQsSUFBbEM7QUFDRCxHQUZNLE1BRUEsSUFBR3pHLElBQUksS0FBSyxlQUFaLEVBQTZCO0FBQ2xDNEgsZUFBVyxDQUFDMUMsY0FBWixJQUE4QnVCLElBQTlCO0FBQ0QsR0FGTSxNQUVBLElBQUd6RyxJQUFJLEtBQUssZ0JBQVosRUFBOEI7QUFDbkM0SCxlQUFXLENBQUNrQyx1QkFBWixJQUF1Q3JELElBQXZDO0FBQ0QsR0FGTSxNQUVBO0FBQ0wsVUFBTSxJQUFJdEcsS0FBSixDQUFVLG1DQUFWLENBQU47QUFDRDtBQUNGLENBaEJEOztBQWtCQW1ILFdBQVcsQ0FBQzdFLFNBQVosQ0FBc0JtRSxZQUF0QixHQUFxQyxVQUFTYixJQUFULEVBQWUvRixJQUFmLEVBQXFCeUcsSUFBckIsRUFBMkI7QUFDOUQsTUFBSWpELFNBQVMsR0FBR2tELEdBQUcsQ0FBQ0MsSUFBSixFQUFoQjs7QUFDQSxNQUFJbUYsZUFBZSxHQUFHLEtBQUtqRSxtQkFBTCxDQUF5QjlCLElBQXpCLENBQXRCOztBQUNBLE1BQUk2QixXQUFXLEdBQUcsS0FBSy9DLFdBQUwsQ0FBaUJyQixTQUFqQixFQUE0QnNJLGVBQTVCLENBQWxCOztBQUVBLE1BQUc5TCxJQUFJLEtBQUssVUFBWixFQUF3QjtBQUN0QjRILGVBQVcsQ0FBQ3FDLGVBQVosSUFBK0J4RCxJQUEvQjtBQUNELEdBRkQsTUFFTyxJQUFHekcsSUFBSSxLQUFLLGFBQVosRUFBMkI7QUFDaEM0SCxlQUFXLENBQUNvQyxvQkFBWixJQUFvQ3ZELElBQXBDO0FBQ0QsR0FGTSxNQUVBO0FBQ0wsVUFBTSxJQUFJdEcsS0FBSixDQUFVLG1DQUFWLENBQU47QUFDRDtBQUNGLENBWkQsQzs7Ozs7Ozs7Ozs7QUM3V0EsSUFBSXNNLGVBQUo7QUFBb0JDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ0YsaUJBQWUsQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILG1CQUFlLEdBQUNHLENBQWhCO0FBQWtCOztBQUF0QyxDQUExQixFQUFrRSxDQUFsRTtBQUFxRSxJQUFJQyxTQUFKO0FBQWNILE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGlCQUFaLEVBQThCO0FBQUNHLFNBQU8sQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNDLGFBQVMsR0FBQ0QsQ0FBVjtBQUFZOztBQUF4QixDQUE5QixFQUF3RCxDQUF4RDtBQUEyRCxJQUFJRyxlQUFKLEVBQW9CQyxpQkFBcEI7QUFBc0NOLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG9CQUFaLEVBQWlDO0FBQUNJLGlCQUFlLENBQUNILENBQUQsRUFBRztBQUFDRyxtQkFBZSxHQUFDSCxDQUFoQjtBQUFrQixHQUF0Qzs7QUFBdUNJLG1CQUFpQixDQUFDSixDQUFELEVBQUc7QUFBQ0kscUJBQWlCLEdBQUNKLENBQWxCO0FBQW9COztBQUFoRixDQUFqQyxFQUFtSCxDQUFuSDtBQUFzSCxJQUFJSyxtQkFBSixFQUF3QkMscUJBQXhCO0FBQThDUixNQUFNLENBQUNDLElBQVAsQ0FBWSxrQ0FBWixFQUErQztBQUFDTSxxQkFBbUIsQ0FBQ0wsQ0FBRCxFQUFHO0FBQUNLLHVCQUFtQixHQUFDTCxDQUFwQjtBQUFzQixHQUE5Qzs7QUFBK0NNLHVCQUFxQixDQUFDTixDQUFELEVBQUc7QUFBQ00seUJBQXFCLEdBQUNOLENBQXRCO0FBQXdCOztBQUFoRyxDQUEvQyxFQUFpSixDQUFqSjs7QUFBNVcsSUFBSU8sZ0JBQWdCLEdBQUduTyxHQUFHLENBQUNDLE9BQUosQ0FBWSxnQkFBWixDQUF2Qjs7QUFNQW1PLFdBQVcsR0FBRyxZQUFZO0FBQ3hCLE9BQUszSCxTQUFMLEdBQWlCaUIsR0FBRyxDQUFDQyxJQUFKLEVBQWpCO0FBQ0EsT0FBSzBHLFdBQUwsR0FBbUIsQ0FBbkI7QUFDQSxPQUFLQyxjQUFMLEdBQXNCLE9BQU8sRUFBUCxHQUFZLEVBQWxDLENBSHdCLENBR2M7O0FBRXRDLE9BQUtDLGVBQUwsR0FBdUJkLGVBQWUsRUFBdEM7QUFDQSxPQUFLZSxhQUFMLEdBQXFCLElBQUlMLGdCQUFKLENBQXFCLEdBQXJCLENBQXJCO0FBQ0EsT0FBS0ssYUFBTCxDQUFtQjVJLEtBQW5CO0FBQ0EsT0FBSzRJLGFBQUwsQ0FBbUJDLEVBQW5CLENBQXNCLEtBQXRCLEVBQTZCQyxHQUFHLElBQUk7QUFDbEM7QUFDQSxTQUFLSCxlQUFMLENBQXFCbEgsR0FBckIsQ0FBeUJxSCxHQUFHLEdBQUcsSUFBL0I7QUFDRCxHQUhEO0FBS0EsT0FBS0MsU0FBTCxHQUFpQixJQUFJZCxTQUFKLEVBQWpCO0FBQ0EsT0FBS2MsU0FBTCxDQUFlL0ksS0FBZjtBQUdBLE9BQUtnSixPQUFMLEdBQWVDLE9BQU8sQ0FBQ0MsTUFBUixFQUFmO0FBQ0EsT0FBS0MsZ0JBQUwsR0FBd0JGLE9BQU8sQ0FBQ0csUUFBUixFQUF4QjtBQUNBLE9BQUtDLFVBQUwsR0FBa0IsRUFBbEI7QUFDQSxPQUFLQyxlQUFMLEdBQXVCLENBQXZCO0FBRUFDLGFBQVcsQ0FBQyxNQUFNO0FBQ2hCLFNBQUtILFFBQUw7QUFDRCxHQUZVLEVBRVIsSUFGUSxDQUFYO0FBR0QsQ0F6QkQ7O0FBMkJBNUosQ0FBQyxDQUFDQyxNQUFGLENBQVMrSSxXQUFXLENBQUMzSyxTQUFyQixFQUFnQ2EsV0FBVyxDQUFDYixTQUE1Qzs7QUFFQTJLLFdBQVcsQ0FBQzNLLFNBQVosQ0FBc0JvRSxZQUF0QixHQUFxQyxZQUFXO0FBQzlDLE1BQUlULE9BQU8sR0FBRyxFQUFkOztBQUNBLE1BQUlnSSxHQUFHLEdBQUcxSCxHQUFHLENBQUNDLElBQUosRUFBVjs7QUFDQVAsU0FBTyxDQUFDWCxTQUFSLEdBQW9CakgsTUFBTSxDQUFDeUksVUFBUCxDQUFrQkMsUUFBbEIsQ0FBMkIsS0FBS3pCLFNBQWhDLENBQXBCO0FBQ0FXLFNBQU8sQ0FBQ0csT0FBUixHQUFrQi9ILE1BQU0sQ0FBQ3lJLFVBQVAsQ0FBa0JDLFFBQWxCLENBQTJCa0gsR0FBM0IsQ0FBbEI7QUFDQWhJLFNBQU8sQ0FBQ29FLFFBQVIsR0FBbUJXLFNBQVMsQ0FBQ3hNLE1BQU0sQ0FBQzRMLE1BQVAsQ0FBY0MsUUFBZixDQUE1QjtBQUVBLE1BQUk2RCxXQUFXLEdBQUdSLE9BQU8sQ0FBQ1EsV0FBUixFQUFsQjtBQUNBakksU0FBTyxDQUFDa0ksTUFBUixHQUFpQkQsV0FBVyxDQUFDRSxHQUFaLElBQW1CLE9BQUssSUFBeEIsQ0FBakI7QUFDQW5JLFNBQU8sQ0FBQ29JLGtCQUFSLEdBQTZCLENBQUNILFdBQVcsQ0FBQ0ksWUFBWixJQUE0QixDQUE3QixLQUFtQyxPQUFLLElBQXhDLENBQTdCO0FBQ0FySSxTQUFPLENBQUNzSSxjQUFSLEdBQXlCTCxXQUFXLENBQUNNLFFBQVosSUFBd0IsT0FBSyxJQUE3QixDQUF6QjtBQUNBdkksU0FBTyxDQUFDd0ksY0FBUixHQUF5QlAsV0FBVyxDQUFDUSxRQUFaLElBQXdCLE9BQUssSUFBN0IsQ0FBekI7QUFDQXpJLFNBQU8sQ0FBQzBJLGVBQVIsR0FBMEJULFdBQVcsQ0FBQ1UsU0FBWixJQUF5QixPQUFLLElBQTlCLENBQTFCO0FBRUEzSSxTQUFPLENBQUNpSCxXQUFSLEdBQXNCLEtBQUtBLFdBQTNCO0FBQ0EsT0FBS0EsV0FBTCxHQUFtQixDQUFuQjtBQUVBakgsU0FBTyxDQUFDNEksY0FBUixHQUF5Qm5CLE9BQU8sQ0FBQ29CLGtCQUFSLEdBQTZCM08sTUFBdEQ7QUFDQThGLFNBQU8sQ0FBQzhJLGFBQVIsR0FBd0JyQixPQUFPLENBQUNzQixpQkFBUixHQUE0QjdPLE1BQXBELENBbEI4QyxDQW9COUM7O0FBQ0E4RixTQUFPLENBQUNnSixjQUFSLEdBQXlCLEtBQUs1QixhQUFMLENBQW1CNkIsTUFBbkIsR0FBNEJDLFFBQXJEO0FBQ0FsSixTQUFPLENBQUNtSCxlQUFSLEdBQTBCLEtBQUtBLGVBQS9CO0FBQ0EsT0FBS0EsZUFBTCxHQUF1QmQsZUFBZSxFQUF0QztBQUVBckcsU0FBTyxDQUFDbUosZUFBUixHQUEwQixLQUFLNUIsU0FBTCxDQUFldkgsT0FBZixDQUF1Qm9KLE9BQWpEO0FBQ0FwSixTQUFPLENBQUNxSixlQUFSLEdBQTBCLEtBQUs5QixTQUFMLENBQWV2SCxPQUFmLENBQXVCc0osT0FBakQ7QUFDQXRKLFNBQU8sQ0FBQ3VKLHFCQUFSLEdBQWdDLEtBQUtoQyxTQUFMLENBQWV2SCxPQUFmLENBQXVCd0osYUFBdkQ7QUFDQXhKLFNBQU8sQ0FBQ3lKLGdCQUFSLEdBQTJCLEtBQUtsQyxTQUFMLENBQWV2SCxPQUFmLENBQXVCMEosUUFBbEQ7QUFDQSxPQUFLbkMsU0FBTCxDQUFlb0MsS0FBZjtBQUVBLFFBQU1DLGFBQWEsR0FBRy9DLG1CQUFtQixFQUF6QztBQUNBQyx1QkFBcUI7QUFFckI5RyxTQUFPLENBQUM2SixhQUFSLEdBQXdCRCxhQUFhLENBQUNFLFFBQXRDO0FBQ0E5SixTQUFPLENBQUMrSix5QkFBUixHQUFvQ0gsYUFBYSxDQUFDSSxnQkFBbEQ7QUFDQWhLLFNBQU8sQ0FBQ2lLLHVCQUFSLEdBQWtDTCxhQUFhLENBQUNNLGNBQWhEO0FBQ0FsSyxTQUFPLENBQUNtSyxxQkFBUixHQUFnQ1AsYUFBYSxDQUFDUSxZQUE5QztBQUNBcEssU0FBTyxDQUFDcUssd0JBQVIsR0FBbUNULGFBQWEsQ0FBQ1UsZUFBakQ7QUFDQXRLLFNBQU8sQ0FBQ3VLLGdCQUFSLEdBQTJCWCxhQUFhLENBQUNZLE9BQXpDO0FBQ0F4SyxTQUFPLENBQUN5Syw4QkFBUixHQUF5Q2IsYUFBYSxDQUFDYyxVQUF2RDtBQUNBMUssU0FBTyxDQUFDMkssMkJBQVIsR0FBc0NmLGFBQWEsQ0FBQ2dCLE9BQXBEO0FBRUEsUUFBTUMsWUFBWSxHQUFHbEUsZUFBZSxFQUFwQztBQUNBQyxtQkFBaUI7QUFDakI1RyxTQUFPLENBQUM4SyxhQUFSLEdBQXdCRCxZQUFZLENBQUNELE9BQXJDO0FBQ0E1SyxTQUFPLENBQUMrSyxZQUFSLEdBQXVCRixZQUFZLENBQUNHLE1BQXBDO0FBQ0FoTCxTQUFPLENBQUNpTCxhQUFSLEdBQXdCSixZQUFZLENBQUNmLFFBQXJDO0FBRUE5SixTQUFPLENBQUNrTCxJQUFSLEdBQWUsQ0FBZjtBQUNBbEwsU0FBTyxDQUFDbUwsUUFBUixHQUFtQixDQUFuQjtBQUNBbkwsU0FBTyxDQUFDb0wsVUFBUixHQUFxQixDQUFyQjs7QUFFQSxNQUFJLEtBQUt2RCxVQUFMLENBQWdCM04sTUFBaEIsR0FBeUIsQ0FBN0IsRUFBZ0M7QUFDOUIsUUFBSW1SLFlBQVksR0FBRyxLQUFLeEQsVUFBTCxDQUFnQixLQUFLQSxVQUFMLENBQWdCM04sTUFBaEIsR0FBeUIsQ0FBekMsQ0FBbkI7QUFDQThGLFdBQU8sQ0FBQ2tMLElBQVIsR0FBZUcsWUFBWSxDQUFDQyxLQUFiLEdBQXFCLEdBQXBDO0FBQ0F0TCxXQUFPLENBQUNtTCxRQUFSLEdBQW1CRSxZQUFZLENBQUNFLElBQWIsR0FBb0IsR0FBdkM7QUFDQXZMLFdBQU8sQ0FBQ29MLFVBQVIsR0FBcUJDLFlBQVksQ0FBQ0csR0FBYixHQUFtQixHQUF4QztBQUNEOztBQUVEeEwsU0FBTyxDQUFDNkgsVUFBUixHQUFxQixLQUFLQSxVQUFMLENBQWdCNEQsR0FBaEIsQ0FBb0JDLEtBQUssSUFBSTtBQUNoRCxXQUFPO0FBQ0xDLFVBQUksRUFBRXZULE1BQU0sQ0FBQ3lJLFVBQVAsQ0FBa0JDLFFBQWxCLENBQTJCNEssS0FBSyxDQUFDQyxJQUFqQyxDQUREO0FBRUxMLFdBQUssRUFBRUksS0FBSyxDQUFDSixLQUZSO0FBR0xFLFNBQUcsRUFBRUUsS0FBSyxDQUFDRixHQUhOO0FBSUxELFVBQUksRUFBRUcsS0FBSyxDQUFDSDtBQUpQLEtBQVA7QUFNRCxHQVBvQixDQUFyQjtBQVNBLE9BQUsxRCxVQUFMLEdBQWtCLEVBQWxCO0FBQ0EsT0FBS3hJLFNBQUwsR0FBaUIySSxHQUFqQjtBQUNBLFNBQU87QUFBQzRELGlCQUFhLEVBQUUsQ0FBQzVMLE9BQUQ7QUFBaEIsR0FBUDtBQUNELENBeEVEOztBQTBFQSxTQUFTNkwsVUFBVCxDQUFvQm5FLE1BQXBCLEVBQTRCO0FBQzFCLFNBQU9BLE1BQU0sQ0FBQyxDQUFELENBQU4sR0FBWSxJQUFaLEdBQW1CQSxNQUFNLENBQUMsQ0FBRCxDQUFOLEdBQVksT0FBdEM7QUFDRDs7QUFFRFYsV0FBVyxDQUFDM0ssU0FBWixDQUFzQnVMLFFBQXRCLEdBQWlDLFlBQVc7QUFDMUMsTUFBSWtFLFVBQVUsR0FBR0QsVUFBVSxDQUFDcEUsT0FBTyxDQUFDQyxNQUFSLENBQWUsS0FBS0YsT0FBcEIsQ0FBRCxDQUEzQjtBQUNBLE1BQUl1RSxTQUFTLEdBQUd0RSxPQUFPLENBQUNHLFFBQVIsQ0FBaUIsS0FBS0QsZ0JBQXRCLENBQWhCO0FBQ0EsTUFBSXFFLFVBQVUsR0FBR0QsU0FBUyxDQUFDUixJQUFWLEdBQWlCLElBQWxDO0FBQ0EsTUFBSVUsVUFBVSxHQUFHRixTQUFTLENBQUNHLE1BQVYsR0FBbUIsSUFBcEM7QUFDQSxNQUFJQyxZQUFZLEdBQUdILFVBQVUsR0FBR0MsVUFBaEM7QUFDQSxNQUFJRyxpQkFBaUIsR0FBR0QsWUFBWSxHQUFHTCxVQUF2QztBQUVBLE9BQUtqRSxVQUFMLENBQWdCckwsSUFBaEIsQ0FBcUI7QUFDbkJtUCxRQUFJLEVBQUVyTCxHQUFHLENBQUNDLElBQUosRUFEYTtBQUVuQitLLFNBQUssRUFBRWMsaUJBRlk7QUFHbkJiLFFBQUksRUFBRVMsVUFBVSxHQUFHRixVQUhBO0FBSW5CTixPQUFHLEVBQUVTLFVBQVUsR0FBR0YsU0FBUyxDQUFDRztBQUpULEdBQXJCO0FBT0EsT0FBS3BFLGVBQUwsR0FBdUJzRSxpQkFBaUIsR0FBRyxHQUEzQztBQUNBaFUsUUFBTSxDQUFDaVUsVUFBUCxDQUFrQkMsT0FBbEIsQ0FBMEIsS0FBS3hFLGVBQS9CO0FBRUEsT0FBS04sT0FBTCxHQUFlQyxPQUFPLENBQUNDLE1BQVIsRUFBZjtBQUNBLE9BQUtDLGdCQUFMLEdBQXdCRixPQUFPLENBQUNHLFFBQVIsRUFBeEI7QUFDRCxDQXBCRDs7QUFzQkFaLFdBQVcsQ0FBQzNLLFNBQVosQ0FBc0JrUSxxQkFBdEIsR0FBOEMsVUFBU2pMLEdBQVQsRUFBY0QsT0FBZCxFQUF1QjtBQUNuRSxNQUFHQyxHQUFHLENBQUNBLEdBQUosS0FBWSxTQUFaLElBQXlCLENBQUNBLEdBQUcsQ0FBQ0QsT0FBakMsRUFBMEM7QUFDeEMsU0FBS21MLGVBQUwsQ0FBcUJuTCxPQUFyQjtBQUNELEdBRkQsTUFFTyxJQUFHLENBQUMsS0FBRCxFQUFRLFFBQVIsRUFBa0IxRSxPQUFsQixDQUEwQjJFLEdBQUcsQ0FBQ0EsR0FBOUIsS0FBc0MsQ0FBQyxDQUExQyxFQUE2QztBQUNsRCxRQUFHLENBQUMsS0FBS21MLGVBQUwsQ0FBcUJwTCxPQUFyQixDQUFKLEVBQW1DO0FBQ2pDLFdBQUttTCxlQUFMLENBQXFCbkwsT0FBckI7QUFDRDtBQUNGOztBQUNEQSxTQUFPLENBQUNxTCxTQUFSLEdBQW9CM0csSUFBSSxDQUFDaUMsR0FBTCxFQUFwQjtBQUNELENBVEQ7O0FBV0FoQixXQUFXLENBQUMzSyxTQUFaLENBQXNCbVEsZUFBdEIsR0FBd0MsVUFBU25MLE9BQVQsRUFBa0I7QUFDeEQsTUFBRyxDQUFDc0wsY0FBYyxDQUFDdEwsT0FBTyxDQUFDdUwsTUFBVCxDQUFsQixFQUFvQztBQUNsQyxTQUFLM0YsV0FBTDtBQUNEO0FBQ0YsQ0FKRDs7QUFNQUQsV0FBVyxDQUFDM0ssU0FBWixDQUFzQm9RLGVBQXRCLEdBQXdDLFVBQVNwTCxPQUFULEVBQWtCO0FBQ3hELE1BQUl3TCxZQUFZLEdBQUc5RyxJQUFJLENBQUNpQyxHQUFMLEtBQWEzRyxPQUFPLENBQUNxTCxTQUF4Qzs7QUFDQSxTQUFPRyxZQUFZLEdBQUcsS0FBSzNGLGNBQTNCO0FBQ0QsQ0FIRCxDLENBS0E7QUFFQTs7O0FBQ0EsSUFBSTRGLGdCQUFnQixHQUFHLGdKQUF2QixDLENBRUE7O0FBQ0EsSUFBSUMsbUJBQW1CLEdBQUcsOEdBQTFCOztBQUVBLFNBQVNKLGNBQVQsQ0FBeUJDLE1BQXpCLEVBQWlDO0FBQy9CLE1BQUlJLElBQUksR0FBR0osTUFBTSxDQUFDNVEsT0FBUCxDQUFlLE1BQWYsQ0FBWDtBQUNBLE1BQUdnUixJQUFILEVBQVMsT0FBT0YsZ0JBQWdCLENBQUMxUyxJQUFqQixDQUFzQjRTLElBQXRCLENBQVA7QUFDVCxNQUFJQyxPQUFPLEdBQUdMLE1BQU0sQ0FBQzVRLE9BQVAsQ0FBZSxpQkFBZixLQUFxQzRRLE1BQU0sQ0FBQ00sYUFBMUQ7QUFDQSxNQUFHRCxPQUFILEVBQVksT0FBT0YsbUJBQW1CLENBQUMzUyxJQUFwQixDQUF5QjZTLE9BQXpCLENBQVA7QUFDYixDOzs7Ozs7Ozs7OztBQzFLREUsVUFBVSxHQUFHLFVBQVVDLEtBQVYsRUFBaUI7QUFDNUJqUixnQkFBYyxDQUFDa1IsSUFBZixDQUFvQixJQUFwQjtBQUNBLE1BQUl0SixJQUFJLEdBQUcsSUFBWDtBQUNBLE9BQUtxSixLQUFMLEdBQWFBLEtBQWI7QUFDQSxPQUFLdk8sTUFBTCxHQUFjLEVBQWQ7QUFDQSxPQUFLUSxTQUFMLEdBQWlCMEcsSUFBSSxDQUFDaUMsR0FBTCxFQUFqQjtBQUNBLE9BQUtzRixTQUFMLEdBQWlCLEVBQWpCO0FBQ0QsQ0FQRDs7QUFTQTFQLE1BQU0sQ0FBQzJQLE1BQVAsQ0FBY0osVUFBVSxDQUFDOVEsU0FBekIsRUFBb0NhLFdBQVcsQ0FBQ2IsU0FBaEQ7QUFDQXVCLE1BQU0sQ0FBQzJQLE1BQVAsQ0FBY0osVUFBVSxDQUFDOVEsU0FBekIsRUFBb0NGLGNBQWMsQ0FBQ0UsU0FBbkQ7O0FBRUE4USxVQUFVLENBQUM5USxTQUFYLENBQXFCb0UsWUFBckIsR0FBb0MsWUFBVztBQUM3QyxNQUFJVCxPQUFPLEdBQUdoQyxDQUFDLENBQUN3UCxNQUFGLENBQVMsS0FBSzNPLE1BQWQsQ0FBZDs7QUFDQSxPQUFLUSxTQUFMLEdBQWlCaUIsR0FBRyxDQUFDQyxJQUFKLEVBQWpCO0FBRUFQLFNBQU8sQ0FBQzFHLE9BQVIsQ0FBZ0IsVUFBVW1VLE1BQVYsRUFBa0I7QUFDaENBLFVBQU0sQ0FBQ3BPLFNBQVAsR0FBbUJqSCxNQUFNLENBQUN5SSxVQUFQLENBQWtCQyxRQUFsQixDQUEyQjJNLE1BQU0sQ0FBQ3BPLFNBQWxDLENBQW5CO0FBQ0QsR0FGRDtBQUlBLE9BQUtSLE1BQUwsR0FBYyxFQUFkO0FBQ0EsU0FBTztBQUFDQSxVQUFNLEVBQUVtQjtBQUFULEdBQVA7QUFDRCxDQVZEOztBQVlBbU4sVUFBVSxDQUFDOVEsU0FBWCxDQUFxQnFSLFVBQXJCLEdBQWtDLFlBQVk7QUFDNUMsU0FBTzFQLENBQUMsQ0FBQ3dQLE1BQUYsQ0FBUyxLQUFLM08sTUFBZCxFQUFzQjNFLE1BQTdCO0FBQ0QsQ0FGRDs7QUFJQWlULFVBQVUsQ0FBQzlRLFNBQVgsQ0FBcUJzUixVQUFyQixHQUFrQyxVQUFTMVEsRUFBVCxFQUFhb0YsS0FBYixFQUFvQjtBQUNwRCxNQUFJekIsR0FBRyxHQUFHeUIsS0FBSyxDQUFDekksSUFBTixHQUFhLEdBQWIsR0FBbUJxRCxFQUFFLENBQUNwRCxPQUFoQzs7QUFDQSxNQUFHLEtBQUtnRixNQUFMLENBQVkrQixHQUFaLENBQUgsRUFBcUI7QUFDbkIsU0FBSy9CLE1BQUwsQ0FBWStCLEdBQVosRUFBaUJoQyxLQUFqQjtBQUNELEdBRkQsTUFFTyxJQUFJLEtBQUs4TyxVQUFMLEtBQW9CLEtBQUtKLFNBQTdCLEVBQXdDO0FBQzdDLFFBQUlNLFFBQVEsR0FBRyxLQUFLQyxZQUFMLENBQWtCNVEsRUFBbEIsRUFBc0JvRixLQUF0QixDQUFmOztBQUNBLFFBQUcsS0FBS3hGLFlBQUwsQ0FBa0IrUSxRQUFRLENBQUNoVSxJQUEzQixFQUFpQ2dVLFFBQVEsQ0FBQ2pPLElBQTFDLEVBQWdEMUMsRUFBaEQsRUFBb0QyUSxRQUFRLENBQUM3USxPQUE3RCxDQUFILEVBQTBFO0FBQ3hFLFdBQUs4QixNQUFMLENBQVkrQixHQUFaLElBQW1CLEtBQUtpTixZQUFMLENBQWtCNVEsRUFBbEIsRUFBc0JvRixLQUF0QixDQUFuQjtBQUNEO0FBQ0Y7QUFDRixDQVZEOztBQVlBOEssVUFBVSxDQUFDOVEsU0FBWCxDQUFxQndSLFlBQXJCLEdBQW9DLFVBQVM1USxFQUFULEVBQWFvRixLQUFiLEVBQW9CO0FBQ3RELE1BQUlzSixJQUFJLEdBQUc1RixJQUFJLENBQUNpQyxHQUFMLEVBQVg7QUFDQSxNQUFJOEYsS0FBSyxHQUFHN1EsRUFBRSxDQUFDNlEsS0FBZixDQUZzRCxDQUl0RDs7QUFDQSxNQUFHN1EsRUFBRSxDQUFDOFEsT0FBTixFQUFlO0FBQ2JELFNBQUssR0FBRyxjQUFjN1EsRUFBRSxDQUFDOFEsT0FBakIsR0FBMkIsTUFBM0IsR0FBb0NELEtBQTVDO0FBQ0QsR0FQcUQsQ0FTdEQ7OztBQUNBLE1BQUlFLFVBQVUsR0FBRzNMLEtBQUssQ0FBQzRMLE1BQU4sSUFBZ0I1TCxLQUFLLENBQUM0TCxNQUFOLENBQWE1TCxLQUFLLENBQUM0TCxNQUFOLENBQWEvVCxNQUFiLEdBQXFCLENBQWxDLENBQWpDO0FBQ0EsTUFBSWdVLFdBQVcsR0FBR0YsVUFBVSxJQUFJQSxVQUFVLENBQUMsQ0FBRCxDQUF4QixJQUErQkEsVUFBVSxDQUFDLENBQUQsQ0FBVixDQUFjbFIsS0FBL0Q7O0FBRUEsTUFBR29SLFdBQUgsRUFBZ0I7QUFDZEEsZUFBVyxDQUFDSixLQUFaLEdBQW9CQSxLQUFwQjtBQUNEOztBQUVELFNBQU87QUFDTFYsU0FBSyxFQUFFLEtBQUtBLEtBRFA7QUFFTHpOLFFBQUksRUFBRTFDLEVBQUUsQ0FBQ3BELE9BRko7QUFHTEQsUUFBSSxFQUFFeUksS0FBSyxDQUFDekksSUFIUDtBQUlMeUYsYUFBUyxFQUFFc00sSUFKTjtBQUtMNU8sV0FBTyxFQUFFc0YsS0FBSyxDQUFDdEYsT0FBTixJQUFpQnNGLEtBQUssQ0FBQzFDLElBTDNCO0FBTUwwQyxTQUFLLEVBQUVBLEtBTkY7QUFPTDhMLFVBQU0sRUFBRSxDQUFDO0FBQUNMLFdBQUssRUFBRUE7QUFBUixLQUFELENBUEg7QUFRTGxQLFNBQUssRUFBRTtBQVJGLEdBQVA7QUFVRCxDQTNCRCxDOzs7Ozs7Ozs7OztBQ3hDQSxNQUFNO0FBQUVyQjtBQUFGLElBQWUxRSxPQUFPLENBQUMsdUJBQUQsQ0FBNUI7O0FBRUEsTUFBTTJFLHFCQUFxQixHQUFHLENBQUMsSUFBRCxFQUFPLE1BQVAsRUFBZSxPQUFmLEVBQXdCLE9BQXhCLEVBQWlDLFNBQWpDLEVBQTRDLE9BQTVDLEVBQXFELElBQXJELENBQTlCOztBQUdBLE1BQU00USxTQUFTLEdBQUcsWUFBWTtBQUM1QixPQUFLaFAsZUFBTCxHQUF1QnhCLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjLElBQWQsQ0FBdkI7QUFDQSxPQUFLTSxXQUFMLEdBQW1CLElBQUlDLFdBQUosQ0FBZ0I7QUFDakNDLFlBQVEsRUFBRSxPQUFPLEVBRGdCO0FBRWpDQyxrQkFBYyxFQUFFLEVBRmlCO0FBR2pDQyxnQkFBWSxFQUFFO0FBSG1CLEdBQWhCLENBQW5CO0FBTUEsT0FBS0osV0FBTCxDQUFpQkssS0FBakI7QUFDRCxDQVREOztBQVdBUixDQUFDLENBQUNDLE1BQUYsQ0FBU21RLFNBQVMsQ0FBQy9SLFNBQW5CLEVBQThCYSxXQUFXLENBQUNiLFNBQTFDOztBQUVBK1IsU0FBUyxDQUFDL1IsU0FBVixDQUFvQmdTLGNBQXBCLEdBQXFDLFVBQVVoTSxLQUFWLEVBQWlCaU0sR0FBakIsRUFBc0I3UyxHQUF0QixFQUEyQjtBQUM5RCxRQUFNNkIsTUFBTSxHQUFHLEtBQUtILFVBQUwsQ0FBZ0JrRixLQUFLLENBQUM3QyxFQUF0QixDQUFmOztBQUNBLE9BQUtDLGNBQUwsQ0FBb0JuQyxNQUFwQixFQUE0QitFLEtBQTVCLEVBQW1DNUcsR0FBbkM7O0FBQ0EsT0FBSzBDLFdBQUwsQ0FBaUJ5QixRQUFqQixDQUEwQnlDLEtBQTFCO0FBQ0QsQ0FKRDs7QUFNQStMLFNBQVMsQ0FBQy9SLFNBQVYsQ0FBb0JvQyxXQUFwQixHQUFrQyxVQUFVckIsU0FBVixFQUFxQm1SLE9BQXJCLEVBQThCO0FBQzlELFFBQU1qUixNQUFNLEdBQUcsS0FBS0gsVUFBTCxDQUFnQkMsU0FBaEIsQ0FBZjs7QUFFQSxNQUFJLENBQUMsS0FBS2dDLGVBQUwsQ0FBcUI5QixNQUFyQixDQUFMLEVBQW1DO0FBQ2pDLFNBQUs4QixlQUFMLENBQXFCOUIsTUFBckIsSUFBK0I7QUFDN0JrUixZQUFNLEVBQUU1USxNQUFNLENBQUNDLE1BQVAsQ0FBYyxJQUFkO0FBRHFCLEtBQS9CO0FBR0Q7O0FBRUQsUUFBTTJRLE1BQU0sR0FBRyxLQUFLcFAsZUFBTCxDQUFxQjlCLE1BQXJCLEVBQTZCa1IsTUFBNUM7O0FBRUEsTUFBSSxDQUFDQSxNQUFNLENBQUNELE9BQUQsQ0FBWCxFQUFzQjtBQUNwQkMsVUFBTSxDQUFDRCxPQUFELENBQU4sR0FBa0I7QUFDaEJ2UCxlQUFTLEVBQUUsSUFBSXpCLFFBQUosQ0FBYTtBQUN0QjBCLGFBQUssRUFBRTtBQURlLE9BQWIsQ0FESztBQUloQkwsV0FBSyxFQUFFLENBSlM7QUFLaEJDLFlBQU0sRUFBRSxDQUxRO0FBTWhCNFAsaUJBQVcsRUFBRTdRLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjLElBQWQ7QUFORyxLQUFsQjtBQVNBTCx5QkFBcUIsQ0FBQ2xFLE9BQXRCLENBQThCLFVBQVU0RixLQUFWLEVBQWlCO0FBQzdDc1AsWUFBTSxDQUFDRCxPQUFELENBQU4sQ0FBZ0JyUCxLQUFoQixJQUF5QixDQUF6QjtBQUNELEtBRkQ7QUFHRDs7QUFFRCxTQUFPLEtBQUtFLGVBQUwsQ0FBcUI5QixNQUFyQixFQUE2QmtSLE1BQTdCLENBQW9DRCxPQUFwQyxDQUFQO0FBQ0QsQ0EzQkQ7O0FBNkJBSCxTQUFTLENBQUMvUixTQUFWLENBQW9Cb0QsY0FBcEIsR0FBcUMsVUFBVW5DLE1BQVYsRUFBa0IrRSxLQUFsQixFQUF5QjVHLEdBQXpCLEVBQThCO0FBQ2pFLE1BQUlpVCxjQUFjLEdBQUcsS0FBS2pRLFdBQUwsQ0FBaUJuQixNQUFqQixFQUF5QitFLEtBQUssQ0FBQzFDLElBQS9CLENBQXJCOztBQUVBLE1BQUksQ0FBQyxLQUFLUCxlQUFMLENBQXFCOUIsTUFBckIsRUFBNkIrQixTQUFsQyxFQUE2QztBQUMzQyxTQUFLRCxlQUFMLENBQXFCOUIsTUFBckIsRUFBNkIrQixTQUE3QixHQUF5Q2dELEtBQUssQ0FBQzdDLEVBQS9DO0FBQ0QsR0FMZ0UsQ0FPakU7OztBQUNBaEMsdUJBQXFCLENBQUNsRSxPQUF0QixDQUE4QjRGLEtBQUssSUFBSTtBQUNyQyxRQUFJYSxLQUFLLEdBQUdzQyxLQUFLLENBQUNyQyxPQUFOLENBQWNkLEtBQWQsQ0FBWjs7QUFDQSxRQUFJYSxLQUFLLEdBQUcsQ0FBWixFQUFlO0FBQ2IyTyxvQkFBYyxDQUFDeFAsS0FBRCxDQUFkLElBQXlCYSxLQUF6QjtBQUNEO0FBQ0YsR0FMRDtBQU9BLFFBQU1yRSxVQUFVLEdBQUdELEdBQUcsQ0FBQ0MsVUFBdkI7QUFDQSxNQUFJaVQsWUFBSjs7QUFFQSxNQUFJalQsVUFBVSxHQUFHLEdBQWpCLEVBQXNCO0FBQ3BCaVQsZ0JBQVksR0FBRyxLQUFmO0FBQ0QsR0FGRCxNQUVPLElBQUlqVCxVQUFVLEdBQUcsR0FBakIsRUFBc0I7QUFDM0JpVCxnQkFBWSxHQUFHLEtBQWY7QUFDRCxHQUZNLE1BRUEsSUFBSWpULFVBQVUsR0FBRyxHQUFqQixFQUFzQjtBQUMzQmlULGdCQUFZLEdBQUcsS0FBZjtBQUNELEdBRk0sTUFFQSxJQUFJalQsVUFBVSxHQUFHLEdBQWpCLEVBQXNCO0FBQzNCaVQsZ0JBQVksR0FBRyxLQUFmO0FBQ0QsR0FGTSxNQUVBLElBQUlqVCxVQUFVLEdBQUcsR0FBakIsRUFBc0I7QUFDM0JpVCxnQkFBWSxHQUFHLEtBQWY7QUFDRDs7QUFFREQsZ0JBQWMsQ0FBQ0QsV0FBZixDQUEyQkUsWUFBM0IsSUFBMkNELGNBQWMsQ0FBQ0QsV0FBZixDQUEyQkUsWUFBM0IsS0FBNEMsQ0FBdkY7QUFDQUQsZ0JBQWMsQ0FBQ0QsV0FBZixDQUEyQkUsWUFBM0IsS0FBNEMsQ0FBNUM7QUFFQUQsZ0JBQWMsQ0FBQzlQLEtBQWYsSUFBd0IsQ0FBeEI7QUFDQThQLGdCQUFjLENBQUMxUCxTQUFmLENBQXlCaUIsR0FBekIsQ0FBNkJvQyxLQUFLLENBQUNyQyxPQUFOLENBQWNFLEtBQTNDO0FBQ0EsT0FBS2QsZUFBTCxDQUFxQjlCLE1BQXJCLEVBQTZCNkMsT0FBN0IsR0FBdUNrQyxLQUFLLENBQUNyQyxPQUFOLENBQWNSLEVBQXJEO0FBQ0QsQ0FwQ0Q7O0FBc0NBNE8sU0FBUyxDQUFDL1IsU0FBVixDQUFvQm9FLFlBQXBCLEdBQW1DLFlBQVc7QUFDNUMsTUFBSW5HLE9BQU8sR0FBRztBQUNac1UsZUFBVyxFQUFFLEVBREQ7QUFFWkMsZ0JBQVksRUFBRTtBQUZGLEdBQWQ7QUFLQSxNQUFJelAsZUFBZSxHQUFHLEtBQUtBLGVBQTNCO0FBQ0EsT0FBS0EsZUFBTCxHQUF1QnhCLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjLElBQWQsQ0FBdkI7O0FBRUEsT0FBSSxJQUFJK0MsR0FBUixJQUFleEIsZUFBZixFQUFnQztBQUM5QixRQUFJWSxPQUFPLEdBQUdaLGVBQWUsQ0FBQ3dCLEdBQUQsQ0FBN0IsQ0FEOEIsQ0FFOUI7O0FBQ0EsUUFBSXZCLFNBQVMsR0FBR1csT0FBTyxDQUFDWCxTQUF4QjtBQUNBVyxXQUFPLENBQUNYLFNBQVIsR0FBb0JqSCxNQUFNLENBQUN5SSxVQUFQLENBQWtCQyxRQUFsQixDQUEyQnpCLFNBQTNCLENBQXBCOztBQUVBLFNBQUksSUFBSXlQLFdBQVIsSUFBdUI5TyxPQUFPLENBQUN3TyxNQUEvQixFQUF1QztBQUNyQ2hSLDJCQUFxQixDQUFDbEUsT0FBdEIsQ0FBOEIsVUFBVTRGLEtBQVYsRUFBaUI7QUFDN0NjLGVBQU8sQ0FBQ3dPLE1BQVIsQ0FBZU0sV0FBZixFQUE0QjVQLEtBQTVCLEtBQXNDYyxPQUFPLENBQUN3TyxNQUFSLENBQWVNLFdBQWYsRUFBNEJsUSxLQUFsRTtBQUNELE9BRkQ7QUFHRDs7QUFFRHRFLFdBQU8sQ0FBQ3NVLFdBQVIsQ0FBb0JwUyxJQUFwQixDQUF5QjRDLGVBQWUsQ0FBQ3dCLEdBQUQsQ0FBeEM7QUFDRDs7QUFFRHRHLFNBQU8sQ0FBQ3VVLFlBQVIsR0FBdUIsS0FBSzFRLFdBQUwsQ0FBaUI2QyxhQUFqQixFQUF2QjtBQUVBLFNBQU8xRyxPQUFQO0FBQ0QsQ0EzQkQ7O0FBM0ZBZ00sTUFBTSxDQUFDeUksYUFBUCxDQXdIZVgsU0F4SGYsRTs7Ozs7Ozs7Ozs7QUNBQSxJQUFJWSxJQUFJLEdBQUc1VyxNQUFNLENBQUM0VyxJQUFQLEdBQWMsRUFBekI7O0FBRUFBLElBQUksQ0FBQ0MsUUFBTCxHQUFnQixVQUFTcFAsRUFBVCxFQUFhckYsUUFBYixFQUF1QjtBQUNyQ3BDLFFBQU0sQ0FBQzhXLE9BQVAsQ0FBZUMsTUFBZixDQUFzQnRQLEVBQXRCLEVBQ0d1UCxJQURILENBQ1EsVUFBU3pULElBQVQsRUFBZTtBQUNuQm5CLFlBQVEsQ0FBQyxJQUFELEVBQU9tQixJQUFQLENBQVI7QUFDRCxHQUhILEVBSUcwVCxLQUpILENBSVMsVUFBU3ZWLEdBQVQsRUFBYztBQUNuQlUsWUFBUSxDQUFDVixHQUFELENBQVI7QUFDRCxHQU5IO0FBT0QsQ0FSRDs7QUFXQWtWLElBQUksQ0FBQ00sUUFBTCxHQUFnQixVQUFTelAsRUFBVCxFQUFhMFAsT0FBYixFQUFzQi9VLFFBQXRCLEVBQWdDO0FBQzlDcEMsUUFBTSxDQUFDOFcsT0FBUCxDQUFlTSxTQUFmLENBQXlCM1AsRUFBekIsRUFBNkIwUCxPQUE3QixFQUNHSCxJQURILENBQ1EsVUFBU3pULElBQVQsRUFBZTtBQUNuQm5CLFlBQVEsQ0FBQyxJQUFELEVBQU9tQixJQUFQLENBQVI7QUFDRCxHQUhILEVBSUcwVCxLQUpILENBSVMsVUFBU3ZWLEdBQVQsRUFBYztBQUNuQlUsWUFBUSxDQUFDVixHQUFELENBQVI7QUFDRCxHQU5IO0FBT0QsQ0FSRDs7QUFVQWtWLElBQUksQ0FBQ1MsR0FBTCxHQUFXclgsTUFBTSxDQUFDSyxVQUFQLENBQWtCdVcsSUFBSSxDQUFDTSxRQUF2QixDQUFYO0FBQ0FOLElBQUksQ0FBQ1UsR0FBTCxHQUFXdFgsTUFBTSxDQUFDSyxVQUFQLENBQWtCdVcsSUFBSSxDQUFDQyxRQUF2QixDQUFYLEM7Ozs7Ozs7Ozs7O0FDeEJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBRUFuVSxLQUFLLEdBQUcsTUFBTTtBQUNaNlUsYUFBVyxHQVNIO0FBQUEsUUFUSztBQUNYMVUsaUJBQVcsR0FBRyxJQURIO0FBQ1M7QUFDcEIyVSxjQUFRLEdBQUcsR0FGQTtBQUdYO0FBQ0E7QUFDQTFVLGdCQUFVLEdBQUcsSUFBSSxLQUxOO0FBS2E7QUFDeEJGLGdCQUFVLEdBQUcsRUFORjtBQU9YRCxjQUFRLEdBQUcsQ0FQQTtBQVFYOFUsVUFBSSxHQUFHLEdBUkksQ0FRQzs7QUFSRCxLQVNMLHVFQUFKLEVBQUk7QUFDTixTQUFLNVUsV0FBTCxHQUFtQkEsV0FBbkI7QUFDQSxTQUFLMlUsUUFBTCxHQUFnQkEsUUFBaEI7QUFDQSxTQUFLMVUsVUFBTCxHQUFrQkEsVUFBbEI7QUFDQSxTQUFLRixVQUFMLEdBQWtCQSxVQUFsQjtBQUNBLFNBQUtELFFBQUwsR0FBZ0JBLFFBQWhCO0FBQ0EsU0FBSzhVLElBQUwsR0FBWUEsSUFBWjtBQUNBLFNBQUtDLFVBQUwsR0FBa0IsSUFBbEI7QUFDRCxHQWxCVyxDQW9CWjs7O0FBQ0FDLE9BQUssR0FBRztBQUNOLFFBQUcsS0FBS0QsVUFBUixFQUNFRSxZQUFZLENBQUMsS0FBS0YsVUFBTixDQUFaO0FBQ0YsU0FBS0EsVUFBTCxHQUFrQixJQUFsQjtBQUNELEdBekJXLENBMkJaO0FBQ0E7OztBQUNBRyxVQUFRLENBQUNyUixLQUFELEVBQVE7QUFDZCxRQUFHQSxLQUFLLEdBQUcsS0FBSzdELFFBQWhCLEVBQ0UsT0FBTyxLQUFLQyxVQUFaO0FBRUYsUUFBSWtWLE9BQU8sR0FBR0MsSUFBSSxDQUFDQyxHQUFMLENBQ1osS0FBS2xWLFVBRE8sRUFFWixLQUFLRCxXQUFMLEdBQW1Ca1YsSUFBSSxDQUFDRSxHQUFMLENBQVMsS0FBS1QsUUFBZCxFQUF3QmhSLEtBQXhCLENBRlAsQ0FBZCxDQUpjLENBT2Q7QUFDQTs7QUFDQXNSLFdBQU8sR0FBR0EsT0FBTyxJQUFLSSxNQUFNLENBQUNDLFFBQVAsS0FBb0IsS0FBS1YsSUFBMUIsSUFDQyxJQUFJLEtBQUtBLElBQUwsR0FBVSxDQURmLENBQUosQ0FBakI7QUFFQSxXQUFPTSxJQUFJLENBQUNLLElBQUwsQ0FBVU4sT0FBVixDQUFQO0FBQ0QsR0F6Q1csQ0EyQ1o7OztBQUNBNVUsWUFBVSxDQUFDc0QsS0FBRCxFQUFRNlIsRUFBUixFQUFZO0FBQ3BCLFVBQU1QLE9BQU8sR0FBRyxLQUFLRCxRQUFMLENBQWNyUixLQUFkLENBQWhCOztBQUNBLFFBQUcsS0FBS2tSLFVBQVIsRUFDRUUsWUFBWSxDQUFDLEtBQUtGLFVBQU4sQ0FBWjtBQUVGLFNBQUtBLFVBQUwsR0FBa0JZLFVBQVUsQ0FBQ0QsRUFBRCxFQUFLUCxPQUFMLENBQTVCO0FBQ0EsV0FBT0EsT0FBUDtBQUNEOztBQW5EVyxDQUFkLEM7Ozs7Ozs7Ozs7O0FDWkE1SixNQUFNLENBQUNxSyxNQUFQLENBQWM7QUFBQ3RLLGlCQUFlLEVBQUMsTUFBSUE7QUFBckIsQ0FBZDs7QUFBQSxNQUFNO0FBQUU5STtBQUFGLElBQWUxRSxPQUFPLENBQUMsdUJBQUQsQ0FBNUI7O0FBRUErWCxpQkFBaUIsR0FBRyxVQUFTM1gsSUFBVCxFQUFlO0FBQ2pDLE1BQUk0WCxPQUFPLEdBQUc1WCxJQUFJLENBQUNBLElBQUksQ0FBQ2lCLE1BQUwsR0FBYSxDQUFkLENBQWxCO0FBQ0EsU0FBUSxPQUFPMlcsT0FBUixJQUFvQixVQUEzQjtBQUNELENBSEQ7O0FBS0FDLFFBQVEsR0FBRyxVQUFTdFMsS0FBVCxFQUFnQjtBQUN6QixPQUFLcUIsRUFBTCxHQUFVLENBQVY7QUFDRCxDQUZEOztBQUlBaVIsUUFBUSxDQUFDelUsU0FBVCxDQUFtQnFULEdBQW5CLEdBQXlCLFlBQVc7QUFDbEMsU0FBTyxLQUFLLEtBQUs3UCxFQUFMLEVBQVo7QUFDRCxDQUZEOztBQUlBa1IsZUFBZSxHQUFHLElBQUlELFFBQUosRUFBbEIsQyxDQUVBOztBQUNBRSxlQUFlLEdBQUcsVUFBVWxVLEtBQVYsRUFBaUI7QUFDakMsUUFBTWdSLEtBQUssR0FBRyxDQUFDaFIsS0FBSyxJQUFJLElBQUkvQyxLQUFKLEVBQVYsRUFBdUIrVCxLQUF2QixDQUE2Qm1ELEtBQTdCLENBQW1DLElBQW5DLENBQWQ7QUFDQSxNQUFJQyxRQUFRLEdBQUcsQ0FBZixDQUZpQyxDQUlqQztBQUNBOztBQUNBLFNBQU9BLFFBQVEsR0FBR3BELEtBQUssQ0FBQzVULE1BQXhCLEVBQWdDZ1gsUUFBUSxFQUF4QyxFQUE0QztBQUMxQyxRQUFJcEQsS0FBSyxDQUFDb0QsUUFBRCxDQUFMLENBQWdCdlUsT0FBaEIsQ0FBd0IsZ0JBQXhCLE1BQThDLENBQUMsQ0FBbkQsRUFBc0Q7QUFDcEQ7QUFDRDtBQUNGOztBQUVELFNBQU9tUixLQUFLLENBQUMzVSxLQUFOLENBQVkrWCxRQUFaLEVBQXNCQyxJQUF0QixDQUEyQixJQUEzQixDQUFQO0FBQ0QsQ0FiRCxDLENBZUE7QUFDQTtBQUNBOzs7QUFDQUMsY0FBYyxHQUFHLFNBQVNBLGNBQVQsQ0FBd0JDLE9BQXhCLEVBQWlDWixFQUFqQyxFQUFxQ3hYLElBQXJDLEVBQTJDO0FBQzFELE1BQUlxWSxDQUFDLEdBQUdyWSxJQUFSOztBQUNBLFVBQU9xWSxDQUFDLENBQUNwWCxNQUFUO0FBQ0UsU0FBSyxDQUFMO0FBQ0UsYUFBT3VXLEVBQUUsQ0FBQ3BELElBQUgsQ0FBUWdFLE9BQVIsQ0FBUDs7QUFDRixTQUFLLENBQUw7QUFDRSxhQUFPWixFQUFFLENBQUNwRCxJQUFILENBQVFnRSxPQUFSLEVBQWlCQyxDQUFDLENBQUMsQ0FBRCxDQUFsQixDQUFQOztBQUNGLFNBQUssQ0FBTDtBQUNFLGFBQU9iLEVBQUUsQ0FBQ3BELElBQUgsQ0FBUWdFLE9BQVIsRUFBaUJDLENBQUMsQ0FBQyxDQUFELENBQWxCLEVBQXVCQSxDQUFDLENBQUMsQ0FBRCxDQUF4QixDQUFQOztBQUNGLFNBQUssQ0FBTDtBQUNFLGFBQU9iLEVBQUUsQ0FBQ3BELElBQUgsQ0FBUWdFLE9BQVIsRUFBaUJDLENBQUMsQ0FBQyxDQUFELENBQWxCLEVBQXVCQSxDQUFDLENBQUMsQ0FBRCxDQUF4QixFQUE2QkEsQ0FBQyxDQUFDLENBQUQsQ0FBOUIsQ0FBUDs7QUFDRixTQUFLLENBQUw7QUFDRSxhQUFPYixFQUFFLENBQUNwRCxJQUFILENBQVFnRSxPQUFSLEVBQWlCQyxDQUFDLENBQUMsQ0FBRCxDQUFsQixFQUF1QkEsQ0FBQyxDQUFDLENBQUQsQ0FBeEIsRUFBNkJBLENBQUMsQ0FBQyxDQUFELENBQTlCLEVBQW1DQSxDQUFDLENBQUMsQ0FBRCxDQUFwQyxDQUFQOztBQUNGLFNBQUssQ0FBTDtBQUNFLGFBQU9iLEVBQUUsQ0FBQ3BELElBQUgsQ0FBUWdFLE9BQVIsRUFBaUJDLENBQUMsQ0FBQyxDQUFELENBQWxCLEVBQXVCQSxDQUFDLENBQUMsQ0FBRCxDQUF4QixFQUE2QkEsQ0FBQyxDQUFDLENBQUQsQ0FBOUIsRUFBbUNBLENBQUMsQ0FBQyxDQUFELENBQXBDLEVBQXlDQSxDQUFDLENBQUMsQ0FBRCxDQUExQyxDQUFQOztBQUNGO0FBQ0UsYUFBT2IsRUFBRSxDQUFDalgsS0FBSCxDQUFTNlgsT0FBVCxFQUFrQkMsQ0FBbEIsQ0FBUDtBQWRKO0FBZ0JELENBbEJEOztBQW9CQUMsaUJBQWlCLEdBQUcsWUFBWTtBQUM5QixTQUFPO0FBQ0wsbUJBQWUzWixvQkFBb0IsQ0FBQyxhQUFELENBRDlCO0FBRUwsbUJBQWVBLG9CQUFvQixDQUFDLGFBQUQsQ0FGOUI7QUFHTCwwQkFBc0JBLG9CQUFvQixDQUFDLG9CQUFEO0FBSHJDLEdBQVA7QUFLRCxDQU5ELEMsQ0FRQTs7O0FBQ0FtTixTQUFTLEdBQUcsVUFBVXlNLEdBQVYsRUFBZTtBQUN6QixNQUFJQSxHQUFHLFlBQVlDLEdBQWYsSUFBc0JELEdBQUcsWUFBWUUsR0FBekMsRUFBOEM7QUFDNUMsV0FBT0YsR0FBRyxDQUFDblIsSUFBWDtBQUNEOztBQUVELFNBQU96QyxNQUFNLENBQUMrVCxJQUFQLENBQVlILEdBQVosRUFBaUJ0WCxNQUF4QjtBQUNELENBTkQsQyxDQVFBO0FBQ0E7OztBQUNBZ0ssT0FBTyxHQUFHLFVBQVVzTixHQUFWLEVBQWVoWCxRQUFmLEVBQXlCO0FBQ2pDLE1BQUlnWCxHQUFHLFlBQVlDLEdBQW5CLEVBQXdCO0FBQ3RCLFdBQU9ELEdBQUcsQ0FBQ2xZLE9BQUosQ0FBWWtCLFFBQVosQ0FBUDtBQUNEOztBQUVELE9BQUssSUFBSW9HLEdBQVQsSUFBZ0I0USxHQUFoQixFQUFxQjtBQUNuQixRQUFJelIsS0FBSyxHQUFHeVIsR0FBRyxDQUFDNVEsR0FBRCxDQUFmO0FBQ0FwRyxZQUFRLENBQUN1RixLQUFELEVBQVFhLEdBQVIsQ0FBUjtBQUNEO0FBQ0YsQ0FURCxDLENBV0E7OztBQUNBK0UsV0FBVyxHQUFHLFVBQVU2TCxHQUFWLEVBQWU1USxHQUFmLEVBQW9CO0FBQ2hDLE1BQUk0USxHQUFHLFlBQVlDLEdBQW5CLEVBQXdCO0FBQ3RCLFdBQU9ELEdBQUcsQ0FBQzlCLEdBQUosQ0FBUTlPLEdBQVIsQ0FBUDtBQUNEOztBQUVELFNBQU80USxHQUFHLENBQUM1USxHQUFELENBQVY7QUFDRCxDQU5EOztBQVFPLFNBQVN5RixlQUFULEdBQTRCO0FBQ2pDLFNBQU8sSUFBSTlJLFFBQUosQ0FBYTtBQUNsQjBCLFNBQUssRUFBRTtBQURXLEdBQWIsQ0FBUDtBQUdELEM7Ozs7Ozs7Ozs7O0FDbkdELElBQUlnQyxNQUFNLEdBQUcyUSxTQUFTLEVBQXRCOztBQUVBdFIsR0FBRyxHQUFHLFVBQVUzRixRQUFWLEVBQW9CO0FBQ3hCLE9BQUtKLElBQUwsR0FBWSxpQkFBWjtBQUNBLE9BQUtzWCxXQUFMLENBQWlCbFgsUUFBakI7QUFDQSxPQUFLbVgsSUFBTCxHQUFZLENBQVo7QUFDQSxPQUFLQyxNQUFMLEdBQWMsS0FBZDtBQUNBLE9BQUtDLFdBQUwsR0FBbUIsQ0FBbkI7QUFDQSxPQUFLQyxNQUFMLEdBQWMsSUFBSW5YLEtBQUosQ0FBVTtBQUN0QkcsZUFBVyxFQUFFLE9BQUssRUFESTtBQUV0QkMsY0FBVSxFQUFFLE9BQUssRUFBTCxHQUFRLEVBRkU7QUFHdEJILFlBQVEsRUFBRTtBQUhZLEdBQVYsQ0FBZDtBQUtELENBWEQ7O0FBYUF1RixHQUFHLENBQUNDLElBQUosR0FBVyxZQUFXO0FBQ3BCLE1BQUl5SCxHQUFHLEdBQUdqQyxJQUFJLENBQUNpQyxHQUFMLEVBQVY7O0FBQ0EsTUFBRyxPQUFPQSxHQUFQLElBQWMsUUFBakIsRUFBMkI7QUFDekIsV0FBT0EsR0FBUDtBQUNELEdBRkQsTUFFTyxJQUFHQSxHQUFHLFlBQVlqQyxJQUFsQixFQUF3QjtBQUM3QjtBQUNBO0FBQ0EsV0FBT2lDLEdBQUcsQ0FBQ2hDLE9BQUosRUFBUDtBQUNELEdBSk0sTUFJQTtBQUNMO0FBQ0EsV0FBUSxJQUFJRCxJQUFKLEVBQUQsQ0FBYUMsT0FBYixFQUFQO0FBQ0Q7QUFDRixDQVpEOztBQWNBMUYsR0FBRyxDQUFDakUsU0FBSixDQUFjd1YsV0FBZCxHQUE0QixVQUFTbFgsUUFBVCxFQUFtQjtBQUM3QyxPQUFLQSxRQUFMLEdBQWdCQSxRQUFRLEdBQUdBLFFBQVEsR0FBRyxLQUFLSixJQUFuQixHQUEwQixJQUFsRDtBQUNELENBRkQ7O0FBSUErRixHQUFHLENBQUNqRSxTQUFKLENBQWMySixPQUFkLEdBQXdCLFlBQVc7QUFDakMsU0FBTzFGLEdBQUcsQ0FBQ0MsSUFBSixLQUFhNFAsSUFBSSxDQUFDK0IsS0FBTCxDQUFXLEtBQUtKLElBQWhCLENBQXBCO0FBQ0QsQ0FGRDs7QUFJQXhSLEdBQUcsQ0FBQ2pFLFNBQUosQ0FBY3lFLFFBQWQsR0FBeUIsVUFBU3FSLFNBQVQsRUFBb0I7QUFDM0MsU0FBT0EsU0FBUyxHQUFHaEMsSUFBSSxDQUFDSyxJQUFMLENBQVUsS0FBS3NCLElBQWYsQ0FBbkI7QUFDRCxDQUZEOztBQUlBeFIsR0FBRyxDQUFDakUsU0FBSixDQUFjK1YsSUFBZCxHQUFxQixZQUFXO0FBQzlCLE1BQUksS0FBS3pYLFFBQUwsS0FBa0IsSUFBdEIsRUFBNEI7QUFDMUI7QUFDRDs7QUFFRHNHLFFBQU0sQ0FBQyxXQUFELENBQU47QUFDQSxNQUFJOEMsSUFBSSxHQUFHLElBQVg7QUFDQSxNQUFJbkosVUFBVSxHQUFHLENBQWpCO0FBQ0EsTUFBSUMsS0FBSyxHQUFHLElBQUlDLEtBQUosQ0FBVTtBQUNwQkcsZUFBVyxFQUFFLE9BQUssRUFERTtBQUVwQkMsY0FBVSxFQUFFLE9BQUssRUFGRztBQUdwQkgsWUFBUSxFQUFFLENBSFU7QUFJcEJDLGNBQVUsRUFBRTtBQUpRLEdBQVYsQ0FBWjtBQU1BOEYsVUFBUTs7QUFFUixXQUFTQSxRQUFULEdBQXFCO0FBQ25CLFFBQUdsRyxVQUFVLEdBQUMsQ0FBZCxFQUFpQjtBQUNmcUcsWUFBTSxDQUFDLCtCQUFELEVBQWtDckcsVUFBbEMsQ0FBTixDQURlLENBRWY7O0FBQ0FDLFdBQUssQ0FBQ1MsVUFBTixDQUFpQlYsVUFBVSxFQUEzQixFQUErQnlYLFFBQS9CO0FBQ0QsS0FKRCxNQUlPO0FBQ0xwUixZQUFNLENBQUMseUJBQUQsQ0FBTjtBQUNBOEMsVUFBSSxDQUFDa08sTUFBTCxDQUFZM1csVUFBWixDQUF1QnlJLElBQUksQ0FBQ2lPLFdBQUwsRUFBdkIsRUFBMkMsWUFBWTtBQUNyRCxZQUFJL1ksSUFBSSxHQUFHLEdBQUdFLEtBQUgsQ0FBU2tVLElBQVQsQ0FBY2lGLFNBQWQsQ0FBWDtBQUNBdk8sWUFBSSxDQUFDcU8sSUFBTCxDQUFVNVksS0FBVixDQUFnQnVLLElBQWhCLEVBQXNCOUssSUFBdEI7QUFDRCxPQUhEO0FBSUQ7QUFDRixHQTVCNkIsQ0E4QjlCO0FBQ0E7OztBQUNBLFdBQVNvWixRQUFULEdBQXFCO0FBQ25CdE8sUUFBSSxDQUFDd08sYUFBTCxDQUFtQixVQUFTelksR0FBVCxFQUFjO0FBQy9CLFVBQUcsQ0FBQ0EsR0FBSixFQUFTO0FBQ1AwWSx5QkFBaUI7QUFDbEIsT0FGRCxNQUVPO0FBQ0wxUixnQkFBUTtBQUNUO0FBQ0YsS0FORDtBQU9EOztBQUVELFdBQVMwUixpQkFBVCxHQUE4QjtBQUM1QixRQUFJQyxlQUFlLEdBQUksSUFBSTFNLElBQUosRUFBRCxDQUFhQyxPQUFiLEVBQXRCO0FBQ0FqQyxRQUFJLENBQUN3TyxhQUFMLENBQW1CLFVBQVN6WSxHQUFULEVBQWM0WSxVQUFkLEVBQTBCO0FBQzNDLFVBQUcsQ0FBQzVZLEdBQUQsSUFBUTRZLFVBQVgsRUFBdUI7QUFDckI7QUFDQSxZQUFJQyxXQUFXLEdBQUcsQ0FBRSxJQUFJNU0sSUFBSixFQUFELENBQWFDLE9BQWIsS0FBeUJ5TSxlQUExQixJQUEyQyxDQUE3RDtBQUNBLFlBQUlHLGVBQWUsR0FBR0YsVUFBVSxHQUFHQyxXQUFuQztBQUNBNU8sWUFBSSxDQUFDK04sSUFBTCxHQUFZYyxlQUFlLEdBQUdILGVBQTlCO0FBQ0ExTyxZQUFJLENBQUNnTyxNQUFMLEdBQWMsSUFBZCxDQUxxQixDQU1yQjs7QUFDQWhPLFlBQUksQ0FBQ2tPLE1BQUwsQ0FBWTNXLFVBQVosQ0FBdUJ5SSxJQUFJLENBQUNpTyxXQUFMLEVBQXZCLEVBQTJDLFlBQVk7QUFDckQsY0FBSS9ZLElBQUksR0FBRyxHQUFHRSxLQUFILENBQVNrVSxJQUFULENBQWNpRixTQUFkLENBQVg7QUFDQXZPLGNBQUksQ0FBQ3FPLElBQUwsQ0FBVTVZLEtBQVYsQ0FBZ0J1SyxJQUFoQixFQUFzQjlLLElBQXRCO0FBQ0QsU0FIRDtBQUlBZ0ksY0FBTSxDQUFDLGlDQUFELEVBQW9DOEMsSUFBSSxDQUFDK04sSUFBekMsQ0FBTjtBQUNELE9BWkQsTUFZTztBQUNMaFIsZ0JBQVE7QUFDVDtBQUNGLEtBaEJEO0FBaUJEO0FBQ0YsQ0E5REQ7O0FBZ0VBUixHQUFHLENBQUNqRSxTQUFKLENBQWNrVyxhQUFkLEdBQThCLFVBQVMvWCxRQUFULEVBQW1CO0FBQy9DLE1BQUl1SixJQUFJLEdBQUcsSUFBWDs7QUFFQSxNQUFJQSxJQUFJLENBQUNwSixRQUFMLEtBQWtCLElBQXRCLEVBQTRCO0FBQzFCLFVBQU0sSUFBSVosS0FBSixDQUFVLCtDQUFWLENBQU47QUFDRDs7QUFFRCxNQUFHeEIsTUFBTSxDQUFDRyxRQUFWLEVBQW9CO0FBQ2xCTixVQUFNLENBQUM4VyxPQUFQLENBQWVRLEdBQWYsQ0FBbUIzTCxJQUFJLENBQUN4SixJQUF4QixFQUE4QjtBQUFFc1ksZUFBUyxFQUFFO0FBQWIsS0FBOUIsRUFBbUR6RCxJQUFuRCxDQUF3RHhULE9BQU8sSUFBSTtBQUNqRSxVQUFJOFcsVUFBVSxHQUFHSSxRQUFRLENBQUNsWCxPQUFELENBQXpCO0FBQ0FwQixjQUFRLENBQUMsSUFBRCxFQUFPa1ksVUFBUCxDQUFSO0FBQ0QsS0FIRCxFQUlDckQsS0FKRCxDQUlPdlYsR0FBRyxJQUFJO0FBQ1pVLGNBQVEsQ0FBQ1YsR0FBRCxDQUFSO0FBQ0QsS0FORDtBQU9ELEdBUkQsTUFRTztBQUNMaUMsZUFBVyxDQUFDLEtBQUQsRUFBUWdJLElBQUksQ0FBQ3BKLFFBQUwsc0JBQTRCLElBQUlvTCxJQUFKLEdBQVdDLE9BQVgsRUFBNUIsY0FBb0RtSyxJQUFJLENBQUM0QyxNQUFMLEVBQXBELENBQVIsRUFBNkUsVUFBU2paLEdBQVQsRUFBYzJCLEdBQWQsRUFBbUI7QUFDekcsVUFBSTNCLEdBQUosRUFBUztBQUNQVSxnQkFBUSxDQUFDVixHQUFELENBQVI7QUFDRCxPQUZELE1BRU87QUFDTCxZQUFJNFksVUFBVSxHQUFHSSxRQUFRLENBQUNyWCxHQUFHLENBQUNHLE9BQUwsQ0FBekI7QUFDQXBCLGdCQUFRLENBQUMsSUFBRCxFQUFPa1ksVUFBUCxDQUFSO0FBQ0Q7QUFDRixLQVBVLENBQVg7QUFRRDtBQUNGLENBekJEOztBQTJCQSxTQUFTZCxTQUFULEdBQXFCO0FBQ25CLE1BQUdyWixNQUFNLENBQUNHLFFBQVYsRUFBb0I7QUFDbEIsV0FBT0UsR0FBRyxDQUFDQyxPQUFKLENBQVksT0FBWixFQUFxQixZQUFyQixDQUFQO0FBQ0QsR0FGRCxNQUVPO0FBQ0wsV0FBTyxVQUFTZ0IsT0FBVCxFQUFrQjtBQUN2QixVQUFJbVosWUFBWSxHQUNkemEsTUFBTSxDQUFDMGEsYUFBUCxDQUFxQkMsT0FBckIsQ0FBNkIsWUFBN0IsTUFBK0MsSUFBL0MsSUFDRyxPQUFPM1gsT0FBUCxLQUFtQixXQUZ4Qjs7QUFJQSxVQUFHeVgsWUFBSCxFQUFpQjtBQUNmLFlBQUduWixPQUFILEVBQVk7QUFDVkEsaUJBQU8sR0FBRyxnQkFBZ0JBLE9BQTFCO0FBQ0F5WSxtQkFBUyxDQUFDLENBQUQsQ0FBVCxHQUFlelksT0FBZjtBQUNEOztBQUNEMEIsZUFBTyxDQUFDNFgsR0FBUixDQUFZM1osS0FBWixDQUFrQitCLE9BQWxCLEVBQTJCK1csU0FBM0I7QUFDRDtBQUNGLEtBWkQ7QUFhRDtBQUNGLEM7Ozs7Ozs7Ozs7O0FDdEpELElBQUljLEdBQUcsR0FBR3hhLEdBQUcsQ0FBQ0MsT0FBSixDQUFZLEtBQVosQ0FBVjs7QUFDQSxJQUFJMEIsSUFBSSxHQUFHM0IsR0FBRyxDQUFDQyxPQUFKLENBQVksTUFBWixDQUFYOztBQUNBLElBQUl3YSxFQUFFLEdBQUd6YSxHQUFHLENBQUNDLE9BQUosQ0FBWSxJQUFaLENBQVQ7O0FBQ0EsSUFBSW9JLE1BQU0sR0FBR3JJLEdBQUcsQ0FBQ0MsT0FBSixDQUFZLE9BQVosRUFBcUIsdUJBQXJCLENBQWIsQyxDQUVBOzs7QUFDQSxJQUFJeWEsV0FBVyxHQUFHQyxvQkFBb0IsQ0FBQ0MsVUFBckIsQ0FBZ0NGLFdBQWxEO0FBQ0EsSUFBSUcsV0FBVyxHQUFJRixvQkFBb0IsQ0FBQ0MsVUFBckIsQ0FBZ0NDLFdBQW5EO0FBQ0EsSUFBSUMsU0FBUyxHQUFHSCxvQkFBb0IsQ0FBQ0csU0FBckM7QUFDQSxJQUFJQyxjQUFKOztBQUVBLElBQUlGLFdBQUosRUFBaUI7QUFDZkUsZ0JBQWMsR0FBR0YsV0FBVyxDQUFDRyxNQUFaLENBQW1CLENBQUNDLE1BQUQsRUFBU2hjLElBQVQsS0FBa0I7QUFDcERnYyxVQUFNLENBQUNoYyxJQUFELENBQU4sR0FBZTBDLElBQUksQ0FBQ3VaLE9BQUwsQ0FBYXZaLElBQUksQ0FBQ3daLE9BQUwsQ0FBYUwsU0FBYixDQUFiLEVBQXNDN2IsSUFBdEMsQ0FBZjtBQUVBLFdBQU9nYyxNQUFQO0FBQ0QsR0FKZ0IsRUFJZCxFQUpjLENBQWpCO0FBS0QsQ0FORCxNQU1PO0FBQ0xGLGdCQUFjLEdBQUcvVixNQUFNLENBQUMrVCxJQUFQLENBQVkyQixXQUFaLEVBQXlCTSxNQUF6QixDQUFnQyxDQUFDQyxNQUFELEVBQVNqVCxHQUFULEtBQWlCO0FBQ2hFaVQsVUFBTSxDQUFDalQsR0FBRCxDQUFOLEdBQWNyRyxJQUFJLENBQUN1WixPQUFMLENBQWFKLFNBQWIsRUFBd0JuWixJQUFJLENBQUN3WixPQUFMLENBQWFULFdBQVcsQ0FBQzFTLEdBQUQsQ0FBeEIsQ0FBeEIsQ0FBZDtBQUVBLFdBQU9pVCxNQUFQO0FBQ0QsR0FKZ0IsRUFJZCxFQUpjLENBQWpCO0FBS0Q7O0FBRURHLGlCQUFpQixHQUFHLFlBQXFCO0FBQUEsTUFBWEMsSUFBVyx1RUFBSixFQUFJO0FBQ3ZDLE1BQUlDLFdBQVcsR0FBRyxFQUFsQjs7QUFFQSxNQUFJLE9BQU9ELElBQVAsS0FBZ0IsUUFBcEIsRUFBOEI7QUFDNUIsUUFBSTtBQUNGQSxVQUFJLEdBQUdoWSxJQUFJLENBQUNrWSxLQUFMLENBQVdGLElBQVgsQ0FBUDtBQUNELEtBRkQsQ0FFRSxPQUFPRyxDQUFQLEVBQVU7QUFDVm5ULFlBQU0sQ0FBQyxxQkFBRCxFQUF3Qm1ULENBQXhCLEVBQTJCSCxJQUEzQixDQUFOO0FBQ0E7QUFDRDtBQUNGOztBQUVELE1BQUlJLGdCQUFnQixHQUFHSixJQUFJLENBQUNJLGdCQUFMLElBQXlCLEVBQWhEO0FBQ0FwVCxRQUFNLENBQUMsTUFBRCxFQUFTb1QsZ0JBQVQsQ0FBTjtBQUVBLE1BQUlDLFFBQVEsR0FBR0QsZ0JBQWdCLENBQUM1SSxHQUFqQixDQUFzQjhJLFNBQUQsSUFBZTtBQUNqRCxRQUFJLENBQUNuYyxNQUFNLENBQUNDLE9BQVAsQ0FBZW1jLGdCQUFwQixFQUFzQztBQUNwQyxhQUFPTixXQUFXLENBQUMxWCxJQUFaLENBQWlCK1gsU0FBakIsQ0FBUDtBQUNEOztBQUVELFdBQU9FLGdCQUFnQixDQUFDRixTQUFTLENBQUMxYyxJQUFYLEVBQWlCMGMsU0FBUyxDQUFDRyxJQUFWLENBQWVuYSxJQUFoQyxDQUFoQixDQUNKNlUsSUFESSxDQUNDLFVBQVV1RixhQUFWLEVBQXlCO0FBQzdCLFVBQUlBLGFBQWEsS0FBSyxJQUF0QixFQUE0QjtBQUMxQlQsbUJBQVcsQ0FBQzFYLElBQVosQ0FBaUIrWCxTQUFqQjtBQUNELE9BRkQsTUFFTztBQUNMSyxxQkFBYSxDQUFDTCxTQUFELEVBQVlJLGFBQVosQ0FBYjtBQUNEO0FBQ0YsS0FQSSxDQUFQO0FBUUQsR0FiYyxDQUFmO0FBZUFFLFNBQU8sQ0FBQ0MsR0FBUixDQUFZUixRQUFaLEVBQXNCbEYsSUFBdEIsQ0FBMkIsWUFBWTtBQUNyQyxRQUFJOEUsV0FBVyxDQUFDaGEsTUFBWixHQUFxQixDQUF6QixFQUE0QjtBQUMxQitHLFlBQU0sQ0FBQyxnQ0FBRCxFQUFtQ2lULFdBQW5DLENBQU47QUFDQTliLFlBQU0sQ0FBQzhXLE9BQVAsQ0FBZTZGLFFBQWYsQ0FBd0I7QUFDdEJDLDZCQUFxQixFQUFFZDtBQURELE9BQXhCLEVBR0M5RSxJQUhELENBR00sVUFBVTZFLElBQVYsRUFBZ0I7QUFDcEJELHlCQUFpQixDQUFDQyxJQUFELENBQWpCO0FBQ0QsT0FMRCxFQU1DNUUsS0FORCxDQU1PLFVBQVV2VixHQUFWLEVBQWU7QUFDcEJ5QixlQUFPLENBQUM0WCxHQUFSLENBQVksZ0NBQVosRUFBOENyWixHQUE5QztBQUNELE9BUkQ7QUFTRDtBQUNGLEdBYkQ7QUFlRCxDQTdDRDs7QUErQ0EsU0FBUzhhLGFBQVQsQ0FBdUJMLFNBQXZCLEVBQWtDVSxhQUFsQyxFQUFpRDtBQUMvQ2hVLFFBQU0sQ0FBQyxtQkFBRCxFQUFzQnNULFNBQXRCLEVBQWlDVSxhQUFqQyxDQUFOO0FBRUEsTUFBSUMsTUFBTSxHQUFHN0IsRUFBRSxDQUFDOEIsZ0JBQUgsQ0FBb0JGLGFBQXBCLENBQWI7QUFFQUMsUUFBTSxDQUFDN04sRUFBUCxDQUFVLE9BQVYsRUFBb0J2TixHQUFELElBQVM7QUFDMUJ5QixXQUFPLENBQUM0WCxHQUFSLENBQVksNENBQVosRUFBMERyWixHQUExRDtBQUNELEdBRkQ7QUFJQSxNQUFJakMsSUFBSSxHQUFHMGMsU0FBUyxDQUFDMWMsSUFBckI7QUFDQSxNQUFJdWQsV0FBVyxHQUFHYixTQUFTLENBQUNhLFdBQTVCO0FBQ0EsTUFBSVYsSUFBSSxHQUFHVyxrQkFBa0IsQ0FBQ2QsU0FBUyxDQUFDRyxJQUFWLENBQWVuYSxJQUFoQixDQUE3QjtBQUVBbkMsUUFBTSxDQUFDOFcsT0FBUCxDQUFlb0csVUFBZiwyQkFBNkN6ZCxJQUE3QywwQkFBaUV1ZCxXQUFqRSxtQkFBcUZWLElBQXJGLEdBQTZGUSxNQUE3RixFQUNHN0YsS0FESCxDQUNTLFVBQVV2VixHQUFWLEVBQWU7QUFDcEJ5QixXQUFPLENBQUM0WCxHQUFSLENBQVksc0NBQVosRUFBb0RyWixHQUFwRDtBQUNELEdBSEg7QUFJRDs7QUFFRCxTQUFTeWIsV0FBVCxDQUFzQkMsT0FBdEIsRUFBK0I7QUFDN0JBLFNBQU8sR0FBR2piLElBQUksQ0FBQ2tiLEtBQUwsQ0FBV0MsU0FBWCxDQUFxQkYsT0FBckIsQ0FBVjs7QUFFQSxNQUFJQSxPQUFPLENBQUMsQ0FBRCxDQUFQLEtBQWUsR0FBbkIsRUFBd0I7QUFDdEJBLFdBQU8sR0FBR0EsT0FBTyxDQUFDcmMsS0FBUixDQUFjLENBQWQsQ0FBVjtBQUNEOztBQUVELFNBQU9xYyxPQUFQO0FBQ0Q7O0FBRUQsU0FBU0cscUJBQVQsQ0FBZ0M5ZCxJQUFoQyxFQUFzQzJkLE9BQXRDLEVBQStDO0FBQzdDLFFBQU1JLFFBQVEsR0FBR0wsV0FBVyxDQUFDQyxPQUFELENBQTVCO0FBRUEsU0FBTyxJQUFJWCxPQUFKLENBQVksVUFBVWYsT0FBVixFQUFtQjtBQUNwQyxVQUFNK0IsUUFBUSxHQUFHbEMsY0FBYyxDQUFDOWIsSUFBRCxDQUEvQjtBQUNBLFVBQU1pZSxXQUFXLEdBQUd2YixJQUFJLENBQUM0VyxJQUFMLENBQVUwRSxRQUFWLEVBQW9CLFNBQXBCLEVBQStCRCxRQUEvQixJQUEyQyxNQUEvRDtBQUVBdkMsTUFBRSxDQUFDMEMsSUFBSCxDQUFRRCxXQUFSLEVBQXFCLFVBQVVoYyxHQUFWLEVBQWU7QUFDbENnYSxhQUFPLENBQUNoYSxHQUFHLEdBQUcsSUFBSCxHQUFVZ2MsV0FBZCxDQUFQO0FBQ0QsS0FGRDtBQUdELEdBUE0sQ0FBUDtBQVFEOztBQUVELFNBQVNyQixnQkFBVCxDQUEwQjVjLElBQTFCLEVBQWdDMmQsT0FBaEMsRUFBeUM7QUFDdkMsU0FBTyxJQUFJWCxPQUFKLENBQVksQ0FBQ2YsT0FBRCxFQUFVa0MsTUFBVixLQUFxQjtBQUN0QyxRQUFJQyxhQUFhLEdBQUdDLE1BQU0sQ0FBQ0MsY0FBUCxDQUFzQnRlLElBQXRCLENBQXBCOztBQUVBLFFBQUksQ0FBQ29lLGFBQUQsSUFBa0IsQ0FBQ0EsYUFBYSxDQUFDRyxRQUFyQyxFQUErQztBQUM3QyxhQUFPdEMsT0FBTyxDQUFDLElBQUQsQ0FBZDtBQUNEOztBQUVELFFBQUl1QyxRQUFRLEdBQUdKLGFBQWEsQ0FBQ0csUUFBZCxDQUF1QkUsSUFBdkIsQ0FBNkI1QixJQUFELElBQVU7QUFDbkQsYUFBT0EsSUFBSSxDQUFDdEIsR0FBTCxJQUFZc0IsSUFBSSxDQUFDdEIsR0FBTCxDQUFTbUQsVUFBVCxDQUFvQmYsT0FBcEIsQ0FBbkI7QUFDRCxLQUZjLENBQWY7O0FBSUEsUUFBSWEsUUFBUSxJQUFJQSxRQUFRLENBQUNHLFNBQXpCLEVBQW9DO0FBQ2xDLGFBQU8xQyxPQUFPLENBQUN2WixJQUFJLENBQUM0VyxJQUFMLENBQ2J3QyxjQUFjLENBQUM5YixJQUFELENBREQsRUFFYndlLFFBQVEsQ0FBQ0csU0FGSSxDQUFELENBQWQ7QUFJRDs7QUFFRGIseUJBQXFCLENBQUM5ZCxJQUFELEVBQU8yZCxPQUFQLENBQXJCLENBQXFDcEcsSUFBckMsQ0FBMEMwRSxPQUExQyxFQUFtRHpFLEtBQW5ELENBQXlEMkcsTUFBekQ7QUFDRCxHQW5CTSxDQUFQO0FBb0JELEM7Ozs7Ozs7Ozs7O0FDdklELElBQUlTLHFCQUFxQixHQUFHLENBQUMsS0FBRCxFQUFRLElBQVIsRUFBYyxRQUFkLEVBQXdCLE1BQXhCLEVBQWdDLFVBQWhDLENBQTVCLEMsQ0FFQTs7QUFDQUMsZUFBZSxHQUFHLFlBQVc7QUFDM0IsT0FBS0MsY0FBTCxHQUFzQixFQUF0QjtBQUNBLE9BQUtDLDBCQUFMLEdBQWtDLEVBQWxDO0FBQ0EsT0FBS0MsYUFBTCxHQUFxQixFQUFyQjtBQUNELENBSkQ7O0FBTUFILGVBQWUsQ0FBQ3JhLFNBQWhCLENBQTBCeWEsUUFBMUIsR0FBcUMsVUFBU3pWLE9BQVQsRUFBa0IwVixLQUFsQixFQUF5QjtBQUM1RCxNQUFJaFQsSUFBSSxHQUFHLElBQVg7O0FBQ0EsTUFBSWlULE9BQU8sR0FBR2pULElBQUksQ0FBQ2tULGNBQUwsQ0FBb0I1VixPQUFPLENBQUN4QixFQUE1QixFQUFnQ2tYLEtBQWhDLENBQWQ7O0FBRUEsTUFBSUcsT0FBTyxHQUFHN1YsT0FBTyxDQUFDNlYsT0FBUixJQUFtQixFQUFqQzs7QUFDQSxNQUFHLE9BQU9BLE9BQU8sQ0FBQ0MsT0FBZixLQUEyQixVQUE5QixFQUEwQztBQUN4QztBQUNBO0FBQ0FELFdBQU8sR0FBR0EsT0FBTyxDQUFDQyxPQUFSLEVBQVY7QUFDRDs7QUFFRCxNQUFJQyxRQUFRLEdBQUdGLE9BQU8sQ0FBQ3pMLEdBQVIsQ0FBWSxVQUFTbkssR0FBVCxFQUFjO0FBQ3ZDLFFBQUlWLEdBQUcsR0FBR21ELElBQUksQ0FBQ2tULGNBQUwsQ0FBb0I1VixPQUFPLENBQUN4QixFQUE1QixFQUFnQ3lCLEdBQUcsQ0FBQ3pCLEVBQXBDLENBQVY7O0FBQ0EsV0FBT2tFLElBQUksQ0FBQ3NULGdCQUFMLENBQXNCelcsR0FBdEIsRUFBMkJVLEdBQTNCLENBQVA7QUFDRCxHQUhjLENBQWY7QUFLQThWLFVBQVEsR0FBR0EsUUFBUSxJQUFJLEVBQXZCLENBaEI0RCxDQWtCNUQ7O0FBQ0EsTUFBSUUsMEJBQTBCLEdBQUcsS0FBS1YsMEJBQUwsQ0FBZ0N2VixPQUFPLENBQUN4QixFQUF4QyxDQUFqQzs7QUFDQSxNQUFHeVgsMEJBQUgsRUFBK0I7QUFDN0IsUUFBSTFXLEdBQUcsR0FBR21ELElBQUksQ0FBQ2tULGNBQUwsQ0FBb0I1VixPQUFPLENBQUN4QixFQUE1QixFQUFnQ3lYLDBCQUEwQixDQUFDelgsRUFBM0QsQ0FBVjs7QUFDQXVYLFlBQVEsQ0FBQ2hlLE9BQVQsQ0FBaUIsS0FBS2llLGdCQUFMLENBQXNCelcsR0FBdEIsRUFBMkIwVywwQkFBM0IsQ0FBakI7QUFDRDs7QUFFRCxPQUFLWCxjQUFMLENBQW9CSyxPQUFwQixJQUErQkksUUFBL0I7QUFDRCxDQTFCRDs7QUE0QkFWLGVBQWUsQ0FBQ3JhLFNBQWhCLENBQTBCa2IsS0FBMUIsR0FBa0MsVUFBU2xXLE9BQVQsRUFBa0IwVixLQUFsQixFQUF5QjtBQUN6RCxNQUFJQyxPQUFPLEdBQUcsS0FBS0MsY0FBTCxDQUFvQjVWLE9BQU8sQ0FBQ3hCLEVBQTVCLEVBQWdDa1gsS0FBaEMsQ0FBZDs7QUFDQSxNQUFJSyxRQUFRLEdBQUcsS0FBS1QsY0FBTCxDQUFvQkssT0FBcEIsS0FBZ0MsRUFBL0M7QUFDQSxTQUFPLEtBQUtMLGNBQUwsQ0FBb0JLLE9BQXBCLENBQVA7QUFFQSxNQUFJUSxnQkFBZ0IsR0FBSUosUUFBUSxDQUFDM0wsR0FBVCxDQUFhLEtBQUtnTSxrQkFBTCxDQUF3QkMsSUFBeEIsQ0FBNkIsSUFBN0IsQ0FBYixDQUF4QjtBQUNBLFNBQU9GLGdCQUFQO0FBQ0QsQ0FQRDs7QUFTQWQsZUFBZSxDQUFDcmEsU0FBaEIsQ0FBMEI0YSxjQUExQixHQUEyQyxVQUFTVSxTQUFULEVBQW9CWixLQUFwQixFQUEyQjtBQUNwRSxTQUFPWSxTQUFTLEdBQUcsSUFBWixHQUFtQlosS0FBMUI7QUFDRCxDQUZEOztBQUlBTCxlQUFlLENBQUNyYSxTQUFoQixDQUEwQmdiLGdCQUExQixHQUE2QyxVQUFTelcsR0FBVCxFQUFjVSxHQUFkLEVBQW1CO0FBQzlELE1BQUl5QyxJQUFJLEdBQUcsSUFBWDtBQUNBLE1BQUk2VCxhQUFhLEdBQUc3VCxJQUFJLENBQUM4UyxhQUFMLENBQW1CalcsR0FBbkIsQ0FBcEI7O0FBQ0EsTUFBRyxDQUFDZ1gsYUFBSixFQUFtQjtBQUNqQjdULFFBQUksQ0FBQzhTLGFBQUwsQ0FBbUJqVyxHQUFuQixJQUEwQmdYLGFBQWEsR0FBRzVaLENBQUMsQ0FBQzZaLElBQUYsQ0FBT3ZXLEdBQVAsRUFBWW1WLHFCQUFaLENBQTFDO0FBQ0FtQixpQkFBYSxDQUFDRSxJQUFkLEdBQXFCbFgsR0FBckI7QUFDQWdYLGlCQUFhLENBQUNHLFdBQWQsR0FBNEIsQ0FBNUI7QUFDRCxHQUpELE1BSU87QUFDTEgsaUJBQWEsQ0FBQ0csV0FBZDtBQUNEOztBQUVELFNBQU9ILGFBQVA7QUFDRCxDQVpEOztBQWNBbEIsZUFBZSxDQUFDcmEsU0FBaEIsQ0FBMEJvYixrQkFBMUIsR0FBK0MsVUFBU25XLEdBQVQsRUFBYztBQUMzREEsS0FBRyxDQUFDeVcsV0FBSjs7QUFDQSxNQUFHelcsR0FBRyxDQUFDeVcsV0FBSixJQUFtQixDQUF0QixFQUF5QjtBQUN2QixXQUFPLEtBQUtsQixhQUFMLENBQW1CdlYsR0FBRyxDQUFDd1csSUFBdkIsQ0FBUDtBQUNELEdBSjBELENBTTNEO0FBQ0E7OztBQUNBLFNBQU85WixDQUFDLENBQUM2WixJQUFGLENBQU92VyxHQUFQLEVBQVltVixxQkFBWixDQUFQO0FBQ0QsQ0FURDs7QUFXQUMsZUFBZSxDQUFDcmEsU0FBaEIsQ0FBMEIyYixhQUExQixHQUEwQyxVQUFTM1csT0FBVCxFQUFrQkMsR0FBbEIsRUFBdUIyVyxPQUF2QixFQUFnQztBQUN4RSxNQUFJbFUsSUFBSSxHQUFHLElBQVg7QUFDQSxNQUFJbVUsT0FBTyxHQUFHblMsSUFBSSxDQUFDaUMsR0FBTCxFQUFkO0FBQ0FqRSxNQUFJLENBQUM2UywwQkFBTCxDQUFnQ3ZWLE9BQU8sQ0FBQ3hCLEVBQXhDLElBQThDeUIsR0FBOUM7QUFFQSxNQUFJNlcsU0FBUyxHQUFHLEtBQWhCOztBQUNBLE1BQUlDLGNBQWMsR0FBRyxZQUFXO0FBQzlCLFFBQUcsQ0FBQ0QsU0FBSixFQUFlO0FBQ2IsVUFBSUUsUUFBUSxHQUFHdFMsSUFBSSxDQUFDaUMsR0FBTCxLQUFha1EsT0FBNUI7O0FBQ0EsVUFBSXRYLEdBQUcsR0FBR21ELElBQUksQ0FBQ2tULGNBQUwsQ0FBb0I1VixPQUFPLENBQUN4QixFQUE1QixFQUFnQ3lCLEdBQUcsQ0FBQ3pCLEVBQXBDLENBQVY7O0FBQ0EsVUFBSStYLGFBQWEsR0FBRzdULElBQUksQ0FBQzhTLGFBQUwsQ0FBbUJqVyxHQUFuQixDQUFwQjs7QUFDQSxVQUFHZ1gsYUFBSCxFQUFrQjtBQUNoQkEscUJBQWEsQ0FBQ1MsUUFBZCxHQUF5QkEsUUFBekI7QUFDRDs7QUFDRCxhQUFPdFUsSUFBSSxDQUFDNlMsMEJBQUwsQ0FBZ0N2VixPQUFPLENBQUN4QixFQUF4QyxDQUFQO0FBQ0FzWSxlQUFTLEdBQUcsSUFBWjtBQUNBRixhQUFPO0FBQ1I7QUFDRixHQVpEOztBQWNBLFNBQU9HLGNBQVA7QUFDRCxDQXJCRCxDOzs7Ozs7Ozs7OztBQzNFQTtBQUNBRSxVQUFVLEdBQUcsRUFBYjs7QUFFQUEsVUFBVSxDQUFDQyxJQUFYLEdBQWtCLFVBQVNDLGlCQUFULEVBQTRCO0FBQzVDLE1BQUluZ0IsT0FBTyxHQUFHbWdCLGlCQUFpQixDQUFDbmdCLE9BQWhDOztBQUNBLE1BQUlBLE9BQU8sQ0FBQ29nQixLQUFaLEVBQW1CO0FBQ2pCLFdBQU87QUFDTEMsVUFBSSxFQUFFLHlCQUREO0FBRUxDLFlBQU0sRUFBRSxpREFGSDtBQUdMQyxjQUFRLEVBQUU7QUFITCxLQUFQO0FBS0Q7O0FBQUE7O0FBRUQsTUFBSUMsT0FBTyxHQUFHN2EsQ0FBQyxDQUFDOGEsR0FBRixDQUFNTixpQkFBaUIsQ0FBQ08sUUFBeEIsRUFBa0MsVUFBVWhaLEtBQVYsRUFBaUJiLEtBQWpCLEVBQXdCO0FBQ3RFLFFBQUlBLEtBQUssQ0FBQ3hFLE1BQU4sQ0FBYSxDQUFiLEVBQWdCLENBQWhCLE1BQXVCLEdBQTNCLEVBQ0UsT0FBTyxJQUFQO0FBQ0gsR0FIYSxDQUFkOztBQUtBLE1BQUdtZSxPQUFILEVBQVk7QUFDVixXQUFPO0FBQ0xILFVBQUksRUFBRSxxQkFERDtBQUVMQyxZQUFNLEVBQUUscURBRkg7QUFHTEMsY0FBUSxFQUFFO0FBSEwsS0FBUDtBQUtEOztBQUFBOztBQUVELE1BQUlJLFdBQVcsR0FBR2hiLENBQUMsQ0FBQzhXLEdBQUYsQ0FBTTBELGlCQUFpQixDQUFDTyxRQUF4QixFQUFrQyxVQUFVaFosS0FBVixFQUFpQmIsS0FBakIsRUFBd0I7QUFDMUUsV0FBTyxPQUFPYSxLQUFQLEtBQWlCLFFBQWpCLElBQ0wsT0FBT0EsS0FBUCxLQUFpQixRQURaLElBRUwsT0FBT0EsS0FBUCxLQUFpQixTQUZaLElBR0xBLEtBQUssS0FBSyxJQUhMLElBSUxBLEtBQUssWUFBWXhILE1BQU0sQ0FBQzBnQixVQUFQLENBQWtCQyxRQUpyQztBQUtELEdBTmlCLENBQWxCOztBQVFBLE1BQUcsQ0FBQ0YsV0FBSixFQUFpQjtBQUNmLFdBQU87QUFDTE4sVUFBSSxFQUFFLGtCQUREO0FBRUxDLFlBQU0sRUFBRSxvREFGSDtBQUdMQyxjQUFRLEVBQUU7QUFITCxLQUFQO0FBS0Q7O0FBRUQsU0FBTyxJQUFQO0FBQ0QsQ0F4Q0Q7O0FBMENBTixVQUFVLENBQUNhLElBQVgsR0FBa0IsVUFBU1gsaUJBQVQsRUFBNEI7QUFDNUMsTUFBSW5nQixPQUFPLEdBQUdtZ0IsaUJBQWlCLENBQUNuZ0IsT0FBaEM7QUFDQSxNQUFJK2dCLE9BQU8sR0FBRyxJQUFJQyxTQUFTLENBQUNDLE9BQWQsQ0FBc0JkLGlCQUFpQixDQUFDTyxRQUF4QyxDQUFkOztBQUNBLE1BQUkxZ0IsT0FBTyxDQUFDb2dCLEtBQVosRUFBbUI7QUFDakIsV0FBTztBQUNMQyxVQUFJLEVBQUUseUJBREQ7QUFFTEMsWUFBTSxFQUFFLGlEQUZIO0FBR0xDLGNBQVEsRUFBRTtBQUhMLEtBQVA7QUFLRDs7QUFBQTtBQUVELFNBQU8sSUFBUDtBQUNELENBWkQ7O0FBZUFOLFVBQVUsQ0FBQ2lCLEdBQVgsR0FBaUIsWUFBVztBQUMxQixNQUFHLENBQUM5UixPQUFPLENBQUM4UixHQUFSLENBQVlDLGVBQWhCLEVBQWlDO0FBQy9CLFdBQU87QUFDTGQsVUFBSSxFQUFFLFFBREQ7QUFFTEMsWUFBTSxFQUFFLDBEQUZIO0FBR0xDLGNBQVEsRUFBRTtBQUhMLEtBQVA7QUFLRCxHQU5ELE1BTU87QUFDTCxXQUFPLElBQVA7QUFDRDtBQUNGLENBVkQ7O0FBWUFOLFVBQVUsQ0FBQ21CLFlBQVgsR0FBMEIsVUFBU2pCLGlCQUFULEVBQTRCO0FBQ3BELE1BQUdBLGlCQUFpQixDQUFDbmdCLE9BQWxCLENBQTBCcWhCLGFBQTdCLEVBQTRDO0FBQzFDLFdBQU87QUFDTGhCLFVBQUksRUFBRSxlQUREO0FBRUxDLFlBQU0sRUFBRTtBQUZILEtBQVA7QUFJRCxHQUxELE1BS087QUFDTCxXQUFPLElBQVA7QUFDRDtBQUNGLENBVEQsQyxDQVdBO0FBQ0E7OztBQUNBTCxVQUFVLENBQUNxQixnQkFBWCxHQUE4QixVQUFTbkIsaUJBQVQsRUFBNEI7QUFDeEQsTUFBR2EsU0FBUyxDQUFDQyxPQUFiLEVBQXNCO0FBQ3BCLFFBQUk7QUFDRixVQUFJRixPQUFPLEdBQUcsSUFBSUMsU0FBUyxDQUFDQyxPQUFkLENBQXNCZCxpQkFBaUIsQ0FBQ08sUUFBeEMsQ0FBZDtBQUNBLGFBQU8sSUFBUDtBQUNELEtBSEQsQ0FHRSxPQUFNOWIsRUFBTixFQUFVO0FBQ1YsYUFBTztBQUNMeWIsWUFBSSxFQUFFLHlCQUREO0FBRUxDLGNBQU0sRUFBRSxrREFBbUQxYixFQUFFLENBQUNwRCxPQUZ6RDtBQUdMK2UsZ0JBQVEsRUFBRTtBQUhMLE9BQVA7QUFLRDtBQUNGLEdBWEQsTUFXTztBQUNMO0FBQ0EsV0FBTyxJQUFQO0FBQ0Q7QUFDRixDQWhCRDs7QUFrQkFOLFVBQVUsQ0FBQ3NCLGVBQVgsR0FBNkIsVUFBU3BCLGlCQUFULEVBQTRCO0FBQ3ZELE1BQUlZLE9BQU8sR0FBRyxJQUFJQyxTQUFTLENBQUNDLE9BQWQsQ0FBc0JkLGlCQUFpQixDQUFDTyxRQUF4QyxDQUFkOztBQUNBLE1BQUdNLFNBQVMsQ0FBQ1EsTUFBVixJQUFvQnJCLGlCQUFpQixDQUFDbmdCLE9BQWxCLENBQTBCeWhCLElBQWpELEVBQXVEO0FBQ3JELFFBQUk7QUFDRixVQUFJQyxNQUFNLEdBQUcsSUFBSVYsU0FBUyxDQUFDUSxNQUFkLENBQ1hyQixpQkFBaUIsQ0FBQ25nQixPQUFsQixDQUEwQnloQixJQURmLEVBRVg7QUFBRVYsZUFBTyxFQUFFQTtBQUFYLE9BRlcsQ0FBYjtBQUlBLGFBQU8sSUFBUDtBQUNELEtBTkQsQ0FNRSxPQUFNbmMsRUFBTixFQUFVO0FBQ1YsYUFBTztBQUNMeWIsWUFBSSxFQUFFLHdCQUREO0FBRUxDLGNBQU0sRUFBRSxxREFBcUQxYixFQUFFLENBQUNwRCxPQUYzRDtBQUdMK2UsZ0JBQVEsRUFBRTtBQUhMLE9BQVA7QUFLRDtBQUNGLEdBZEQsTUFjTztBQUNMLFdBQU8sSUFBUDtBQUNEO0FBQ0YsQ0FuQkQ7O0FBcUJBTixVQUFVLENBQUMwQixNQUFYLEdBQW9CLFVBQVN4QixpQkFBVCxFQUE0QjtBQUM5QyxNQUFJbmdCLE9BQU8sR0FBR21nQixpQkFBaUIsQ0FBQ25nQixPQUFoQzs7QUFDQSxNQUFHQSxPQUFPLENBQUMyaEIsTUFBWCxFQUFtQjtBQUNqQixRQUFJO0FBQ0ZDLHFCQUFlLENBQUNDLHlCQUFoQixDQUEwQzdoQixPQUFPLENBQUMyaEIsTUFBbEQ7O0FBQ0EsYUFBTyxJQUFQO0FBQ0QsS0FIRCxDQUdFLE9BQU81RixDQUFQLEVBQVU7QUFDVixVQUFJQSxDQUFDLENBQUN6VSxJQUFGLEtBQVcsZ0JBQWYsRUFBaUM7QUFDL0IsZUFBTztBQUNMK1ksY0FBSSxFQUFFLHNCQUREO0FBRUxDLGdCQUFNLEVBQUUsa0RBQWtEdkUsQ0FBQyxDQUFDdmEsT0FGdkQ7QUFHTCtlLGtCQUFRLEVBQUU7QUFITCxTQUFQO0FBS0QsT0FORCxNQU1PO0FBQ0wsY0FBTXhFLENBQU47QUFDRDtBQUNGO0FBQ0Y7O0FBQ0QsU0FBTyxJQUFQO0FBQ0QsQ0FuQkQ7O0FBcUJBa0UsVUFBVSxDQUFDNkIsSUFBWCxHQUFrQixVQUFTM0IsaUJBQVQsRUFBNEI7QUFDNUMsTUFBR0EsaUJBQWlCLENBQUNuZ0IsT0FBbEIsQ0FBMEI4aEIsSUFBN0IsRUFBbUM7QUFDakMsV0FBTztBQUNMekIsVUFBSSxFQUFFLG9CQUREO0FBRUxDLFlBQU0sRUFBRSxtQ0FGSDtBQUdMQyxjQUFRLEVBQUU7QUFITCxLQUFQO0FBS0Q7O0FBRUQsU0FBTyxJQUFQO0FBQ0QsQ0FWRDs7QUFZQU4sVUFBVSxDQUFDOEIsS0FBWCxHQUFtQixVQUFTNUIsaUJBQVQsRUFBNEI7QUFDN0MsTUFBSVksT0FBTyxHQUFHLElBQUlDLFNBQVMsQ0FBQ0MsT0FBZCxDQUFzQmQsaUJBQWlCLENBQUNPLFFBQXhDLENBQWQ7O0FBQ0EsTUFBR0ssT0FBTyxDQUFDaUIsUUFBUixFQUFILEVBQXVCO0FBQ3JCLFdBQU87QUFDTDNCLFVBQUksRUFBRSxxQkFERDtBQUVMQyxZQUFNLEVBQUUsOENBRkg7QUFHTEMsY0FBUSxFQUFFO0FBSEwsS0FBUDtBQUtEOztBQUFBO0FBRUQsU0FBTyxJQUFQO0FBQ0QsQ0FYRDs7QUFhQU4sVUFBVSxDQUFDZ0MsR0FBWCxHQUFpQixVQUFTOUIsaUJBQVQsRUFBNEI7QUFDM0MsTUFBSVksT0FBTyxHQUFHLElBQUlDLFNBQVMsQ0FBQ0MsT0FBZCxDQUFzQmQsaUJBQWlCLENBQUNPLFFBQXhDLENBQWQ7O0FBRUEsTUFBR0ssT0FBTyxDQUFDbUIsV0FBUixFQUFILEVBQTBCO0FBQ3hCLFdBQU87QUFDTDdCLFVBQUksRUFBRSxtQkFERDtBQUVMQyxZQUFNLEVBQUUsNkRBRkg7QUFHTEMsY0FBUSxFQUFFO0FBSEwsS0FBUDtBQUtEOztBQUFBO0FBRUQsU0FBTyxJQUFQO0FBQ0QsQ0FaRDs7QUFjQU4sVUFBVSxDQUFDa0MsY0FBWCxHQUE0QixVQUFTaEMsaUJBQVQsRUFBNEI7QUFDdEQsTUFBSW5nQixPQUFPLEdBQUdtZ0IsaUJBQWlCLENBQUNuZ0IsT0FBaEM7O0FBRUEsTUFBSUEsT0FBTyxDQUFDb2dCLEtBQVIsSUFBaUIsQ0FBQ3BnQixPQUFPLENBQUN5aEIsSUFBOUIsRUFBcUM7QUFDbkMsV0FBTztBQUNMcEIsVUFBSSxFQUFFLGVBREQ7QUFFTEMsWUFBTSxFQUFFLDhFQUZIO0FBR0xDLGNBQVEsRUFBRTtBQUhMLEtBQVA7QUFLRDs7QUFBQTtBQUVELFNBQU8sSUFBUDtBQUNELENBWkQ7O0FBY0FOLFVBQVUsQ0FBQ21DLFlBQVgsR0FBMEIsVUFBU2pDLGlCQUFULEVBQTRCa0MsTUFBNUIsRUFBb0M7QUFDNUQsTUFBR0EsTUFBTSxJQUFJLENBQUNBLE1BQU0sQ0FBQy9LLFdBQVAsQ0FBbUJnTCxlQUFqQyxFQUFrRDtBQUNoRCxXQUFPO0FBQ0xqQyxVQUFJLEVBQUUsZUFERDtBQUVMQyxZQUFNLEVBQUUsa0RBRkg7QUFHTEMsY0FBUSxFQUFFO0FBSEwsS0FBUDtBQUtEOztBQUNELFNBQU8sSUFBUDtBQUNELENBVEQ7O0FBV0FOLFVBQVUsQ0FBQ3NDLFdBQVgsR0FBeUIsVUFBU3BDLGlCQUFULEVBQTRCa0MsTUFBNUIsRUFBb0M7QUFDM0QsTUFBRyxDQUFDbmlCLE1BQU0sQ0FBQ3NpQixPQUFYLEVBQW9CO0FBQ2xCLFdBQU87QUFDTG5DLFVBQUksRUFBRSxjQUREO0FBRUxDLFlBQU0sRUFBRSxrR0FGSDtBQUdMQyxjQUFRLEVBQUU7QUFITCxLQUFQO0FBS0Q7O0FBQ0QsU0FBTyxJQUFQO0FBQ0QsQ0FURDs7QUFXQSxJQUFJa0Msa0JBQWtCLEdBQUcsQ0FDdkJ4QyxVQUFVLENBQUNpQixHQURZLEVBRXZCakIsVUFBVSxDQUFDbUIsWUFGWSxFQUd2Qm5CLFVBQVUsQ0FBQ3FCLGdCQUhZLENBQXpCO0FBTUEsSUFBSW9CLGNBQWMsR0FBRyxDQUNuQnpDLFVBQVUsQ0FBQzBCLE1BRFEsRUFFbkIxQixVQUFVLENBQUM2QixJQUZRLEVBR25CN0IsVUFBVSxDQUFDOEIsS0FIUSxFQUluQjlCLFVBQVUsQ0FBQ2dDLEdBSlEsRUFLbkJoQyxVQUFVLENBQUNrQyxjQUxRLEVBTW5CbEMsVUFBVSxDQUFDc0IsZUFOUSxFQU9uQnRCLFVBQVUsQ0FBQ21DLFlBUFEsRUFRbkJuQyxVQUFVLENBQUNzQyxXQVJRLENBQXJCO0FBV0EsSUFBSUksZUFBZSxHQUFHLENBQ3BCLENBQUMsVUFBRCxFQUFhMUMsVUFBVSxDQUFDYSxJQUF4QixDQURvQixFQUVwQixDQUFDLFVBQUQsRUFBYWIsVUFBVSxDQUFDQyxJQUF4QixDQUZvQixDQUF0Qjs7QUFLQW5nQixNQUFNLENBQUM2aUIsZUFBUCxHQUF5QixVQUFTekMsaUJBQVQsRUFBNEIwQyxjQUE1QixFQUE0QztBQUNuRSxNQUFHLE9BQU83QixTQUFQLElBQW9CLFdBQXZCLEVBQW9DO0FBQ2xDLFdBQU87QUFDTFgsVUFBSSxFQUFFLGVBREQ7QUFFTEMsWUFBTSxFQUFFLDZFQUZIO0FBR0xDLGNBQVEsRUFBRTtBQUhMLEtBQVA7QUFLRDs7QUFFRCxNQUFJL0UsTUFBTSxHQUFHc0gsV0FBVyxDQUFDTCxrQkFBRCxFQUFxQnRDLGlCQUFyQixFQUF3QzBDLGNBQXhDLENBQXhCOztBQUNBLE1BQUdySCxNQUFNLEtBQUssSUFBZCxFQUFvQjtBQUNsQixXQUFPQSxNQUFQO0FBQ0Q7O0FBRUQsTUFBSXVILGFBQWEsR0FBRzdpQixNQUFNLENBQUNzaUIsT0FBM0I7O0FBQ0EsT0FBSSxJQUFJNWdCLEVBQUUsR0FBQyxDQUFYLEVBQWNBLEVBQUUsR0FBQytnQixlQUFlLENBQUM5Z0IsTUFBakMsRUFBeUNELEVBQUUsRUFBM0MsRUFBK0M7QUFDN0MsUUFBSW9oQixXQUFXLEdBQUdMLGVBQWUsQ0FBQy9nQixFQUFELENBQWpDOztBQUNBLFFBQUdvaEIsV0FBVyxDQUFDLENBQUQsQ0FBWCxDQUFlamhCLElBQWYsQ0FBb0JnaEIsYUFBcEIsQ0FBSCxFQUF1QztBQUNyQyxVQUFJRSxPQUFPLEdBQUdELFdBQVcsQ0FBQyxDQUFELENBQVgsQ0FBZTdDLGlCQUFmLEVBQWtDMEMsY0FBbEMsQ0FBZDs7QUFDQSxVQUFHSSxPQUFPLEtBQUssSUFBZixFQUFxQjtBQUNuQixlQUFPQSxPQUFQO0FBQ0Q7QUFDRjtBQUNGOztBQUVEekgsUUFBTSxHQUFHc0gsV0FBVyxDQUFDSixjQUFELEVBQWlCdkMsaUJBQWpCLEVBQW9DMEMsY0FBcEMsQ0FBcEI7O0FBQ0EsTUFBR3JILE1BQU0sS0FBSyxJQUFkLEVBQW9CO0FBQ2xCLFdBQU9BLE1BQVA7QUFDRDs7QUFFRCxTQUFPO0FBQ0w2RSxRQUFJLEVBQUUsaUJBREQ7QUFFTEMsVUFBTSxFQUFFLDBEQUZIO0FBR0xDLFlBQVEsRUFBRTtBQUhMLEdBQVA7QUFLRCxDQW5DRDs7QUFxQ0EsU0FBU3VDLFdBQVQsQ0FBcUJJLFdBQXJCLEVBQWtDL0MsaUJBQWxDLEVBQXFEMEMsY0FBckQsRUFBcUU7QUFDbkUsT0FBSSxJQUFJamhCLEVBQUUsR0FBQyxDQUFYLEVBQWNBLEVBQUUsR0FBQ3NoQixXQUFXLENBQUNyaEIsTUFBN0IsRUFBcUNELEVBQUUsRUFBdkMsRUFBMkM7QUFDekMsUUFBSW1mLE9BQU8sR0FBR21DLFdBQVcsQ0FBQ3RoQixFQUFELENBQXpCO0FBQ0EsUUFBSXFoQixPQUFPLEdBQUdsQyxPQUFPLENBQUNaLGlCQUFELEVBQW9CMEMsY0FBcEIsQ0FBckI7O0FBQ0EsUUFBR0ksT0FBTyxLQUFLLElBQWYsRUFBcUI7QUFDbkIsYUFBT0EsT0FBUDtBQUNEO0FBQ0Y7O0FBQ0QsU0FBTyxJQUFQO0FBQ0QsQzs7Ozs7Ozs7Ozs7QUNoU0QsSUFBSUUsV0FBVyxHQUFHNWlCLEdBQUcsQ0FBQ0MsT0FBSixDQUFZLE9BQVosRUFBcUIsZUFBckIsQ0FBbEI7O0FBQ0EsSUFBSTRpQixpQkFBaUIsR0FBRztBQUFDLFFBQU0sSUFBUDtBQUFhLFVBQVEsSUFBckI7QUFBMkIsV0FBUyxJQUFwQztBQUEwQyxVQUFRLElBQWxEO0FBQXdELFdBQVMsSUFBakU7QUFBdUUsWUFBVSxJQUFqRjtBQUF1RixRQUFNO0FBQTdGLENBQXhCO0FBQ0EsSUFBSUMsV0FBVyxHQUFHLENBQUMsS0FBRCxFQUFRLFFBQVIsRUFBa0IsTUFBbEIsQ0FBbEI7QUFDQSxJQUFJQyxnQkFBZ0IsR0FBRyxJQUF2Qjs7QUFFQUMsTUFBTSxHQUFHLFNBQVNBLE1BQVQsR0FBa0I7QUFDekIsT0FBS3hmLFFBQUwsR0FBZ0IsRUFBaEI7QUFDQSxPQUFLeWYsYUFBTCxHQUFxQixDQUFDLFVBQUQsQ0FBckI7QUFDQSxPQUFLQyxxQkFBTCxHQUE2QixFQUE3QjtBQUNELENBSkQsQyxDQU1BO0FBQ0E7QUFDQTs7O0FBQ0FGLE1BQU0sQ0FBQ3ZmLFNBQVAsQ0FBaUJtQyxLQUFqQixHQUF5QixVQUFVbUIsSUFBVixFQUFnQi9GLElBQWhCLEVBSWpCO0FBQUEsTUFKdUM7QUFDN0MrZCxhQUQ2QztBQUU3Q1osU0FGNkM7QUFHN0NnRjtBQUg2QyxHQUl2Qyx1RUFBSixFQUFJOztBQUVOO0FBQ0EsTUFBSSxPQUFPcGMsSUFBUCxLQUFnQixRQUFoQixJQUE0QixPQUFPL0YsSUFBUCxLQUFnQixRQUFoRCxFQUEwRDtBQUN4RCxRQUFJeUgsT0FBTyxHQUFHMUIsSUFBZDtBQUNBLFFBQUkyQixHQUFHLEdBQUcxSCxJQUFWO0FBQ0ErZCxhQUFTLEdBQUd0VyxPQUFPLENBQUN4QixFQUFwQjtBQUNBa1gsU0FBSyxHQUFHelYsR0FBRyxDQUFDekIsRUFBWjtBQUNBa2MsVUFBTSxHQUFHMWEsT0FBTyxDQUFDMGEsTUFBakI7O0FBRUEsUUFBR3phLEdBQUcsQ0FBQ0EsR0FBSixJQUFXLFFBQWQsRUFBd0I7QUFDdEIxSCxVQUFJLEdBQUcsUUFBUDtBQUNBK0YsVUFBSSxHQUFHMkIsR0FBRyxDQUFDNUMsTUFBWDtBQUNELEtBSEQsTUFHTyxJQUFHNEMsR0FBRyxDQUFDQSxHQUFKLElBQVcsS0FBZCxFQUFxQjtBQUMxQjFILFVBQUksR0FBRyxLQUFQO0FBQ0ErRixVQUFJLEdBQUcyQixHQUFHLENBQUMzQixJQUFYO0FBQ0QsS0FITSxNQUdBO0FBQ0wsYUFBTyxJQUFQO0FBQ0Q7QUFDRjs7QUFFRCxNQUFJK2IsV0FBVyxDQUFDL2UsT0FBWixDQUFvQi9DLElBQXBCLE1BQThCLENBQUMsQ0FBbkMsRUFBc0M7QUFDcEMyQixXQUFPLENBQUNDLElBQVIsMkNBQStDNUIsSUFBL0M7QUFDQSxXQUFPLElBQVA7QUFDRDs7QUFHRCxNQUFJb2lCLFNBQVMsR0FBRztBQUNkQyxPQUFHLFlBQUt0RSxTQUFMLGVBQW1CWixLQUFLLElBQUloRyxlQUFlLENBQUNyQixHQUFoQixFQUE1QixDQURXO0FBRWQ5VixRQUZjO0FBR2QrRixRQUhjO0FBSWQwQixXQUFPLEVBQUVzVyxTQUpLO0FBS2Q5WCxNQUFFLEVBQUVrWCxLQUxVO0FBTWQ5SSxVQUFNLEVBQUUsRUFOTTtBQU9kOE47QUFQYyxHQUFoQjtBQVVBLFNBQU9DLFNBQVA7QUFDRCxDQTFDRDs7QUE0Q0FKLE1BQU0sQ0FBQ3ZmLFNBQVAsQ0FBaUI2ZixLQUFqQixHQUF5QixVQUFVRixTQUFWLEVBQXFCcGlCLElBQXJCLEVBQTJCK0IsSUFBM0IsRUFBaUN3Z0IsUUFBakMsRUFBMkM7QUFDbEU7QUFDQSxNQUFJQyxTQUFTLEdBQUcsS0FBS0MsWUFBTCxDQUFrQkwsU0FBbEIsQ0FBaEI7O0FBRUEsT0FDRTtBQUNBSSxXQUFTLElBQ1QsQ0FBQyxVQUFELEVBQWEsT0FBYixFQUFzQnpmLE9BQXRCLENBQThCeWYsU0FBUyxDQUFDeGlCLElBQXhDLEtBQWlELENBRGpELElBRUE7QUFDQW9pQixXQUFTLENBQUNNLGlCQUxaLEVBTUk7QUFDRixXQUFPLEtBQVA7QUFDRDs7QUFFRCxNQUFJSixLQUFLLEdBQUc7QUFDVnRpQixRQURVO0FBRVY0RixNQUFFLEVBQUVjLEdBQUcsQ0FBQ0MsSUFBSixFQUZNO0FBR1ZnYyxTQUFLLEVBQUUsSUFIRztBQUlWQyxVQUFNLEVBQUU7QUFKRSxHQUFaLENBZGtFLENBcUJsRTs7QUFDQSxNQUFJLENBQUNmLGlCQUFpQixDQUFDN2hCLElBQUQsQ0FBdEIsRUFBOEI7QUFDNUJzaUIsU0FBSyxDQUFDSyxLQUFOLEdBQWNMLEtBQUssQ0FBQzFjLEVBQXBCO0FBQ0Q7O0FBRUQsTUFBRzdELElBQUgsRUFBUztBQUNQLFFBQUlrSyxJQUFJLEdBQUc3SCxDQUFDLENBQUM2WixJQUFGLENBQU9tRSxTQUFQLEVBQWtCLE1BQWxCLEVBQTBCLE1BQTFCLENBQVg7O0FBQ0FFLFNBQUssQ0FBQ3ZnQixJQUFOLEdBQWEsS0FBSzhnQixhQUFMLENBQW1CN2lCLElBQW5CLEVBQXlCK0IsSUFBekIsRUFBK0JrSyxJQUEvQixFQUFxQyxPQUFyQyxDQUFiO0FBQ0Q7O0FBRUQsTUFBSXNXLFFBQVEsSUFBSUEsUUFBUSxDQUFDeGMsSUFBekIsRUFBK0I7QUFDN0J1YyxTQUFLLENBQUN2YyxJQUFOLEdBQWF3YyxRQUFRLENBQUN4YyxJQUF0QjtBQUNEOztBQUVELE1BQUl2SCxNQUFNLENBQUNDLE9BQVAsQ0FBZXFrQixlQUFuQixFQUFvQztBQUNsQ1IsU0FBSyxDQUFDcE8sS0FBTixHQUFja0QsZUFBZSxFQUE3QjtBQUNEOztBQUVEd0ssYUFBVyxDQUFDLE9BQUQsRUFBVTVoQixJQUFWLEVBQWdCb2lCLFNBQVMsQ0FBQ0MsR0FBMUIsQ0FBWDs7QUFFQSxNQUFJRyxTQUFTLElBQUksQ0FBQ0EsU0FBUyxDQUFDRyxLQUE1QixFQUFtQztBQUNqQyxRQUFJLENBQUNILFNBQVMsQ0FBQ0ksTUFBZixFQUF1QjtBQUNyQmpoQixhQUFPLENBQUN1QixLQUFSLENBQWMsdURBQWQ7QUFDQXZCLGFBQU8sQ0FBQ3VCLEtBQVIsQ0FBYywrREFBZDtBQUNBdkIsYUFBTyxDQUFDb2hCLEdBQVIsQ0FBWVgsU0FBWixFQUF1QjtBQUFFWSxhQUFLLEVBQUU7QUFBVCxPQUF2QjtBQUNEOztBQUNELFFBQUlDLFVBQVUsR0FBR1QsU0FBUyxDQUFDSSxNQUFWLENBQWlCSixTQUFTLENBQUNJLE1BQVYsQ0FBaUJ0aUIsTUFBakIsR0FBMEIsQ0FBM0MsQ0FBakIsQ0FOaUMsQ0FRakM7O0FBQ0EsUUFBSSxDQUFDMmlCLFVBQUQsSUFBZUEsVUFBVSxDQUFDTixLQUE5QixFQUFxQztBQUNuQ0gsZUFBUyxDQUFDSSxNQUFWLENBQWlCaGdCLElBQWpCLENBQXNCMGYsS0FBdEI7QUFDQSxhQUFPQSxLQUFQO0FBQ0Q7O0FBRUQsV0FBTyxLQUFQO0FBQ0Q7O0FBRURGLFdBQVMsQ0FBQy9OLE1BQVYsQ0FBaUJ6UixJQUFqQixDQUFzQjBmLEtBQXRCO0FBRUEsU0FBT0EsS0FBUDtBQUNELENBN0REOztBQStEQU4sTUFBTSxDQUFDdmYsU0FBUCxDQUFpQnlnQixRQUFqQixHQUE0QixVQUFTZCxTQUFULEVBQW9CRSxLQUFwQixFQUEyQnZnQixJQUEzQixFQUFpQztBQUMzRCxNQUFJdWdCLEtBQUssQ0FBQ0ssS0FBVixFQUFpQjtBQUNmO0FBQ0EsV0FBTyxLQUFQO0FBQ0Q7O0FBRURMLE9BQUssQ0FBQ0ssS0FBTixHQUFjamMsR0FBRyxDQUFDQyxJQUFKLEVBQWQ7O0FBRUEsTUFBRzVFLElBQUgsRUFBUztBQUNQLFFBQUlrSyxJQUFJLEdBQUc3SCxDQUFDLENBQUM2WixJQUFGLENBQU9tRSxTQUFQLEVBQWtCLE1BQWxCLEVBQTBCLE1BQTFCLENBQVg7O0FBQ0FFLFNBQUssQ0FBQ3ZnQixJQUFOLEdBQWFpQyxNQUFNLENBQUMyUCxNQUFQLENBQ1gyTyxLQUFLLENBQUN2Z0IsSUFBTixJQUFjLEVBREgsRUFFWCxLQUFLOGdCLGFBQUwsV0FBc0JQLEtBQUssQ0FBQ3RpQixJQUE1QixVQUF1QytCLElBQXZDLEVBQTZDa0ssSUFBN0MsRUFBbUQsS0FBbkQsQ0FGVyxDQUFiO0FBSUQ7O0FBQ0QyVixhQUFXLENBQUMsT0FBRCxFQUFVVSxLQUFLLENBQUN0aUIsSUFBTixHQUFhLEtBQXZCLEVBQThCb2lCLFNBQVMsQ0FBQ0MsR0FBeEMsQ0FBWDtBQUVBLFNBQU8sSUFBUDtBQUNELENBbEJEOztBQW9CQUwsTUFBTSxDQUFDdmYsU0FBUCxDQUFpQmdnQixZQUFqQixHQUFnQyxVQUFTTCxTQUFULEVBQW9CO0FBQ2xELFNBQU9BLFNBQVMsQ0FBQy9OLE1BQVYsQ0FBaUIrTixTQUFTLENBQUMvTixNQUFWLENBQWlCL1QsTUFBakIsR0FBeUIsQ0FBMUMsQ0FBUDtBQUNELENBRkQ7O0FBSUEwaEIsTUFBTSxDQUFDdmYsU0FBUCxDQUFpQjBnQixZQUFqQixHQUFnQyxVQUFTZixTQUFULEVBQW9CO0FBQ2xELE1BQUlJLFNBQVMsR0FBRyxLQUFLQyxZQUFMLENBQWtCTCxTQUFsQixDQUFoQjs7QUFFQSxNQUFJLENBQUNJLFNBQVMsQ0FBQ0csS0FBZixFQUFzQjtBQUNwQixTQUFLTyxRQUFMLENBQWNkLFNBQWQsRUFBeUJJLFNBQXpCO0FBQ0FBLGFBQVMsQ0FBQ1ksU0FBVixHQUFzQixJQUF0QjtBQUNBLFdBQU8sSUFBUDtBQUNEOztBQUNELFNBQU8sS0FBUDtBQUNELENBVEQsQyxDQVdBO0FBQ0E7QUFDQTs7O0FBQ0FwQixNQUFNLENBQUN2ZixTQUFQLENBQWlCNGdCLGdCQUFqQixHQUFvQyxVQUFVZixLQUFWLEVBQWlCO0FBQ25ELFNBQU8sQ0FBQ0EsS0FBSyxDQUFDTSxNQUFOLENBQWFVLEtBQWIsQ0FBbUJoQixLQUFLLElBQUk7QUFDbEMsV0FBT0EsS0FBSyxDQUFDdGlCLElBQU4sS0FBZSxPQUF0QjtBQUNELEdBRk8sQ0FBUjtBQUdELENBSkQ7O0FBTUFnaUIsTUFBTSxDQUFDdmYsU0FBUCxDQUFpQjhnQixVQUFqQixHQUE4QixVQUFTakIsS0FBVCxFQUFrQztBQUFBLE1BQWxCVSxLQUFrQix1RUFBVixDQUFVO0FBQUEsTUFBUHZhLEtBQU87QUFDOUQsTUFBSSthLG1CQUFtQixHQUFHbEIsS0FBSyxDQUFDSyxLQUFOLEdBQWNMLEtBQUssQ0FBQzFjLEVBQTlDO0FBQ0EsTUFBSTZkLFVBQVUsR0FBRyxDQUFDbkIsS0FBSyxDQUFDdGlCLElBQVAsQ0FBakI7QUFDQSxNQUFJNGlCLE1BQU0sR0FBRyxFQUFiO0FBRUFhLFlBQVUsQ0FBQzdnQixJQUFYLENBQWdCNGdCLG1CQUFoQjtBQUNBQyxZQUFVLENBQUM3Z0IsSUFBWCxDQUFnQjBmLEtBQUssQ0FBQ3ZnQixJQUFOLElBQWMsRUFBOUI7O0FBRUEsTUFBSXVnQixLQUFLLENBQUNNLE1BQU4sQ0FBYXRpQixNQUFiLElBQXVCLEtBQUsraUIsZ0JBQUwsQ0FBc0JmLEtBQXRCLENBQTNCLEVBQXlEO0FBQ3ZELFFBQUlvQixPQUFPLEdBQUdwQixLQUFLLENBQUMxYyxFQUFwQjs7QUFDQSxTQUFJLElBQUkrZCxDQUFDLEdBQUcsQ0FBWixFQUFlQSxDQUFDLEdBQUdyQixLQUFLLENBQUNNLE1BQU4sQ0FBYXRpQixNQUFoQyxFQUF3Q3FqQixDQUFDLEVBQXpDLEVBQTZDO0FBQzNDLFVBQUlDLFdBQVcsR0FBR3RCLEtBQUssQ0FBQ00sTUFBTixDQUFhZSxDQUFiLENBQWxCOztBQUNBLFVBQUksQ0FBQ0MsV0FBVyxDQUFDakIsS0FBakIsRUFBd0I7QUFDdEIsYUFBS08sUUFBTCxDQUFjemEsS0FBZCxFQUFxQm1iLFdBQXJCO0FBQ0FBLG1CQUFXLENBQUNSLFNBQVosR0FBd0IsSUFBeEI7QUFDRDs7QUFFRCxVQUFJUyxXQUFXLEdBQUdELFdBQVcsQ0FBQ2hlLEVBQVosR0FBaUI4ZCxPQUFuQzs7QUFDQSxVQUFJRyxXQUFXLEdBQUcsQ0FBbEIsRUFBcUI7QUFDbkJqQixjQUFNLENBQUNoZ0IsSUFBUCxDQUFZLENBQUMsU0FBRCxFQUFZaWhCLFdBQVosQ0FBWjtBQUNEOztBQUVEakIsWUFBTSxDQUFDaGdCLElBQVAsQ0FBWSxLQUFLMmdCLFVBQUwsQ0FBZ0JLLFdBQWhCLEVBQTZCWixLQUFLLEdBQUcsQ0FBckMsRUFBd0N2YSxLQUF4QyxDQUFaO0FBQ0FpYixhQUFPLEdBQUdFLFdBQVcsQ0FBQ2pCLEtBQXRCO0FBQ0Q7QUFDRjs7QUFHRCxNQUNFQyxNQUFNLENBQUN0aUIsTUFBUCxJQUNBZ2lCLEtBQUssQ0FBQ3BPLEtBRE4sSUFFQW9PLEtBQUssQ0FBQ2MsU0FGTixJQUdBZCxLQUFLLENBQUN2YyxJQUpSLEVBS0U7QUFDQTBkLGNBQVUsQ0FBQzdnQixJQUFYLENBQWdCO0FBQ2RzUixXQUFLLEVBQUVvTyxLQUFLLENBQUNwTyxLQURDO0FBRWQwTyxZQUFNLEVBQUVBLE1BQU0sQ0FBQ3RpQixNQUFQLEdBQWdCc2lCLE1BQWhCLEdBQXlCa0IsU0FGbkI7QUFHZFYsZUFBUyxFQUFFZCxLQUFLLENBQUNjLFNBSEg7QUFJZHJkLFVBQUksRUFBRXVjLEtBQUssQ0FBQ3ZjO0FBSkUsS0FBaEI7QUFNRDs7QUFFRCxTQUFPMGQsVUFBUDtBQUNELENBM0NEOztBQTZDQXpCLE1BQU0sQ0FBQ3ZmLFNBQVAsQ0FBaUJzaEIsVUFBakIsR0FBOEIsVUFBVTNCLFNBQVYsRUFBcUI7QUFDakQsTUFBSTRCLFVBQVUsR0FBRzVCLFNBQVMsQ0FBQy9OLE1BQVYsQ0FBaUIsQ0FBakIsQ0FBakI7QUFDQSxNQUFJbU8sU0FBUyxHQUFHSixTQUFTLENBQUMvTixNQUFWLENBQWlCK04sU0FBUyxDQUFDL04sTUFBVixDQUFpQi9ULE1BQWpCLEdBQTBCLENBQTNDLENBQWhCO0FBQ0EsTUFBSTJqQixlQUFlLEdBQUcsRUFBdEI7O0FBRUEsTUFBSUQsVUFBVSxDQUFDaGtCLElBQVgsS0FBb0IsT0FBeEIsRUFBaUM7QUFDL0IyQixXQUFPLENBQUNDLElBQVIsQ0FBYSxzQ0FBYjtBQUNBLFdBQU8sSUFBUDtBQUNELEdBSEQsTUFHTyxJQUFJNGdCLFNBQVMsQ0FBQ3hpQixJQUFWLEtBQW1CLFVBQW5CLElBQWlDd2lCLFNBQVMsQ0FBQ3hpQixJQUFWLEtBQW1CLE9BQXhELEVBQWlFO0FBQ3RFO0FBQ0EyQixXQUFPLENBQUNDLElBQVIsQ0FBYSxtREFBYjtBQUNBLFdBQU8sSUFBUDtBQUNELEdBSk0sTUFJQTtBQUNMO0FBQ0F3Z0IsYUFBUyxDQUFDdGMsT0FBVixHQUFvQjBjLFNBQVMsQ0FBQ3hpQixJQUFWLEtBQW1CLE9BQXZDO0FBQ0FvaUIsYUFBUyxDQUFDeGMsRUFBVixHQUFlb2UsVUFBVSxDQUFDcGUsRUFBMUI7QUFFQSxRQUFJUSxPQUFPLEdBQUc7QUFDWkUsV0FBSyxFQUFFa2MsU0FBUyxDQUFDNWMsRUFBVixHQUFlb2UsVUFBVSxDQUFDcGU7QUFEckIsS0FBZDtBQUlBLFFBQUlzZSxlQUFlLEdBQUcsQ0FBdEI7QUFFQUYsY0FBVSxHQUFHLENBQUMsT0FBRCxFQUFVLENBQVYsQ0FBYjs7QUFDQSxRQUFJNUIsU0FBUyxDQUFDL04sTUFBVixDQUFpQixDQUFqQixFQUFvQnRTLElBQXhCLEVBQThCO0FBQzVCaWlCLGdCQUFVLENBQUNwaEIsSUFBWCxDQUFnQndmLFNBQVMsQ0FBQy9OLE1BQVYsQ0FBaUIsQ0FBakIsRUFBb0J0UyxJQUFwQztBQUNEOztBQUNEa2lCLG1CQUFlLENBQUNyaEIsSUFBaEIsQ0FBcUJvaEIsVUFBckI7O0FBRUEsU0FBSyxJQUFJM2pCLEVBQUUsR0FBRyxDQUFkLEVBQWlCQSxFQUFFLEdBQUcraEIsU0FBUyxDQUFDL04sTUFBVixDQUFpQi9ULE1BQWpCLEdBQTBCLENBQWhELEVBQW1ERCxFQUFFLElBQUksQ0FBekQsRUFBNEQ7QUFDMUQsVUFBSThqQixTQUFTLEdBQUcvQixTQUFTLENBQUMvTixNQUFWLENBQWlCaFUsRUFBRSxHQUFHLENBQXRCLENBQWhCO0FBQ0EsVUFBSWlpQixLQUFLLEdBQUdGLFNBQVMsQ0FBQy9OLE1BQVYsQ0FBaUJoVSxFQUFqQixDQUFaOztBQUVBLFVBQUksQ0FBQ2lpQixLQUFLLENBQUNLLEtBQVgsRUFBa0I7QUFDaEJoaEIsZUFBTyxDQUFDdUIsS0FBUixDQUFjLG9DQUFkLEVBQW9Eb2YsS0FBSyxDQUFDdGlCLElBQTFEO0FBQ0EsZUFBTyxJQUFQO0FBQ0Q7O0FBRUQsVUFBSTZqQixXQUFXLEdBQUd2QixLQUFLLENBQUMxYyxFQUFOLEdBQVd1ZSxTQUFTLENBQUN4QixLQUF2Qzs7QUFDQSxVQUFJa0IsV0FBVyxHQUFHLENBQWxCLEVBQXFCO0FBQ25CSSx1QkFBZSxDQUFDcmhCLElBQWhCLENBQXFCLENBQUMsU0FBRCxFQUFZaWhCLFdBQVosQ0FBckI7QUFDRDs7QUFDRCxVQUFJSixVQUFVLEdBQUcsS0FBS0YsVUFBTCxDQUFnQmpCLEtBQWhCLEVBQXVCLENBQXZCLEVBQTBCRixTQUExQixDQUFqQjtBQUNBNkIscUJBQWUsQ0FBQ3JoQixJQUFoQixDQUFxQjZnQixVQUFyQjtBQUVBcmQsYUFBTyxDQUFDa2MsS0FBSyxDQUFDdGlCLElBQVAsQ0FBUCxHQUFzQm9HLE9BQU8sQ0FBQ2tjLEtBQUssQ0FBQ3RpQixJQUFQLENBQVAsSUFBdUIsQ0FBN0M7QUFDQW9HLGFBQU8sQ0FBQ2tjLEtBQUssQ0FBQ3RpQixJQUFQLENBQVAsSUFBdUJ5akIsVUFBVSxDQUFDLENBQUQsQ0FBakM7QUFDQVMscUJBQWUsSUFBSVQsVUFBVSxDQUFDLENBQUQsQ0FBN0I7QUFDRDtBQUNGOztBQUVESSxhQUFXLEdBQUdyQixTQUFTLENBQUM1YyxFQUFWLEdBQWV3YyxTQUFTLENBQUMvTixNQUFWLENBQWlCK04sU0FBUyxDQUFDL04sTUFBVixDQUFpQi9ULE1BQWpCLEdBQTBCLENBQTNDLEVBQThDcWlCLEtBQTNFO0FBQ0EsTUFBR2tCLFdBQVcsR0FBRyxDQUFqQixFQUFvQkksZUFBZSxDQUFDcmhCLElBQWhCLENBQXFCLENBQUMsU0FBRCxFQUFZaWhCLFdBQVosQ0FBckI7QUFFcEIsTUFBSU8sYUFBYSxHQUFHLENBQUM1QixTQUFTLENBQUN4aUIsSUFBWCxFQUFpQixDQUFqQixDQUFwQjtBQUNBLE1BQUd3aUIsU0FBUyxDQUFDemdCLElBQWIsRUFBbUJxaUIsYUFBYSxDQUFDeGhCLElBQWQsQ0FBbUI0ZixTQUFTLENBQUN6Z0IsSUFBN0I7QUFDbkJraUIsaUJBQWUsQ0FBQ3JoQixJQUFoQixDQUFxQndoQixhQUFyQjs7QUFFQSxNQUFJSCxlQUFlLENBQUMzakIsTUFBaEIsR0FBeUJ5aEIsZ0JBQTdCLEVBQStDO0FBQzdDLFVBQU1zQyxXQUFXLEdBQUdKLGVBQWUsQ0FBQzNqQixNQUFoQixHQUF5QnloQixnQkFBN0M7QUFDQWtDLG1CQUFlLENBQUNqaEIsTUFBaEIsQ0FBdUIrZSxnQkFBdkIsRUFBeUNzQyxXQUF6QztBQUNEOztBQUVEamUsU0FBTyxDQUFDa2UsT0FBUixHQUFrQmxlLE9BQU8sQ0FBQ0UsS0FBUixHQUFnQjRkLGVBQWxDO0FBQ0E5QixXQUFTLENBQUNoYyxPQUFWLEdBQW9CQSxPQUFwQjtBQUNBZ2MsV0FBUyxDQUFDL04sTUFBVixHQUFtQjRQLGVBQW5CO0FBQ0E3QixXQUFTLENBQUNNLGlCQUFWLEdBQThCLElBQTlCO0FBQ0EsU0FBT04sU0FBUDtBQUNELENBcEVEOztBQXNFQUosTUFBTSxDQUFDdmYsU0FBUCxDQUFpQkMsU0FBakIsR0FBNkIsVUFBUzZoQixRQUFULEVBQW1CO0FBQzlDLE9BQUsvaEIsUUFBTCxDQUFjSSxJQUFkLENBQW1CMmhCLFFBQW5CO0FBQ0QsQ0FGRDs7QUFJQXZDLE1BQU0sQ0FBQ3ZmLFNBQVAsQ0FBaUIraEIsV0FBakIsR0FBK0IsVUFBVWxmLEtBQVYsRUFBaUI7QUFDOUMsT0FBSzJjLGFBQUwsQ0FBbUJyZixJQUFuQixDQUF3QjBDLEtBQXhCO0FBQ0QsQ0FGRDs7QUFJQTBjLE1BQU0sQ0FBQ3ZmLFNBQVAsQ0FBaUJvZ0IsYUFBakIsR0FBaUMsVUFBUzRCLFNBQVQsRUFBb0IxaUIsSUFBcEIsRUFBMEJrSyxJQUExQixFQUFnQztBQUMvRCxPQUFLekosUUFBTCxDQUFjOUMsT0FBZCxDQUFzQixVQUFTNmtCLFFBQVQsRUFBbUI7QUFDdkN4aUIsUUFBSSxHQUFHd2lCLFFBQVEsQ0FBQ0UsU0FBRCxFQUFZcmdCLENBQUMsQ0FBQ3NnQixLQUFGLENBQVEzaUIsSUFBUixDQUFaLEVBQTJCa0ssSUFBM0IsQ0FBZjtBQUNELEdBRkQ7O0FBSUEsU0FBT2xLLElBQVA7QUFDRCxDQU5EOztBQVFBaWdCLE1BQU0sQ0FBQ3ZmLFNBQVAsQ0FBaUJraUIsbUJBQWpCLEdBQXVDLFVBQVVDLFFBQVYsRUFBb0I7QUFDekQsUUFBTUMsWUFBWSxHQUFJak4sR0FBRCxJQUFTO0FBQzVCLFFBQUlrTixNQUFKOztBQUNBLFNBQUs3QyxhQUFMLENBQW1CdmlCLE9BQW5CLENBQTJCLFVBQVU0RixLQUFWLEVBQWlCO0FBQzFDLFVBQUlBLEtBQUssSUFBSXNTLEdBQWIsRUFBa0I7QUFDaEJrTixjQUFNLEdBQUdBLE1BQU0sSUFBSTlnQixNQUFNLENBQUMyUCxNQUFQLENBQWMsRUFBZCxFQUFrQmlFLEdBQWxCLENBQW5CO0FBQ0FrTixjQUFNLENBQUN4ZixLQUFELENBQU4sR0FBZ0IsaUJBQWhCO0FBQ0Q7QUFDRixLQUxEOztBQU9BLFdBQU93ZixNQUFQO0FBQ0QsR0FWRDs7QUFZQSxNQUFJQyxLQUFLLENBQUNDLE9BQU4sQ0FBY0osUUFBZCxDQUFKLEVBQTZCO0FBQzNCLFFBQUlFLE1BQUosQ0FEMkIsQ0FFM0I7QUFDQTtBQUNBOztBQUNBLFFBQUl4a0IsTUFBTSxHQUFHaVcsSUFBSSxDQUFDQyxHQUFMLENBQVNvTyxRQUFRLENBQUN0a0IsTUFBbEIsRUFBMEIsS0FBSzRoQixxQkFBL0IsQ0FBYjs7QUFDQSxTQUFLLElBQUl5QixDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHcmpCLE1BQXBCLEVBQTRCcWpCLENBQUMsRUFBN0IsRUFBaUM7QUFDL0IsVUFBSSxPQUFPaUIsUUFBUSxDQUFDakIsQ0FBRCxDQUFmLEtBQXVCLFFBQXZCLElBQW1DaUIsUUFBUSxDQUFDakIsQ0FBRCxDQUFSLEtBQWdCLElBQXZELEVBQTZEO0FBQzNELFlBQUkxSixNQUFNLEdBQUc0SyxZQUFZLENBQUNELFFBQVEsQ0FBQ2pCLENBQUQsQ0FBVCxDQUF6Qjs7QUFDQSxZQUFJMUosTUFBSixFQUFZO0FBQ1Y2SyxnQkFBTSxHQUFHQSxNQUFNLElBQUksQ0FBQyxHQUFHRixRQUFKLENBQW5CO0FBQ0FFLGdCQUFNLENBQUNuQixDQUFELENBQU4sR0FBWTFKLE1BQVo7QUFDRDtBQUNGO0FBQ0Y7O0FBRUQsV0FBTzZLLE1BQU0sSUFBSUYsUUFBakI7QUFDRDs7QUFFRCxTQUFPQyxZQUFZLENBQUNELFFBQUQsQ0FBWixJQUEwQkEsUUFBakM7QUFDRCxDQWpDRDs7QUFtQ0FwbUIsTUFBTSxDQUFDeW1CLE1BQVAsR0FBZ0IsSUFBSWpELE1BQUosRUFBaEIsQyxDQUNBOztBQUNBeGpCLE1BQU0sQ0FBQ3dqQixNQUFQLEdBQWdCQSxNQUFoQixDOzs7Ozs7Ozs7OztBQzdVQTtBQUNBO0FBQ0E7QUFDQUEsTUFBTSxDQUFDa0QsY0FBUCxHQUF3QixTQUFTQSxjQUFULENBQXdCQyxZQUF4QixFQUFzQ0MsWUFBdEMsRUFBb0RyZixJQUFwRCxFQUEwRDtBQUNoRm9mLGNBQVksR0FBSUEsWUFBWSxJQUFJLEVBQWhDO0FBRUEsTUFBSUUsYUFBYSxHQUFHLEVBQXBCO0FBQ0FGLGNBQVksQ0FBQ3psQixPQUFiLENBQXFCLFVBQVNNLElBQVQsRUFBZTtBQUNsQ3FsQixpQkFBYSxDQUFDcmxCLElBQUQsQ0FBYixHQUFzQixJQUF0QjtBQUNELEdBRkQ7QUFJQSxTQUFPLFVBQVVBLElBQVYsRUFBZ0IrQixJQUFoQixFQUFzQmtLLElBQXRCLEVBQTRCO0FBQ2pDLFFBQUdrWixZQUFZLENBQUM3a0IsTUFBYixHQUFzQixDQUF0QixJQUEyQixDQUFDK2tCLGFBQWEsQ0FBQ3JsQixJQUFELENBQTVDLEVBQ0UsT0FBTytCLElBQVA7QUFFRixRQUFHcWpCLFlBQVksSUFBSUEsWUFBWSxJQUFJblosSUFBSSxDQUFDak0sSUFBeEMsRUFDRSxPQUFPK0IsSUFBUDtBQUVGLFFBQUdnRSxJQUFJLElBQUlBLElBQUksSUFBSWtHLElBQUksQ0FBQ2xHLElBQXhCLEVBQ0UsT0FBT2hFLElBQVA7O0FBRUYsUUFBRy9CLElBQUksSUFBSSxPQUFYLEVBQW9CO0FBQ2xCLFVBQUkrQixJQUFJLENBQUM0RixNQUFULEVBQWlCO0FBQ2Y1RixZQUFJLENBQUM0RixNQUFMLEdBQWMsWUFBZDtBQUNEOztBQUNELFVBQUk1RixJQUFJLENBQUNLLE9BQVQsRUFBa0I7QUFDaEJMLFlBQUksQ0FBQ0ssT0FBTCxHQUFlLFlBQWY7QUFDRDs7QUFDRCxVQUFJTCxJQUFJLENBQUNzWSxJQUFULEVBQWU7QUFDYnRZLFlBQUksQ0FBQ3NZLElBQUwsR0FBWSxZQUFaO0FBQ0Q7QUFDRixLQVZELE1BVU8sSUFBR3JhLElBQUksSUFBSSxJQUFYLEVBQWlCO0FBQ3RCK0IsVUFBSSxDQUFDb2QsUUFBTCxHQUFnQixZQUFoQjtBQUNELEtBRk0sTUFFQSxJQUFHbmYsSUFBSSxJQUFJLE1BQVgsRUFBbUI7QUFDeEIrQixVQUFJLENBQUN5WCxHQUFMLEdBQVcsWUFBWDtBQUNELEtBRk0sTUFFQSxJQUFHeFosSUFBSSxJQUFJLE9BQVgsRUFBb0I7QUFDekIsT0FBQyxNQUFELEVBQVMsSUFBVCxFQUFlLElBQWYsRUFBcUIsS0FBckIsRUFBNEIsU0FBNUIsRUFBdUNOLE9BQXZDLENBQStDLFVBQVM0bEIsSUFBVCxFQUFlO0FBQzVELFlBQUd2akIsSUFBSSxDQUFDdWpCLElBQUQsQ0FBUCxFQUFlO0FBQ2J2akIsY0FBSSxDQUFDdWpCLElBQUQsQ0FBSixHQUFhLFlBQWI7QUFDRDtBQUNGLE9BSkQ7QUFLRDs7QUFFRCxXQUFPdmpCLElBQVA7QUFDRCxHQWpDRDtBQWtDRCxDQTFDRCxDLENBNENBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBaWdCLE1BQU0sQ0FBQ3VELHNCQUFQLEdBQWdDLFNBQVNMLGNBQVQsR0FBMEI7QUFDeEQsU0FBTyxVQUFVbGxCLElBQVYsRUFBZ0IrQixJQUFoQixFQUFzQjtBQUMzQixRQUFJeWpCLFlBQVksR0FBRyxFQUFuQjs7QUFFQSxRQUFJeGxCLElBQUksSUFBSSxPQUFaLEVBQXFCO0FBQ25Cd2xCLGtCQUFZLEdBQUcsQ0FBQyxRQUFELENBQWY7QUFDRCxLQUZELE1BRU8sSUFBSXhsQixJQUFJLEtBQUssU0FBYixFQUF3QjtBQUM3QndsQixrQkFBWSxHQUFHLENBQUUsUUFBRixDQUFmO0FBQ0QsS0FGTSxNQUVBLElBQUl4bEIsSUFBSSxJQUFJLElBQVosRUFBa0I7QUFDdkJ3bEIsa0JBQVksR0FBRyxDQUNiLE1BRGEsRUFDTCxNQURLLEVBQ0csUUFESCxFQUNhLE9BRGIsRUFDc0IsYUFEdEIsRUFDcUMsU0FEckMsRUFDZ0QsT0FEaEQsRUFFYixRQUZhLEVBRUgscUJBRkcsRUFFb0IsYUFGcEIsRUFFbUMsb0JBRm5DLEVBR2IsZ0JBSGEsQ0FBZjtBQUtELEtBTk0sTUFNQSxJQUFJeGxCLElBQUksSUFBSSxNQUFaLEVBQW9CO0FBQ3pCd2xCLGtCQUFZLEdBQUcsQ0FBQyxRQUFELEVBQVcsWUFBWCxDQUFmO0FBQ0QsS0FGTSxNQUVBLElBQUl4bEIsSUFBSSxJQUFJLE9BQVosRUFBcUI7QUFDMUJ3bEIsa0JBQVksR0FBRyxFQUFmO0FBQ0QsS0FGTSxNQUVBLElBQUl4bEIsSUFBSSxLQUFLLFFBQWIsRUFBdUI7QUFDNUI7QUFDQXdsQixrQkFBWSxHQUFHeGhCLE1BQU0sQ0FBQytULElBQVAsQ0FBWWhXLElBQVosQ0FBZjtBQUNELEtBSE0sTUFHQSxJQUFJL0IsSUFBSSxLQUFLLE9BQWIsRUFBc0I7QUFDM0J3bEIsa0JBQVksR0FBRyxDQUFDLE9BQUQsQ0FBZjtBQUNEOztBQUVEeGhCLFVBQU0sQ0FBQytULElBQVAsQ0FBWWhXLElBQVosRUFBa0JyQyxPQUFsQixDQUEwQnNILEdBQUcsSUFBSTtBQUMvQixVQUFJd2UsWUFBWSxDQUFDemlCLE9BQWIsQ0FBcUJpRSxHQUFyQixNQUE4QixDQUFDLENBQW5DLEVBQXNDO0FBQ3BDakYsWUFBSSxDQUFDaUYsR0FBRCxDQUFKLEdBQVksWUFBWjtBQUNEO0FBQ0YsS0FKRDtBQU1BLFdBQU9qRixJQUFQO0FBQ0QsR0EvQkQ7QUFnQ0QsQ0FqQ0QsQyxDQW1DQTs7O0FBQ0FpZ0IsTUFBTSxDQUFDeUQsY0FBUCxHQUF3QixTQUFTQSxjQUFULENBQXdCQyxjQUF4QixFQUF3Q04sWUFBeEMsRUFBc0RyZixJQUF0RCxFQUE0RDtBQUNsRjJmLGdCQUFjLEdBQUdBLGNBQWMsSUFBSSxFQUFuQztBQUVBLE1BQUlDLE9BQU8sR0FBRyxFQUFkO0FBQ0FELGdCQUFjLENBQUNobUIsT0FBZixDQUF1QixVQUFTa21CLFFBQVQsRUFBbUI7QUFDeENELFdBQU8sQ0FBQ0MsUUFBRCxDQUFQLEdBQW9CLElBQXBCO0FBQ0QsR0FGRDtBQUlBLFNBQU8sVUFBUzVsQixJQUFULEVBQWUrQixJQUFmLEVBQXFCa0ssSUFBckIsRUFBMkI7QUFDaEMsUUFBR2pNLElBQUksSUFBSSxJQUFSLElBQWlCK0IsSUFBSSxJQUFJLENBQUM0akIsT0FBTyxDQUFDNWpCLElBQUksQ0FBQzhqQixJQUFOLENBQXBDLEVBQWtEO0FBQ2hELGFBQU85akIsSUFBUDtBQUNEOztBQUVELFFBQUdxakIsWUFBWSxJQUFJQSxZQUFZLElBQUluWixJQUFJLENBQUNqTSxJQUF4QyxFQUNFLE9BQU8rQixJQUFQO0FBRUYsUUFBR2dFLElBQUksSUFBSUEsSUFBSSxJQUFJa0csSUFBSSxDQUFDbEcsSUFBeEIsRUFDRSxPQUFPaEUsSUFBUDtBQUVGQSxRQUFJLENBQUNvZCxRQUFMLEdBQWdCLFlBQWhCO0FBQ0EsV0FBT3BkLElBQVA7QUFDRCxHQWJEO0FBY0QsQ0F0QkQsQzs7Ozs7Ozs7Ozs7QUN4RkEsSUFBSXNGLE1BQU0sR0FBR3JJLEdBQUcsQ0FBQ0MsT0FBSixDQUFZLE9BQVosRUFBcUIsV0FBckIsQ0FBYjs7QUFFQXVGLFdBQVcsR0FBRyxTQUFTQSxXQUFULENBQXFCL0YsT0FBckIsRUFBOEI7QUFDMUNBLFNBQU8sR0FBR0EsT0FBTyxJQUFJLEVBQXJCO0FBRUEsT0FBS2lHLGNBQUwsR0FBc0JqRyxPQUFPLENBQUNpRyxjQUFSLElBQTBCLEVBQWhEO0FBQ0EsT0FBS0QsUUFBTCxHQUFnQmhHLE9BQU8sQ0FBQ2dHLFFBQVIsSUFBb0IsT0FBTyxFQUEzQztBQUNBLE9BQUtFLFlBQUwsR0FBb0JsRyxPQUFPLENBQUNrRyxZQUFSLElBQXdCLEtBQUtELGNBQUwsR0FBc0IsQ0FBbEUsQ0FMMEMsQ0FPMUM7O0FBQ0EsT0FBS29oQixTQUFMLEdBQWlCOWhCLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjLElBQWQsQ0FBakIsQ0FSMEMsQ0FTMUM7O0FBQ0EsT0FBSzhoQixlQUFMLEdBQXVCL2hCLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjLElBQWQsQ0FBdkIsQ0FWMEMsQ0FXMUM7O0FBQ0EsT0FBSytoQixZQUFMLEdBQW9CLEVBQXBCO0FBRUEsT0FBS0MsWUFBTCxHQUFvQmppQixNQUFNLENBQUNDLE1BQVAsQ0FBYyxJQUFkLENBQXBCLENBZDBDLENBZ0IxQzs7QUFDQSxPQUFLQyxRQUFMLEdBQWdCRixNQUFNLENBQUNDLE1BQVAsQ0FBYyxJQUFkLENBQWhCO0FBQ0QsQ0FsQkQ7O0FBb0JBTyxXQUFXLENBQUMvQixTQUFaLENBQXNCdUQsUUFBdEIsR0FBaUMsVUFBU3lDLEtBQVQsRUFBZ0I7QUFDL0MsTUFBSXlkLElBQUksR0FBRyxDQUFDemQsS0FBSyxDQUFDekksSUFBUCxFQUFheUksS0FBSyxDQUFDMUMsSUFBbkIsRUFBeUJ3UixJQUF6QixDQUE4QixJQUE5QixDQUFYOztBQUNBLE1BQUcsQ0FBQyxLQUFLd08sZUFBTCxDQUFxQkcsSUFBckIsQ0FBSixFQUFnQztBQUM5QixTQUFLSCxlQUFMLENBQXFCRyxJQUFyQixJQUE2QkMsS0FBSyxDQUFDekIsS0FBTixDQUFZamMsS0FBWixDQUE3QjtBQUNELEdBRkQsTUFFTyxJQUFHLEtBQUtzZCxlQUFMLENBQXFCRyxJQUFyQixFQUEyQjlmLE9BQTNCLENBQW1DRSxLQUFuQyxHQUEyQ21DLEtBQUssQ0FBQ3JDLE9BQU4sQ0FBY0UsS0FBNUQsRUFBbUU7QUFDeEUsU0FBS3lmLGVBQUwsQ0FBcUJHLElBQXJCLElBQTZCQyxLQUFLLENBQUN6QixLQUFOLENBQVlqYyxLQUFaLENBQTdCO0FBQ0QsR0FGTSxNQUVBLElBQUdBLEtBQUssQ0FBQzNDLE9BQVQsRUFBa0I7QUFDdkIsU0FBS3NnQixhQUFMLENBQW1CM2QsS0FBbkI7QUFDRDtBQUNGLENBVEQ7O0FBV0FqRSxXQUFXLENBQUMvQixTQUFaLENBQXNCMkUsYUFBdEIsR0FBc0MsWUFBVztBQUMvQyxNQUFJaWYsTUFBTSxHQUFHLEtBQUtMLFlBQWxCO0FBQ0EsT0FBS0EsWUFBTCxHQUFvQixFQUFwQixDQUYrQyxDQUkvQzs7QUFDQUssUUFBTSxDQUFDM21CLE9BQVAsQ0FBZSxVQUFTK0ksS0FBVCxFQUFnQjtBQUM3QkEsU0FBSyxDQUFDN0MsRUFBTixHQUFXcEgsTUFBTSxDQUFDeUksVUFBUCxDQUFrQkMsUUFBbEIsQ0FBMkJ1QixLQUFLLENBQUM3QyxFQUFqQyxDQUFYO0FBQ0QsR0FGRDtBQUdBLFNBQU95Z0IsTUFBUDtBQUNELENBVEQ7O0FBV0E3aEIsV0FBVyxDQUFDL0IsU0FBWixDQUFzQm1DLEtBQXRCLEdBQThCLFlBQVc7QUFDdkMsT0FBSzBoQixlQUFMLEdBQXVCblksV0FBVyxDQUFDLEtBQUtvWSxhQUFMLENBQW1CekksSUFBbkIsQ0FBd0IsSUFBeEIsQ0FBRCxFQUFnQyxLQUFLclosUUFBckMsQ0FBbEM7QUFDRCxDQUZEOztBQUlBRCxXQUFXLENBQUMvQixTQUFaLENBQXNCK2pCLElBQXRCLEdBQTZCLFlBQVc7QUFDdEMsTUFBRyxLQUFLRixlQUFSLEVBQXlCO0FBQ3ZCRyxpQkFBYSxDQUFDLEtBQUtILGVBQU4sQ0FBYjtBQUNEO0FBQ0YsQ0FKRDs7QUFNQTloQixXQUFXLENBQUMvQixTQUFaLENBQXNCMmpCLGFBQXRCLEdBQXNDLFVBQVMzZCxLQUFULEVBQWdCO0FBQ3BEO0FBQ0EsTUFBSStaLFNBQVMsR0FBRy9aLEtBQUssQ0FBQzRMLE1BQU4sQ0FBYTVMLEtBQUssQ0FBQzRMLE1BQU4sQ0FBYS9ULE1BQWIsR0FBcUIsQ0FBbEMsQ0FBaEI7O0FBQ0EsTUFBR2tpQixTQUFTLElBQUlBLFNBQVMsQ0FBQyxDQUFELENBQXpCLEVBQThCO0FBQzVCLFFBQUl0ZixLQUFLLEdBQUdzZixTQUFTLENBQUMsQ0FBRCxDQUFULENBQWF0ZixLQUF6QixDQUQ0QixDQUc1Qjs7QUFDQSxRQUFJd2pCLFFBQVEsR0FBRyxDQUFDamUsS0FBSyxDQUFDekksSUFBUCxFQUFheUksS0FBSyxDQUFDMUMsSUFBbkIsRUFBeUI3QyxLQUFLLENBQUNqRCxPQUEvQixFQUF3Q3NYLElBQXhDLENBQTZDLElBQTdDLENBQWY7O0FBQ0EsUUFBRyxDQUFDLEtBQUtyVCxRQUFMLENBQWN3aUIsUUFBZCxDQUFKLEVBQTZCO0FBQzNCLFVBQUlDLFlBQVksR0FBR1IsS0FBSyxDQUFDekIsS0FBTixDQUFZamMsS0FBWixDQUFuQjtBQUNBLFdBQUt2RSxRQUFMLENBQWN3aUIsUUFBZCxJQUEwQkMsWUFBMUI7QUFFQSxXQUFLWCxZQUFMLENBQWtCcGpCLElBQWxCLENBQXVCK2pCLFlBQXZCO0FBQ0Q7QUFDRixHQVhELE1BV087QUFDTHRmLFVBQU0sQ0FBQywrQkFBRCxFQUFrQ2hGLElBQUksQ0FBQ0MsU0FBTCxDQUFlbUcsS0FBSyxDQUFDNEwsTUFBckIsQ0FBbEMsQ0FBTjtBQUNEO0FBQ0YsQ0FqQkQ7O0FBbUJBN1AsV0FBVyxDQUFDL0IsU0FBWixDQUFzQjhqQixhQUF0QixHQUFzQyxZQUFXO0FBQy9DLE1BQUlwYyxJQUFJLEdBQUcsSUFBWDtBQUVBLE1BQUl5YyxLQUFLLEdBQUcsSUFBSTlPLEdBQUosRUFBWjtBQUNBOVQsUUFBTSxDQUFDK1QsSUFBUCxDQUFZLEtBQUsrTixTQUFqQixFQUE0QnBtQixPQUE1QixDQUFvQ3NILEdBQUcsSUFBSTtBQUN6QzRmLFNBQUssQ0FBQ3ZnQixHQUFOLENBQVVXLEdBQVY7QUFDRCxHQUZEO0FBR0FoRCxRQUFNLENBQUMrVCxJQUFQLENBQVksS0FBS2dPLGVBQWpCLEVBQWtDcm1CLE9BQWxDLENBQTBDc0gsR0FBRyxJQUFJO0FBQy9DNGYsU0FBSyxDQUFDdmdCLEdBQU4sQ0FBVVcsR0FBVjtBQUNELEdBRkQ7O0FBSUEsT0FBS2tmLElBQUwsSUFBYVUsS0FBYixFQUFvQjtBQUNsQnpjLFFBQUksQ0FBQzhiLFlBQUwsQ0FBa0JDLElBQWxCLElBQTBCL2IsSUFBSSxDQUFDOGIsWUFBTCxDQUFrQkMsSUFBbEIsS0FBMkIsQ0FBckQ7QUFDQSxRQUFJSCxlQUFlLEdBQUc1YixJQUFJLENBQUM0YixlQUFMLENBQXFCRyxJQUFyQixDQUF0QjtBQUNBLFFBQUlXLGVBQWUsR0FBR2QsZUFBZSxHQUFFQSxlQUFlLENBQUMzZixPQUFoQixDQUF3QkUsS0FBMUIsR0FBa0MsQ0FBdkU7QUFFQTZELFFBQUksQ0FBQzJiLFNBQUwsQ0FBZUksSUFBZixJQUF1Qi9iLElBQUksQ0FBQzJiLFNBQUwsQ0FBZUksSUFBZixLQUF3QixFQUEvQyxDQUxrQixDQU1sQjs7QUFDQS9iLFFBQUksQ0FBQzJiLFNBQUwsQ0FBZUksSUFBZixFQUFxQnRqQixJQUFyQixDQUEwQmlrQixlQUExQjtBQUNBLFFBQUlDLGVBQWUsR0FBRzNjLElBQUksQ0FBQzJiLFNBQUwsQ0FBZUksSUFBZixFQUFxQjVsQixNQUFyQixHQUE4QjZKLElBQUksQ0FBQ3pGLGNBQXpEOztBQUNBLFFBQUdvaUIsZUFBZSxHQUFHLENBQXJCLEVBQXdCO0FBQ3RCM2MsVUFBSSxDQUFDMmIsU0FBTCxDQUFlSSxJQUFmLEVBQXFCbGpCLE1BQXJCLENBQTRCLENBQTVCLEVBQStCOGpCLGVBQS9CO0FBQ0Q7O0FBRUQsUUFBSUMsY0FBYyxHQUFJNWMsSUFBSSxDQUFDOGIsWUFBTCxDQUFrQkMsSUFBbEIsSUFBMEIvYixJQUFJLENBQUN4RixZQUFoQyxJQUFpRCxDQUF0RTtBQUNBd0YsUUFBSSxDQUFDOGIsWUFBTCxDQUFrQkMsSUFBbEI7O0FBRUEsUUFBSWMsVUFBVSxHQUFHRCxjQUFjLElBQzFCNWMsSUFBSSxDQUFDOGMsZUFBTCxDQUFxQmYsSUFBckIsRUFBMkJILGVBQTNCLENBREw7O0FBR0EsUUFBR2lCLFVBQVUsSUFBSWpCLGVBQWpCLEVBQWtDO0FBQ2hDNWIsVUFBSSxDQUFDNmIsWUFBTCxDQUFrQnBqQixJQUFsQixDQUF1Qm1qQixlQUF2QjtBQUNELEtBckJpQixDQXVCbEI7OztBQUNBNWIsUUFBSSxDQUFDNGIsZUFBTCxDQUFxQkcsSUFBckIsSUFBNkIsSUFBN0I7QUFDRDs7QUFBQSxHQXBDOEMsQ0FzQy9DOztBQUNBL2IsTUFBSSxDQUFDakcsUUFBTCxHQUFnQkYsTUFBTSxDQUFDQyxNQUFQLENBQWMsSUFBZCxDQUFoQjtBQUNELENBeENEOztBQTBDQU8sV0FBVyxDQUFDL0IsU0FBWixDQUFzQndrQixlQUF0QixHQUF3QyxVQUFTZixJQUFULEVBQWV6ZCxLQUFmLEVBQXNCO0FBQzVELE1BQUdBLEtBQUgsRUFBVTtBQUNSLFFBQUl5ZSxPQUFPLEdBQUcsS0FBS3BCLFNBQUwsQ0FBZUksSUFBZixDQUFkO0FBQ0EsV0FBTyxLQUFLaUIsVUFBTCxDQUFnQkQsT0FBaEIsRUFBeUJ6ZSxLQUFLLENBQUNyQyxPQUFOLENBQWNFLEtBQXZDLEVBQThDLENBQTlDLENBQVA7QUFDRCxHQUhELE1BR087QUFDTCxXQUFPLEtBQVA7QUFDRDtBQUNGLENBUEQ7QUFTQTtBQUNBO0FBQ0E7OztBQUNBOUIsV0FBVyxDQUFDL0IsU0FBWixDQUFzQjBrQixVQUF0QixHQUFtQyxVQUFTRCxPQUFULEVBQWtCRSxTQUFsQixFQUE2QkMsT0FBN0IsRUFBc0M7QUFDdkUsTUFBSUMsTUFBTSxHQUFHLEtBQUtDLFVBQUwsQ0FBZ0JMLE9BQWhCLENBQWI7O0FBQ0EsTUFBSU0sR0FBRyxHQUFHLEtBQUtDLGFBQUwsQ0FBbUJQLE9BQW5CLEVBQTRCSSxNQUE1QixDQUFWOztBQUNBLE1BQUlJLElBQUksR0FBRyxLQUFLQyxvQkFBTCxDQUEwQkwsTUFBMUIsRUFBa0NGLFNBQWxDLElBQStDSSxHQUExRDtBQUVBLFNBQU9FLElBQUksR0FBR0wsT0FBZDtBQUNELENBTkQ7O0FBUUE3aUIsV0FBVyxDQUFDL0IsU0FBWixDQUFzQjhrQixVQUF0QixHQUFtQyxVQUFTTCxPQUFULEVBQWtCO0FBQ25ELE1BQUlVLGFBQWEsR0FBR3hqQixDQUFDLENBQUNzZ0IsS0FBRixDQUFRd0MsT0FBUixFQUFpQmhILElBQWpCLENBQXNCLFVBQVN4SSxDQUFULEVBQVltUSxDQUFaLEVBQWU7QUFDdkQsV0FBT25RLENBQUMsR0FBQ21RLENBQVQ7QUFDRCxHQUZtQixDQUFwQjs7QUFHQSxTQUFPLEtBQUtDLGFBQUwsQ0FBbUJGLGFBQW5CLEVBQWtDLENBQWxDLENBQVA7QUFDRCxDQUxEOztBQU9BcGpCLFdBQVcsQ0FBQy9CLFNBQVosQ0FBc0JxbEIsYUFBdEIsR0FBc0MsVUFBU1osT0FBVCxFQUFrQmEsR0FBbEIsRUFBdUI7QUFDM0QsTUFBSUMsR0FBRyxHQUFJLENBQUNkLE9BQU8sQ0FBQzVtQixNQUFSLEdBQWlCLENBQWxCLElBQXVCeW5CLEdBQXhCLEdBQStCLENBQXpDOztBQUNBLE1BQUdDLEdBQUcsR0FBRyxDQUFOLElBQVcsQ0FBZCxFQUFpQjtBQUNmLFdBQU9kLE9BQU8sQ0FBQ2MsR0FBRyxHQUFFLENBQU4sQ0FBZDtBQUNELEdBRkQsTUFFTztBQUNMQSxPQUFHLEdBQUdBLEdBQUcsR0FBSUEsR0FBRyxHQUFHLENBQW5CO0FBQ0EsV0FBTyxDQUFDZCxPQUFPLENBQUNjLEdBQUcsR0FBRSxDQUFOLENBQVAsR0FBa0JkLE9BQU8sQ0FBQ2MsR0FBRCxDQUExQixJQUFpQyxDQUF4QztBQUNEO0FBQ0YsQ0FSRDs7QUFVQXhqQixXQUFXLENBQUMvQixTQUFaLENBQXNCZ2xCLGFBQXRCLEdBQXNDLFVBQVNQLE9BQVQsRUFBa0JJLE1BQWxCLEVBQTBCO0FBQzlELE1BQUlXLGdCQUFnQixHQUFHN2pCLENBQUMsQ0FBQ3lOLEdBQUYsQ0FBTXFWLE9BQU4sRUFBZSxLQUFLUyxvQkFBTCxDQUEwQkwsTUFBMUIsQ0FBZixDQUF2Qjs7QUFDQSxNQUFJRSxHQUFHLEdBQUcsS0FBS0QsVUFBTCxDQUFnQlUsZ0JBQWhCLENBQVY7O0FBRUEsU0FBT1QsR0FBUDtBQUNELENBTEQ7O0FBT0FoakIsV0FBVyxDQUFDL0IsU0FBWixDQUFzQmtsQixvQkFBdEIsR0FBNkMsVUFBU0wsTUFBVCxFQUFpQjtBQUM1RCxTQUFPLFVBQVNZLENBQVQsRUFBWTtBQUNqQixXQUFPM1IsSUFBSSxDQUFDNFIsR0FBTCxDQUFTYixNQUFNLEdBQUdZLENBQWxCLENBQVA7QUFDRCxHQUZEO0FBR0QsQ0FKRDs7QUFNQTFqQixXQUFXLENBQUMvQixTQUFaLENBQXNCMmxCLFFBQXRCLEdBQWlDLFVBQVNDLFVBQVQsRUFBcUI7QUFDcEQsTUFBR0EsVUFBVSxDQUFDL25CLE1BQVgsR0FBb0IsQ0FBdkIsRUFBMEI7QUFDeEIsUUFBSWdHLEtBQUssR0FBRyxDQUFaO0FBQ0EraEIsY0FBVSxDQUFDM29CLE9BQVgsQ0FBbUIsVUFBUzRvQixLQUFULEVBQWdCO0FBQ2pDaGlCLFdBQUssSUFBSWdpQixLQUFUO0FBQ0QsS0FGRDtBQUdBLFdBQU9oaUIsS0FBSyxHQUFDK2hCLFVBQVUsQ0FBQy9uQixNQUF4QjtBQUNELEdBTkQsTUFNTztBQUNMLFdBQU8sQ0FBUDtBQUNEO0FBQ0YsQ0FWRCxDOzs7Ozs7Ozs7OztBQ3JLQSxJQUFJaW9CLEdBQUcsR0FBR3ZwQixHQUFHLENBQUNDLE9BQUosQ0FBWSxXQUFaLENBQVY7O0FBQ0EsSUFBSXVwQixNQUFNLEdBQUd4cEIsR0FBRyxDQUFDQyxPQUFKLENBQVksUUFBWixDQUFiOztBQUNBLElBQUl3cEIsYUFBYSxHQUFHenBCLEdBQUcsQ0FBQ0MsT0FBSixDQUFZLHFCQUFaLENBQXBCOztBQUVBeXBCLFVBQVUsR0FBRyxVQUFVQyxRQUFWLEVBQW9CQyxTQUFwQixFQUErQjtBQUMxQyxPQUFLQyxLQUFMLEdBQWEsSUFBSU4sR0FBSixDQUFRO0FBQUNPLE9BQUcsRUFBRUg7QUFBTixHQUFSLENBQWI7QUFDQSxPQUFLQyxTQUFMLEdBQWlCQSxTQUFqQjtBQUNBLE9BQUs1YSxRQUFMLEdBQWdCLENBQWhCO0FBQ0QsQ0FKRCxDLENBTUE7OztBQUNBMGEsVUFBVSxDQUFDam1CLFNBQVgsQ0FBcUJpUSxPQUFyQixHQUErQixVQUFVcEIsSUFBVixFQUFnQjtBQUM3QyxPQUFLdEQsUUFBTCxHQUFnQnNELElBQWhCO0FBQ0QsQ0FGRDs7QUFJQW9YLFVBQVUsQ0FBQ2ptQixTQUFYLENBQXFCc21CLE9BQXJCLEdBQStCLFVBQVVsRCxJQUFWLEVBQWdCbUQsS0FBaEIsRUFBdUJDLElBQXZCLEVBQTZCbG5CLElBQTdCLEVBQW1DO0FBQ2hFO0FBQ0E7QUFDQSxNQUFJLEVBQUVBLElBQUksS0FBS0EsSUFBSSxDQUFDekIsTUFBTCxJQUFnQixPQUFPeUIsSUFBSSxDQUFDMEUsSUFBWixLQUFxQixVQUFyQixJQUFtQzFFLElBQUksQ0FBQzBFLElBQUwsRUFBeEQsQ0FBTixDQUFKLEVBQWtGO0FBQ2hGLFdBQU8sQ0FBUDtBQUNEOztBQUVELE1BQUlPLEdBQUcsR0FBRyxLQUFLa2lCLE1BQUwsQ0FBWXJELElBQVosRUFBa0JtRCxLQUFsQixFQUF5QkMsSUFBekIsQ0FBVjtBQUNBLE1BQUkzRCxJQUFJLEdBQUcsS0FBS3VELEtBQUwsQ0FBVy9TLEdBQVgsQ0FBZTlPLEdBQWYsQ0FBWDs7QUFFQSxNQUFJLENBQUNzZSxJQUFMLEVBQVc7QUFDVEEsUUFBSSxHQUFHLElBQUk2RCxjQUFKLENBQW1CLEtBQUtQLFNBQXhCLENBQVA7QUFDQSxTQUFLQyxLQUFMLENBQVdoVCxHQUFYLENBQWU3TyxHQUFmLEVBQW9Cc2UsSUFBcEI7QUFDRDs7QUFFRCxNQUFJLEtBQUs4RCxXQUFMLENBQWlCOUQsSUFBakIsQ0FBSixFQUE0QjtBQUMxQixRQUFJK0QsR0FBRyxHQUFHLEVBQVY7O0FBQ0EsUUFBRyxPQUFPdG5CLElBQUksQ0FBQytULEdBQVosS0FBb0IsVUFBdkIsRUFBa0M7QUFDaEM7QUFDQS9ULFVBQUksQ0FBQ3JDLE9BQUwsQ0FBYSxVQUFTNHBCLE9BQVQsRUFBaUI7QUFDNUJELFdBQUcsR0FBR0MsT0FBTjtBQUNBLGVBQU8sS0FBUCxDQUY0QixDQUVkO0FBQ2YsT0FIRDtBQUlELEtBTkQsTUFNTztBQUNMRCxTQUFHLEdBQUd0bkIsSUFBSSxDQUFDLENBQUQsQ0FBVjtBQUNEOztBQUNELFFBQUkwRSxJQUFJLEdBQUc4aUIsTUFBTSxDQUFDQyxVQUFQLENBQWtCZixhQUFhLENBQUNZLEdBQUQsQ0FBL0IsRUFBc0MsTUFBdEMsQ0FBWDtBQUNBL0QsUUFBSSxDQUFDbUUsT0FBTCxDQUFhaGpCLElBQWI7QUFDRDs7QUFFRCxTQUFPNmUsSUFBSSxDQUFDb0UsUUFBTCxFQUFQO0FBQ0QsQ0EvQkQ7O0FBaUNBaEIsVUFBVSxDQUFDam1CLFNBQVgsQ0FBcUJ5bUIsTUFBckIsR0FBOEIsVUFBVXJELElBQVYsRUFBZ0JtRCxLQUFoQixFQUF1QkMsSUFBdkIsRUFBNkI7QUFDekQsU0FBT1IsYUFBYSxDQUFDLENBQUM1QyxJQUFELEVBQU9tRCxLQUFQLEVBQWNDLElBQWQsQ0FBRCxDQUFwQjtBQUNELENBRkQsQyxDQUlBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBUCxVQUFVLENBQUNqbUIsU0FBWCxDQUFxQmtuQixZQUFyQixHQUFvQyxVQUFVckUsSUFBVixFQUFnQjtBQUNsRCxTQUFPLENBQ0wsQ0FBQ0EsSUFBSSxDQUFDc0QsU0FBTCxHQUFpQnRELElBQUksQ0FBQzFSLE1BQUwsQ0FBWXRULE1BQTlCLElBQXNDZ2xCLElBQUksQ0FBQ3NELFNBRHRDLEVBRUwsQ0FBQ3pjLElBQUksQ0FBQ2lDLEdBQUwsS0FBYWtYLElBQUksQ0FBQ3NFLE9BQW5CLElBQThCLEtBRnpCLEVBR0wsQ0FBQyxNQUFNLEtBQUs1YixRQUFaLElBQXdCLEdBSG5CLEVBSUw2RCxHQUpLLENBSUQsVUFBVWdZLEtBQVYsRUFBaUI7QUFDckIsV0FBT0EsS0FBSyxHQUFHLENBQVIsR0FBWSxDQUFaLEdBQWdCQSxLQUF2QjtBQUNELEdBTk0sRUFNSjdQLE1BTkksQ0FNRyxVQUFVMVQsS0FBVixFQUFpQnVqQixLQUFqQixFQUF3QjtBQUNoQyxXQUFPLENBQUN2akIsS0FBSyxJQUFJLENBQVYsSUFBZXVqQixLQUF0QjtBQUNELEdBUk0sSUFRRixDQVJMO0FBU0QsQ0FWRDs7QUFZQW5CLFVBQVUsQ0FBQ2ptQixTQUFYLENBQXFCMm1CLFdBQXJCLEdBQW1DLFVBQVU5RCxJQUFWLEVBQWdCO0FBQ2pEO0FBQ0EsTUFBSSxDQUFDQSxJQUFJLENBQUMxUixNQUFMLENBQVl0VCxNQUFqQixFQUF5QjtBQUN2QixXQUFPLElBQVA7QUFDRDs7QUFFRCxNQUFJd3BCLFdBQVcsR0FBRzNkLElBQUksQ0FBQ2lDLEdBQUwsRUFBbEI7QUFDQSxNQUFJMmIsZUFBZSxHQUFHRCxXQUFXLEdBQUd4RSxJQUFJLENBQUNzRSxPQUF6Qzs7QUFDQSxNQUFJRyxlQUFlLEdBQUcsT0FBSyxFQUEzQixFQUErQjtBQUM3QixXQUFPLElBQVA7QUFDRDs7QUFFRCxTQUFPLEtBQUtKLFlBQUwsQ0FBa0JyRSxJQUFsQixJQUEwQixHQUFqQztBQUNELENBYkQ7O0FBZ0JBNkQsY0FBYyxHQUFHLFVBQVVQLFNBQVYsRUFBcUI7QUFDcEMsT0FBS0EsU0FBTCxHQUFpQkEsU0FBakI7QUFDQSxPQUFLZ0IsT0FBTCxHQUFlLENBQWY7QUFDQSxPQUFLaFcsTUFBTCxHQUFjLEVBQWQ7QUFDRCxDQUpEOztBQU1BdVYsY0FBYyxDQUFDMW1CLFNBQWYsQ0FBeUJnbkIsT0FBekIsR0FBbUMsVUFBVXRqQixLQUFWLEVBQWlCO0FBQ2xELE9BQUt5TixNQUFMLENBQVloUixJQUFaLENBQWlCdUQsS0FBakI7QUFDQSxPQUFLeWpCLE9BQUwsR0FBZXpkLElBQUksQ0FBQ2lDLEdBQUwsRUFBZjs7QUFFQSxNQUFJLEtBQUt3RixNQUFMLENBQVl0VCxNQUFaLEdBQXFCLEtBQUtzb0IsU0FBOUIsRUFBeUM7QUFDdkMsU0FBS2hWLE1BQUwsQ0FBWW9XLEtBQVo7QUFDRDtBQUNGLENBUEQ7O0FBU0FiLGNBQWMsQ0FBQzFtQixTQUFmLENBQXlCaW5CLFFBQXpCLEdBQW9DLFlBQVk7QUFDOUMsV0FBU08sVUFBVCxDQUFvQnZTLENBQXBCLEVBQXVCbVEsQ0FBdkIsRUFBMEI7QUFDeEIsV0FBT25RLENBQUMsR0FBR21RLENBQVg7QUFDRDs7QUFDRCxNQUFJcUMsTUFBTSxHQUFHLEtBQUt0VyxNQUFMLENBQVlzTSxJQUFaLENBQWlCK0osVUFBakIsQ0FBYjtBQUNBLE1BQUkzQyxNQUFNLEdBQUcsQ0FBYjs7QUFFQSxNQUFJNEMsTUFBTSxDQUFDNXBCLE1BQVAsR0FBZ0IsQ0FBaEIsS0FBc0IsQ0FBMUIsRUFBNkI7QUFDM0IsUUFBSTZwQixHQUFHLEdBQUdELE1BQU0sQ0FBQzVwQixNQUFQLEdBQWdCLENBQTFCO0FBQ0FnbkIsVUFBTSxHQUFHLENBQUM0QyxNQUFNLENBQUNDLEdBQUQsQ0FBTixHQUFjRCxNQUFNLENBQUNDLEdBQUcsR0FBQyxDQUFMLENBQXJCLElBQWdDLENBQXpDO0FBQ0QsR0FIRCxNQUdPO0FBQ0wsUUFBSUEsR0FBRyxHQUFHNVQsSUFBSSxDQUFDNlQsS0FBTCxDQUFXRixNQUFNLENBQUM1cEIsTUFBUCxHQUFnQixDQUEzQixDQUFWO0FBQ0FnbkIsVUFBTSxHQUFHNEMsTUFBTSxDQUFDQyxHQUFELENBQWY7QUFDRDs7QUFFRCxTQUFPN0MsTUFBUDtBQUNELENBaEJELEM7Ozs7Ozs7Ozs7O0FDcEdBLElBQUk5UyxTQUFKO0FBQWM5SCxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNHLFNBQU8sQ0FBQ0YsQ0FBRCxFQUFHO0FBQUM0SCxhQUFTLEdBQUM1SCxDQUFWO0FBQVk7O0FBQXhCLENBQTVCLEVBQXNELENBQXREO0FBQXlELElBQUl5ZCxVQUFKO0FBQWUzZCxNQUFNLENBQUNDLElBQVAsQ0FBWSw0QkFBWixFQUF5QztBQUFDRyxTQUFPLENBQUNGLENBQUQsRUFBRztBQUFDeWQsY0FBVSxHQUFDemQsQ0FBWDtBQUFhOztBQUF6QixDQUF6QyxFQUFvRSxDQUFwRTs7QUFHdEYsSUFBSTBkLFFBQVEsR0FBR3RyQixHQUFHLENBQUNDLE9BQUosQ0FBWSxJQUFaLEVBQWtCcXJCLFFBQWxCLEVBQWY7O0FBQ0EsSUFBSWpqQixNQUFNLEdBQUdySSxHQUFHLENBQUNDLE9BQUosQ0FBWSxPQUFaLEVBQXFCLFlBQXJCLENBQWI7O0FBQ0EsSUFBSXNyQixNQUFNLEdBQUd2ckIsR0FBRyxDQUFDQyxPQUFKLENBQVksUUFBWixDQUFiOztBQUVBLElBQUl1ckIsVUFBVSxHQUFHeHJCLEdBQUcsQ0FBQ0MsT0FBSixDQUFZLGdCQUFaLEVBQThCVCxNQUEvQzs7QUFFQUEsTUFBTSxDQUFDaXNCLE1BQVAsR0FBZ0IsRUFBaEI7QUFDQWpzQixNQUFNLENBQUNDLE9BQVAsR0FBaUIsRUFBakI7QUFDQUQsTUFBTSxDQUFDbWhCLEdBQVAsR0FBYTtBQUNYK0ssWUFBVSxFQUFFLElBREQ7QUFDTztBQUNsQkMsWUFBVSxFQUFFLElBQUloc0IsTUFBTSxDQUFDaXNCLG1CQUFYO0FBRkQsQ0FBYjtBQUlBcHNCLE1BQU0sQ0FBQ3FzQixlQUFQLEdBQXlCLElBQUkvTixlQUFKLEVBQXpCO0FBQ0F0ZSxNQUFNLENBQUN5RyxNQUFQLEdBQWdCLEVBQWhCO0FBQ0F6RyxNQUFNLENBQUN5RyxNQUFQLENBQWN2QyxTQUFkLEdBQTBCbEUsTUFBTSxDQUFDeUcsTUFBUCxDQUFjckMsSUFBZCxDQUFtQmtiLElBQW5CLENBQXdCdGYsTUFBTSxDQUFDeUcsTUFBL0IsQ0FBMUI7QUFFQXpHLE1BQU0sQ0FBQ2lzQixNQUFQLENBQWMxbEIsT0FBZCxHQUF3QixJQUFJbEIsWUFBSixFQUF4QjtBQUNBckYsTUFBTSxDQUFDaXNCLE1BQVAsQ0FBY0ssTUFBZCxHQUF1QixJQUFJeGpCLFdBQUosRUFBdkI7QUFDQTlJLE1BQU0sQ0FBQ2lzQixNQUFQLENBQWNuWSxNQUFkLEdBQXVCLElBQUlsRixXQUFKLEVBQXZCO0FBQ0E1TyxNQUFNLENBQUNpc0IsTUFBUCxDQUFjTSxJQUFkLEdBQXFCLElBQUl2VyxTQUFKLEVBQXJCO0FBQ0FoVyxNQUFNLENBQUNpVSxVQUFQLEdBQW9CLElBQUlpVyxVQUFKLENBQWUsTUFBZixFQUF1QixFQUF2QixDQUFwQjtBQUNBbHFCLE1BQU0sQ0FBQ3lJLFVBQVAsR0FBb0IsSUFBSVAsR0FBSixFQUFwQixDLENBRUE7QUFDQTtBQUNBOztBQUNBLElBQUlza0IsYUFBYSxHQUFHcnNCLE1BQU0sQ0FBQ3dQLFdBQVAsQ0FBbUIsTUFBTTtBQUMzQzNQLFFBQU0sQ0FBQ3lzQixhQUFQO0FBQ0QsQ0FGbUIsRUFFakIsT0FBTyxFQUZVLENBQXBCOztBQUtBenNCLE1BQU0sQ0FBQzBzQixPQUFQLEdBQWlCLFVBQVMxWCxLQUFULEVBQWdCMlgsU0FBaEIsRUFBMkIxc0IsT0FBM0IsRUFBb0M7QUFDbkRBLFNBQU8sR0FBR0EsT0FBTyxJQUFJLEVBQXJCO0FBQ0FBLFNBQU8sQ0FBQytVLEtBQVIsR0FBZ0JBLEtBQWhCO0FBQ0EvVSxTQUFPLENBQUMwc0IsU0FBUixHQUFvQkEsU0FBcEI7QUFDQTFzQixTQUFPLENBQUMyc0IsY0FBUixHQUF5QjNzQixPQUFPLENBQUMyc0IsY0FBUixJQUEwQixPQUFPLEVBQTFEO0FBQ0Ezc0IsU0FBTyxDQUFDc0MsUUFBUixHQUFtQnRDLE9BQU8sQ0FBQ3NDLFFBQVIsSUFBb0IsNkJBQXZDO0FBQ0F0QyxTQUFPLENBQUM0c0IscUJBQVIsR0FBZ0M1c0IsT0FBTyxDQUFDNHNCLHFCQUFSLElBQWlDLEtBQWpFO0FBQ0E1c0IsU0FBTyxDQUFDNnNCLFVBQVIsR0FBcUI3c0IsT0FBTyxDQUFDNnNCLFVBQVIsSUFBc0IsRUFBM0M7QUFDQTdzQixTQUFPLENBQUM4c0IsYUFBUixHQUF3QixDQUFDLENBQUM5c0IsT0FBTyxDQUFDNnJCLFFBQWxDO0FBQ0E3ckIsU0FBTyxDQUFDNnJCLFFBQVIsR0FBbUI3ckIsT0FBTyxDQUFDNnJCLFFBQVIsSUFBb0JBLFFBQXZDO0FBQ0E3ckIsU0FBTyxDQUFDK3NCLEtBQVIsR0FBZ0Ivc0IsT0FBTyxDQUFDK3NCLEtBQVIsSUFBaUIsSUFBakM7QUFDQS9zQixTQUFPLENBQUNndEIsZUFBUixHQUEwQmh0QixPQUFPLENBQUNndEIsZUFBUixJQUEyQixNQUFyRDtBQUNBaHRCLFNBQU8sQ0FBQ3FrQixlQUFSLEdBQTBCcmtCLE9BQU8sQ0FBQ3FrQixlQUFSLElBQTJCLEtBQXJEOztBQUVBLE1BQUdya0IsT0FBTyxDQUFDaXRCLHFCQUFYLEVBQWtDO0FBQ2hDbHRCLFVBQU0sQ0FBQ2lVLFVBQVAsR0FBb0IsSUFBSWlXLFVBQUosQ0FBZWpxQixPQUFPLENBQUNpdEIscUJBQXZCLEVBQThDLEVBQTlDLENBQXBCO0FBQ0QsR0FoQmtELENBa0JuRDs7O0FBQ0EsTUFBR3RuQixDQUFDLENBQUN1bkIsSUFBRixDQUFPbHRCLE9BQU8sQ0FBQ3NDLFFBQWYsTUFBNkIsR0FBaEMsRUFBcUM7QUFDbkN0QyxXQUFPLENBQUNzQyxRQUFSLEdBQW1CdEMsT0FBTyxDQUFDc0MsUUFBUixDQUFpQkQsTUFBakIsQ0FBd0IsQ0FBeEIsRUFBMkJyQyxPQUFPLENBQUNzQyxRQUFSLENBQWlCVCxNQUFqQixHQUEwQixDQUFyRCxDQUFuQjtBQUNELEdBckJrRCxDQXVCbkQ7OztBQUNBLE1BQUc3QixPQUFPLENBQUNtdEIsbUJBQVIsS0FBZ0M5SCxTQUFuQyxFQUE4QztBQUM1Q3JsQixXQUFPLENBQUNtdEIsbUJBQVIsR0FBOEIsSUFBOUI7QUFDRCxHQTFCa0QsQ0E0Qm5EOzs7QUFDQSxNQUFJbnRCLE9BQU8sQ0FBQ21jLGdCQUFSLEtBQTZCa0osU0FBN0IsSUFBMENubEIsTUFBTSxDQUFDa3RCLFlBQXJELEVBQW1FO0FBQ2pFcHRCLFdBQU8sQ0FBQ21jLGdCQUFSLEdBQTJCLElBQTNCO0FBQ0Q7O0FBRURwYyxRQUFNLENBQUNDLE9BQVAsR0FBaUJBLE9BQWpCO0FBQ0FELFFBQU0sQ0FBQ0MsT0FBUCxDQUFlcXRCLFdBQWYsR0FBNkI7QUFDM0IscUJBQWlCdHRCLE1BQU0sQ0FBQ0MsT0FBUCxDQUFlK1UsS0FETDtBQUUzQix5QkFBcUJoVixNQUFNLENBQUNDLE9BQVAsQ0FBZTBzQjtBQUZULEdBQTdCOztBQUtBLE1BQUkzWCxLQUFLLElBQUkyWCxTQUFiLEVBQXdCO0FBQ3RCMXNCLFdBQU8sQ0FBQytVLEtBQVIsR0FBZ0IvVSxPQUFPLENBQUMrVSxLQUFSLENBQWN1WSxJQUFkLEVBQWhCO0FBQ0F0dEIsV0FBTyxDQUFDMHNCLFNBQVIsR0FBb0Ixc0IsT0FBTyxDQUFDMHNCLFNBQVIsQ0FBa0JZLElBQWxCLEVBQXBCO0FBRUF2dEIsVUFBTSxDQUFDOFcsT0FBUCxHQUFpQixJQUFJa1YsVUFBSixDQUFlO0FBQzlCaFgsV0FBSyxFQUFFL1UsT0FBTyxDQUFDK1UsS0FEZTtBQUU5QjJYLGVBQVMsRUFBRTFzQixPQUFPLENBQUMwc0IsU0FGVztBQUc5QnBxQixjQUFRLEVBQUV0QyxPQUFPLENBQUNzQyxRQUhZO0FBSTlCdXBCLGNBQVEsRUFBRTdyQixPQUFPLENBQUM2ckIsUUFKWTtBQUs5QjBCLGtCQUFZLEVBQUUzQixVQUFVLENBQUMsZ0JBQUQsQ0FBVixJQUFnQztBQUxoQixLQUFmLENBQWpCOztBQVFBN3JCLFVBQU0sQ0FBQzhXLE9BQVAsQ0FBZTJXLFVBQWYsR0FDR3pXLElBREgsQ0FDUSxZQUFZO0FBQ2hCbk8sWUFBTSxDQUFDLG9CQUFELEVBQXVCbU0sS0FBdkIsQ0FBTjtBQUNBN1IsYUFBTyxDQUFDNFgsR0FBUixDQUFZLG1DQUFaOztBQUNBL2EsWUFBTSxDQUFDMHRCLGFBQVA7O0FBQ0ExdEIsWUFBTSxDQUFDMnRCLG9CQUFQO0FBQ0QsS0FOSCxFQU9HMVcsS0FQSCxDQU9TLFVBQVV2VixHQUFWLEVBQWU7QUFDcEIsVUFBSUEsR0FBRyxDQUFDRCxPQUFKLEtBQWdCLGNBQXBCLEVBQW9DO0FBQ2xDMEIsZUFBTyxDQUFDNFgsR0FBUixDQUFZLGlFQUFaO0FBQ0QsT0FGRCxNQUVPO0FBQ0w1WCxlQUFPLENBQUM0WCxHQUFSLENBQVksbUNBQW1DclosR0FBRyxDQUFDRCxPQUFuRDtBQUNEO0FBQ0YsS0FiSDtBQWNELEdBMUJELE1BMEJPO0FBQ0wsVUFBTSxJQUFJRSxLQUFKLENBQVUseUNBQVYsQ0FBTjtBQUNEOztBQUVEM0IsUUFBTSxDQUFDeUksVUFBUCxHQUFvQixJQUFJUCxHQUFKLENBQVFqSSxPQUFPLENBQUNzQyxRQUFoQixDQUFwQjtBQUNBdkMsUUFBTSxDQUFDeUksVUFBUCxDQUFrQnVSLElBQWxCO0FBQ0FoYSxRQUFNLENBQUNpc0IsTUFBUCxDQUFjdm5CLEtBQWQsR0FBc0IsSUFBSXFRLFVBQUosQ0FBZUMsS0FBZixDQUF0QixDQXZFbUQsQ0F5RW5EOztBQUNBLE1BQUk0WSxXQUFXLEdBQUc1dEIsTUFBTSxDQUFDaXNCLE1BQVAsQ0FBY3ZuQixLQUFkLENBQW9CUixTQUFwQixDQUE4Qm9iLElBQTlCLENBQW1DdGYsTUFBTSxDQUFDaXNCLE1BQVAsQ0FBY3ZuQixLQUFqRCxDQUFsQjtBQUNBMUUsUUFBTSxDQUFDeUcsTUFBUCxDQUFjdkYsT0FBZCxDQUFzQjBzQixXQUF0QjtBQUNBNXRCLFFBQU0sQ0FBQ3lHLE1BQVAsR0FBZ0J6RyxNQUFNLENBQUNpc0IsTUFBUCxDQUFjdm5CLEtBQTlCLENBNUVtRCxDQThFbkQ7O0FBQ0EvRSwyQkFBeUIsQ0FBQ2t1QixNQUExQixHQUFtQztBQUNqQzdZLFNBQUssRUFBRUEsS0FEMEI7QUFFakN6UyxZQUFRLEVBQUV0QyxPQUFPLENBQUNzQyxRQUZlO0FBR2pDc3FCLHlCQUFxQixFQUFFNXNCLE9BQU8sQ0FBQzRzQixxQkFIRTtBQUlqQ0ksbUJBQWUsRUFBRWh0QixPQUFPLENBQUNndEI7QUFKUSxHQUFuQzs7QUFPQSxNQUFHaHRCLE9BQU8sQ0FBQ210QixtQkFBWCxFQUFnQztBQUM5QnB0QixVQUFNLENBQUNvdEIsbUJBQVA7QUFDRCxHQUZELE1BRU87QUFDTHB0QixVQUFNLENBQUM4dEIsb0JBQVA7QUFDRCxHQTFGa0QsQ0E0Rm5EOzs7QUFDQTN0QixRQUFNLENBQUM0dEIsT0FBUCxDQUFlLFlBQVk7QUFDekJDLDJCQUF1QjtBQUN2QkMsNEJBQXdCO0FBQ3hCQyxvQkFBZ0I7QUFDakIsR0FKRDtBQU1BL3RCLFFBQU0sQ0FBQ2d1QixPQUFQLENBQWUsSUFBZixFQUFxQixZQUFZO0FBQy9CLFFBQUlsdUIsT0FBTyxHQUFHTix5QkFBeUIsQ0FBQ2t1QixNQUF4QztBQUNBLFNBQUtPLEtBQUwsQ0FBVyxpQkFBWCxFQUE4QmxXLE1BQU0sQ0FBQ3pRLEVBQVAsRUFBOUIsRUFBMkN4SCxPQUEzQztBQUNBLFNBQUtvdUIsS0FBTDtBQUNELEdBSkQsRUFuR21ELENBeUduRDs7QUFDQXJ1QixRQUFNLENBQUNxQyxTQUFQLEdBQW1CLElBQW5CO0FBQ0QsQ0EzR0QsQyxDQTZHQTs7O0FBQ0FyQyxNQUFNLENBQUN5c0IsYUFBUCxHQUF1QixZQUFZO0FBQ2pDLE1BQUl2cUIsT0FBTyxHQUFHO0FBQUMwUyxRQUFJLEVBQUU1VSxNQUFNLENBQUNDLE9BQVAsQ0FBZTZyQixRQUF0QjtBQUFnQ3dDLGtCQUFjLEVBQUVuVixpQkFBaUI7QUFBakUsR0FBZDs7QUFDQSxNQUFJN1EsaUJBQWlCLEdBQUd0SSxNQUFNLENBQUN1dUIsZUFBUCxFQUF4Qjs7QUFDQTNvQixHQUFDLENBQUNDLE1BQUYsQ0FBUzNELE9BQVQsRUFBa0JsQyxNQUFNLENBQUNpc0IsTUFBUCxDQUFjMWxCLE9BQWQsQ0FBc0I4QixZQUF0QixDQUFtQ0MsaUJBQW5DLENBQWxCOztBQUNBMUMsR0FBQyxDQUFDQyxNQUFGLENBQVMzRCxPQUFULEVBQWtCbEMsTUFBTSxDQUFDaXNCLE1BQVAsQ0FBY0ssTUFBZCxDQUFxQmprQixZQUFyQixDQUFrQ0MsaUJBQWxDLENBQWxCOztBQUNBMUMsR0FBQyxDQUFDQyxNQUFGLENBQVMzRCxPQUFULEVBQWtCbEMsTUFBTSxDQUFDaXNCLE1BQVAsQ0FBY25ZLE1BQWQsQ0FBcUJ6TCxZQUFyQixFQUFsQjs7QUFDQXpDLEdBQUMsQ0FBQ0MsTUFBRixDQUFTM0QsT0FBVCxFQUFrQmxDLE1BQU0sQ0FBQ2lzQixNQUFQLENBQWNNLElBQWQsQ0FBbUJsa0IsWUFBbkIsRUFBbEI7O0FBRUEsTUFBR3JJLE1BQU0sQ0FBQ0MsT0FBUCxDQUFlbXRCLG1CQUFsQixFQUF1QztBQUNyQ3huQixLQUFDLENBQUNDLE1BQUYsQ0FBUzNELE9BQVQsRUFBa0JsQyxNQUFNLENBQUNpc0IsTUFBUCxDQUFjdm5CLEtBQWQsQ0FBb0IyRCxZQUFwQixFQUFsQjtBQUNEOztBQUVELFNBQU9uRyxPQUFQO0FBQ0QsQ0FiRDs7QUFlQWxDLE1BQU0sQ0FBQ3d1QixjQUFQLEdBQXdCLENBQXhCO0FBQ0F4dUIsTUFBTSxDQUFDeXVCLHVCQUFQLEdBQWlDMVcsSUFBSSxDQUFDSyxJQUFMLENBQVcsT0FBSyxFQUFOLEdBQVlwWSxNQUFNLENBQUNDLE9BQVAsQ0FBZTJzQixjQUFyQyxDQUFqQzs7QUFDQTVzQixNQUFNLENBQUN1dUIsZUFBUCxHQUF5QixZQUFZO0FBQ25DLFNBQVF2dUIsTUFBTSxDQUFDd3VCLGNBQVAsS0FBMEJ4dUIsTUFBTSxDQUFDeXVCLHVCQUFsQyxJQUE4RCxDQUFyRTtBQUNELENBRkQ7O0FBSUF6dUIsTUFBTSxDQUFDMHRCLGFBQVAsR0FBdUIsWUFBWTtBQUNqQyxNQUFJZ0IsUUFBUSxHQUFHLEVBQWY7QUFDQUEsVUFBUSxDQUFDak0sT0FBVCxHQUFtQnRpQixNQUFNLENBQUNzaUIsT0FBMUI7QUFDQWlNLFVBQVEsQ0FBQ0MsZUFBVCxHQUEyQixPQUEzQjtBQUNBRCxVQUFRLENBQUNFLGVBQVQsR0FBMkIsRUFBM0I7QUFDQUYsVUFBUSxDQUFDSixjQUFULEdBQTBCblYsaUJBQWlCLEVBQTNDOztBQUVBdlQsR0FBQyxDQUFDeUcsSUFBRixDQUFPd2lCLE9BQVAsRUFBZ0IsVUFBVXpnQixDQUFWLEVBQWE3RyxJQUFiLEVBQW1CO0FBQ2pDbW5CLFlBQVEsQ0FBQ0UsZUFBVCxDQUF5QnhxQixJQUF6QixDQUE4QjtBQUM1Qm1ELFVBQUksRUFBRUEsSUFEc0I7QUFFNUIxSCxhQUFPLEVBQUVnc0IsVUFBVSxDQUFDdGtCLElBQUQsQ0FBVixJQUFvQjtBQUZELEtBQTlCO0FBSUQsR0FMRDs7QUFPQXZILFFBQU0sQ0FBQzhXLE9BQVAsQ0FBZTZGLFFBQWYsQ0FBd0I7QUFDdEIxVixhQUFTLEVBQUUsSUFBSTBHLElBQUosRUFEVztBQUV0QitnQixZQUFRLEVBQUVBO0FBRlksR0FBeEIsRUFHRzFYLElBSEgsQ0FHUSxVQUFTNkUsSUFBVCxFQUFlO0FBQ3JCRCxxQkFBaUIsQ0FBQ0MsSUFBRCxDQUFqQjtBQUNELEdBTEQsRUFLRzVFLEtBTEgsQ0FLUyxVQUFTdlYsR0FBVCxFQUFjO0FBQ3JCeUIsV0FBTyxDQUFDdUIsS0FBUixDQUFjLHNDQUFkLEVBQXNEaEQsR0FBRyxDQUFDRCxPQUExRDtBQUNELEdBUEQ7QUFRRCxDQXRCRDs7QUF3QkF6QixNQUFNLENBQUMydEIsb0JBQVAsR0FBOEIsWUFBWTtBQUN4QzFGLGVBQWEsQ0FBQ3VFLGFBQUQsQ0FBYjtBQUVBbFUsWUFBVSxDQUFDLFlBQVk7QUFDckJ0WSxVQUFNLENBQUMydEIsb0JBQVA7O0FBQ0EzdEIsVUFBTSxDQUFDOHVCLFlBQVA7QUFDRCxHQUhTLEVBR1A5dUIsTUFBTSxDQUFDQyxPQUFQLENBQWUyc0IsY0FIUixDQUFWO0FBSUQsQ0FQRDs7QUFTQTVzQixNQUFNLENBQUM4dUIsWUFBUCxHQUFzQixZQUFZO0FBQ2hDLE1BQUkvQyxNQUFKLENBQVcsWUFBVztBQUNwQixRQUFJN3BCLE9BQU8sR0FBR2xDLE1BQU0sQ0FBQ3lzQixhQUFQLEVBQWQ7O0FBQ0F6c0IsVUFBTSxDQUFDOFcsT0FBUCxDQUFlNkYsUUFBZixDQUF3QnphLE9BQXhCLEVBQ0M4VSxJQURELENBQ00sVUFBVTZFLElBQVYsRUFBZ0I7QUFDcEJELHVCQUFpQixDQUFDQyxJQUFELENBQWpCO0FBQ0QsS0FIRCxFQUlDNUUsS0FKRCxDQUlPLFVBQVN2VixHQUFULEVBQWM7QUFDbkJ5QixhQUFPLENBQUM0WCxHQUFSLENBQVksa0JBQVosRUFBZ0NyWixHQUFHLENBQUNELE9BQXBDO0FBQ0QsS0FORDtBQU9ELEdBVEQsRUFTR3N0QixHQVRIO0FBVUQsQ0FYRCxDLENBYUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQS91QixNQUFNLENBQUNndkIsUUFBUCxHQUFrQixVQUFTQyxZQUFULEVBQXVCQyxzQkFBdkIsRUFBK0M7QUFDL0RELGNBQVksR0FBR0EsWUFBWSxJQUFJbEQsTUFBTSxDQUFDb0QsT0FBdEM7O0FBQ0EsTUFBR0YsWUFBSCxFQUFpQjtBQUNmLFFBQUdDLHNCQUFILEVBQTJCO0FBQ3pCLGFBQU9sdkIsTUFBTSxDQUFDbWhCLEdBQVAsQ0FBV2dMLFVBQVgsQ0FBc0I3VSxHQUF0QixFQUFQO0FBQ0Q7O0FBQ0QsV0FBTzJYLFlBQVksQ0FBQ0csWUFBcEI7QUFDRDtBQUNGLENBUkQsQyxDQVVBOzs7QUFDQXB2QixNQUFNLENBQUNxdkIsUUFBUCxHQUFrQixVQUFTNWhCLElBQVQsRUFBZTtBQUMvQnNlLFFBQU0sQ0FBQ29ELE9BQVAsQ0FBZUMsWUFBZixHQUE4QjNoQixJQUE5QjtBQUNELENBRkQ7O0FBSUF6TixNQUFNLENBQUNzdkIsd0JBQVAsR0FBa0MsWUFBWTtBQUM1Q0MsZUFBYSxDQUFDQyxlQUFkLENBQThCLFNBQVNDLFNBQVQsT0FBb0Q7QUFBQSxRQUFqQztBQUFFQyxhQUFGO0FBQVd6b0IsZUFBWDtBQUFzQmM7QUFBdEIsS0FBaUM7O0FBQ2hGLFFBQUksQ0FBQy9ILE1BQU0sQ0FBQ3FDLFNBQVosRUFBdUI7QUFDckI7QUFDRDs7QUFFRHJDLFVBQU0sQ0FBQzhXLE9BQVAsQ0FBZTZGLFFBQWYsQ0FBd0I7QUFBRWdULGNBQVEsRUFBRSxDQUFDO0FBQUNELGVBQUQ7QUFBVXpvQixpQkFBVjtBQUFxQmM7QUFBckIsT0FBRDtBQUFaLEtBQXhCLEVBQ0drUCxLQURILENBQ1MrRSxDQUFDLElBQUk3WSxPQUFPLENBQUM0WCxHQUFSLENBQVksZ0NBQVosRUFBOENpQixDQUE5QyxDQURkO0FBRUQsR0FQRDtBQVFELENBVEQ7O0FBV0FoYyxNQUFNLENBQUNvdEIsbUJBQVAsR0FBNkIsWUFBWTtBQUN2Q3p0QiwyQkFBeUIsQ0FBQ2t1QixNQUExQixDQUFpQ1QsbUJBQWpDLEdBQXVELElBQXZEO0FBQ0FwdEIsUUFBTSxDQUFDQyxPQUFQLENBQWVtdEIsbUJBQWYsR0FBcUMsSUFBckM7QUFDRCxDQUhEOztBQUtBcHRCLE1BQU0sQ0FBQzh0QixvQkFBUCxHQUE4QixZQUFZO0FBQ3hDbnVCLDJCQUF5QixDQUFDa3VCLE1BQTFCLENBQWlDVCxtQkFBakMsR0FBdUQsS0FBdkQ7QUFDQXB0QixRQUFNLENBQUNDLE9BQVAsQ0FBZW10QixtQkFBZixHQUFxQyxLQUFyQztBQUNELENBSEQ7O0FBS0FwdEIsTUFBTSxDQUFDdVYsVUFBUCxHQUFvQixVQUFVL1QsSUFBVixFQUFnQkMsT0FBaEIsRUFBeUJ4QixPQUF6QixFQUFrQztBQUNwRCxNQUFHRCxNQUFNLENBQUNDLE9BQVAsQ0FBZW10QixtQkFBZixJQUFzQzVyQixJQUF0QyxJQUE4Q0MsT0FBakQsRUFBMEQ7QUFDeER4QixXQUFPLEdBQUdBLE9BQU8sSUFBSSxFQUFyQjtBQUNBQSxXQUFPLENBQUMwRSxPQUFSLEdBQWtCMUUsT0FBTyxDQUFDMEUsT0FBUixJQUFtQixRQUFyQztBQUNBMUUsV0FBTyxDQUFDOFYsTUFBUixHQUFpQjlWLE9BQU8sQ0FBQzhWLE1BQVIsSUFBa0IsRUFBbkM7QUFDQSxRQUFJclIsS0FBSyxHQUFHO0FBQUNqRCxhQUFPLEVBQUVBLE9BQVY7QUFBbUJpVSxXQUFLLEVBQUV6VixPQUFPLENBQUM4VjtBQUFsQyxLQUFaO0FBQ0EsUUFBSTlMLEtBQUssR0FBRztBQUNWekksVUFBSSxFQUFFQSxJQURJO0FBRVZtRCxhQUFPLEVBQUUxRSxPQUFPLENBQUMwRSxPQUZQO0FBR1Y0QyxVQUFJLEVBQUU5RixPQUhJO0FBSVY2RixhQUFPLEVBQUUsSUFKQztBQUtWRixRQUFFLEVBQUVwSCxNQUFNLENBQUN5SSxVQUFQLENBQWtCbUYsT0FBbEIsRUFMTTtBQU1WaUksWUFBTSxFQUFFLENBQUMsQ0FBQyxPQUFELEVBQVUsQ0FBVixFQUFhLEVBQWIsQ0FBRCxFQUFtQixDQUFDLE9BQUQsRUFBVSxDQUFWLEVBQWE7QUFBQ25SLGFBQUssRUFBRUE7QUFBUixPQUFiLENBQW5CLENBTkU7QUFPVmtELGFBQU8sRUFBRTtBQUFDRSxhQUFLLEVBQUU7QUFBUjtBQVBDLEtBQVo7QUFTQTlILFVBQU0sQ0FBQ2lzQixNQUFQLENBQWN2bkIsS0FBZCxDQUFvQjZRLFVBQXBCLENBQStCN1EsS0FBL0IsRUFBc0N1RixLQUF0QztBQUNEO0FBQ0YsQ0FqQkQ7O0FBbUJBakssTUFBTSxDQUFDNHZCLG1CQUFQLEdBQTZCLFVBQVVsdUIsR0FBVixFQUFlO0FBQzFDQSxLQUFHLENBQUNtdUIsV0FBSixHQUFrQixJQUFsQjtBQUNELENBRkQ7O0FBSUE3dkIsTUFBTSxDQUFDOHZCLFVBQVAsR0FBb0IsVUFBVXZvQixJQUFWLEVBQTJCO0FBQUEsTUFBWGhFLElBQVcsdUVBQUosRUFBSTs7QUFDN0MsTUFBSTRvQixVQUFVLEdBQUduc0IsTUFBTSxDQUFDZ3ZCLFFBQVAsRUFBakI7O0FBQ0EsTUFBRzdDLFVBQUgsRUFBZTtBQUNiLFdBQU9uc0IsTUFBTSxDQUFDeW1CLE1BQVAsQ0FBYzNDLEtBQWQsQ0FBb0JxSSxVQUFVLENBQUNsaUIsS0FBL0IsRUFBc0MsUUFBdEMsRUFBZ0QxRyxJQUFoRCxFQUFzRDtBQUFFZ0U7QUFBRixLQUF0RCxDQUFQO0FBQ0Q7O0FBRUQsU0FBTyxLQUFQO0FBQ0QsQ0FQRDs7QUFTQXZILE1BQU0sQ0FBQyt2QixRQUFQLEdBQWtCLFVBQVVqTSxLQUFWLEVBQWlCdmdCLElBQWpCLEVBQXVCO0FBQ3ZDLE1BQUk0b0IsVUFBVSxHQUFHbnNCLE1BQU0sQ0FBQ2d2QixRQUFQLEVBQWpCLENBRHVDLENBR3ZDO0FBQ0E7OztBQUNBLE1BQUk3QyxVQUFVLElBQUlySSxLQUFsQixFQUF5QjtBQUN2QjlqQixVQUFNLENBQUN5bUIsTUFBUCxDQUFjL0IsUUFBZCxDQUF1QnlILFVBQVUsQ0FBQ2xpQixLQUFsQyxFQUF5QzZaLEtBQXpDLEVBQWdEdmdCLElBQWhEO0FBQ0Q7QUFDRixDQVJELEM7Ozs7Ozs7Ozs7O0FDN1JBLElBQUl5c0IsS0FBSyxHQUFHeHZCLEdBQUcsQ0FBQ0MsT0FBSixDQUFZLFFBQVosQ0FBWjs7QUFFQXd2QixVQUFVLEdBQUcsVUFBU0MsV0FBVCxFQUFzQjtBQUNqQyxNQUFJQyxxQkFBcUIsR0FBR0QsV0FBVyxDQUFDRSxjQUF4Qzs7QUFDQUYsYUFBVyxDQUFDRSxjQUFaLEdBQTZCLFVBQVM1YixNQUFULEVBQWlCdEwsR0FBakIsRUFBc0I7QUFDakRpbkIseUJBQXFCLENBQUNsYixJQUF0QixDQUEyQixJQUEzQixFQUFpQ1QsTUFBakMsRUFBeUN0TCxHQUF6QztBQUNBLFFBQUlELE9BQU8sR0FBR3VMLE1BQU0sQ0FBQzZiLGNBQXJCLENBRmlELENBR2pEO0FBQ0E7QUFDQTs7QUFDQSxRQUFHLENBQUNwbkIsT0FBSixFQUFhO0FBQ1g7QUFDRDs7QUFFRGpKLFVBQU0sQ0FBQ2lCLFFBQVAsQ0FBZ0JxdkIsSUFBaEIsQ0FBcUIsUUFBckIsRUFBK0IsZUFBL0IsRUFBZ0RwbkIsR0FBaEQsRUFBcURzTCxNQUFNLENBQUM2YixjQUE1RDs7QUFFQSxRQUFHcndCLE1BQU0sQ0FBQ3FDLFNBQVYsRUFBcUI7QUFDbkJyQyxZQUFNLENBQUNpc0IsTUFBUCxDQUFjblksTUFBZCxDQUFxQksscUJBQXJCLENBQTJDakwsR0FBM0MsRUFBZ0RzTCxNQUFNLENBQUM2YixjQUF2RDtBQUNEO0FBQ0YsR0FmRDtBQWdCRCxDQWxCRCxDOzs7Ozs7Ozs7OztBQ0ZBLElBQUlFLGlCQUFKO0FBQXNCcmlCLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFNBQVosRUFBc0I7QUFBQ29pQixtQkFBaUIsQ0FBQ25pQixDQUFELEVBQUc7QUFBQ21pQixxQkFBaUIsR0FBQ25pQixDQUFsQjtBQUFvQjs7QUFBMUMsQ0FBdEIsRUFBa0UsQ0FBbEU7QUFFdEIsTUFBTW9pQixpQkFBaUIsR0FBRyxJQUExQjs7QUFFQUMsV0FBVyxHQUFHLFVBQVNDLFlBQVQsRUFBdUI7QUFDbkMsTUFBSUMsc0JBQXNCLEdBQUdELFlBQVksQ0FBQ0UsY0FBMUM7O0FBQ0FGLGNBQVksQ0FBQ0UsY0FBYixHQUE4QixVQUFTMW5CLEdBQVQsRUFBYztBQUMxQyxRQUFHLElBQUgsRUFBUztBQUNQLFVBQUlpakIsVUFBVSxHQUFHO0FBQ2ZsakIsZUFBTyxFQUFFLEtBQUt4QixFQURDO0FBRWZrYyxjQUFNLEVBQUUsS0FBS0E7QUFGRSxPQUFqQjs7QUFLQSxVQUFHemEsR0FBRyxDQUFDQSxHQUFKLElBQVcsUUFBWCxJQUF1QkEsR0FBRyxDQUFDQSxHQUFKLElBQVcsS0FBckMsRUFBNEM7QUFDMUNpakIsa0JBQVUsQ0FBQ2xpQixLQUFYLEdBQW1CakssTUFBTSxDQUFDeW1CLE1BQVAsQ0FBY3JnQixLQUFkLENBQW9CLElBQXBCLEVBQTBCOEMsR0FBMUIsQ0FBbkI7QUFDQWxKLGNBQU0sQ0FBQ3FzQixlQUFQLENBQXVCM04sUUFBdkIsQ0FBZ0MsSUFBaEMsRUFBc0N4VixHQUFHLENBQUN6QixFQUExQzs7QUFFQSxZQUFJMEIsTUFBTSxHQUFHbkosTUFBTSxDQUFDeW1CLE1BQVAsQ0FBY04sbUJBQWQsQ0FBa0NqZCxHQUFHLENBQUNDLE1BQUosSUFBYyxFQUFoRCxDQUFiLENBSjBDLENBSzFDOzs7QUFDQSxZQUFJMG5CLGlCQUFpQixHQUFHaHRCLElBQUksQ0FBQ0MsU0FBTCxDQUFlcUYsTUFBZixDQUF4QixDQU4wQyxDQVExQztBQUNBOztBQUNBLFlBQUkwbkIsaUJBQWlCLENBQUMvdUIsTUFBbEIsR0FBMkIwdUIsaUJBQS9CLEVBQWtEO0FBQ2hESywyQkFBaUIsa0RBQTJDTCxpQkFBM0MsMEJBQTRFSyxpQkFBaUIsQ0FBQzl2QixLQUFsQixDQUF3QixDQUF4QixFQUEyQnl2QixpQkFBM0IsQ0FBNUUsQ0FBakI7QUFDRDs7QUFFRCxZQUFJTSxTQUFTLEdBQUc7QUFBRW5OLGdCQUFNLEVBQUUsS0FBS0EsTUFBZjtBQUF1QnhhLGdCQUFNLEVBQUUwbkI7QUFBL0IsU0FBaEI7QUFDQTd3QixjQUFNLENBQUN5bUIsTUFBUCxDQUFjM0MsS0FBZCxDQUFvQnFJLFVBQVUsQ0FBQ2xpQixLQUEvQixFQUFzQyxPQUF0QyxFQUErQzZtQixTQUEvQztBQUNBLFlBQUlDLFdBQVcsR0FBRy93QixNQUFNLENBQUN5bUIsTUFBUCxDQUFjM0MsS0FBZCxDQUFvQnFJLFVBQVUsQ0FBQ2xpQixLQUEvQixFQUFzQyxNQUF0QyxFQUE4QyxFQUE5QyxFQUFrRGtpQixVQUFsRCxDQUFsQjtBQUNBampCLFdBQUcsQ0FBQzhuQixZQUFKLEdBQW1CRCxXQUFuQjtBQUNBN25CLFdBQUcsQ0FBQ2ttQixZQUFKLEdBQW1CakQsVUFBbkI7O0FBRUEsWUFBR2pqQixHQUFHLENBQUNBLEdBQUosSUFBVyxLQUFkLEVBQXFCO0FBQ25CO0FBQ0E7QUFDQWxKLGdCQUFNLENBQUNpQixRQUFQLENBQWdCcXZCLElBQWhCLENBQXFCLFFBQXJCLEVBQStCLGFBQS9CLEVBQThDLElBQTlDLEVBQW9EcG5CLEdBQXBEOztBQUNBbEosZ0JBQU0sQ0FBQ2lzQixNQUFQLENBQWNLLE1BQWQsQ0FBcUJ0akIsU0FBckIsQ0FBK0IsSUFBL0IsRUFBcUNFLEdBQXJDO0FBQ0Q7QUFDRixPQWhDTSxDQWtDUDs7O0FBQ0FsSixZQUFNLENBQUNpQixRQUFQLENBQWdCcXZCLElBQWhCLENBQXFCLFFBQXJCLEVBQStCLG9CQUEvQixFQUFxRCxJQUFyRCxFQUEyRHBuQixHQUEzRDtBQUNBbEosWUFBTSxDQUFDaXNCLE1BQVAsQ0FBY25ZLE1BQWQsQ0FBcUJLLHFCQUFyQixDQUEyQ2pMLEdBQTNDLEVBQWdELElBQWhEO0FBQ0Q7O0FBRUQsV0FBT3luQixzQkFBc0IsQ0FBQzFiLElBQXZCLENBQTRCLElBQTVCLEVBQWtDL0wsR0FBbEMsQ0FBUDtBQUNELEdBekNELENBRm1DLENBNkNuQzs7O0FBQ0EsTUFBSStuQixxQkFBcUIsR0FBR1AsWUFBWSxDQUFDUSxpQkFBYixDQUErQjVxQixNQUEzRDs7QUFDQW9xQixjQUFZLENBQUNRLGlCQUFiLENBQStCNXFCLE1BQS9CLEdBQXdDLFVBQVM0QyxHQUFULEVBQWMyVyxPQUFkLEVBQXVCO0FBQzdELFFBQUlsVSxJQUFJLEdBQUcsSUFBWCxDQUQ2RCxDQUU3RDs7QUFDQSxRQUFJd2dCLFVBQVUsR0FBR2pqQixHQUFHLENBQUNrbUIsWUFBckI7O0FBQ0EsUUFBR2pELFVBQUgsRUFBZTtBQUNibnNCLFlBQU0sQ0FBQ3F2QixRQUFQLENBQWdCbEQsVUFBaEIsRUFEYSxDQUdiOzs7QUFDQSxVQUFJbk4sUUFBUSxHQUFHaGYsTUFBTSxDQUFDcXNCLGVBQVAsQ0FBdUJsTixLQUF2QixDQUE2QixJQUE3QixFQUFtQ2pXLEdBQUcsQ0FBQ3pCLEVBQXZDLENBQWY7QUFDQXpILFlBQU0sQ0FBQ3ltQixNQUFQLENBQWMvQixRQUFkLENBQXVCeUgsVUFBVSxDQUFDbGlCLEtBQWxDLEVBQXlDZixHQUFHLENBQUM4bkIsWUFBN0MsRUFBMkQ7QUFBQ0csY0FBTSxFQUFFblM7QUFBVCxPQUEzRDtBQUVBYSxhQUFPLEdBQUc3ZixNQUFNLENBQUNxc0IsZUFBUCxDQUF1QnpNLGFBQXZCLENBQXFDLElBQXJDLEVBQTJDMVcsR0FBM0MsRUFBZ0QyVyxPQUFoRCxDQUFWO0FBQ0EsVUFBSXVSLFFBQVEsR0FBR3B4QixNQUFNLENBQUNtaEIsR0FBUCxDQUFXZ0wsVUFBWCxDQUFzQmtGLFNBQXRCLENBQWdDbEYsVUFBaEMsRUFBNEMsWUFBWTtBQUNyRSxlQUFPOEUscUJBQXFCLENBQUNoYyxJQUF0QixDQUEyQnRKLElBQTNCLEVBQWlDekMsR0FBakMsRUFBc0MyVyxPQUF0QyxDQUFQO0FBQ0QsT0FGYyxDQUFmO0FBR0FBLGFBQU87QUFDUixLQVpELE1BWU87QUFDTCxVQUFJdVIsUUFBUSxHQUFHSCxxQkFBcUIsQ0FBQ2hjLElBQXRCLENBQTJCdEosSUFBM0IsRUFBaUN6QyxHQUFqQyxFQUFzQzJXLE9BQXRDLENBQWY7QUFDRDs7QUFFRCxXQUFPdVIsUUFBUDtBQUNELEdBckJELENBL0NtQyxDQXNFbkM7OztBQUNBLE1BQUlFLGlCQUFpQixHQUFHWixZQUFZLENBQUNRLGlCQUFiLENBQStCeG5CLEdBQXZEOztBQUNBZ25CLGNBQVksQ0FBQ1EsaUJBQWIsQ0FBK0J4bkIsR0FBL0IsR0FBcUMsVUFBU1IsR0FBVCxFQUFjMlcsT0FBZCxFQUF1QjtBQUMxRCxRQUFJbFUsSUFBSSxHQUFHLElBQVgsQ0FEMEQsQ0FFMUQ7O0FBQ0EsUUFBSXdnQixVQUFVLEdBQUdqakIsR0FBRyxDQUFDa21CLFlBQXJCOztBQUNBLFFBQUdqRCxVQUFILEVBQWU7QUFDYm5zQixZQUFNLENBQUNxdkIsUUFBUCxDQUFnQmxELFVBQWhCLEVBRGEsQ0FHYjs7O0FBQ0EsVUFBSW5OLFFBQVEsR0FBR2hmLE1BQU0sQ0FBQ3FzQixlQUFQLENBQXVCbE4sS0FBdkIsQ0FBNkIsSUFBN0IsRUFBbUNqVyxHQUFHLENBQUN6QixFQUF2QyxDQUFmO0FBQ0F6SCxZQUFNLENBQUN5bUIsTUFBUCxDQUFjL0IsUUFBZCxDQUF1QnlILFVBQVUsQ0FBQ2xpQixLQUFsQyxFQUF5Q2YsR0FBRyxDQUFDOG5CLFlBQTdDLEVBQTJEO0FBQUNHLGNBQU0sRUFBRW5TO0FBQVQsT0FBM0Q7QUFFQWEsYUFBTyxHQUFHN2YsTUFBTSxDQUFDcXNCLGVBQVAsQ0FBdUJ6TSxhQUF2QixDQUFxQyxJQUFyQyxFQUEyQzFXLEdBQTNDLEVBQWdEMlcsT0FBaEQsQ0FBVjtBQUNBLFVBQUl1UixRQUFRLEdBQUdweEIsTUFBTSxDQUFDbWhCLEdBQVAsQ0FBV2dMLFVBQVgsQ0FBc0JrRixTQUF0QixDQUFnQ2xGLFVBQWhDLEVBQTRDLFlBQVk7QUFDckUsZUFBT21GLGlCQUFpQixDQUFDcmMsSUFBbEIsQ0FBdUJ0SixJQUF2QixFQUE2QnpDLEdBQTdCLEVBQWtDMlcsT0FBbEMsQ0FBUDtBQUNELE9BRmMsQ0FBZjtBQUdBQSxhQUFPO0FBQ1IsS0FaRCxNQVlPO0FBQ0wsVUFBSXVSLFFBQVEsR0FBR0UsaUJBQWlCLENBQUNyYyxJQUFsQixDQUF1QnRKLElBQXZCLEVBQTZCekMsR0FBN0IsRUFBa0MyVyxPQUFsQyxDQUFmO0FBQ0Q7O0FBRUQsV0FBT3VSLFFBQVA7QUFDRCxHQXJCRCxDQXhFbUMsQ0ErRm5DOzs7QUFDQSxNQUFJRyxtQkFBbUIsR0FBR2IsWUFBWSxDQUFDUSxpQkFBYixDQUErQk0sS0FBekQ7O0FBQ0FkLGNBQVksQ0FBQ1EsaUJBQWIsQ0FBK0JNLEtBQS9CLEdBQXVDLFVBQVN0b0IsR0FBVCxFQUFjMlcsT0FBZCxFQUF1QjtBQUM1REEsV0FBTyxHQUFHN2YsTUFBTSxDQUFDcXNCLGVBQVAsQ0FBdUJ6TSxhQUF2QixDQUFxQyxJQUFyQyxFQUEyQzFXLEdBQTNDLEVBQWdEMlcsT0FBaEQsQ0FBVjtBQUNBLFFBQUl1UixRQUFRLEdBQUdHLG1CQUFtQixDQUFDdGMsSUFBcEIsQ0FBeUIsSUFBekIsRUFBK0IvTCxHQUEvQixFQUFvQzJXLE9BQXBDLENBQWY7QUFDQUEsV0FBTztBQUNQLFdBQU91UixRQUFQO0FBQ0QsR0FMRCxDQWpHbUMsQ0F3R25DOzs7QUFDQSxNQUFJSyxZQUFZLEdBQUdmLFlBQVksQ0FBQ3p1QixJQUFoQzs7QUFDQXl1QixjQUFZLENBQUN6dUIsSUFBYixHQUFvQixVQUFTaUgsR0FBVCxFQUFjO0FBQ2hDLFFBQUdBLEdBQUcsQ0FBQ0EsR0FBSixJQUFXLFFBQWQsRUFBd0I7QUFDdEIsVUFBSWlqQixVQUFVLEdBQUduc0IsTUFBTSxDQUFDZ3ZCLFFBQVAsRUFBakI7O0FBQ0EsVUFBRzdDLFVBQUgsRUFBZTtBQUNiLFlBQUdqakIsR0FBRyxDQUFDeEUsS0FBUCxFQUFjO0FBQ1osY0FBSUEsS0FBSyxHQUFHa0IsQ0FBQyxDQUFDNlosSUFBRixDQUFPdlcsR0FBRyxDQUFDeEUsS0FBWCxFQUFrQixDQUFDLFNBQUQsRUFBWSxPQUFaLEVBQXFCLFNBQXJCLENBQWxCLENBQVosQ0FEWSxDQUdaOzs7QUFDQSxjQUFHeW5CLFVBQVUsSUFBSUEsVUFBVSxDQUFDdUYsWUFBNUIsRUFBMEM7QUFDeEM7QUFDQTtBQUNBaHRCLGlCQUFLLEdBQUdrQixDQUFDLENBQUM2WixJQUFGLENBQU8wTSxVQUFVLENBQUN1RixZQUFsQixFQUFnQyxDQUFDLFNBQUQsRUFBWSxPQUFaLEVBQXFCLFNBQXJCLENBQWhDLENBQVIsQ0FId0MsQ0FJeEM7O0FBQ0EsZ0JBQUdodEIsS0FBSyxDQUFDZ1IsS0FBTixJQUFlaFIsS0FBSyxDQUFDZ1IsS0FBTixDQUFZQSxLQUE5QixFQUFxQztBQUNuQ2hSLG1CQUFLLENBQUNnUixLQUFOLEdBQWNoUixLQUFLLENBQUNnUixLQUFOLENBQVlBLEtBQTFCO0FBQ0Q7QUFDRjs7QUFFRDFWLGdCQUFNLENBQUN5bUIsTUFBUCxDQUFjOUIsWUFBZCxDQUEyQndILFVBQVUsQ0FBQ2xpQixLQUF0QztBQUNBakssZ0JBQU0sQ0FBQ3ltQixNQUFQLENBQWMzQyxLQUFkLENBQW9CcUksVUFBVSxDQUFDbGlCLEtBQS9CLEVBQXNDLE9BQXRDLEVBQStDO0FBQUN2RixpQkFBSyxFQUFFQTtBQUFSLFdBQS9DO0FBQ0QsU0FoQkQsTUFnQk87QUFDTDFFLGdCQUFNLENBQUN5bUIsTUFBUCxDQUFjOUIsWUFBZCxDQUEyQndILFVBQVUsQ0FBQ2xpQixLQUF0QztBQUNBakssZ0JBQU0sQ0FBQ3ltQixNQUFQLENBQWMzQyxLQUFkLENBQW9CcUksVUFBVSxDQUFDbGlCLEtBQS9CLEVBQXNDLFVBQXRDO0FBQ0QsU0FwQlksQ0FzQmI7OztBQUNBLFlBQUlBLEtBQUssR0FBR2pLLE1BQU0sQ0FBQ3ltQixNQUFQLENBQWNsQixVQUFkLENBQXlCNEcsVUFBVSxDQUFDbGlCLEtBQXBDLENBQVo7QUFDQWpLLGNBQU0sQ0FBQ2lCLFFBQVAsQ0FBZ0JxdkIsSUFBaEIsQ0FBcUIsUUFBckIsRUFBK0IsaUJBQS9CLEVBQWtEcm1CLEtBQWxELEVBQXlELElBQXpEO0FBQ0FqSyxjQUFNLENBQUNpc0IsTUFBUCxDQUFjMWxCLE9BQWQsQ0FBc0JXLGFBQXRCLENBQW9DK0MsS0FBcEMsRUF6QmEsQ0EyQmI7O0FBQ0EsWUFBR3ZGLEtBQUssSUFBSTFFLE1BQU0sQ0FBQ0MsT0FBUCxDQUFlbXRCLG1CQUEzQixFQUFnRDtBQUM5Q3B0QixnQkFBTSxDQUFDaXNCLE1BQVAsQ0FBY3ZuQixLQUFkLENBQW9CNlEsVUFBcEIsQ0FBK0I3USxLQUEvQixFQUFzQ3VGLEtBQXRDO0FBQ0QsU0E5QlksQ0FnQ2I7QUFDQTs7O0FBQ0FqSyxjQUFNLENBQUNxdkIsUUFBUCxDQUFnQixJQUFoQjtBQUNEO0FBQ0Y7O0FBRUQsV0FBT29DLFlBQVksQ0FBQ3hjLElBQWIsQ0FBa0IsSUFBbEIsRUFBd0IvTCxHQUF4QixDQUFQO0FBQ0QsR0ExQ0Q7QUEyQ0QsQ0FySkQsQyxDQXVKQTs7O0FBQ0F0RCxDQUFDLENBQUN5RyxJQUFGLENBQU9sTSxNQUFNLENBQUM0TCxNQUFQLENBQWM0bEIsZUFBckIsRUFBc0MsVUFBU0MsT0FBVCxFQUFrQnJxQixJQUFsQixFQUF3QjtBQUM1RHNxQiwyQkFBeUIsQ0FBQ3RxQixJQUFELEVBQU9xcUIsT0FBUCxFQUFnQnp4QixNQUFNLENBQUM0TCxNQUFQLENBQWM0bEIsZUFBOUIsQ0FBekI7QUFDRCxDQUZELEUsQ0FJQTs7O0FBQ0EsSUFBSUcscUJBQXFCLEdBQUczeEIsTUFBTSxDQUFDb0csT0FBbkM7O0FBQ0FwRyxNQUFNLENBQUNvRyxPQUFQLEdBQWlCLFVBQVN3ckIsU0FBVCxFQUFvQjtBQUNuQ25zQixHQUFDLENBQUN5RyxJQUFGLENBQU8wbEIsU0FBUCxFQUFrQixVQUFTSCxPQUFULEVBQWtCcnFCLElBQWxCLEVBQXdCO0FBQ3hDc3FCLDZCQUF5QixDQUFDdHFCLElBQUQsRUFBT3FxQixPQUFQLEVBQWdCRyxTQUFoQixDQUF6QjtBQUNELEdBRkQ7O0FBR0FELHVCQUFxQixDQUFDQyxTQUFELENBQXJCO0FBQ0QsQ0FMRDs7QUFRQSxTQUFTRix5QkFBVCxDQUFtQ3RxQixJQUFuQyxFQUF5Q3lxQixlQUF6QyxFQUEwREQsU0FBMUQsRUFBcUU7QUFDbkVBLFdBQVMsQ0FBQ3hxQixJQUFELENBQVQsR0FBa0IsWUFBVztBQUMzQixRQUFHO0FBQ0QsYUFBT3lxQixlQUFlLENBQUM1d0IsS0FBaEIsQ0FBc0IsSUFBdEIsRUFBNEI4WSxTQUE1QixDQUFQO0FBQ0QsS0FGRCxDQUVFLE9BQU1yVixFQUFOLEVBQVU7QUFDVixVQUFHQSxFQUFFLElBQUk3RSxNQUFNLENBQUNndkIsUUFBUCxFQUFULEVBQTRCO0FBQzFCO0FBQ0E7QUFDQSxZQUFHLE9BQU9ucUIsRUFBUCxLQUFjLFFBQWpCLEVBQTJCO0FBQ3pCQSxZQUFFLEdBQUc7QUFBQ3BELG1CQUFPLEVBQUVvRCxFQUFWO0FBQWM2USxpQkFBSyxFQUFFN1E7QUFBckIsV0FBTDtBQUNELFNBTHlCLENBTTFCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBLFlBQUk3RSxNQUFNLENBQUNDLE9BQVAsQ0FBZW10QixtQkFBbkIsRUFBd0M7QUFDdEN2b0IsWUFBRSxDQUFDNlEsS0FBSCxHQUFXO0FBQUNBLGlCQUFLLEVBQUU3USxFQUFFLENBQUM2USxLQUFYO0FBQWtCdWMsa0JBQU0sRUFBRSxRQUExQjtBQUFvQyxhQUFDMUIsaUJBQUQsR0FBcUI7QUFBekQsV0FBWDtBQUNBdndCLGdCQUFNLENBQUNndkIsUUFBUCxHQUFrQjBDLFlBQWxCLEdBQWlDN3NCLEVBQWpDO0FBQ0Q7QUFDRjs7QUFDRCxZQUFNQSxFQUFOO0FBQ0Q7QUFDRixHQXpCRDtBQTBCRCxDOzs7Ozs7Ozs7OztBQ3JNRCxJQUFJMHJCLGlCQUFKO0FBQXNCcmlCLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFNBQVosRUFBc0I7QUFBQ29pQixtQkFBaUIsQ0FBQ25pQixDQUFELEVBQUc7QUFBQ21pQixxQkFBaUIsR0FBQ25pQixDQUFsQjtBQUFvQjs7QUFBMUMsQ0FBdEIsRUFBa0UsQ0FBbEU7O0FBRXRCOGpCLGdCQUFnQixHQUFHLFVBQVNDLGlCQUFULEVBQTRCO0FBQzdDO0FBQ0E7QUFDQSxNQUFJQyxrQkFBa0IsR0FBR0QsaUJBQWlCLENBQUNFLFdBQTNDOztBQUNBRixtQkFBaUIsQ0FBQ0UsV0FBbEIsR0FBZ0MsWUFBVztBQUN6QyxRQUFJbEcsVUFBVSxHQUFHbnNCLE1BQU0sQ0FBQ2d2QixRQUFQLEVBQWpCOztBQUNBLFFBQUk3QyxVQUFKLEVBQWdCO0FBQ2QsV0FBS2lELFlBQUwsR0FBb0JqRCxVQUFwQjtBQUNEOztBQUFBO0FBQ0RpRyxzQkFBa0IsQ0FBQ25kLElBQW5CLENBQXdCLElBQXhCO0FBQ0QsR0FORDs7QUFRQSxNQUFJcWQsYUFBYSxHQUFHSCxpQkFBaUIsQ0FBQzlELEtBQXRDOztBQUNBOEQsbUJBQWlCLENBQUM5RCxLQUFsQixHQUEwQixZQUFXO0FBQ25DO0FBQ0E7QUFDQSxRQUFHLENBQUMsS0FBS2tFLGdCQUFULEVBQTJCO0FBQ3pCLFVBQUlwRyxVQUFVLEdBQUduc0IsTUFBTSxDQUFDZ3ZCLFFBQVAsTUFBcUIsS0FBS0ksWUFBM0M7O0FBQ0EsYUFBTyxLQUFLQSxZQUFaLENBRnlCLENBR3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0EsVUFBR2pELFVBQVUsSUFBSSxLQUFLeGlCLGVBQW5CLElBQXNDLEtBQUtBLGVBQUwsSUFBd0J3aUIsVUFBVSxDQUFDbGlCLEtBQVgsQ0FBaUJ4QyxFQUFsRixFQUFzRjtBQUNwRnpILGNBQU0sQ0FBQ3ltQixNQUFQLENBQWM5QixZQUFkLENBQTJCd0gsVUFBVSxDQUFDbGlCLEtBQXRDO0FBQ0FqSyxjQUFNLENBQUN5bUIsTUFBUCxDQUFjM0MsS0FBZCxDQUFvQnFJLFVBQVUsQ0FBQ2xpQixLQUEvQixFQUFzQyxVQUF0QztBQUNBLFlBQUlBLEtBQUssR0FBR2pLLE1BQU0sQ0FBQ3ltQixNQUFQLENBQWNsQixVQUFkLENBQXlCNEcsVUFBVSxDQUFDbGlCLEtBQXBDLENBQVo7QUFDRDs7QUFFRGpLLFlBQU0sQ0FBQ2lCLFFBQVAsQ0FBZ0JxdkIsSUFBaEIsQ0FBcUIsUUFBckIsRUFBK0IsY0FBL0IsRUFBK0NybUIsS0FBL0MsRUFBc0QsS0FBS3VvQixRQUEzRCxFQUFxRSxJQUFyRTs7QUFDQXh5QixZQUFNLENBQUNpc0IsTUFBUCxDQUFjSyxNQUFkLENBQXFCdGlCLFdBQXJCLENBQWlDLEtBQUt3b0IsUUFBdEMsRUFBZ0QsSUFBaEQsRUFBc0R2b0IsS0FBdEQ7O0FBQ0EsV0FBS3NvQixnQkFBTCxHQUF3QixJQUF4QjtBQUNELEtBcEJrQyxDQXNCbkM7QUFDQTs7O0FBQ0FELGlCQUFhLENBQUNyZCxJQUFkLENBQW1CLElBQW5CO0FBQ0QsR0F6QkQ7O0FBMkJBLE1BQUl3ZCxhQUFhLEdBQUdOLGlCQUFpQixDQUFDenRCLEtBQXRDOztBQUNBeXRCLG1CQUFpQixDQUFDenRCLEtBQWxCLEdBQTBCLFVBQVNoRCxHQUFULEVBQWM7QUFDdEMsUUFBSSxPQUFPQSxHQUFQLEtBQWUsUUFBbkIsRUFBNkI7QUFDM0JBLFNBQUcsR0FBRztBQUFFRCxlQUFPLEVBQUVDO0FBQVgsT0FBTjtBQUNEOztBQUVELFFBQUl5cUIsVUFBVSxHQUFHbnNCLE1BQU0sQ0FBQ2d2QixRQUFQLEVBQWpCOztBQUVBLFFBQUk3QyxVQUFVLElBQUksS0FBS3hpQixlQUFuQixJQUFzQyxLQUFLQSxlQUFMLElBQXdCd2lCLFVBQVUsQ0FBQ2xpQixLQUFYLENBQWlCeEMsRUFBbkYsRUFBdUY7QUFDckZ6SCxZQUFNLENBQUN5bUIsTUFBUCxDQUFjOUIsWUFBZCxDQUEyQndILFVBQVUsQ0FBQ2xpQixLQUF0Qzs7QUFFQSxVQUFJeW9CLFdBQVcsR0FBRzlzQixDQUFDLENBQUM2WixJQUFGLENBQU8vZCxHQUFQLEVBQVksU0FBWixFQUF1QixPQUF2QixDQUFsQjs7QUFDQTFCLFlBQU0sQ0FBQ3ltQixNQUFQLENBQWMzQyxLQUFkLENBQW9CcUksVUFBVSxDQUFDbGlCLEtBQS9CLEVBQXNDLE9BQXRDLEVBQStDO0FBQUN2RixhQUFLLEVBQUVndUI7QUFBUixPQUEvQztBQUNBLFVBQUl6b0IsS0FBSyxHQUFHakssTUFBTSxDQUFDeW1CLE1BQVAsQ0FBY2xCLFVBQWQsQ0FBeUI0RyxVQUFVLENBQUNsaUIsS0FBcEMsQ0FBWjs7QUFFQWpLLFlBQU0sQ0FBQ2lzQixNQUFQLENBQWNLLE1BQWQsQ0FBcUJsaUIsV0FBckIsQ0FBaUMsS0FBS29vQixRQUF0QyxFQUFnRCxJQUFoRCxFQUFzRHZvQixLQUF0RCxFQVBxRixDQVNyRjtBQUNBO0FBQ0E7OztBQUNBLFVBQUdqSyxNQUFNLENBQUNDLE9BQVAsQ0FBZW10QixtQkFBZixJQUFzQ25qQixLQUF6QyxFQUFnRDtBQUM5Q2pLLGNBQU0sQ0FBQ2lzQixNQUFQLENBQWN2bkIsS0FBZCxDQUFvQjZRLFVBQXBCLENBQStCN1QsR0FBL0IsRUFBb0N1SSxLQUFwQztBQUNEO0FBQ0YsS0F0QnFDLENBd0J0QztBQUNBO0FBQ0E7OztBQUNBLFFBQUlqSyxNQUFNLENBQUNDLE9BQVAsQ0FBZW10QixtQkFBbkIsRUFBd0M7QUFDdEMxckIsU0FBRyxDQUFDZ1UsS0FBSixHQUFZO0FBQUNBLGFBQUssRUFBRWhVLEdBQUcsQ0FBQ2dVLEtBQVo7QUFBbUJ1YyxjQUFNLEVBQUUsY0FBM0I7QUFBMkMsU0FBQzFCLGlCQUFELEdBQXFCO0FBQWhFLE9BQVo7QUFDRDs7QUFDRGtDLGlCQUFhLENBQUN4ZCxJQUFkLENBQW1CLElBQW5CLEVBQXlCdlQsR0FBekI7QUFDRCxHQS9CRDs7QUFpQ0EsTUFBSWl4QixrQkFBa0IsR0FBR1IsaUJBQWlCLENBQUNTLFdBQTNDOztBQUNBVCxtQkFBaUIsQ0FBQ1MsV0FBbEIsR0FBZ0MsWUFBVztBQUN6QzV5QixVQUFNLENBQUNpQixRQUFQLENBQWdCcXZCLElBQWhCLENBQXFCLFFBQXJCLEVBQStCLGdCQUEvQixFQUFpRCxLQUFLa0MsUUFBdEQsRUFBZ0UsSUFBaEU7O0FBQ0F4eUIsVUFBTSxDQUFDaXNCLE1BQVAsQ0FBY0ssTUFBZCxDQUFxQjdpQixXQUFyQixDQUFpQyxLQUFLK29CLFFBQXRDLEVBQWdELElBQWhEOztBQUNBRyxzQkFBa0IsQ0FBQzFkLElBQW5CLENBQXdCLElBQXhCO0FBQ0QsR0FKRCxDQTNFNkMsQ0FpRjdDOzs7QUFDQSxHQUFDLE9BQUQsRUFBVSxTQUFWLEVBQXFCLFNBQXJCLEVBQWdDL1QsT0FBaEMsQ0FBd0MsVUFBUzJ4QixRQUFULEVBQW1CO0FBQ3pELFFBQUlDLFlBQVksR0FBR1gsaUJBQWlCLENBQUNVLFFBQUQsQ0FBcEM7O0FBQ0FWLHFCQUFpQixDQUFDVSxRQUFELENBQWpCLEdBQThCLFVBQVNFLGNBQVQsRUFBeUJ0ckIsRUFBekIsRUFBNkJtYSxNQUE3QixFQUFxQztBQUNqRSxVQUFJalcsSUFBSSxHQUFHLElBQVgsQ0FEaUUsQ0FHakU7QUFDQTtBQUNBO0FBQ0E7O0FBQ0EzTCxZQUFNLENBQUNtaEIsR0FBUCxDQUFXK0ssVUFBWCxHQUF3QnZnQixJQUF4QjtBQUNBLFVBQUl0SSxHQUFHLEdBQUd5dkIsWUFBWSxDQUFDN2QsSUFBYixDQUFrQnRKLElBQWxCLEVBQXdCb25CLGNBQXhCLEVBQXdDdHJCLEVBQXhDLEVBQTRDbWEsTUFBNUMsQ0FBVjtBQUNBNWhCLFlBQU0sQ0FBQ21oQixHQUFQLENBQVcrSyxVQUFYLEdBQXdCLElBQXhCO0FBRUEsYUFBTzdvQixHQUFQO0FBQ0QsS0FaRDtBQWFELEdBZkQ7QUFnQkQsQ0FsR0QsQzs7Ozs7Ozs7Ozs7QUNGQTJ2QixzQkFBc0IsR0FBRyxVQUFTQyxLQUFULEVBQWdCO0FBQ3ZDO0FBQ0E7QUFDQSxNQUFJQyx5QkFBeUIsR0FBR0QsS0FBSyxDQUFDRSxrQkFBdEM7O0FBQ0FGLE9BQUssQ0FBQ0Usa0JBQU4sR0FBMkIsVUFBU0MsVUFBVCxFQUFxQkMsU0FBckIsRUFBZ0M7QUFDekQsUUFBSWhNLElBQUksR0FBRyxLQUFLaU0sa0JBQUwsQ0FBd0JQLGNBQW5DO0FBQ0EsUUFBSXZJLEtBQUssR0FBRyxLQUFLOEksa0JBQUwsQ0FBd0IzUyxRQUFwQztBQUNBLFFBQUk4SixJQUFJLEdBQUcsS0FBSzZJLGtCQUFMLENBQXdCcnpCLE9BQW5DO0FBQ0EsUUFBSXN6QixPQUFPLEdBQUd2ekIsTUFBTSxDQUFDaVUsVUFBUCxDQUFrQnNXLE9BQWxCLENBQTBCbEQsSUFBMUIsRUFBZ0NtRCxLQUFoQyxFQUF1Q0MsSUFBdkMsRUFBNkMySSxVQUE3QyxDQUFkO0FBQ0EsUUFBSUcsT0FBTyxHQUFHdnpCLE1BQU0sQ0FBQ2lVLFVBQVAsQ0FBa0JzVyxPQUFsQixDQUEwQmxELElBQTFCLEVBQWdDbUQsS0FBaEMsRUFBdUNDLElBQXZDLEVBQTZDNEksU0FBN0MsQ0FBZDtBQUNBLFFBQUk3c0IsS0FBSyxHQUFHNHNCLFVBQVUsQ0FBQ25yQixJQUFYLEtBQW9Cb3JCLFNBQVMsQ0FBQ3ByQixJQUFWLEVBQWhDOztBQUNBLFFBQUcsS0FBS3VyQixVQUFSLEVBQW9CO0FBQ2xCeHpCLFlBQU0sQ0FBQ2lzQixNQUFQLENBQWNLLE1BQWQsQ0FBcUJ2ZSxvQkFBckIsQ0FBMEMsS0FBS3lsQixVQUEvQyxFQUEyRGh0QixLQUEzRDtBQUNBeEcsWUFBTSxDQUFDaXNCLE1BQVAsQ0FBY0ssTUFBZCxDQUFxQnRrQixZQUFyQixDQUFrQyxLQUFLd3JCLFVBQUwsQ0FBZ0Jqc0IsSUFBbEQsRUFBd0QsZUFBeEQsRUFBeUVnc0IsT0FBTyxHQUFDL3NCLEtBQWpGO0FBQ0QsS0FIRCxNQUdPO0FBQ0wsV0FBS2l0QixnQkFBTCxHQUF3Qmp0QixLQUF4QjtBQUNBLFdBQUtrdEIsUUFBTCxHQUFnQjtBQUNkQyxxQkFBYSxFQUFFSixPQUFPLEdBQUMvc0I7QUFEVCxPQUFoQjtBQUdEOztBQUNELFdBQU8wc0IseUJBQXlCLENBQUNqZSxJQUExQixDQUErQixJQUEvQixFQUFxQ21lLFVBQXJDLEVBQWlEQyxTQUFqRCxDQUFQO0FBQ0QsR0FqQkQ7O0FBbUJBLE1BQUlPLGdDQUFnQyxHQUFHWCxLQUFLLENBQUNZLHlCQUE3Qzs7QUFDQVosT0FBSyxDQUFDWSx5QkFBTixHQUFrQyxVQUFTL2xCLEVBQVQsRUFBYTtBQUM3QzlOLFVBQU0sQ0FBQ2lzQixNQUFQLENBQWNLLE1BQWQsQ0FBcUJ6ZSxvQkFBckIsQ0FBMEMsS0FBSzJsQixVQUEvQyxFQUEyRDFsQixFQUEzRDtBQUNBLFdBQU84bEIsZ0NBQWdDLENBQUMzZSxJQUFqQyxDQUFzQyxJQUF0QyxFQUE0Q25ILEVBQTVDLENBQVA7QUFDRCxHQUhEOztBQUtBLE1BQUlnbUIsd0NBQXdDLEdBQUdiLEtBQUssQ0FBQ2MsaUNBQXJEOztBQUNBZCxPQUFLLENBQUNjLGlDQUFOLEdBQTBDLFVBQVNqbUIsRUFBVCxFQUFhO0FBQ3JEOU4sVUFBTSxDQUFDaXNCLE1BQVAsQ0FBY0ssTUFBZCxDQUFxQnplLG9CQUFyQixDQUEwQyxLQUFLMmxCLFVBQS9DLEVBQTJEMWxCLEVBQTNEO0FBQ0EsV0FBT2dtQix3Q0FBd0MsQ0FBQzdlLElBQXpDLENBQThDLElBQTlDLEVBQW9EbkgsRUFBcEQsQ0FBUDtBQUNELEdBSEQsQ0E5QnVDLENBbUN2Qzs7O0FBQ0EsR0FBQyxlQUFELEVBQWtCLGtCQUFsQixFQUFzQyxrQkFBdEMsRUFBMEQ1TSxPQUExRCxDQUFrRSxVQUFTOHlCLE1BQVQsRUFBaUI7QUFDakYsUUFBSUMsVUFBVSxHQUFHaEIsS0FBSyxDQUFDZSxNQUFELENBQXRCOztBQUNBZixTQUFLLENBQUNlLE1BQUQsQ0FBTCxHQUFnQixVQUFTOWEsQ0FBVCxFQUFZbVEsQ0FBWixFQUFlNkssQ0FBZixFQUFrQjtBQUNoQyxVQUFHLEtBQUtWLFVBQVIsRUFBb0I7QUFDbEJ4ekIsY0FBTSxDQUFDaXNCLE1BQVAsQ0FBY0ssTUFBZCxDQUFxQnRlLGdCQUFyQixDQUFzQyxLQUFLd2xCLFVBQTNDLEVBQXVEUSxNQUF2RCxFQUErRCxDQUEvRDs7QUFFQSxZQUFHQSxNQUFNLEtBQUssZUFBZCxFQUErQjtBQUM3QixjQUFJM00sSUFBSSxHQUFHLEtBQUtpTSxrQkFBTCxDQUF3QlAsY0FBbkM7QUFDQSxjQUFJdkksS0FBSyxHQUFHLEtBQUs4SSxrQkFBTCxDQUF3QjNTLFFBQXBDO0FBQ0EsY0FBSThKLElBQUksR0FBRyxLQUFLNkksa0JBQUwsQ0FBd0JyekIsT0FBbkM7QUFDQSxjQUFJc3pCLE9BQU8sR0FBR3Z6QixNQUFNLENBQUNpVSxVQUFQLENBQWtCc1csT0FBbEIsQ0FBMEJsRCxJQUExQixFQUFnQ21ELEtBQWhDLEVBQXVDQyxJQUF2QyxFQUE2QyxDQUFDcEIsQ0FBRCxDQUE3QyxDQUFkO0FBRUFycEIsZ0JBQU0sQ0FBQ2lzQixNQUFQLENBQWNLLE1BQWQsQ0FBcUJ0a0IsWUFBckIsQ0FBa0MsS0FBS3dyQixVQUFMLENBQWdCanNCLElBQWxELEVBQXdELGFBQXhELEVBQXVFZ3NCLE9BQXZFO0FBQ0Q7QUFDRixPQVhELE1BV087QUFDTDtBQUNBLFlBQUcsQ0FBQyxLQUFLWSxrQkFBVCxFQUE2QjtBQUMzQixlQUFLQSxrQkFBTCxHQUEwQjtBQUN4QkMsd0JBQVksRUFBRTtBQURVLFdBQTFCO0FBR0Q7O0FBRUQsYUFBS0Qsa0JBQUwsQ0FBd0JDLFlBQXhCOztBQUVBLFlBQUdKLE1BQU0sS0FBSyxlQUFkLEVBQStCO0FBQzdCLGNBQUcsQ0FBQyxLQUFLTixRQUFULEVBQW1CO0FBQ2pCLGlCQUFLQSxRQUFMLEdBQWdCO0FBQ2RXLDRCQUFjLEVBQUU7QUFERixhQUFoQjtBQUdEOztBQUVELGNBQUcsQ0FBQyxLQUFLWCxRQUFMLENBQWNXLGNBQWxCLEVBQWtDO0FBQ2hDLGlCQUFLWCxRQUFMLENBQWNXLGNBQWQsR0FBK0IsQ0FBL0I7QUFDRDs7QUFFRCxjQUFJaE4sSUFBSSxHQUFHLEtBQUtpTSxrQkFBTCxDQUF3QlAsY0FBbkM7QUFDQSxjQUFJdkksS0FBSyxHQUFHLEtBQUs4SSxrQkFBTCxDQUF3QjNTLFFBQXBDO0FBQ0EsY0FBSThKLElBQUksR0FBRyxLQUFLNkksa0JBQUwsQ0FBd0JyekIsT0FBbkM7QUFDQSxjQUFJc3pCLE9BQU8sR0FBR3Z6QixNQUFNLENBQUNpVSxVQUFQLENBQWtCc1csT0FBbEIsQ0FBMEJsRCxJQUExQixFQUFnQ21ELEtBQWhDLEVBQXVDQyxJQUF2QyxFQUE2QyxDQUFDcEIsQ0FBRCxDQUE3QyxDQUFkO0FBRUEsZUFBS3FLLFFBQUwsQ0FBY1csY0FBZCxJQUFnQ2QsT0FBaEM7QUFDRDtBQUNGOztBQUVELGFBQU9VLFVBQVUsQ0FBQ2hmLElBQVgsQ0FBZ0IsSUFBaEIsRUFBc0JpRSxDQUF0QixFQUF5Qm1RLENBQXpCLEVBQTRCNkssQ0FBNUIsQ0FBUDtBQUNELEtBM0NEO0FBNENELEdBOUNEO0FBZ0RBLE1BQUlJLFlBQVksR0FBR3JCLEtBQUssQ0FBQ2pMLElBQXpCOztBQUNBaUwsT0FBSyxDQUFDakwsSUFBTixHQUFhLFlBQVc7QUFDdEIsUUFBRyxLQUFLd0wsVUFBTCxJQUFtQixLQUFLQSxVQUFMLENBQWdCaHlCLElBQWhCLEtBQXlCLEtBQS9DLEVBQXNEO0FBQ3BEeEIsWUFBTSxDQUFDaUIsUUFBUCxDQUFnQnF2QixJQUFoQixDQUFxQixRQUFyQixFQUErQixpQkFBL0IsRUFBa0QsS0FBS2tELFVBQXZEO0FBQ0F4ekIsWUFBTSxDQUFDaXNCLE1BQVAsQ0FBY0ssTUFBZCxDQUFxQjVlLG9CQUFyQixDQUEwQyxLQUFLOGxCLFVBQS9DO0FBQ0Q7O0FBRUQsV0FBT2MsWUFBWSxDQUFDcmYsSUFBYixDQUFrQixJQUFsQixDQUFQO0FBQ0QsR0FQRDtBQVFELENBN0ZEOztBQStGQXNmLHdCQUF3QixHQUFHLFVBQVN0QixLQUFULEVBQWdCO0FBQ3pDLE1BQUl1QixpQkFBaUIsR0FBR3ZCLEtBQUssQ0FBQ3dCLFVBQTlCOztBQUNBeEIsT0FBSyxDQUFDd0IsVUFBTixHQUFtQixZQUFXO0FBQzVCLFFBQUlydUIsS0FBSyxHQUFHdUgsSUFBSSxDQUFDaUMsR0FBTCxFQUFaO0FBQ0E0a0IscUJBQWlCLENBQUN2ZixJQUFsQixDQUF1QixJQUF2QixFQUY0QixDQUk1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLFFBQUl6TyxLQUFLLEdBQUcsQ0FBWjtBQUNBLFFBQUkrc0IsT0FBTyxHQUFHLENBQWQ7O0FBRUEsUUFBRyxLQUFLbUIsUUFBTCxJQUFpQixLQUFLQSxRQUFMLENBQWN6c0IsSUFBbEMsRUFBd0M7QUFDdEN6QixXQUFLLEdBQUcsS0FBS2t1QixRQUFMLENBQWN6c0IsSUFBZCxNQUF3QixDQUFoQztBQUVBLFVBQUlvZixJQUFJLEdBQUcsS0FBS2lNLGtCQUFMLENBQXdCUCxjQUFuQztBQUNBLFVBQUl2SSxLQUFLLEdBQUcsS0FBSzhJLGtCQUFMLENBQXdCM1MsUUFBcEM7QUFDQSxVQUFJOEosSUFBSSxHQUFHLEtBQUs2SSxrQkFBTCxDQUF3QnJ6QixPQUFuQztBQUVBc3pCLGFBQU8sR0FBR3Z6QixNQUFNLENBQUNpVSxVQUFQLENBQWtCc1csT0FBbEIsQ0FBMEJsRCxJQUExQixFQUFnQ21ELEtBQWhDLEVBQXVDQyxJQUF2QyxFQUE2QyxLQUFLaUssUUFBTCxDQUFjQyxJQUEzRCxJQUFpRW51QixLQUEzRTtBQUNEOztBQUVELFFBQUcsS0FBS2d0QixVQUFSLEVBQW9CO0FBQ2xCeHpCLFlBQU0sQ0FBQ2lzQixNQUFQLENBQWNLLE1BQWQsQ0FBcUJ2ZSxvQkFBckIsQ0FBMEMsS0FBS3lsQixVQUEvQyxFQUEyRGh0QixLQUEzRDtBQUNBeEcsWUFBTSxDQUFDaXNCLE1BQVAsQ0FBY0ssTUFBZCxDQUFxQnRrQixZQUFyQixDQUFrQyxLQUFLd3JCLFVBQUwsQ0FBZ0Jqc0IsSUFBbEQsRUFBd0QsZUFBeEQsRUFBeUVnc0IsT0FBekU7QUFDRCxLQUhELE1BR087QUFDTCxXQUFLRSxnQkFBTCxHQUF3Qmp0QixLQUF4QjtBQUNBLFdBQUtvdUIsY0FBTCxHQUFzQnJCLE9BQXRCO0FBQ0Q7QUFDRixHQTdCRDs7QUErQkEsTUFBSWUsWUFBWSxHQUFHckIsS0FBSyxDQUFDakwsSUFBekI7O0FBQ0FpTCxPQUFLLENBQUNqTCxJQUFOLEdBQWEsWUFBVztBQUN0QixRQUFHLEtBQUt3TCxVQUFMLElBQW1CLEtBQUtBLFVBQUwsQ0FBZ0JoeUIsSUFBaEIsS0FBeUIsS0FBL0MsRUFBc0Q7QUFDcER4QixZQUFNLENBQUNpQixRQUFQLENBQWdCcXZCLElBQWhCLENBQXFCLFFBQXJCLEVBQStCLGlCQUEvQixFQUFrRCxLQUFLa0QsVUFBdkQ7QUFDQXh6QixZQUFNLENBQUNpc0IsTUFBUCxDQUFjSyxNQUFkLENBQXFCNWUsb0JBQXJCLENBQTBDLEtBQUs4bEIsVUFBL0M7QUFDRDs7QUFFRCxXQUFPYyxZQUFZLENBQUNyZixJQUFiLENBQWtCLElBQWxCLENBQVA7QUFDRCxHQVBEO0FBUUQsQ0ExQ0Q7O0FBNENBNGYsZUFBZSxHQUFHLFVBQVM1QixLQUFULEVBQWdCO0FBQ2hDLE1BQUk2QixpQkFBaUIsR0FBRzdCLEtBQUssQ0FBQzhCLDJCQUE5Qjs7QUFDQzlCLE9BQUssQ0FBQzhCLDJCQUFOLEdBQW9DLFVBQVNDLE1BQVQsRUFBaUI7QUFDcEQsUUFBRyxDQUFDLEtBQUtDLG9CQUFULEVBQStCO0FBQzdCLFdBQUtBLG9CQUFMLEdBQTRCdG5CLElBQUksQ0FBQ2lDLEdBQUwsRUFBNUI7QUFDRDs7QUFFRG9sQixVQUFNLENBQUNFLG9CQUFQLEdBQThCLEtBQUtDLE1BQUwsRUFBOUI7QUFDQUgsVUFBTSxDQUFDSSxZQUFQLEdBQXNCLEtBQUtDLE1BQUwsQ0FBWUMsWUFBWixDQUF5Qnh6QixNQUEvQzs7QUFFQSxRQUFHLENBQUNrekIsTUFBTSxDQUFDRSxvQkFBWCxFQUFpQztBQUMvQkYsWUFBTSxDQUFDTyxtQkFBUCxHQUE2QjVuQixJQUFJLENBQUNpQyxHQUFMLEtBQWEsS0FBS3FsQixvQkFBL0M7QUFDRDs7QUFDRCxXQUFPSCxpQkFBaUIsQ0FBQzdmLElBQWxCLENBQXVCLElBQXZCLEVBQTZCK2YsTUFBN0IsQ0FBUDtBQUNELEdBWkE7QUFhRixDQWZEOztBQWlCQVEsd0JBQXdCLEdBQUcsWUFBVztBQUNwQztBQUNBLE1BQUlDLG9CQUFvQixHQUFHQyxPQUFPLENBQUNDLGVBQVIsQ0FBd0IxeEIsU0FBbkQ7QUFDQSxNQUFJMnhCLHNCQUFzQixHQUFHSCxvQkFBb0IsQ0FBQ0ksZUFBbEQ7O0FBQ0FKLHNCQUFvQixDQUFDSSxlQUFyQixHQUF1QyxVQUFTelYsaUJBQVQsRUFBNEIwVixPQUE1QixFQUFxQ0MsU0FBckMsRUFBZ0Q7QUFDckYsUUFBSUMsR0FBRyxHQUFHSixzQkFBc0IsQ0FBQzNnQixJQUF2QixDQUE0QixJQUE1QixFQUFrQ21MLGlCQUFsQyxFQUFxRDBWLE9BQXJELEVBQThEQyxTQUE5RCxDQUFWLENBRHFGLENBRXJGOztBQUNBLFFBQUk1SixVQUFVLEdBQUduc0IsTUFBTSxDQUFDZ3ZCLFFBQVAsQ0FBZ0IsSUFBaEIsRUFBc0IsSUFBdEIsQ0FBakI7O0FBRUEsUUFBRzdDLFVBQVUsSUFBSTZKLEdBQUcsQ0FBQ0MsWUFBckIsRUFBbUM7QUFDakMsVUFBRyxDQUFDRCxHQUFHLENBQUNDLFlBQUosQ0FBaUJDLGVBQXJCLEVBQXNDO0FBQ3BDO0FBQ0FGLFdBQUcsQ0FBQ0MsWUFBSixDQUFpQkMsZUFBakIsR0FBbUMsSUFBbkM7QUFDQWwyQixjQUFNLENBQUNpQixRQUFQLENBQWdCcXZCLElBQWhCLENBQXFCLFFBQXJCLEVBQStCLHFCQUEvQixFQUFzRG5FLFVBQVUsQ0FBQ2xpQixLQUFqRTtBQUNBakssY0FBTSxDQUFDaXNCLE1BQVAsQ0FBY0ssTUFBZCxDQUFxQmxmLG9CQUFyQixDQUEwQytlLFVBQVUsQ0FBQ2xpQixLQUFyRCxFQUE0RCxLQUE1RDs7QUFDQSxZQUFHa2lCLFVBQVUsQ0FBQ2xpQixLQUFYLENBQWlCekksSUFBakIsSUFBeUIsS0FBNUIsRUFBbUM7QUFDakMsY0FBSTIwQixTQUFTLEdBQUc7QUFDZDMwQixnQkFBSSxFQUFFMnFCLFVBQVUsQ0FBQ2xpQixLQUFYLENBQWlCekksSUFEVDtBQUVkK0YsZ0JBQUksRUFBRTRrQixVQUFVLENBQUNsaUIsS0FBWCxDQUFpQjFDLElBRlQ7QUFHZE4scUJBQVMsRUFBRyxJQUFJMEcsSUFBSixFQUFELENBQWFDLE9BQWI7QUFIRyxXQUFoQjtBQU1BLGNBQUlrVixjQUFjLEdBQUdrVCxHQUFHLENBQUNDLFlBQUosQ0FBaUJHLGNBQXRDO0FBQ0F0VCx3QkFBYyxDQUFDMFEsVUFBZixHQUE0QjJDLFNBQTVCO0FBQ0FuMkIsZ0JBQU0sQ0FBQ2lCLFFBQVAsQ0FBZ0JxdkIsSUFBaEIsQ0FBcUIsUUFBckIsRUFBK0IsaUJBQS9CLEVBQWtENkYsU0FBbEQ7QUFDQW4yQixnQkFBTSxDQUFDaXNCLE1BQVAsQ0FBY0ssTUFBZCxDQUFxQjllLG9CQUFyQixDQUEwQzJvQixTQUExQyxFQVZpQyxDQVlqQzs7QUFDQSxjQUFHclQsY0FBYyxDQUFDMlEsZ0JBQWxCLEVBQW9DO0FBQ2xDenpCLGtCQUFNLENBQUNpc0IsTUFBUCxDQUFjSyxNQUFkLENBQXFCdmUsb0JBQXJCLENBQTBDb29CLFNBQTFDLEVBQXFEclQsY0FBYyxDQUFDMlEsZ0JBQXBFO0FBQ0EzUSwwQkFBYyxDQUFDMlEsZ0JBQWYsR0FBa0MsQ0FBbEM7QUFDRCxXQWhCZ0MsQ0FrQmpDOzs7QUFDQSxjQUFHM1EsY0FBYyxDQUFDOFIsY0FBbEIsRUFBa0M7QUFDaEM1MEIsa0JBQU0sQ0FBQ2lzQixNQUFQLENBQWNLLE1BQWQsQ0FBcUJ0a0IsWUFBckIsQ0FBa0NtdUIsU0FBUyxDQUFDNXVCLElBQTVDLEVBQWtELGVBQWxELEVBQW1FdWIsY0FBYyxDQUFDOFIsY0FBbEY7QUFDQTlSLDBCQUFjLENBQUM4UixjQUFmLEdBQWdDLENBQWhDO0FBQ0QsV0F0QmdDLENBd0JqQzs7O0FBQ0FodkIsV0FBQyxDQUFDeUcsSUFBRixDQUFPeVcsY0FBYyxDQUFDcVIsa0JBQXRCLEVBQTBDLFVBQVMzdEIsS0FBVCxFQUFnQmdDLEdBQWhCLEVBQXFCO0FBQzdEeEksa0JBQU0sQ0FBQ2lzQixNQUFQLENBQWNLLE1BQWQsQ0FBcUJ0ZSxnQkFBckIsQ0FBc0Ntb0IsU0FBdEMsRUFBaUQzdEIsR0FBakQsRUFBc0RoQyxLQUF0RDtBQUNELFdBRkQsRUF6QmlDLENBNkJqQzs7O0FBQ0FaLFdBQUMsQ0FBQ3lHLElBQUYsQ0FBT3lXLGNBQWMsQ0FBQzRRLFFBQXRCLEVBQWdDLFVBQVNsdEIsS0FBVCxFQUFnQmdDLEdBQWhCLEVBQXFCO0FBQ25EeEksa0JBQU0sQ0FBQ2lzQixNQUFQLENBQWNLLE1BQWQsQ0FBcUJ0a0IsWUFBckIsQ0FBa0NtdUIsU0FBUyxDQUFDNXVCLElBQTVDLEVBQWtEaUIsR0FBbEQsRUFBdURoQyxLQUF2RDtBQUNELFdBRkQ7QUFHRDtBQUNGLE9BdkNELE1BdUNPO0FBQ0x4RyxjQUFNLENBQUNpQixRQUFQLENBQWdCcXZCLElBQWhCLENBQXFCLFFBQXJCLEVBQStCLHdCQUEvQixFQUF5RG5FLFVBQVUsQ0FBQ2xpQixLQUFwRTtBQUNBakssY0FBTSxDQUFDaXNCLE1BQVAsQ0FBY0ssTUFBZCxDQUFxQmxmLG9CQUFyQixDQUEwQytlLFVBQVUsQ0FBQ2xpQixLQUFyRCxFQUE0RCxJQUE1RDtBQUNEO0FBQ0Y7O0FBRUQsV0FBTytyQixHQUFQO0FBQ0QsR0FwREQ7QUFxREQsQ0F6REQsQzs7Ozs7Ozs7Ozs7QUM1SkFLLGdCQUFnQixHQUFHLFlBQVc7QUFDNUIsTUFBSUMsb0JBQW9CLEdBQUdDLFNBQVMsQ0FBQ0MsWUFBckM7O0FBRUFELFdBQVMsQ0FBQ0MsWUFBVixHQUF5QixVQUFTdHRCLEdBQVQsRUFBYztBQUNyQyxRQUFJdXRCLFNBQVMsR0FBR0gsb0JBQW9CLENBQUNwdEIsR0FBRCxDQUFwQztBQUNBLFFBQUl3dEIsT0FBTyxHQUFHM0wsTUFBTSxDQUFDQyxVQUFQLENBQWtCeUwsU0FBbEIsRUFBNkIsTUFBN0IsQ0FBZDs7QUFFQSxRQUFJdEssVUFBVSxHQUFHbnNCLE1BQU0sQ0FBQ2d2QixRQUFQLENBQWdCLElBQWhCLEVBQXNCLElBQXRCLENBQWpCOztBQUVBLFFBQUc3QyxVQUFVLElBQUksQ0FBQ25zQixNQUFNLENBQUNtaEIsR0FBUCxDQUFXK0ssVUFBN0IsRUFBeUM7QUFDdkMsVUFBR0MsVUFBVSxDQUFDbGlCLEtBQVgsQ0FBaUJ6SSxJQUFqQixLQUEwQixRQUE3QixFQUF1QztBQUNyQ3hCLGNBQU0sQ0FBQ2lzQixNQUFQLENBQWMxbEIsT0FBZCxDQUFzQjZCLFlBQXRCLENBQW1DK2pCLFVBQVUsQ0FBQ2xpQixLQUFYLENBQWlCMUMsSUFBcEQsRUFBMERtdkIsT0FBMUQ7QUFDRDs7QUFFRCxhQUFPRCxTQUFQO0FBQ0QsS0Fab0MsQ0FjckM7QUFDQTs7O0FBQ0EsUUFBR3oyQixNQUFNLENBQUNtaEIsR0FBUCxDQUFXK0ssVUFBZCxFQUEwQjtBQUN4QixVQUFHbHNCLE1BQU0sQ0FBQ21oQixHQUFQLENBQVcrSyxVQUFYLENBQXNCa0QsWUFBekIsRUFBc0M7QUFDcENwdkIsY0FBTSxDQUFDaXNCLE1BQVAsQ0FBY0ssTUFBZCxDQUFxQmxrQixZQUFyQixDQUFrQ3BJLE1BQU0sQ0FBQ21oQixHQUFQLENBQVcrSyxVQUFYLENBQXNCdGlCLEtBQXhELEVBQStELGFBQS9ELEVBQThFOHNCLE9BQTlFO0FBQ0EsZUFBT0QsU0FBUDtBQUNEOztBQUNEejJCLFlBQU0sQ0FBQ2lzQixNQUFQLENBQWNLLE1BQWQsQ0FBcUJsa0IsWUFBckIsQ0FBa0NwSSxNQUFNLENBQUNtaEIsR0FBUCxDQUFXK0ssVUFBWCxDQUFzQnRpQixLQUF4RCxFQUErRCxVQUEvRCxFQUEyRThzQixPQUEzRTtBQUNBLGFBQU9ELFNBQVA7QUFDRDs7QUFFRHoyQixVQUFNLENBQUNpc0IsTUFBUCxDQUFjMWxCLE9BQWQsQ0FBc0I2QixZQUF0QixDQUFtQyx5QkFBbkMsRUFBOERzdUIsT0FBOUQ7QUFDQSxXQUFPRCxTQUFQO0FBQ0QsR0EzQkQ7QUE0QkQsQ0EvQkQsQzs7Ozs7Ozs7Ozs7QUNBQSxJQUFJRSxVQUFKO0FBQWV6b0IsTUFBTSxDQUFDQyxJQUFQLENBQVksa0JBQVosRUFBK0I7QUFBQ3dvQixZQUFVLENBQUN2b0IsQ0FBRCxFQUFHO0FBQUN1b0IsY0FBVSxHQUFDdm9CLENBQVg7QUFBYTs7QUFBNUIsQ0FBL0IsRUFBNkQsQ0FBN0Q7QUFBZ0UsSUFBSXdvQixjQUFKO0FBQW1CMW9CLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGtCQUFaLEVBQStCO0FBQUN5b0IsZ0JBQWMsQ0FBQ3hvQixDQUFELEVBQUc7QUFBQ3dvQixrQkFBYyxHQUFDeG9CLENBQWY7QUFBaUI7O0FBQXBDLENBQS9CLEVBQXFFLENBQXJFO0FBQXdFLElBQUl5b0IsTUFBSjtBQUFXM29CLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFNBQVosRUFBc0I7QUFBQzBvQixRQUFNLENBQUN6b0IsQ0FBRCxFQUFHO0FBQUN5b0IsVUFBTSxHQUFDem9CLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEIsRUFBNEMsQ0FBNUM7QUFBK0MsSUFBSTBvQixVQUFKO0FBQWU1b0IsTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDMm9CLFlBQVUsQ0FBQzFvQixDQUFELEVBQUc7QUFBQzBvQixjQUFVLEdBQUMxb0IsQ0FBWDtBQUFhOztBQUE1QixDQUExQixFQUF3RCxDQUF4RDtBQUEyRCxJQUFJMm9CLFdBQUo7QUFBZ0I3b0IsTUFBTSxDQUFDQyxJQUFQLENBQVksbUJBQVosRUFBZ0M7QUFBQzRvQixhQUFXLENBQUMzb0IsQ0FBRCxFQUFHO0FBQUMyb0IsZUFBVyxHQUFDM29CLENBQVo7QUFBYzs7QUFBOUIsQ0FBaEMsRUFBZ0UsQ0FBaEU7QUFBbUUsSUFBSTRvQixVQUFKO0FBQWU5b0IsTUFBTSxDQUFDQyxJQUFQLENBQVksWUFBWixFQUF5QjtBQUFDNm9CLFlBQVUsQ0FBQzVvQixDQUFELEVBQUc7QUFBQzRvQixjQUFVLEdBQUM1b0IsQ0FBWDtBQUFhOztBQUE1QixDQUF6QixFQUF1RCxDQUF2RDtBQU9oWixJQUFJNm9CLFlBQVksR0FBRyxLQUFuQjs7QUFDQWozQixNQUFNLENBQUNrM0IsbUJBQVAsR0FBNkIsVUFBUzkwQixRQUFULEVBQW1CO0FBQzlDLE1BQUc2MEIsWUFBSCxFQUFpQjtBQUNmNzBCLFlBQVE7QUFDUjtBQUNEOztBQUVENjBCLGNBQVksR0FBRyxJQUFmO0FBQ0FELFlBQVU7QUFDVlgsa0JBQWdCO0FBQ2hCTSxZQUFVO0FBQ1ZDLGdCQUFjO0FBQ2RFLFlBQVU7QUFDVkQsUUFBTTtBQUNORSxhQUFXO0FBRVhyQixTQUFPLENBQUN5QixPQUFSLENBQWdCLFlBQVc7QUFDekI7QUFDQWxILGNBQVUsQ0FBQ3lGLE9BQU8sQ0FBQzBCLE1BQVIsQ0FBZW56QixTQUFoQixDQUFWO0FBQ0F3c0IsZUFBVyxDQUFDaUYsT0FBTyxDQUFDMkIsT0FBUixDQUFnQnB6QixTQUFqQixDQUFYO0FBQ0FpdUIsb0JBQWdCLENBQUN3RCxPQUFPLENBQUM0QixZQUFSLENBQXFCcnpCLFNBQXRCLENBQWhCOztBQUVBLFFBQUd5eEIsT0FBTyxDQUFDNkIsZ0JBQVgsRUFBNkI7QUFDM0J2RSw0QkFBc0IsQ0FBQzBDLE9BQU8sQ0FBQzZCLGdCQUFSLENBQXlCdHpCLFNBQTFCLENBQXRCO0FBQ0Q7O0FBRUQsUUFBR3l4QixPQUFPLENBQUM4QixrQkFBWCxFQUErQjtBQUM3QmpELDhCQUF3QixDQUFDbUIsT0FBTyxDQUFDOEIsa0JBQVIsQ0FBMkJ2ekIsU0FBNUIsQ0FBeEI7QUFDRDs7QUFFRCxRQUFHeXhCLE9BQU8sQ0FBQytCLFdBQVgsRUFBd0I7QUFDdEI1QyxxQkFBZSxDQUFDYSxPQUFPLENBQUMrQixXQUFSLENBQW9CeHpCLFNBQXJCLENBQWY7QUFDRDs7QUFFRHV4Qiw0QkFBd0I7QUFDeEJrQyxlQUFXO0FBRVhDLGFBQVM7QUFDVHYxQixZQUFRO0FBQ1QsR0F2QkQ7QUF3QkQsQ0F2Q0QsQyxDQXlDQTtBQUNBO0FBQ0E7OztBQUNBcEMsTUFBTSxDQUFDazNCLG1CQUFQLENBQTJCLFlBQVc7QUFDcEMvekIsU0FBTyxDQUFDNFgsR0FBUixDQUFZLDRDQUFaO0FBQ0QsQ0FGRCxFOzs7Ozs7Ozs7OztBQ3BEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk2YyxZQUFZLEdBQUdDLGNBQWMsQ0FBQ0Msc0JBQWYsQ0FBc0M3ekIsU0FBdEMsQ0FBZ0Q4ekIsSUFBbkU7O0FBQ0FGLGNBQWMsQ0FBQ0Msc0JBQWYsQ0FBc0M3ekIsU0FBdEMsQ0FBZ0Q4ekIsSUFBaEQsR0FBdUQsU0FBU0EsSUFBVCxDQUFjeHdCLElBQWQsRUFBb0I7QUFDekUsTUFBSW9FLElBQUksR0FBRyxJQUFYO0FBQ0EsTUFBSXFxQixHQUFHLEdBQUc0QixZQUFZLENBQUMzaUIsSUFBYixDQUFrQnRKLElBQWxCLEVBQXdCcEUsSUFBeEIsQ0FBVjs7QUFFQTNCLEdBQUMsQ0FBQ3lHLElBQUYsQ0FBTzJwQixHQUFQLEVBQVksVUFBUzNkLEVBQVQsRUFBYWxYLENBQWIsRUFBZ0I7QUFDMUI7QUFDQTtBQUNBO0FBQ0EsUUFBR3dLLElBQUksQ0FBQ3FzQixLQUFMLENBQVc3MkIsQ0FBWCxDQUFILEVBQWtCO0FBQ2hCNjBCLFNBQUcsQ0FBQzcwQixDQUFELENBQUgsR0FBUyxZQUFXO0FBQ2xCb2xCLGFBQUssQ0FBQ3RpQixTQUFOLENBQWdCakQsT0FBaEIsQ0FBd0JpVSxJQUF4QixDQUE2QmlGLFNBQTdCLEVBQXdDM1MsSUFBeEM7QUFDQSxlQUFPeVIsY0FBYyxDQUFDck4sSUFBSSxDQUFDcXNCLEtBQU4sRUFBYXJzQixJQUFJLENBQUNxc0IsS0FBTCxDQUFXNzJCLENBQVgsQ0FBYixFQUE0QitZLFNBQTVCLENBQXJCO0FBQ0QsT0FIRDtBQUlEO0FBQ0YsR0FWRDs7QUFZQSxTQUFPOGIsR0FBUDtBQUNELENBakJELEMsQ0FtQkE7OztBQUNBLFNBQVNpQyxtQkFBVCxHQUErQjtBQUM3QixRQUFNQyxTQUFTLEdBQUcsT0FBT0MsS0FBUCxLQUFpQixXQUFqQixHQUErQkEsS0FBSyxDQUFDdFgsVUFBckMsR0FBa0QxZ0IsTUFBTSxDQUFDMGdCLFVBQTNFO0FBQ0EsUUFBTXdHLElBQUksR0FBRyxJQUFJNlEsU0FBSixDQUFjLGtCQUFrQmhnQixNQUFNLENBQUN6USxFQUFQLEVBQWhDLENBQWIsQ0FGNkIsQ0FHN0I7O0FBQ0E0ZixNQUFJLENBQUMrUSxPQUFMO0FBRUEsUUFBTUMsTUFBTSxHQUFHaFIsSUFBSSxDQUFDbkosSUFBTCxFQUFmO0FBQ0FtYSxRQUFNLENBQUNDLEtBQVA7QUFDQSxTQUFPRCxNQUFNLENBQUNFLGtCQUFQLENBQTBCaGhCLFdBQWpDO0FBQ0Q7O0FBRURtZ0IsV0FBVyxHQUFHLFNBQVNBLFdBQVQsR0FBdUI7QUFDbkMsTUFBSWpDLG9CQUFvQixHQUFHQyxPQUFPLENBQUNDLGVBQVIsQ0FBd0IxeEIsU0FBbkQsQ0FEbUMsQ0FFbkM7QUFDQTs7QUFDQSxHQUFDLE1BQUQsRUFBUyxRQUFULEVBQW1CLFFBQW5CLEVBQTZCLFFBQTdCLEVBQXVDLGNBQXZDLEVBQXVELFlBQXZELEVBQXFFL0MsT0FBckUsQ0FBNkUsVUFBU3MzQixJQUFULEVBQWU7QUFDMUYsUUFBSTFGLFlBQVksR0FBRzJDLG9CQUFvQixDQUFDK0MsSUFBRCxDQUF2Qzs7QUFDQS9DLHdCQUFvQixDQUFDK0MsSUFBRCxDQUFwQixHQUE2QixVQUFTcFIsUUFBVCxFQUFtQnpHLFFBQW5CLEVBQTZCOFgsR0FBN0IsRUFBa0N4NEIsT0FBbEMsRUFBMkM7QUFDdEUsVUFBSWlDLE9BQU8sR0FBRztBQUNabWxCLFlBQUksRUFBRUQsUUFETTtBQUVab1IsWUFBSSxFQUFFQTtBQUZNLE9BQWQ7O0FBS0EsVUFBR0EsSUFBSSxJQUFJLFFBQVgsRUFBcUIsQ0FDbkI7QUFDRCxPQUZELE1BRU8sSUFBR0EsSUFBSSxJQUFJLGNBQVIsSUFBMEJBLElBQUksSUFBSSxZQUFyQyxFQUFtRDtBQUN4RDtBQUNBdDJCLGVBQU8sQ0FBQ29DLEtBQVIsR0FBZ0JULElBQUksQ0FBQ0MsU0FBTCxDQUFlNmMsUUFBZixDQUFoQjtBQUNELE9BSE0sTUFHQSxJQUFHNlgsSUFBSSxJQUFJLFFBQVIsSUFBb0J2NEIsT0FBcEIsSUFBK0JBLE9BQU8sQ0FBQ3k0QixNQUExQyxFQUFrRDtBQUN2RHgyQixlQUFPLENBQUNzMkIsSUFBUixHQUFlLFFBQWY7QUFDQXQyQixlQUFPLENBQUN5ZSxRQUFSLEdBQW1COWMsSUFBSSxDQUFDQyxTQUFMLENBQWU2YyxRQUFmLENBQW5CO0FBQ0QsT0FITSxNQUdBO0FBQ0w7QUFDQXplLGVBQU8sQ0FBQ3llLFFBQVIsR0FBbUI5YyxJQUFJLENBQUNDLFNBQUwsQ0FBZTZjLFFBQWYsQ0FBbkI7QUFDRDs7QUFFRCxVQUFJd0wsVUFBVSxHQUFHbnNCLE1BQU0sQ0FBQ2d2QixRQUFQLEVBQWpCOztBQUNBLFVBQUc3QyxVQUFILEVBQWU7QUFDYixZQUFJd00sT0FBTyxHQUFHMzRCLE1BQU0sQ0FBQ3ltQixNQUFQLENBQWMzQyxLQUFkLENBQW9CcUksVUFBVSxDQUFDbGlCLEtBQS9CLEVBQXNDLElBQXRDLEVBQTRDL0gsT0FBNUMsQ0FBZDtBQUNELE9BdEJxRSxDQXdCdEU7QUFDQTtBQUNBOzs7QUFDQSxVQUFHO0FBQ0QsWUFBSTh6QixHQUFHLEdBQUdsRCxZQUFZLENBQUMxeEIsS0FBYixDQUFtQixJQUFuQixFQUF5QjhZLFNBQXpCLENBQVYsQ0FEQyxDQUVEOztBQUNBLFlBQUkwZSxVQUFVLEdBQUcsRUFBakI7O0FBRUEsWUFBR3BnQixpQkFBaUIsQ0FBQzBCLFNBQUQsQ0FBcEIsRUFBaUM7QUFDL0IwZSxvQkFBVSxDQUFDQyxLQUFYLEdBQW1CLElBQW5CO0FBQ0Q7O0FBRUQsWUFBR0wsSUFBSSxJQUFJLFFBQVgsRUFBcUI7QUFDbkI7QUFDQTtBQUNBLGNBQUd2NEIsT0FBTyxJQUFJQSxPQUFPLENBQUN5NEIsTUFBbkIsSUFBNkIsT0FBTzFDLEdBQVAsSUFBYyxRQUE5QyxFQUF3RDtBQUN0RDRDLHNCQUFVLENBQUNFLFdBQVgsR0FBeUI5QyxHQUFHLENBQUMrQyxjQUE3QjtBQUNBSCxzQkFBVSxDQUFDSSxVQUFYLEdBQXdCaEQsR0FBRyxDQUFDZ0QsVUFBNUI7QUFDRCxXQUhELE1BR087QUFDTEosc0JBQVUsQ0FBQ0UsV0FBWCxHQUF5QjlDLEdBQXpCO0FBQ0Q7QUFDRixTQVRELE1BU08sSUFBR3dDLElBQUksSUFBSSxRQUFYLEVBQXFCO0FBQzFCSSxvQkFBVSxDQUFDSyxXQUFYLEdBQXlCakQsR0FBekI7QUFDRDs7QUFFRCxZQUFHMkMsT0FBSCxFQUFZO0FBQ1YzNEIsZ0JBQU0sQ0FBQ3ltQixNQUFQLENBQWMvQixRQUFkLENBQXVCeUgsVUFBVSxDQUFDbGlCLEtBQWxDLEVBQXlDMHVCLE9BQXpDLEVBQWtEQyxVQUFsRDtBQUNEO0FBQ0YsT0F6QkQsQ0F5QkUsT0FBTS96QixFQUFOLEVBQVU7QUFDVixZQUFHOHpCLE9BQUgsRUFBWTtBQUNWMzRCLGdCQUFNLENBQUN5bUIsTUFBUCxDQUFjL0IsUUFBZCxDQUF1QnlILFVBQVUsQ0FBQ2xpQixLQUFsQyxFQUF5QzB1QixPQUF6QyxFQUFrRDtBQUFDajNCLGVBQUcsRUFBRW1ELEVBQUUsQ0FBQ3BEO0FBQVQsV0FBbEQ7QUFDRDs7QUFDRCxjQUFNb0QsRUFBTjtBQUNEOztBQUVELGFBQU9teEIsR0FBUDtBQUNELEtBNUREO0FBNkRELEdBL0REO0FBaUVBLE1BQUlrRCxXQUFXLEdBQUd4RCxPQUFPLENBQUN5RCxXQUFSLENBQW9CbDFCLFNBQXRDO0FBQ0EsR0FBQyxTQUFELEVBQVksS0FBWixFQUFtQixPQUFuQixFQUE0QixPQUE1QixFQUFxQyxnQkFBckMsRUFBdUQsU0FBdkQsRUFBa0UvQyxPQUFsRSxDQUEwRSxVQUFTTSxJQUFULEVBQWU7QUFDdkYsUUFBSXN4QixZQUFZLEdBQUdvRyxXQUFXLENBQUMxM0IsSUFBRCxDQUE5Qjs7QUFDQTAzQixlQUFXLENBQUMxM0IsSUFBRCxDQUFYLEdBQW9CLFlBQVc7QUFDN0IsVUFBSTRlLGlCQUFpQixHQUFHLEtBQUtrVCxrQkFBN0I7QUFDQSxVQUFJcHhCLE9BQU8sR0FBR3NELE1BQU0sQ0FBQzJQLE1BQVAsQ0FBYzNQLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjLElBQWQsQ0FBZCxFQUFtQztBQUMvQzRoQixZQUFJLEVBQUVqSCxpQkFBaUIsQ0FBQzJTLGNBRHVCO0FBRS9DcFMsZ0JBQVEsRUFBRTljLElBQUksQ0FBQ0MsU0FBTCxDQUFlc2MsaUJBQWlCLENBQUNPLFFBQWpDLENBRnFDO0FBRy9DNlgsWUFBSSxFQUFFaDNCLElBSHlDO0FBSS9DNjJCLGNBQU0sRUFBRTtBQUp1QyxPQUFuQyxDQUFkOztBQU9BLFVBQUdqWSxpQkFBaUIsQ0FBQ25nQixPQUFyQixFQUE4QjtBQUM1QixZQUFJbTVCLGFBQWEsR0FBR3h6QixDQUFDLENBQUM2WixJQUFGLENBQU9XLGlCQUFpQixDQUFDbmdCLE9BQXpCLEVBQWtDLENBQUMsUUFBRCxFQUFXLE1BQVgsRUFBbUIsT0FBbkIsQ0FBbEMsQ0FBcEI7O0FBQ0EsYUFBSSxJQUFJNkcsS0FBUixJQUFpQnN5QixhQUFqQixFQUFnQztBQUM5QixjQUFJenhCLEtBQUssR0FBR3l4QixhQUFhLENBQUN0eUIsS0FBRCxDQUF6Qjs7QUFDQSxjQUFHLE9BQU9hLEtBQVAsSUFBZ0IsUUFBbkIsRUFBNkI7QUFDM0JBLGlCQUFLLEdBQUc5RCxJQUFJLENBQUNDLFNBQUwsQ0FBZTZELEtBQWYsQ0FBUjtBQUNEOztBQUNEekYsaUJBQU8sQ0FBQzRFLEtBQUQsQ0FBUCxHQUFpQmEsS0FBakI7QUFDRDtBQUNGOztBQUVELFVBQUl3a0IsVUFBVSxHQUFHbnNCLE1BQU0sQ0FBQ2d2QixRQUFQLEVBQWpCOztBQUNBLFVBQUlxSyx1QkFBSjs7QUFDQSxVQUFHbE4sVUFBSCxFQUFlO0FBQ2IsWUFBSXdNLE9BQU8sR0FBRzM0QixNQUFNLENBQUN5bUIsTUFBUCxDQUFjM0MsS0FBZCxDQUFvQnFJLFVBQVUsQ0FBQ2xpQixLQUEvQixFQUFzQyxJQUF0QyxFQUE0Qy9ILE9BQTVDLENBQWQ7QUFFQW0zQiwrQkFBdUIsR0FBR2xOLFVBQVUsQ0FBQ21OLGVBQXJDOztBQUNBLFlBQUk5M0IsSUFBSSxLQUFLLFNBQVQsSUFBc0JBLElBQUksS0FBSyxLQUFuQyxFQUEwQztBQUN4QzJxQixvQkFBVSxDQUFDbU4sZUFBWCxHQUE2QixJQUE3QjtBQUNEO0FBQ0Y7O0FBRUQsVUFBRztBQUNELFlBQUl0RCxHQUFHLEdBQUdsRCxZQUFZLENBQUMxeEIsS0FBYixDQUFtQixJQUFuQixFQUF5QjhZLFNBQXpCLENBQVY7QUFFQSxZQUFJcWYsT0FBTyxHQUFHLEVBQWQ7O0FBQ0EsWUFBRy8zQixJQUFJLElBQUksZ0JBQVIsSUFBNEJBLElBQUksSUFBSSxTQUF2QyxFQUFrRDtBQUNoRCxjQUFJc2hCLGNBQUo7QUFDQXlXLGlCQUFPLENBQUNDLEtBQVIsR0FBZ0IsS0FBaEIsQ0FGZ0QsQ0FHaEQ7O0FBQ0FELGlCQUFPLENBQUNFLG1CQUFSLEdBQThCekQsR0FBRyxDQUFDZCxvQkFBbEM7QUFDQXFFLGlCQUFPLENBQUNHLFdBQVIsR0FBc0IxRCxHQUFHLENBQUNaLFlBQTFCO0FBQ0FtRSxpQkFBTyxDQUFDSSxrQkFBUixHQUE2QjNELEdBQUcsQ0FBQ1QsbUJBQWpDOztBQUVBLGNBQUdTLEdBQUcsQ0FBQ0MsWUFBUCxFQUFxQjtBQUNuQjtBQUNBblQsMEJBQWMsR0FBR2tULEdBQUcsQ0FBQ0MsWUFBSixDQUFpQkcsY0FBbEM7O0FBQ0EsZ0JBQUd0VCxjQUFILEVBQW1CO0FBQ2pCQSw0QkFBYyxHQUFHa1QsR0FBRyxDQUFDQyxZQUFKLENBQWlCRyxjQUFsQztBQUNBLGtCQUFJd0QsbUJBQW1CLEdBQUc5VyxjQUFjLENBQUN2TCxXQUF6QztBQUNBLGtCQUFJc2lCLFNBQVMsR0FBRyxPQUFPRCxtQkFBbUIsQ0FBQ3JYLGVBQTNCLElBQThDLFVBQTlEO0FBQ0FnWCxxQkFBTyxDQUFDQyxLQUFSLEdBQWdCSyxTQUFoQjtBQUNBLGtCQUFJNXhCLElBQUksR0FBRyxDQUFYOztBQUNBK3RCLGlCQUFHLENBQUNDLFlBQUosQ0FBaUI2RCxNQUFqQixDQUF3QkMsSUFBeEIsQ0FBNkI3NEIsT0FBN0IsQ0FBcUMsWUFBVztBQUFDK0csb0JBQUk7QUFBRyxlQUF4RDs7QUFDQXN4QixxQkFBTyxDQUFDUyxjQUFSLEdBQXlCL3hCLElBQXpCLENBUGlCLENBU2pCOztBQUNBLGtCQUFHLENBQUMrdEIsR0FBRyxDQUFDZCxvQkFBUixFQUE4QjtBQUM1QnFFLHVCQUFPLENBQUNVLGtCQUFSLEdBQTZCblgsY0FBYyxDQUFDb1gsYUFBNUM7QUFDRDtBQUNGO0FBQ0Y7O0FBRUQsY0FBRyxDQUFDWCxPQUFPLENBQUNDLEtBQVosRUFBbUI7QUFDakI7QUFDQSxnQkFBSVcsVUFBVSxHQUFHbjZCLE1BQU0sQ0FBQzZpQixlQUFQLENBQXVCekMsaUJBQXZCLEVBQTBDMEMsY0FBMUMsQ0FBakI7QUFDQXlXLG1CQUFPLENBQUNhLFdBQVIsR0FBc0JELFVBQVUsQ0FBQzdaLElBQWpDO0FBQ0FpWixtQkFBTyxDQUFDYyxhQUFSLEdBQXdCRixVQUFVLENBQUM1WixNQUFuQztBQUNBZ1osbUJBQU8sQ0FBQ2UsZUFBUixHQUEwQkgsVUFBVSxDQUFDM1osUUFBckM7QUFDRDtBQUNGLFNBbENELE1Ba0NPLElBQUdoZixJQUFJLElBQUksT0FBUixJQUFtQkEsSUFBSSxJQUFJLEtBQTlCLEVBQW9DO0FBQ3pDO0FBRUErM0IsaUJBQU8sQ0FBQ2dCLFdBQVIsR0FBc0J2RSxHQUFHLENBQUNsMEIsTUFBMUI7O0FBRUEsY0FBR04sSUFBSSxJQUFJLE9BQVgsRUFBb0I7QUFDbEIsZ0JBQUk2bEIsSUFBSSxHQUFHakgsaUJBQWlCLENBQUMyUyxjQUE3QjtBQUNBLGdCQUFJdkksS0FBSyxHQUFHcEssaUJBQWlCLENBQUNPLFFBQTlCO0FBQ0EsZ0JBQUk4SixJQUFJLEdBQUdySyxpQkFBaUIsQ0FBQ25nQixPQUE3QjtBQUNBLGdCQUFJc3pCLE9BQU8sR0FBR3Z6QixNQUFNLENBQUNpVSxVQUFQLENBQWtCc1csT0FBbEIsQ0FBMEJsRCxJQUExQixFQUFnQ21ELEtBQWhDLEVBQXVDQyxJQUF2QyxFQUE2Q3VMLEdBQTdDLElBQW9EQSxHQUFHLENBQUNsMEIsTUFBdEU7QUFDQXkzQixtQkFBTyxDQUFDaEcsT0FBUixHQUFrQkEsT0FBbEI7O0FBRUEsZ0JBQUdwSCxVQUFILEVBQWU7QUFDYixrQkFBR0EsVUFBVSxDQUFDbGlCLEtBQVgsQ0FBaUJ6SSxJQUFqQixLQUEwQixRQUE3QixFQUF1QztBQUNyQ3hCLHNCQUFNLENBQUNpc0IsTUFBUCxDQUFjMWxCLE9BQWQsQ0FBc0J5QixZQUF0QixDQUFtQ21rQixVQUFVLENBQUNsaUIsS0FBWCxDQUFpQjFDLElBQXBELEVBQTBEZ3NCLE9BQTFEO0FBQ0QsZUFGRCxNQUVPLElBQUdwSCxVQUFVLENBQUNsaUIsS0FBWCxDQUFpQnpJLElBQWpCLEtBQTBCLEtBQTdCLEVBQW9DO0FBQ3pDeEIsc0JBQU0sQ0FBQ2lzQixNQUFQLENBQWNLLE1BQWQsQ0FBcUJ0a0IsWUFBckIsQ0FBa0Nta0IsVUFBVSxDQUFDbGlCLEtBQVgsQ0FBaUIxQyxJQUFuRCxFQUF5RCxlQUF6RCxFQUEwRWdzQixPQUExRTtBQUNEOztBQUVEcEgsd0JBQVUsQ0FBQ21OLGVBQVgsR0FBNkJELHVCQUE3QjtBQUNELGFBUkQsTUFRTztBQUNMO0FBQ0FyNUIsb0JBQU0sQ0FBQ2lzQixNQUFQLENBQWMxbEIsT0FBZCxDQUFzQnlCLFlBQXRCLENBQW1DLHlCQUFuQyxFQUE4RHVyQixPQUE5RDtBQUNELGFBbEJpQixDQW9CbEI7O0FBQ0Q7QUFDRjs7QUFFRCxZQUFHb0YsT0FBSCxFQUFZO0FBQ1YzNEIsZ0JBQU0sQ0FBQ3ltQixNQUFQLENBQWMvQixRQUFkLENBQXVCeUgsVUFBVSxDQUFDbGlCLEtBQWxDLEVBQXlDMHVCLE9BQXpDLEVBQWtEWSxPQUFsRDtBQUNEOztBQUNELGVBQU92RCxHQUFQO0FBQ0QsT0F2RUQsQ0F1RUUsT0FBTW54QixFQUFOLEVBQVU7QUFDVixZQUFHOHpCLE9BQUgsRUFBWTtBQUNWMzRCLGdCQUFNLENBQUN5bUIsTUFBUCxDQUFjL0IsUUFBZCxDQUF1QnlILFVBQVUsQ0FBQ2xpQixLQUFsQyxFQUF5QzB1QixPQUF6QyxFQUFrRDtBQUFDajNCLGVBQUcsRUFBRW1ELEVBQUUsQ0FBQ3BEO0FBQVQsV0FBbEQ7QUFDRDs7QUFDRCxjQUFNb0QsRUFBTjtBQUNEO0FBQ0YsS0E1R0Q7QUE2R0QsR0EvR0Q7QUFpSEEsUUFBTTIxQixnQkFBZ0IsR0FBR3ZDLG1CQUFtQixFQUE1QztBQUNBLE1BQUl3QyxjQUFjLEdBQUdELGdCQUFnQixDQUFDdjJCLFNBQWpCLENBQTJCeTJCLFdBQWhEOztBQUNBRixrQkFBZ0IsQ0FBQ3YyQixTQUFqQixDQUEyQnkyQixXQUEzQixHQUF5QyxZQUFZO0FBQ25ELFFBQUl2TyxVQUFVLEdBQUduc0IsTUFBTSxDQUFDZ3ZCLFFBQVAsRUFBakI7O0FBQ0EsUUFBSTJMLFdBQVcsR0FBR3hPLFVBQVUsSUFBSUEsVUFBVSxDQUFDbU4sZUFBM0M7O0FBQ0EsUUFBR3FCLFdBQUgsRUFBaUI7QUFDZixVQUFJN1csS0FBSyxHQUFHOWpCLE1BQU0sQ0FBQ3ltQixNQUFQLENBQWMzQyxLQUFkLENBQW9CcUksVUFBVSxDQUFDbGlCLEtBQS9CLEVBQXNDLElBQXRDLEVBQTRDO0FBQ3REdXVCLFlBQUksRUFBRSxhQURnRDtBQUV0RG5SLFlBQUksRUFBRSxLQUFLaU0sa0JBQUwsQ0FBd0JQO0FBRndCLE9BQTVDLENBQVo7QUFJRDs7QUFFRCxRQUFJdFgsTUFBTSxHQUFHZ2YsY0FBYyxDQUFDeGxCLElBQWYsQ0FBb0IsSUFBcEIsQ0FBYjs7QUFFQSxRQUFJMGxCLFdBQUosRUFBaUI7QUFDZjM2QixZQUFNLENBQUN5bUIsTUFBUCxDQUFjL0IsUUFBZCxDQUF1QnlILFVBQVUsQ0FBQ2xpQixLQUFsQyxFQUF5QzZaLEtBQXpDO0FBQ0Q7O0FBQ0QsV0FBT3JJLE1BQVA7QUFDRCxHQWhCRDtBQWlCRCxDQTFNRCxDOzs7Ozs7Ozs7OztBQ3ZDQSxJQUFJbWYsWUFBWSxHQUFHQyxJQUFJLENBQUM1bEIsSUFBeEI7O0FBRUE0bEIsSUFBSSxDQUFDNWxCLElBQUwsR0FBWSxVQUFTM08sTUFBVCxFQUFpQjBVLEdBQWpCLEVBQXNCO0FBQ2hDLE1BQUltUixVQUFVLEdBQUduc0IsTUFBTSxDQUFDZ3ZCLFFBQVAsRUFBakI7O0FBQ0EsTUFBRzdDLFVBQUgsRUFBZTtBQUNiLFFBQUl3TSxPQUFPLEdBQUczNEIsTUFBTSxDQUFDeW1CLE1BQVAsQ0FBYzNDLEtBQWQsQ0FBb0JxSSxVQUFVLENBQUNsaUIsS0FBL0IsRUFBc0MsTUFBdEMsRUFBOEM7QUFBQzNELFlBQU0sRUFBRUEsTUFBVDtBQUFpQjBVLFNBQUcsRUFBRUE7QUFBdEIsS0FBOUMsQ0FBZDtBQUNEOztBQUVELE1BQUk7QUFDRixRQUFJb1csUUFBUSxHQUFHd0osWUFBWSxDQUFDeDVCLEtBQWIsQ0FBbUIsSUFBbkIsRUFBeUI4WSxTQUF6QixDQUFmLENBREUsQ0FHRjtBQUNBOztBQUNBLFFBQUkwZSxVQUFVLEdBQUdwZ0IsaUJBQWlCLENBQUMwQixTQUFELENBQWpCLEdBQThCO0FBQUMyZSxXQUFLLEVBQUU7QUFBUixLQUE5QixHQUE2QztBQUFDdjFCLGdCQUFVLEVBQUU4dEIsUUFBUSxDQUFDOXRCO0FBQXRCLEtBQTlEOztBQUNBLFFBQUdxMUIsT0FBSCxFQUFZO0FBQ1YzNEIsWUFBTSxDQUFDeW1CLE1BQVAsQ0FBYy9CLFFBQWQsQ0FBdUJ5SCxVQUFVLENBQUNsaUIsS0FBbEMsRUFBeUMwdUIsT0FBekMsRUFBa0RDLFVBQWxEO0FBQ0Q7O0FBQ0QsV0FBT3hILFFBQVA7QUFDRCxHQVZELENBVUUsT0FBTXZzQixFQUFOLEVBQVU7QUFDVixRQUFHOHpCLE9BQUgsRUFBWTtBQUNWMzRCLFlBQU0sQ0FBQ3ltQixNQUFQLENBQWMvQixRQUFkLENBQXVCeUgsVUFBVSxDQUFDbGlCLEtBQWxDLEVBQXlDMHVCLE9BQXpDLEVBQWtEO0FBQUNqM0IsV0FBRyxFQUFFbUQsRUFBRSxDQUFDcEQ7QUFBVCxPQUFsRDtBQUNEOztBQUNELFVBQU1vRCxFQUFOO0FBQ0Q7QUFDRixDQXRCRCxDOzs7Ozs7Ozs7OztBQ0ZBLElBQUk0c0IsWUFBWSxHQUFHcUosS0FBSyxDQUFDNzRCLElBQXpCOztBQUVBNjRCLEtBQUssQ0FBQzc0QixJQUFOLEdBQWEsVUFBU2hDLE9BQVQsRUFBa0I7QUFDN0IsTUFBSWtzQixVQUFVLEdBQUduc0IsTUFBTSxDQUFDZ3ZCLFFBQVAsRUFBakI7O0FBQ0EsTUFBRzdDLFVBQUgsRUFBZTtBQUNiLFFBQUk1b0IsSUFBSSxHQUFHcUMsQ0FBQyxDQUFDNlosSUFBRixDQUFPeGYsT0FBUCxFQUFnQixNQUFoQixFQUF3QixJQUF4QixFQUE4QixJQUE5QixFQUFvQyxLQUFwQyxFQUEyQyxTQUEzQyxDQUFYOztBQUNBLFFBQUkwNEIsT0FBTyxHQUFHMzRCLE1BQU0sQ0FBQ3ltQixNQUFQLENBQWMzQyxLQUFkLENBQW9CcUksVUFBVSxDQUFDbGlCLEtBQS9CLEVBQXNDLE9BQXRDLEVBQStDMUcsSUFBL0MsQ0FBZDtBQUNEOztBQUNELE1BQUk7QUFDRixRQUFJeXlCLEdBQUcsR0FBR3ZFLFlBQVksQ0FBQ3hjLElBQWIsQ0FBa0IsSUFBbEIsRUFBd0JoVixPQUF4QixDQUFWOztBQUNBLFFBQUcwNEIsT0FBSCxFQUFZO0FBQ1YzNEIsWUFBTSxDQUFDeW1CLE1BQVAsQ0FBYy9CLFFBQWQsQ0FBdUJ5SCxVQUFVLENBQUNsaUIsS0FBbEMsRUFBeUMwdUIsT0FBekM7QUFDRDs7QUFDRCxXQUFPM0MsR0FBUDtBQUNELEdBTkQsQ0FNRSxPQUFNbnhCLEVBQU4sRUFBVTtBQUNWLFFBQUc4ekIsT0FBSCxFQUFZO0FBQ1YzNEIsWUFBTSxDQUFDeW1CLE1BQVAsQ0FBYy9CLFFBQWQsQ0FBdUJ5SCxVQUFVLENBQUNsaUIsS0FBbEMsRUFBeUMwdUIsT0FBekMsRUFBa0Q7QUFBQ2ozQixXQUFHLEVBQUVtRCxFQUFFLENBQUNwRDtBQUFULE9BQWxEO0FBQ0Q7O0FBQ0QsVUFBTW9ELEVBQU47QUFDRDtBQUNGLENBbEJELEM7Ozs7Ozs7Ozs7O0FDRkFxSixNQUFNLENBQUNxSyxNQUFQLENBQWM7QUFBQ3llLFlBQVUsRUFBQyxNQUFJQSxVQUFoQjtBQUEyQnpvQixpQkFBZSxFQUFDLE1BQUlBLGVBQS9DO0FBQStEQyxtQkFBaUIsRUFBQyxNQUFJQTtBQUFyRixDQUFkOztBQUFBLElBQUl1ZCxNQUFNLEdBQUd2ckIsR0FBRyxDQUFDQyxPQUFKLENBQVksUUFBWixDQUFiOztBQUNBLElBQUlzNkIsV0FBVyxHQUFHQyxNQUFNLEVBQXhCO0FBQ0EsSUFBSUMsWUFBWSxHQUFHRCxNQUFNLEVBQXpCO0FBRUEsSUFBSXJvQixZQUFZLEdBQUcsQ0FBbkI7QUFDQSxJQUFJdW9CLE9BQU8sR0FBRyxLQUFkOztBQUVPLFNBQVNsRSxVQUFULEdBQXNCO0FBQzNCLE1BQUlrRSxPQUFKLEVBQWE7QUFDWDtBQUNEOztBQUNEQSxTQUFPLEdBQUcsSUFBVjtBQUVBLE1BQUlDLGFBQWEsR0FBR3BQLE1BQU0sQ0FBQ3FQLEtBQTNCOztBQUNBclAsUUFBTSxDQUFDcVAsS0FBUCxHQUFlLFlBQVk7QUFDekIsUUFBSWpQLFVBQVUsR0FBR25zQixNQUFNLENBQUNndkIsUUFBUCxFQUFqQjs7QUFDQSxRQUFJN0MsVUFBSixFQUFnQjtBQUNkLFVBQUl3TSxPQUFPLEdBQUczNEIsTUFBTSxDQUFDeW1CLE1BQVAsQ0FBYzNDLEtBQWQsQ0FBb0JxSSxVQUFVLENBQUNsaUIsS0FBL0IsRUFBc0MsT0FBdEMsQ0FBZDs7QUFDQSxVQUFJMHVCLE9BQUosRUFBYTtBQUNYO0FBQ0E7QUFDQTtBQUNBNU0sY0FBTSxDQUFDb0QsT0FBUCxDQUFlNEwsV0FBZixJQUE4QnBDLE9BQTlCO0FBQ0Q7QUFDRjs7QUFFRCxXQUFPd0MsYUFBYSxFQUFwQjtBQUNELEdBYkQ7O0FBZUEsTUFBSUUsV0FBVyxHQUFHdFAsTUFBTSxDQUFDOW5CLFNBQVAsQ0FBaUI4cUIsR0FBbkM7QUFDQSxNQUFJdU0saUJBQWlCLEdBQUd2UCxNQUFNLENBQUM5bkIsU0FBUCxDQUFpQnMzQixTQUF6Qzs7QUFFQSxXQUFTQyxrQkFBVCxDQUE0QkMsS0FBNUIsRUFBbUM7QUFDakM7QUFDQTtBQUNBLFFBQUksQ0FBQ0EsS0FBSyxDQUFDM2IsT0FBUCxJQUFrQixDQUFDMmIsS0FBSyxDQUFDUixZQUFELENBQTVCLEVBQTRDO0FBQzFDdG9CLGtCQUFZLElBQUksQ0FBaEI7QUFDQThvQixXQUFLLENBQUNSLFlBQUQsQ0FBTCxHQUFzQixJQUF0QjtBQUNEO0FBQ0Y7O0FBRURsUCxRQUFNLENBQUM5bkIsU0FBUCxDQUFpQjhxQixHQUFqQixHQUF1QixVQUFVMk0sR0FBVixFQUFlO0FBQ3BDRixzQkFBa0IsQ0FBQyxJQUFELENBQWxCOztBQUVBLFFBQUksS0FBS1QsV0FBTCxDQUFKLEVBQXVCO0FBQ3JCLFVBQUk1TyxVQUFVLEdBQUduc0IsTUFBTSxDQUFDZ3ZCLFFBQVAsQ0FBZ0IsSUFBaEIsQ0FBakI7O0FBQ0EsVUFBSTdDLFVBQUosRUFBZ0I7QUFDZG5zQixjQUFNLENBQUN5bUIsTUFBUCxDQUFjL0IsUUFBZCxDQUF1QnlILFVBQVUsQ0FBQ2xpQixLQUFsQyxFQUF5QyxLQUFLOHdCLFdBQUwsQ0FBekM7QUFDQSxhQUFLQSxXQUFMLElBQW9CLElBQXBCO0FBQ0Q7QUFDRixLQU5ELE1BTU8sSUFBSSxDQUFDLEtBQUszTCxZQUFOLElBQXNCckQsTUFBTSxDQUFDb0QsT0FBN0IsSUFBd0NwRCxNQUFNLENBQUNvRCxPQUFQLENBQWVDLFlBQTNELEVBQXlFO0FBQzlFO0FBQ0E7QUFDQTtBQUNBLFdBQUtBLFlBQUwsR0FBb0JyRCxNQUFNLENBQUNvRCxPQUFQLENBQWVDLFlBQW5DO0FBQ0Q7O0FBRUQsUUFBSTNULE1BQUo7O0FBQ0EsUUFBSTtBQUNGQSxZQUFNLEdBQUc0ZixXQUFXLENBQUNwbUIsSUFBWixDQUFpQixJQUFqQixFQUF1QnltQixHQUF2QixDQUFUO0FBQ0QsS0FGRCxTQUVVO0FBQ1IsVUFBSSxDQUFDLEtBQUs1YixPQUFWLEVBQW1CO0FBQ2pCbk4sb0JBQVksSUFBSSxDQUFoQjtBQUNBLGFBQUtzb0IsWUFBTCxJQUFxQixLQUFyQjtBQUNEO0FBQ0Y7O0FBRUQsV0FBT3hmLE1BQVA7QUFDRCxHQTNCRDs7QUE2QkFzUSxRQUFNLENBQUM5bkIsU0FBUCxDQUFpQnMzQixTQUFqQixHQUE2QixVQUFVRyxHQUFWLEVBQWU7QUFDMUNGLHNCQUFrQixDQUFDLElBQUQsQ0FBbEIsQ0FEMEMsQ0FHMUM7QUFDQTtBQUNBOztBQUVBLFFBQUkvZixNQUFKOztBQUNBLFFBQUk7QUFDRkEsWUFBTSxHQUFHNmYsaUJBQWlCLENBQUNybUIsSUFBbEIsQ0FBdUIsSUFBdkIsRUFBNkJ5bUIsR0FBN0IsQ0FBVDtBQUNELEtBRkQsU0FFVTtBQUNSLFVBQUksQ0FBQyxLQUFLNWIsT0FBVixFQUFtQjtBQUNqQm5OLG9CQUFZLElBQUksQ0FBaEI7QUFDQSxhQUFLc29CLFlBQUwsSUFBcUIsS0FBckI7QUFDRDtBQUNGOztBQUVELFdBQU94ZixNQUFQO0FBQ0QsR0FsQkQ7QUFtQkQ7O0FBRUQsSUFBSWtnQixnQkFBZ0IsR0FBRyxDQUF2QjtBQUNBLElBQUlDLGdCQUFnQixHQUFHLENBQXZCO0FBQ0EsSUFBSUMsb0JBQW9CLEdBQUcsQ0FBM0I7QUFFQWxzQixXQUFXLENBQUMsTUFBTTtBQUNoQmdzQixrQkFBZ0IsSUFBSWhwQixZQUFwQjtBQUNBaXBCLGtCQUFnQixJQUFJLENBQXBCO0FBQ0QsQ0FIVSxFQUdSLElBSFEsQ0FBWDs7QUFLTyxTQUFTcnRCLGVBQVQsR0FBMkI7QUFDaEMsU0FBTztBQUNMaUUsV0FBTyxFQUFFdVosTUFBTSxDQUFDK1AsYUFBUCxHQUF1QkQsb0JBRDNCO0FBRUxqcEIsVUFBTSxFQUFFK29CLGdCQUFnQixHQUFHQyxnQkFGdEI7QUFHTGxxQixZQUFRLEVBQUVxYSxNQUFNLENBQUNyYTtBQUhaLEdBQVA7QUFLRDs7QUFFTSxTQUFTbEQsaUJBQVQsR0FBNkI7QUFDbENtdEIsa0JBQWdCLEdBQUcsQ0FBbkI7QUFDQUMsa0JBQWdCLEdBQUcsQ0FBbkI7QUFDQUMsc0JBQW9CLEdBQUc5UCxNQUFNLENBQUMrUCxhQUE5QjtBQUNELEM7Ozs7Ozs7Ozs7O0FDaEhENXRCLE1BQU0sQ0FBQ3FLLE1BQVAsQ0FBYztBQUFDZ1ksbUJBQWlCLEVBQUMsTUFBSUE7QUFBdkIsQ0FBZDtBQUFPLE1BQU1BLGlCQUFpQixHQUFHeUssTUFBTSxFQUFoQzs7QUFFUGhOLHVCQUF1QixHQUFHLFlBQVk7QUFDcEMzZSxTQUFPLENBQUNKLEVBQVIsQ0FBVyxtQkFBWCxFQUFnQyxVQUFVdk4sR0FBVixFQUFlO0FBQzdDO0FBQ0EsUUFBR0EsR0FBRyxDQUFDbXVCLFdBQVAsRUFBb0I7QUFDbEI7QUFDRCxLQUo0QyxDQU03Qzs7O0FBQ0EsUUFBRyxDQUFDN3ZCLE1BQU0sQ0FBQ0MsT0FBUCxDQUFlbXRCLG1CQUFuQixFQUF3QztBQUN0QzJPLHVCQUFpQixDQUFDcjZCLEdBQUQsQ0FBakI7QUFDRCxLQVQ0QyxDQVc3QztBQUNBOzs7QUFDQSxRQUFHQSxHQUFHLENBQUNzNkIsUUFBSixJQUFnQixDQUFDaDhCLE1BQU0sQ0FBQ3FDLFNBQTNCLEVBQXNDO0FBQ3BDMDVCLHVCQUFpQixDQUFDcjZCLEdBQUQsQ0FBakI7QUFDRDs7QUFFRCxRQUFJdUksS0FBSyxHQUFHZ3lCLFFBQVEsQ0FBQ3Y2QixHQUFELEVBQU0sY0FBTixFQUFzQixtQkFBdEIsQ0FBcEI7QUFDQTFCLFVBQU0sQ0FBQ2lzQixNQUFQLENBQWN2bkIsS0FBZCxDQUFvQjZRLFVBQXBCLENBQStCN1QsR0FBL0IsRUFBb0N1SSxLQUFwQzs7QUFDQWpLLFVBQU0sQ0FBQzh1QixZQUFQLENBQW9CLFlBQVk7QUFDOUJsWCxrQkFBWSxDQUFDc2tCLEtBQUQsQ0FBWjtBQUNBQyxnQkFBVSxDQUFDejZCLEdBQUQsQ0FBVjtBQUNELEtBSEQ7O0FBS0EsUUFBSXc2QixLQUFLLEdBQUc1akIsVUFBVSxDQUFDLFlBQVk7QUFDakM2akIsZ0JBQVUsQ0FBQ3o2QixHQUFELENBQVY7QUFDRCxLQUZxQixFQUVuQixPQUFLLEVBRmMsQ0FBdEI7O0FBSUEsYUFBU3k2QixVQUFULENBQW9CejZCLEdBQXBCLEVBQXlCO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBMk4sYUFBTyxDQUFDK3NCLFFBQVIsQ0FBaUIsWUFBVztBQUMxQjtBQUNBMTZCLFdBQUcsQ0FBQ3M2QixRQUFKLEdBQWUsSUFBZjtBQUNBRCx5QkFBaUIsQ0FBQ3I2QixHQUFELENBQWpCO0FBQ0QsT0FKRDtBQUtEO0FBQ0YsR0F0Q0Q7O0FBd0NBLFdBQVNxNkIsaUJBQVQsQ0FBMkJyNkIsR0FBM0IsRUFBZ0M7QUFDOUI7QUFDQTtBQUNBO0FBQ0F5QixXQUFPLENBQUN1QixLQUFSLENBQWNoRCxHQUFHLENBQUNnVSxLQUFsQjtBQUNBckcsV0FBTyxDQUFDZ3RCLElBQVIsQ0FBYSxDQUFiO0FBQ0Q7QUFDRixDQWhERDs7QUFrREFwTyx3QkFBd0IsR0FBRyxZQUFZO0FBQ3JDNWUsU0FBTyxDQUFDSixFQUFSLENBQVcsb0JBQVgsRUFBaUMsVUFBVXNSLE1BQVYsRUFBa0I7QUFDakQ7QUFDQSxRQUNFQSxNQUFNLENBQUNzUCxXQUFQLElBQ0EsQ0FBQzd2QixNQUFNLENBQUNDLE9BQVAsQ0FBZW10QixtQkFGbEIsRUFHRTtBQUNBO0FBQ0Q7O0FBRUQsUUFBSW5qQixLQUFLLEdBQUdneUIsUUFBUSxDQUFDMWIsTUFBRCxFQUFTLGlCQUFULEVBQTRCLG9CQUE1QixDQUFwQjtBQUNBdmdCLFVBQU0sQ0FBQ2lzQixNQUFQLENBQWN2bkIsS0FBZCxDQUFvQjZRLFVBQXBCLENBQStCZ0wsTUFBL0IsRUFBdUN0VyxLQUF2QyxFQVZpRCxDQVlqRDtBQUNBO0FBQ0E7O0FBQ0EsVUFBTXhJLE9BQU8sR0FDWCxxQ0FDQSw4REFEQSxHQUVBLGdFQUZBLEdBR0EseUNBSkYsQ0FmaUQsQ0FxQmpEO0FBQ0E7O0FBQ0EwQixXQUFPLENBQUNDLElBQVIsQ0FBYTNCLE9BQWI7QUFDQTBCLFdBQU8sQ0FBQ3VCLEtBQVIsQ0FBYzZiLE1BQU0sSUFBSUEsTUFBTSxDQUFDN0ssS0FBakIsR0FBeUI2SyxNQUFNLENBQUM3SyxLQUFoQyxHQUF3QzZLLE1BQXREO0FBQ0QsR0F6QkQ7QUEwQkQsQ0EzQkQ7O0FBNkJBMk4sZ0JBQWdCLEdBQUcsWUFBWTtBQUM3QixNQUFJb08sbUJBQW1CLEdBQUduOEIsTUFBTSxDQUFDbzhCLE1BQWpDOztBQUNBcDhCLFFBQU0sQ0FBQ284QixNQUFQLEdBQWdCLFVBQVU5NkIsT0FBVixFQUFtQmlVLEtBQW5CLEVBQTBCO0FBQ3hDO0FBQ0E7QUFDQSxVQUFNOG1CLE1BQU0sR0FBRy82QixPQUFPLEtBQUs2akIsU0FBWixJQUF5QjVQLEtBQUssS0FBSzRQLFNBQWxELENBSHdDLENBS3hDO0FBQ0E7O0FBQ0EsUUFBSW1YLGNBQWMsR0FBRyxLQUFyQixDQVB3QyxDQVN4QztBQUNBOztBQUNBLFFBQUkvbUIsS0FBSyxJQUFJQSxLQUFLLENBQUM2YSxpQkFBRCxDQUFsQixFQUF1QztBQUNyQ2tNLG9CQUFjLEdBQUcsSUFBakI7QUFDQXZpQixlQUFTLENBQUMsQ0FBRCxDQUFULEdBQWV4RSxLQUFLLENBQUNBLEtBQXJCO0FBQ0QsS0FIRCxNQUdPLElBQUlBLEtBQUssSUFBSUEsS0FBSyxDQUFDQSxLQUFmLElBQXdCQSxLQUFLLENBQUNBLEtBQU4sQ0FBWTZhLGlCQUFaLENBQTVCLEVBQTREO0FBQ2pFa00sb0JBQWMsR0FBRyxJQUFqQjtBQUNBdmlCLGVBQVMsQ0FBQyxDQUFELENBQVQsR0FBZXhFLEtBQUssQ0FBQ0EsS0FBTixDQUFZQSxLQUEzQjtBQUNELEtBakJ1QyxDQW1CeEM7OztBQUNBLFFBQ0UxVixNQUFNLENBQUNDLE9BQVAsQ0FBZW10QixtQkFBZixJQUNBb1AsTUFEQSxJQUVBLENBQUNDLGNBRkQsSUFHQXo4QixNQUFNLENBQUNxQyxTQUpULEVBS0U7QUFDQSxVQUFJcTZCLFlBQVksR0FBR2o3QixPQUFuQjs7QUFFQSxVQUFJLE9BQU9BLE9BQVAsSUFBa0IsUUFBbEIsSUFBOEJpVSxLQUFLLFlBQVkvVCxLQUFuRCxFQUEwRDtBQUN4RCxjQUFNZzdCLFNBQVMsR0FBR2w3QixPQUFPLENBQUNtN0IsUUFBUixDQUFpQixHQUFqQixJQUF3QixFQUF4QixHQUE2QixHQUEvQztBQUNBRixvQkFBWSxhQUFNajdCLE9BQU4sU0FBZ0JrN0IsU0FBaEIsY0FBNkJqbkIsS0FBSyxDQUFDalUsT0FBbkMsQ0FBWjtBQUNEOztBQUVELFVBQUlpRCxLQUFLLEdBQUcsSUFBSS9DLEtBQUosQ0FBVSs2QixZQUFWLENBQVo7O0FBQ0EsVUFBSWhuQixLQUFLLFlBQVkvVCxLQUFyQixFQUE0QjtBQUMxQitDLGFBQUssQ0FBQ2dSLEtBQU4sR0FBY0EsS0FBSyxDQUFDQSxLQUFwQjtBQUNELE9BRkQsTUFFTyxJQUFJQSxLQUFKLEVBQVc7QUFDaEJoUixhQUFLLENBQUNnUixLQUFOLEdBQWNBLEtBQWQ7QUFDRCxPQUZNLE1BRUE7QUFDTGhSLGFBQUssQ0FBQ2dSLEtBQU4sR0FBY2tELGVBQWUsQ0FBQ2xVLEtBQUQsQ0FBN0I7QUFDRDs7QUFDRCxVQUFJdUYsS0FBSyxHQUFHZ3lCLFFBQVEsQ0FBQ3YzQixLQUFELEVBQVEsaUJBQVIsRUFBMkIsZUFBM0IsQ0FBcEI7QUFDQTFFLFlBQU0sQ0FBQ2lzQixNQUFQLENBQWN2bkIsS0FBZCxDQUFvQjZRLFVBQXBCLENBQStCN1EsS0FBL0IsRUFBc0N1RixLQUF0QztBQUNEOztBQUVELFdBQU9xeUIsbUJBQW1CLENBQUNsN0IsS0FBcEIsQ0FBMEIsSUFBMUIsRUFBZ0M4WSxTQUFoQyxDQUFQO0FBQ0QsR0E5Q0Q7QUErQ0QsQ0FqREQ7O0FBbURBLFNBQVMraEIsUUFBVCxDQUFrQnY2QixHQUFsQixFQUF1QkYsSUFBdkIsRUFBNkJtRCxPQUE3QixFQUFzQztBQUNwQyxTQUFPO0FBQ0xuRCxRQUFJLEVBQUVBLElBREQ7QUFFTG1ELFdBQU8sRUFBRUEsT0FGSjtBQUdMNEMsUUFBSSxFQUFFN0YsR0FBRyxDQUFDRCxPQUhMO0FBSUw2RixXQUFPLEVBQUUsSUFKSjtBQUtMRixNQUFFLEVBQUVwSCxNQUFNLENBQUN5SSxVQUFQLENBQWtCbUYsT0FBbEIsRUFMQztBQU1MaUksVUFBTSxFQUFFLENBQ04sQ0FBQyxPQUFELEVBQVUsQ0FBVixFQUFhLEVBQWIsQ0FETSxFQUVOLENBQUMsT0FBRCxFQUFVLENBQVYsRUFBYTtBQUFDblIsV0FBSyxFQUFFO0FBQUNqRCxlQUFPLEVBQUVDLEdBQUcsQ0FBQ0QsT0FBZDtBQUF1QmlVLGFBQUssRUFBRWhVLEdBQUcsQ0FBQ2dVO0FBQWxDO0FBQVIsS0FBYixDQUZNLENBTkg7QUFVTDlOLFdBQU8sRUFBRTtBQUNQRSxXQUFLLEVBQUU7QUFEQTtBQVZKLEdBQVA7QUFjRCxDOzs7Ozs7Ozs7OztBQ25KRDZ2QixTQUFTLEdBQUcsWUFBWTtBQUN0QjtBQUNBLE1BQUlsRyxZQUFZLEdBQUdpRSxPQUFPLENBQUMyQixPQUFSLENBQWdCcHpCLFNBQWhCLENBQTBCaEMsSUFBN0M7O0FBQ0F5ekIsU0FBTyxDQUFDMkIsT0FBUixDQUFnQnB6QixTQUFoQixDQUEwQmhDLElBQTFCLEdBQWlDLFNBQVM0NkIsbUJBQVQsQ0FBOEIzekIsR0FBOUIsRUFBbUM7QUFDbEUsV0FBT3VvQixZQUFZLENBQUN4YyxJQUFiLENBQWtCLElBQWxCLEVBQXdCL0wsR0FBeEIsQ0FBUDtBQUNELEdBRkQsQ0FIc0IsQ0FPdEI7QUFDQTs7O0FBQ0EsTUFBSXdzQixPQUFPLENBQUMrQixXQUFaLEVBQXlCO0FBQ3ZCLFFBQUlxRixnQkFBZ0IsR0FBR3BILE9BQU8sQ0FBQytCLFdBQVIsQ0FBb0J4ekIsU0FBcEIsQ0FBOEI4NEIsU0FBckQ7O0FBQ0FySCxXQUFPLENBQUMrQixXQUFSLENBQW9CeHpCLFNBQXBCLENBQThCODRCLFNBQTlCLEdBQTBDLFNBQVNDLDJCQUFULENBQXNDaEksTUFBdEMsRUFBOEM7QUFDdEYsYUFBTzhILGdCQUFnQixDQUFDN25CLElBQWpCLENBQXNCLElBQXRCLEVBQTRCK2YsTUFBNUIsQ0FBUDtBQUNELEtBRkQ7QUFHRCxHQWRxQixDQWdCdEI7OztBQUNBLE1BQUlpSSxtQkFBbUIsR0FBR3ZILE9BQU8sQ0FBQ0MsZUFBUixDQUF3QjF4QixTQUF4QixDQUFrQ2k1QixPQUE1RDs7QUFDQXhILFNBQU8sQ0FBQ0MsZUFBUixDQUF3QjF4QixTQUF4QixDQUFrQ2k1QixPQUFsQyxHQUE0QyxTQUFTQyw2QkFBVCxDQUF3QzlWLElBQXhDLEVBQThDd0QsR0FBOUMsRUFBbUR1UyxFQUFuRCxFQUF1RDtBQUNqRyxXQUFPSCxtQkFBbUIsQ0FBQ2hvQixJQUFwQixDQUF5QixJQUF6QixFQUErQm9TLElBQS9CLEVBQXFDd0QsR0FBckMsRUFBMEN1UyxFQUExQyxDQUFQO0FBQ0QsR0FGRCxDQWxCc0IsQ0FzQnRCOzs7QUFDQSxNQUFJQyxtQkFBbUIsR0FBRzNILE9BQU8sQ0FBQ0MsZUFBUixDQUF3QjF4QixTQUF4QixDQUFrQ3E1QixPQUE1RDs7QUFDQTVILFNBQU8sQ0FBQ0MsZUFBUixDQUF3QjF4QixTQUF4QixDQUFrQ3E1QixPQUFsQyxHQUE0QyxTQUFTQyw2QkFBVCxDQUF3Q2xXLElBQXhDLEVBQThDMUcsUUFBOUMsRUFBd0Q4WCxHQUF4RCxFQUE2RHg0QixPQUE3RCxFQUFzRW05QixFQUF0RSxFQUEwRTtBQUNwSCxXQUFPQyxtQkFBbUIsQ0FBQ3BvQixJQUFwQixDQUF5QixJQUF6QixFQUErQm9TLElBQS9CLEVBQXFDMUcsUUFBckMsRUFBK0M4WCxHQUEvQyxFQUFvRHg0QixPQUFwRCxFQUE2RG05QixFQUE3RCxDQUFQO0FBQ0QsR0FGRCxDQXhCc0IsQ0E0QnRCOzs7QUFDQSxNQUFJSSxtQkFBbUIsR0FBRzlILE9BQU8sQ0FBQ0MsZUFBUixDQUF3QjF4QixTQUF4QixDQUFrQ3c1QixPQUE1RDs7QUFDQS9ILFNBQU8sQ0FBQ0MsZUFBUixDQUF3QjF4QixTQUF4QixDQUFrQ3c1QixPQUFsQyxHQUE0QyxTQUFTQyw2QkFBVCxDQUF3Q3JXLElBQXhDLEVBQThDMUcsUUFBOUMsRUFBd0R5YyxFQUF4RCxFQUE0RDtBQUN0RyxXQUFPSSxtQkFBbUIsQ0FBQ3ZvQixJQUFwQixDQUF5QixJQUF6QixFQUErQm9TLElBQS9CLEVBQXFDMUcsUUFBckMsRUFBK0N5YyxFQUEvQyxDQUFQO0FBQ0QsR0FGRCxDQTlCc0IsQ0FrQ3RCOzs7QUFDQSxNQUFJTyxtQkFBbUIsR0FBR2pJLE9BQU8sQ0FBQzJCLE9BQVIsQ0FBZ0JwekIsU0FBaEIsQ0FBMEIyNUIsU0FBcEQ7O0FBQ0FsSSxTQUFPLENBQUMyQixPQUFSLENBQWdCcHpCLFNBQWhCLENBQTBCMjVCLFNBQTFCLEdBQXNDLFNBQVNDLHdCQUFULENBQW1DeFcsSUFBbkMsRUFBeUM1ZixFQUF6QyxFQUE2Q21hLE1BQTdDLEVBQXFEO0FBQ3pGLFdBQU8rYixtQkFBbUIsQ0FBQzFvQixJQUFwQixDQUF5QixJQUF6QixFQUErQm9TLElBQS9CLEVBQXFDNWYsRUFBckMsRUFBeUNtYSxNQUF6QyxDQUFQO0FBQ0QsR0FGRCxDQXBDc0IsQ0F3Q3RCOzs7QUFDQSxNQUFJa2MscUJBQXFCLEdBQUdwSSxPQUFPLENBQUMyQixPQUFSLENBQWdCcHpCLFNBQWhCLENBQTBCODVCLFdBQXREOztBQUNBckksU0FBTyxDQUFDMkIsT0FBUixDQUFnQnB6QixTQUFoQixDQUEwQjg1QixXQUExQixHQUF3QyxTQUFTQywwQkFBVCxDQUFxQzNXLElBQXJDLEVBQTJDNWYsRUFBM0MsRUFBK0NtYSxNQUEvQyxFQUF1RDtBQUM3RixXQUFPa2MscUJBQXFCLENBQUM3b0IsSUFBdEIsQ0FBMkIsSUFBM0IsRUFBaUNvUyxJQUFqQyxFQUF1QzVmLEVBQXZDLEVBQTJDbWEsTUFBM0MsQ0FBUDtBQUNELEdBRkQsQ0ExQ3NCLENBOEN0Qjs7O0FBQ0EsTUFBSXFjLHFCQUFxQixHQUFHdkksT0FBTyxDQUFDMkIsT0FBUixDQUFnQnB6QixTQUFoQixDQUEwQmk2QixXQUF0RDs7QUFDQXhJLFNBQU8sQ0FBQzJCLE9BQVIsQ0FBZ0JwekIsU0FBaEIsQ0FBMEJpNkIsV0FBMUIsR0FBd0MsU0FBU0MsMEJBQVQsQ0FBcUM5VyxJQUFyQyxFQUEyQzVmLEVBQTNDLEVBQStDO0FBQ3JGLFdBQU93MkIscUJBQXFCLENBQUNocEIsSUFBdEIsQ0FBMkIsSUFBM0IsRUFBaUNvUyxJQUFqQyxFQUF1QzVmLEVBQXZDLENBQVA7QUFDRCxHQUZELENBaERzQixDQW9EdEI7OztBQUNBLE1BQUkyMkIscUJBQXFCLEdBQUcxSSxPQUFPLENBQUN5RCxXQUFSLENBQW9CbDFCLFNBQXBCLENBQThCL0MsT0FBMUQ7O0FBQ0F3MEIsU0FBTyxDQUFDeUQsV0FBUixDQUFvQmwxQixTQUFwQixDQUE4Qi9DLE9BQTlCLEdBQXdDLFNBQVNtOUIscUJBQVQsR0FBa0M7QUFDeEUsV0FBT0QscUJBQXFCLENBQUNoOUIsS0FBdEIsQ0FBNEIsSUFBNUIsRUFBa0M4WSxTQUFsQyxDQUFQO0FBQ0QsR0FGRCxDQXREc0IsQ0EwRHRCOzs7QUFDQSxNQUFJb2tCLGlCQUFpQixHQUFHNUksT0FBTyxDQUFDeUQsV0FBUixDQUFvQmwxQixTQUFwQixDQUE4Qm9QLEdBQXREOztBQUNBcWlCLFNBQU8sQ0FBQ3lELFdBQVIsQ0FBb0JsMUIsU0FBcEIsQ0FBOEJvUCxHQUE5QixHQUFvQyxTQUFTa3JCLGlCQUFULEdBQThCO0FBQ2hFLFdBQU9ELGlCQUFpQixDQUFDbDlCLEtBQWxCLENBQXdCLElBQXhCLEVBQThCOFksU0FBOUIsQ0FBUDtBQUNELEdBRkQsQ0E1RHNCLENBZ0V0Qjs7O0FBQ0EsTUFBSXNrQixtQkFBbUIsR0FBRzlJLE9BQU8sQ0FBQ3lELFdBQVIsQ0FBb0JsMUIsU0FBcEIsQ0FBOEJxMEIsS0FBeEQ7O0FBQ0E1QyxTQUFPLENBQUN5RCxXQUFSLENBQW9CbDFCLFNBQXBCLENBQThCcTBCLEtBQTlCLEdBQXNDLFNBQVNtRyxtQkFBVCxHQUFnQztBQUNwRSxXQUFPRCxtQkFBbUIsQ0FBQ3A5QixLQUFwQixDQUEwQixJQUExQixFQUFnQzhZLFNBQWhDLENBQVA7QUFDRCxHQUZELENBbEVzQixDQXNFdEI7OztBQUNBLE1BQUl3a0IsbUJBQW1CLEdBQUdoSixPQUFPLENBQUN5RCxXQUFSLENBQW9CbDFCLFNBQXBCLENBQThCdUMsS0FBeEQ7O0FBQ0FrdkIsU0FBTyxDQUFDeUQsV0FBUixDQUFvQmwxQixTQUFwQixDQUE4QnVDLEtBQTlCLEdBQXNDLFNBQVNtNEIsbUJBQVQsR0FBZ0M7QUFDcEUsV0FBT0QsbUJBQW1CLENBQUN0OUIsS0FBcEIsQ0FBMEIsSUFBMUIsRUFBZ0M4WSxTQUFoQyxDQUFQO0FBQ0QsR0FGRCxDQXhFc0IsQ0E0RXRCOzs7QUFDQSxNQUFJMGtCLDRCQUE0QixHQUFHbEosT0FBTyxDQUFDeUQsV0FBUixDQUFvQmwxQixTQUFwQixDQUE4QjQ2QixjQUFqRTs7QUFDQW5KLFNBQU8sQ0FBQ3lELFdBQVIsQ0FBb0JsMUIsU0FBcEIsQ0FBOEI0NkIsY0FBOUIsR0FBK0MsU0FBU0MsNEJBQVQsR0FBeUM7QUFDdEYsV0FBT0YsNEJBQTRCLENBQUN4OUIsS0FBN0IsQ0FBbUMsSUFBbkMsRUFBeUM4WSxTQUF6QyxDQUFQO0FBQ0QsR0FGRCxDQTlFc0IsQ0FrRnRCOzs7QUFDQSxNQUFJNmtCLHFCQUFxQixHQUFHckosT0FBTyxDQUFDeUQsV0FBUixDQUFvQmwxQixTQUFwQixDQUE4Qis2QixPQUExRDs7QUFDQXRKLFNBQU8sQ0FBQ3lELFdBQVIsQ0FBb0JsMUIsU0FBcEIsQ0FBOEIrNkIsT0FBOUIsR0FBd0MsU0FBU0MscUJBQVQsR0FBa0M7QUFDeEUsV0FBT0YscUJBQXFCLENBQUMzOUIsS0FBdEIsQ0FBNEIsSUFBNUIsRUFBa0M4WSxTQUFsQyxDQUFQO0FBQ0QsR0FGRCxDQXBGc0IsQ0F3RnRCOzs7QUFDQSxNQUFJZ2xCLHNCQUFzQixHQUFHQyxTQUFTLENBQUNDLFNBQVYsQ0FBb0JuN0IsU0FBcEIsQ0FBOEJvN0IsTUFBM0Q7O0FBQ0FGLFdBQVMsQ0FBQ0MsU0FBVixDQUFvQm43QixTQUFwQixDQUE4Qm83QixNQUE5QixHQUF1QyxTQUFTQyxzQkFBVCxDQUFpQ0MsT0FBakMsRUFBMENuOUIsUUFBMUMsRUFBb0Q7QUFDekYsV0FBTzg4QixzQkFBc0IsQ0FBQ2pxQixJQUF2QixDQUE0QixJQUE1QixFQUFrQ3NxQixPQUFsQyxFQUEyQ245QixRQUEzQyxDQUFQO0FBQ0QsR0FGRCxDQTFGc0IsQ0E4RnRCOzs7QUFDQSxNQUFJbzlCLG9CQUFvQixHQUFHTCxTQUFTLENBQUNDLFNBQVYsQ0FBb0JuN0IsU0FBcEIsQ0FBOEJ3N0IsSUFBekQ7O0FBQ0FOLFdBQVMsQ0FBQ0MsU0FBVixDQUFvQm43QixTQUFwQixDQUE4Qnc3QixJQUE5QixHQUFxQyxTQUFTQyxvQkFBVCxDQUErQkMsWUFBL0IsRUFBNkM7QUFDaEYsV0FBT0gsb0JBQW9CLENBQUN2cUIsSUFBckIsQ0FBMEIsSUFBMUIsRUFBZ0MwcUIsWUFBaEMsQ0FBUDtBQUNELEdBRkQ7QUFHRCxDQW5HRCxDOzs7Ozs7Ozs7OztBQ0FBenhCLE1BQU0sQ0FBQ3FLLE1BQVAsQ0FBYztBQUFDcWUsZ0JBQWMsRUFBQyxNQUFJQTtBQUFwQixDQUFkOztBQUFPLFNBQVNBLGNBQVQsR0FBMkI7QUFDaEN6MkIsUUFBTSxDQUFDNHRCLE9BQVAsQ0FBZSxNQUFNO0FBQ25CLFFBQUljLE9BQU8sQ0FBQyw2QkFBRCxDQUFYLEVBQTRDO0FBQzFDLFlBQU0rUSxVQUFVLEdBQUcvUSxPQUFPLENBQUMsNkJBQUQsQ0FBUCxDQUF1QytRLFVBQTFELENBRDBDLENBRzFDO0FBQ0E7O0FBQ0EsVUFBSUMsU0FBUyxHQUFHRCxVQUFVLENBQUNFLEtBQTNCOztBQUNBRixnQkFBVSxDQUFDRSxLQUFYLEdBQW1CLFVBQVUzOUIsSUFBVixFQUFnQjQ5QixTQUFoQixFQUEyQjtBQUM1QyxZQUFJMzlCLFFBQVEsR0FBRyxZQUFZO0FBQ3pCLGdCQUFNcUwsSUFBSSxHQUFHek4sTUFBTSxDQUFDZ3ZCLFFBQVAsRUFBYjs7QUFDQSxjQUFJdmhCLElBQUosRUFBVTtBQUNSQSxnQkFBSSxDQUFDdXlCLGtCQUFMLEdBQTBCNzlCLElBQTFCO0FBQ0Q7O0FBRUQsaUJBQU80OUIsU0FBUyxDQUFDMytCLEtBQVYsQ0FBZ0IsSUFBaEIsRUFBc0I4WSxTQUF0QixDQUFQO0FBQ0QsU0FQRDs7QUFTQSxlQUFPMmxCLFNBQVMsQ0FBQzVxQixJQUFWLENBQWUycUIsVUFBZixFQUEyQno5QixJQUEzQixFQUFpQ0MsUUFBakMsQ0FBUDtBQUNELE9BWEQ7QUFZRDtBQUNGLEdBcEJEO0FBcUJELEM7Ozs7Ozs7Ozs7O0FDdEJEOEwsTUFBTSxDQUFDcUssTUFBUCxDQUFjO0FBQUMwbkIsa0JBQWdCLEVBQUMsTUFBSUEsZ0JBQXRCO0FBQXVDcEosUUFBTSxFQUFDLE1BQUlBO0FBQWxELENBQWQ7QUFBeUUsSUFBSTViLEVBQUo7QUFBTy9NLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLElBQVosRUFBaUI7QUFBQ0csU0FBTyxDQUFDRixDQUFELEVBQUc7QUFBQzZNLE1BQUUsR0FBQzdNLENBQUg7QUFBSzs7QUFBakIsQ0FBakIsRUFBb0MsQ0FBcEM7O0FBQ2hGLE1BQU0yZCxNQUFNLEdBQUd0ckIsT0FBTyxDQUFDLFFBQUQsQ0FBdEI7O0FBRUEsU0FBU3kvQixZQUFULENBQXNCci9CLElBQXRCLEVBQTRCcy9CLGFBQTVCLEVBQTJDO0FBQ3pDLE1BQUksT0FBT3QvQixJQUFJLENBQUNBLElBQUksQ0FBQ2lCLE1BQUwsR0FBYyxDQUFmLENBQVgsS0FBaUMsVUFBckMsRUFBaUQ7QUFDL0NqQixRQUFJLENBQUNBLElBQUksQ0FBQ2lCLE1BQUwsR0FBYyxDQUFmLENBQUosR0FBd0JxK0IsYUFBYSxDQUFDdC9CLElBQUksQ0FBQ0EsSUFBSSxDQUFDaUIsTUFBTCxHQUFjLENBQWYsQ0FBTCxDQUFyQztBQUNEO0FBQ0Y7O0FBRU0sU0FBU20rQixnQkFBVCxDQUEwQkcsWUFBMUIsRUFBd0NuMkIsS0FBeEMsRUFBK0M2WixLQUEvQyxFQUFzRDtBQUMzRCxXQUFTOE4sT0FBVCxDQUFrQmx0QixLQUFsQixFQUF5QjtBQUN2QixRQUFJdUYsS0FBSyxJQUFJNlosS0FBYixFQUFvQjtBQUNsQjlqQixZQUFNLENBQUN5bUIsTUFBUCxDQUFjL0IsUUFBZCxDQUF1QnphLEtBQXZCLEVBQThCNlosS0FBOUIsRUFBcUM7QUFDbkNwZixhQUFLLEVBQUVBO0FBRDRCLE9BQXJDO0FBR0QsS0FMc0IsQ0FPdkI7QUFDQTs7O0FBQ0EsUUFBSTA3QixZQUFZLENBQUNDLGFBQWIsQ0FBMkIsT0FBM0IsTUFBd0MsQ0FBNUMsRUFBK0M7QUFDN0NELGtCQUFZLENBQUNFLGNBQWIsQ0FBNEIsT0FBNUIsRUFBcUMxTyxPQUFyQztBQUNBd08sa0JBQVksQ0FBQzlQLElBQWIsQ0FBa0IsT0FBbEIsRUFBMkI1ckIsS0FBM0I7QUFDRDtBQUNGOztBQUVEMDdCLGNBQVksQ0FBQ254QixFQUFiLENBQWdCLE9BQWhCLEVBQXlCMmlCLE9BQXpCO0FBQ0Q7O0FBRU0sU0FBU2lGLE1BQVQsR0FBa0I7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFJMEosWUFBWSxHQUFHLElBQW5CO0FBRUEsTUFBSUMsWUFBWSxHQUFHdmxCLEVBQUUsQ0FBQzBDLElBQXRCOztBQUNBMUMsSUFBRSxDQUFDMEMsSUFBSCxHQUFVLFlBQVk7QUFDcEIsVUFBTXdPLFVBQVUsR0FBR25zQixNQUFNLENBQUNndkIsUUFBUCxNQUFxQnVSLFlBQXhDOztBQUVBLFFBQUlwVSxVQUFKLEVBQWdCO0FBQ2QsVUFBSXJJLEtBQUssR0FBRzlqQixNQUFNLENBQUN5bUIsTUFBUCxDQUFjM0MsS0FBZCxDQUFvQnFJLFVBQVUsQ0FBQ2xpQixLQUEvQixFQUFzQyxJQUF0QyxFQUE0QztBQUN0RHV1QixZQUFJLEVBQUUsTUFEZ0Q7QUFFdERyMkIsWUFBSSxFQUFFK1gsU0FBUyxDQUFDLENBQUQsQ0FGdUM7QUFHdERqYSxlQUFPLEVBQUUsT0FBT2lhLFNBQVMsQ0FBQyxDQUFELENBQWhCLEtBQXdCLFFBQXhCLEdBQW1DQSxTQUFTLENBQUMsQ0FBRCxDQUE1QyxHQUFrRG9MO0FBSEwsT0FBNUMsQ0FBWjtBQU1BNGEsa0JBQVksQ0FBQ2htQixTQUFELEVBQWFrakIsRUFBRCxJQUFRO0FBQzlCLGVBQU8sWUFBWTtBQUNqQnA5QixnQkFBTSxDQUFDeW1CLE1BQVAsQ0FBYy9CLFFBQWQsQ0FBdUJ5SCxVQUFVLENBQUNsaUIsS0FBbEMsRUFBeUM2WixLQUF6Qzs7QUFFQSxjQUFJLENBQUNpSSxNQUFNLENBQUNvRCxPQUFaLEVBQXFCO0FBQ25Cb1Isd0JBQVksR0FBR3BVLFVBQWY7QUFDRDs7QUFFRCxjQUFJO0FBQ0ZpUixjQUFFLENBQUNoOEIsS0FBSCxDQUFTLElBQVQsRUFBZThZLFNBQWY7QUFDRCxXQUZELFNBRVU7QUFDUnFtQix3QkFBWSxHQUFHLElBQWY7QUFDRDtBQUNGLFNBWkQ7QUFhRCxPQWRXLENBQVo7QUFlRDs7QUFFRCxXQUFPQyxZQUFZLENBQUNwL0IsS0FBYixDQUFtQjZaLEVBQW5CLEVBQXVCZixTQUF2QixDQUFQO0FBQ0QsR0E1QkQ7O0FBOEJBLE1BQUl1bUIsd0JBQXdCLEdBQUd4bEIsRUFBRSxDQUFDOEIsZ0JBQWxDOztBQUNBOUIsSUFBRSxDQUFDOEIsZ0JBQUgsR0FBc0IsWUFBWTtBQUNoQyxVQUFNb1AsVUFBVSxHQUFHbnNCLE1BQU0sQ0FBQ2d2QixRQUFQLE1BQXFCdVIsWUFBeEM7QUFDQSxRQUFJempCLE1BQU0sR0FBRzJqQix3QkFBd0IsQ0FBQ3IvQixLQUF6QixDQUErQixJQUEvQixFQUFxQzhZLFNBQXJDLENBQWI7O0FBRUEsUUFBSWlTLFVBQUosRUFBZ0I7QUFDZCxZQUFNckksS0FBSyxHQUFHOWpCLE1BQU0sQ0FBQ3ltQixNQUFQLENBQWMzQyxLQUFkLENBQW9CcUksVUFBVSxDQUFDbGlCLEtBQS9CLEVBQXNDLElBQXRDLEVBQTRDO0FBQ3hEdXVCLFlBQUksRUFBRSxrQkFEa0Q7QUFFeERyMkIsWUFBSSxFQUFFK1gsU0FBUyxDQUFDLENBQUQsQ0FGeUM7QUFHeERqYSxlQUFPLEVBQUU0RCxJQUFJLENBQUNDLFNBQUwsQ0FBZW9XLFNBQVMsQ0FBQyxDQUFELENBQXhCO0FBSCtDLE9BQTVDLENBQWQ7QUFNQTRDLFlBQU0sQ0FBQzdOLEVBQVAsQ0FBVSxLQUFWLEVBQWlCLE1BQU07QUFDckJqUCxjQUFNLENBQUN5bUIsTUFBUCxDQUFjL0IsUUFBZCxDQUF1QnlILFVBQVUsQ0FBQ2xpQixLQUFsQyxFQUF5QzZaLEtBQXpDO0FBQ0QsT0FGRDtBQUlBbWMsc0JBQWdCLENBQUNuakIsTUFBRCxFQUFTcVAsVUFBVSxDQUFDbGlCLEtBQXBCLEVBQTJCNlosS0FBM0IsQ0FBaEI7QUFDRDs7QUFFRCxXQUFPaEgsTUFBUDtBQUNELEdBbkJEO0FBb0JELEM7Ozs7Ozs7Ozs7O0FDdkZENU8sTUFBTSxDQUFDcUssTUFBUCxDQUFjO0FBQUNqSyxTQUFPLEVBQUMsTUFBSUQ7QUFBYixDQUFkO0FBQUEsSUFBSXF5QixtQkFBSjtBQUNBLElBQUlDLFNBQUo7QUFDQSxJQUFJQyxXQUFKOztBQUVBLElBQUk7QUFDRjtBQUNBLEdBQUM7QUFDQ0YsdUJBREQ7QUFFQ0MsYUFGRDtBQUdDQztBQUhELE1BSUduZ0MsT0FBTyxDQUFDLFlBQUQsQ0FKWDtBQUtELENBUEQsQ0FPRSxPQUFPdWIsQ0FBUCxFQUFVLENBQUU7O0FBRUMsTUFBTTNOLFNBQU4sQ0FBZ0I7QUFDN0JrSixhQUFXLEdBQUc7QUFDWixTQUFLc3BCLFNBQUwsR0FBaUIsSUFBakI7QUFDQSxTQUFLL2dCLE9BQUwsR0FBZSxLQUFmO0FBQ0EsU0FBS2xZLE9BQUwsR0FBZSxFQUFmO0FBRUEsU0FBSzJKLEtBQUw7QUFDRDs7QUFFRG5MLE9BQUssR0FBRztBQUNOLFFBQUksS0FBSzBaLE9BQVQsRUFBa0I7QUFDaEIsYUFBTyxLQUFQO0FBQ0Q7O0FBRUQsUUFBSSxDQUFDNGdCLG1CQUFELElBQXdCLENBQUNDLFNBQTdCLEVBQXdDO0FBQ3RDO0FBQ0EsYUFBTyxLQUFQO0FBQ0Q7O0FBRUQsU0FBSzdnQixPQUFMLEdBQWUsSUFBZjtBQUVBLFNBQUtnaEIsUUFBTCxHQUFnQixJQUFJSixtQkFBSixDQUF3QkssSUFBSSxJQUFJO0FBQzlDQSxVQUFJLENBQUNDLFVBQUwsR0FBa0I5L0IsT0FBbEIsQ0FBMEJvUyxLQUFLLElBQUk7QUFDakMsWUFBSStCLE1BQU0sR0FBRyxLQUFLNHJCLGdCQUFMLENBQXNCM3RCLEtBQUssQ0FBQ29VLElBQTVCLENBQWI7O0FBQ0EsYUFBSzlmLE9BQUwsQ0FBYXlOLE1BQWIsS0FBd0IvQixLQUFLLENBQUM0dEIsUUFBOUI7QUFDRCxPQUhELEVBRDhDLENBTTlDO0FBQ0E7O0FBQ0EsVUFBSSxPQUFPTixXQUFXLENBQUNPLE9BQW5CLEtBQStCLFVBQW5DLEVBQStDO0FBQzdDUCxtQkFBVyxDQUFDTyxPQUFaO0FBQ0Q7QUFDRixLQVhlLENBQWhCO0FBYUEsU0FBS0wsUUFBTCxDQUFjOUIsT0FBZCxDQUFzQjtBQUFFb0MsZ0JBQVUsRUFBRSxDQUFDLElBQUQsQ0FBZDtBQUFzQkMsY0FBUSxFQUFFO0FBQWhDLEtBQXRCO0FBQ0Q7O0FBRURKLGtCQUFnQixDQUFDSyxNQUFELEVBQVM7QUFDdkIsWUFBT0EsTUFBUDtBQUNFLFdBQUtYLFNBQVMsQ0FBQ1kseUJBQWY7QUFDRSxlQUFPLFNBQVA7O0FBQ0YsV0FBS1osU0FBUyxDQUFDYSx5QkFBZjtBQUNFLGVBQU8sU0FBUDs7QUFDRixXQUFLYixTQUFTLENBQUNjLCtCQUFmO0FBQ0UsZUFBTyxlQUFQOztBQUNGLFdBQUtkLFNBQVMsQ0FBQ2UsMEJBQWY7QUFDRSxlQUFPLFVBQVA7O0FBQ0Y7QUFDRXYrQixlQUFPLENBQUM0WCxHQUFSLDRDQUFnRHVtQixNQUFoRDtBQVZKO0FBWUQ7O0FBRUQvdkIsT0FBSyxHQUFHO0FBQ04sU0FBSzNKLE9BQUwsR0FBZTtBQUNib0osYUFBTyxFQUFFLENBREk7QUFFYkUsYUFBTyxFQUFFLENBRkk7QUFHYkUsbUJBQWEsRUFBRSxDQUhGO0FBSWJFLGNBQVEsRUFBRTtBQUpHLEtBQWY7QUFNRDs7QUEzRDRCLEM7Ozs7Ozs7Ozs7O0FDYi9CcEQsTUFBTSxDQUFDcUssTUFBUCxDQUFjO0FBQUM5SixxQkFBbUIsRUFBQyxNQUFJQSxtQkFBekI7QUFBNkNDLHVCQUFxQixFQUFDLE1BQUlBO0FBQXZFLENBQWQ7QUFBQSxJQUFJaXpCLE1BQUo7QUFDQSxJQUFJQyxZQUFZLEdBQUdwOEIsTUFBTSxDQUFDQyxNQUFQLENBQWMsSUFBZCxDQUFuQjtBQUVBLElBQUlxTSxjQUFjLEdBQUcsQ0FBckIsQyxDQUVBOztBQUNBLElBQUlGLGdCQUFnQixHQUFHLENBQXZCO0FBQ0EsSUFBSWl3QixpQkFBaUIsR0FBRyxDQUF4QjtBQUNBLElBQUkzdkIsZUFBZSxHQUFHLENBQXRCO0FBQ0EsSUFBSU0sT0FBTyxHQUFHLENBQWQ7QUFDQSxJQUFJc3ZCLGdCQUFnQixHQUFHLENBQXZCO0FBQ0EsSUFBSUMsWUFBWSxHQUFHLENBQW5CO0FBQ0EsSUFBSUMsZUFBZSxHQUFHLENBQXRCO0FBRUFyeUIsV0FBVyxDQUFDLE1BQU07QUFDaEIsTUFBSWtCLE1BQU0sR0FBR294QixlQUFlLENBQUNDLFVBQVUsRUFBWCxFQUFlLElBQWYsQ0FBNUI7O0FBRUEsTUFBSXJ4QixNQUFKLEVBQVk7QUFDVmt4QixnQkFBWSxJQUFJbHhCLE1BQU0sQ0FBQ3VCLE9BQVAsQ0FBZXRRLE1BQS9CO0FBQ0FrZ0MsbUJBQWUsSUFBSW54QixNQUFNLENBQUN5QixVQUFQLENBQWtCckssSUFBckM7QUFDQTY1QixvQkFBZ0IsSUFBSSxDQUFwQjtBQUNEO0FBQ0YsQ0FSVSxFQVFSLElBUlEsQ0FBWCxDLENBVUE7O0FBQ0EsSUFBSUsscUJBQXFCLEdBQUcsR0FBNUI7O0FBRUEsU0FBU0MsV0FBVCxHQUF3QjtBQUN0QixNQUFJVCxNQUFNLElBQUlBLE1BQU0sQ0FBQ1UsUUFBakIsSUFBNkJWLE1BQU0sQ0FBQ1UsUUFBUCxDQUFnQkMsQ0FBN0MsSUFBa0RYLE1BQU0sQ0FBQ1UsUUFBUCxDQUFnQkMsQ0FBaEIsQ0FBa0JyaUMsT0FBeEUsRUFBaUY7QUFDL0UsV0FBTzBoQyxNQUFNLENBQUNVLFFBQVAsQ0FBZ0JDLENBQWhCLENBQWtCcmlDLE9BQWxCLENBQTBCc2lDLFdBQTFCLElBQXlDSixxQkFBaEQ7QUFDRDs7QUFFRCxTQUFPLENBQVA7QUFDRDs7QUFFTSxTQUFTMXpCLG1CQUFULEdBQWdDO0FBQ3JDLFNBQU87QUFDTGlELFlBQVEsRUFBRTB3QixXQUFXLEVBRGhCO0FBRUx4d0Isb0JBRks7QUFHTEUsa0JBSEs7QUFJTEUsZ0JBQVksRUFBRTZ2QixpQkFKVDtBQUtMM3ZCLG1CQUxLO0FBTUxFLFdBQU8sRUFBRTJ2QixZQUFZLEdBQUdELGdCQU5uQjtBQU9MeHZCLGNBQVUsRUFBRTB2QixlQUFlLEdBQUdGLGdCQVB6QjtBQVFMdHZCO0FBUkssR0FBUDtBQVVEOztBQUFBOztBQUVNLFNBQVM5RCxxQkFBVCxHQUFpQztBQUN0Q2tELGtCQUFnQixHQUFHLENBQW5CO0FBQ0FFLGdCQUFjLEdBQUcsQ0FBakI7QUFDQSt2QixtQkFBaUIsR0FBRyxDQUFwQjtBQUNBM3ZCLGlCQUFlLEdBQUcsQ0FBbEI7QUFDQTZ2QixjQUFZLEdBQUcsQ0FBZjtBQUNBQyxpQkFBZSxHQUFHLENBQWxCO0FBQ0FGLGtCQUFnQixHQUFHLENBQW5CO0FBQ0Fsd0Isa0JBQWdCLEdBQUcsQ0FBbkI7QUFDQVksU0FBTyxHQUFHLENBQVY7QUFDRDs7QUFFRHJTLE1BQU0sQ0FBQzR0QixPQUFQLENBQWUsTUFBTTtBQUNuQixNQUFJeVUsT0FBTyxHQUFHM0ssY0FBYyxDQUFDNEssNkJBQWYsR0FBK0N6SyxLQUEvQyxDQUFxRDJKLE1BQW5FOztBQUVBLE1BQUksQ0FBQ2EsT0FBRCxJQUFZLENBQUNBLE9BQU8sQ0FBQ0YsQ0FBekIsRUFBNEI7QUFDMUI7QUFDQTtBQUNEOztBQUVELE1BQUlyaUMsT0FBTyxHQUFHdWlDLE9BQU8sQ0FBQ0YsQ0FBUixDQUFVcmlDLE9BQXhCOztBQUNBLE1BQUksQ0FBQ0EsT0FBRCxJQUFZLENBQUNBLE9BQU8sQ0FBQ3lpQyxrQkFBekIsRUFBNkM7QUFDM0M7QUFDQTtBQUNEOztBQUVEZixRQUFNLEdBQUdhLE9BQVQsQ0FkbUIsQ0FnQm5COztBQUNBLE1BQUlHLGtCQUFrQixHQUFHQyxvQkFBb0IsQ0FBQ1YsVUFBVSxFQUFYLENBQTdDOztBQUNBLE1BQUlTLGtCQUFrQixJQUFJQSxrQkFBa0IsQ0FBQ0wsQ0FBekMsSUFBOENLLGtCQUFrQixDQUFDTCxDQUFuQixDQUFxQk8sSUFBdkUsRUFBNkU7QUFDM0UsUUFBSUEsSUFBSSxHQUFHRixrQkFBa0IsQ0FBQ0wsQ0FBbkIsQ0FBcUJPLElBQWhDO0FBQ0EsUUFBSUMsZ0JBQWdCLEdBQUdELElBQUksQ0FBQ0Usb0JBQTVCO0FBQ0EsUUFBSUMsb0JBQW9CLEdBQUdILElBQUksQ0FBQ0ksd0JBQWhDLENBSDJFLENBSzNFOztBQUNBendCLFdBQU8sSUFBSXN3QixnQkFBZ0IsR0FBR0Usb0JBQTlCO0FBQ0Q7O0FBRURyQixRQUFNLENBQUMxeUIsRUFBUCxDQUFVLG1CQUFWLEVBQStCNlUsS0FBSyxJQUFJO0FBQ3RDLFFBQUlvZixPQUFPLEdBQUdoQixVQUFVLEVBQXhCOztBQUNBLFFBQUlnQixPQUFPLEtBQUtwZixLQUFLLENBQUNqUCxPQUF0QixFQUErQjtBQUM3QnJDLGFBQU8sSUFBSSxDQUFYO0FBQ0Q7QUFDRixHQUxEO0FBT0FtdkIsUUFBTSxDQUFDMXlCLEVBQVAsQ0FBVSxrQkFBVixFQUE4QjZVLEtBQUssSUFBSTtBQUNyQyxRQUFJalQsTUFBTSxHQUFHb3hCLGVBQWUsQ0FBQ25lLEtBQUssQ0FBQ2pQLE9BQVAsRUFBZ0IsSUFBaEIsQ0FBNUI7O0FBQ0EsUUFBSWhFLE1BQUosRUFBWTtBQUNWQSxZQUFNLENBQUN5QixVQUFQLENBQWtCNndCLE1BQWxCLENBQXlCcmYsS0FBSyxDQUFDc2YsWUFBL0I7QUFDRDtBQUNGLEdBTEQ7QUFPQXpCLFFBQU0sQ0FBQzF5QixFQUFQLENBQVUsMkJBQVYsRUFBdUM2VSxLQUFLLElBQUk7QUFDOUMsUUFBSWpULE1BQU0sR0FBR294QixlQUFlLENBQUNuZSxLQUFLLENBQUNqUCxPQUFQLENBQTVCO0FBQ0FoRSxVQUFNLENBQUN1QixPQUFQLENBQWVoTyxJQUFmLENBQW9CMGYsS0FBSyxDQUFDdlEsSUFBMUI7QUFDRCxHQUhEO0FBS0FvdUIsUUFBTSxDQUFDMXlCLEVBQVAsQ0FBVSwwQkFBVixFQUFzQzZVLEtBQUssSUFBSTtBQUM3QyxRQUFJalQsTUFBTSxHQUFHb3hCLGVBQWUsQ0FBQ25lLEtBQUssQ0FBQ2pQLE9BQVAsRUFBZ0IsSUFBaEIsQ0FBNUI7O0FBQ0EsUUFBSWhFLE1BQUosRUFBWTtBQUNWQSxZQUFNLENBQUN1QixPQUFQLENBQWVvWixLQUFmO0FBQ0Q7QUFDRixHQUxEO0FBT0FtVyxRQUFNLENBQUMxeUIsRUFBUCxDQUFVLHNCQUFWLEVBQWtDNlUsS0FBSyxJQUFJO0FBQ3pDLFFBQUlqVCxNQUFNLEdBQUdveEIsZUFBZSxDQUFDbmUsS0FBSyxDQUFDalAsT0FBUCxDQUE1QjtBQUNBLFFBQUl6TyxLQUFLLEdBQUd5SyxNQUFNLENBQUN1QixPQUFQLENBQWVvWixLQUFmLEVBQVo7QUFDQSxRQUFJMFgsT0FBTyxHQUFHaEIsVUFBVSxFQUF4Qjs7QUFFQSxRQUFJOTdCLEtBQUssSUFBSTg4QixPQUFPLEtBQUtwZixLQUFLLENBQUNqUCxPQUEvQixFQUF3QztBQUN0QyxVQUFJd3VCLGdCQUFnQixHQUFHdmYsS0FBSyxDQUFDdlEsSUFBTixDQUFXM0YsT0FBWCxLQUF1QnhILEtBQUssQ0FBQ3dILE9BQU4sRUFBOUM7QUFFQWdFLHNCQUFnQixJQUFJLENBQXBCO0FBQ0Fpd0IsdUJBQWlCLElBQUl3QixnQkFBckI7O0FBQ0EsVUFBSUEsZ0JBQWdCLEdBQUdueEIsZUFBdkIsRUFBd0M7QUFDdENBLHVCQUFlLEdBQUdteEIsZ0JBQWxCO0FBQ0Q7QUFDRixLQVJELE1BUU87QUFDTHZ4QixvQkFBYyxJQUFJLENBQWxCO0FBQ0Q7O0FBRURqQixVQUFNLENBQUN5QixVQUFQLENBQWtCekssR0FBbEIsQ0FBc0JpYyxLQUFLLENBQUNzZixZQUE1QjtBQUNELEdBbEJEO0FBb0JBekIsUUFBTSxDQUFDMXlCLEVBQVAsQ0FBVSxxQkFBVixFQUFpQzZVLEtBQUssSUFBSTtBQUN4QyxRQUFJalQsTUFBTSxHQUFHb3hCLGVBQWUsQ0FBQ25lLEtBQUssQ0FBQ2pQLE9BQVAsRUFBZ0IsSUFBaEIsQ0FBNUI7O0FBQ0EsUUFBSWhFLE1BQUosRUFBWTtBQUNWQSxZQUFNLENBQUN5QixVQUFQLENBQWtCNndCLE1BQWxCLENBQXlCcmYsS0FBSyxDQUFDc2YsWUFBL0I7QUFDRDtBQUNGLEdBTEQ7QUFPQXpCLFFBQU0sQ0FBQzF5QixFQUFQLENBQVUsY0FBVixFQUEwQixVQUFVNlUsS0FBVixFQUFpQjtBQUN6QyxXQUFPOGQsWUFBWSxDQUFDOWQsS0FBSyxDQUFDalAsT0FBUCxDQUFuQjtBQUNELEdBRkQ7QUFHRCxDQW5GRDs7QUFxRkEsU0FBU290QixlQUFULENBQXlCcHRCLE9BQXpCLEVBQWtDeXVCLGFBQWxDLEVBQWlEO0FBQy9DLE1BQUksT0FBT3p1QixPQUFQLEtBQW1CLFFBQXZCLEVBQWlDO0FBQy9CLFdBQU8sSUFBUDtBQUNEOztBQUVELE1BQUlBLE9BQU8sSUFBSStzQixZQUFmLEVBQTZCO0FBQzNCLFdBQU9BLFlBQVksQ0FBQy9zQixPQUFELENBQW5CO0FBQ0Q7O0FBRUQsTUFBSXl1QixhQUFKLEVBQW1CO0FBQ2pCLFdBQU8sSUFBUDtBQUNEOztBQUVEMUIsY0FBWSxDQUFDL3NCLE9BQUQsQ0FBWixHQUF3QjtBQUN0QnpDLFdBQU8sRUFBRSxFQURhO0FBRXRCRSxjQUFVLEVBQUUsSUFBSWdILEdBQUo7QUFGVSxHQUF4QjtBQUtBLFNBQU9zb0IsWUFBWSxDQUFDL3NCLE9BQUQsQ0FBbkI7QUFDRDs7QUFFRCxTQUFTcXRCLFVBQVQsR0FBc0I7QUFDcEIsTUFBSSxDQUFDUCxNQUFELElBQVcsQ0FBQ0EsTUFBTSxDQUFDVSxRQUF2QixFQUFpQztBQUMvQixXQUFPLElBQVA7QUFDRDs7QUFFRCxNQUFJdDJCLE1BQU0sR0FBRzQxQixNQUFNLENBQUNVLFFBQVAsQ0FBZ0JrQixZQUFoQixFQUFiOztBQUVBLE1BQUl4M0IsTUFBTSxDQUFDdkssSUFBUCxLQUFnQixZQUFwQixFQUFrQztBQUNoQyxXQUFPdUssTUFBTSxDQUFDOEksT0FBZDtBQUNEOztBQUVELE1BQUksQ0FBQzlJLE1BQUQsSUFBVyxDQUFDQSxNQUFNLENBQUNtM0IsT0FBdkIsRUFBZ0M7QUFDOUIsV0FBTyxJQUFQO0FBQ0Q7O0FBRUQsU0FBT24zQixNQUFNLENBQUNtM0IsT0FBZDtBQUNEOztBQUVELFNBQVNOLG9CQUFULENBQThCL3RCLE9BQTlCLEVBQXVDO0FBQ3JDLE1BQUksQ0FBQzhzQixNQUFELElBQVcsQ0FBQ0EsTUFBTSxDQUFDVSxRQUFuQixJQUErQixDQUFDVixNQUFNLENBQUNVLFFBQVAsQ0FBZ0JDLENBQWhELElBQXFELENBQUNYLE1BQU0sQ0FBQ1UsUUFBUCxDQUFnQkMsQ0FBaEIsQ0FBa0JrQixPQUE1RSxFQUFxRjtBQUNuRixXQUFPLElBQVA7QUFDRDs7QUFDRCxNQUFJQyxXQUFXLEdBQUc5QixNQUFNLENBQUNVLFFBQVAsQ0FBZ0JDLENBQWhCLENBQWtCa0IsT0FBbEIsQ0FBMEJsc0IsR0FBMUIsQ0FBOEJ6QyxPQUE5QixDQUFsQjtBQUVBLFNBQU80dUIsV0FBVyxJQUFJLElBQXRCO0FBQ0QsQzs7Ozs7Ozs7Ozs7QUMvTER2MUIsTUFBTSxDQUFDcUssTUFBUCxDQUFjO0FBQUN1ZSxZQUFVLEVBQUMsTUFBSUE7QUFBaEIsQ0FBZDtBQUEyQyxJQUFJOUcsS0FBSjtBQUFVOWhCLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFFBQVosRUFBcUI7QUFBQ0csU0FBTyxDQUFDRixDQUFELEVBQUc7QUFBQzRoQixTQUFLLEdBQUM1aEIsQ0FBTjtBQUFROztBQUFwQixDQUFyQixFQUEyQyxDQUEzQzs7QUFFOUMsU0FBUzBvQixVQUFULEdBQXVCO0FBQzVCMzJCLFFBQU0sQ0FBQzR0QixPQUFQLENBQWUsTUFBTTtBQUNuQixRQUFJLENBQUNjLE9BQU8sQ0FBQyxvQkFBRCxDQUFaLEVBQW9DO0FBQ2xDO0FBQ0Q7O0FBRUQsVUFBTTZVLE1BQU0sR0FBRzdVLE9BQU8sQ0FBQyxvQkFBRCxDQUFQLENBQThCNlUsTUFBN0MsQ0FMbUIsQ0FPbkI7QUFDQTtBQUNBOztBQUNBLFVBQU1DLGdCQUFnQixHQUFHRCxNQUFNLENBQUNuc0IsV0FBUCxDQUFtQnRULFNBQW5CLENBQTZCMi9CLGFBQXREOztBQUNBRixVQUFNLENBQUNuc0IsV0FBUCxDQUFtQnRULFNBQW5CLENBQTZCMi9CLGFBQTdCLEdBQTZDLFVBQVV4aEMsUUFBVixFQUFvQitHLE1BQXBCLEVBQTRCK00sR0FBNUIsRUFBaUM7QUFDNUUsWUFBTXJWLElBQUksR0FBR3FaLFNBQWI7O0FBRUEsVUFBSSxDQUFDOFYsS0FBSyxDQUFDYixPQUFYLEVBQW9CO0FBQ2xCLGVBQU8sSUFBSWEsS0FBSixDQUFVLE1BQU07QUFDckJod0IsZ0JBQU0sQ0FBQ3F2QixRQUFQLENBQWdCblosR0FBRyxDQUFDa1osWUFBcEI7O0FBQ0EsaUJBQU91VSxnQkFBZ0IsQ0FBQ3ZpQyxLQUFqQixDQUF1QixJQUF2QixFQUE2QlAsSUFBN0IsQ0FBUDtBQUNELFNBSE0sRUFHSmt1QixHQUhJLEVBQVA7QUFJRDs7QUFFRCxVQUFJN1ksR0FBRyxDQUFDa1osWUFBUixFQUFzQjtBQUNwQnB2QixjQUFNLENBQUNxdkIsUUFBUCxDQUFnQm5aLEdBQUcsQ0FBQ2taLFlBQXBCO0FBQ0Q7O0FBRUQsYUFBT3VVLGdCQUFnQixDQUFDdmlDLEtBQWpCLENBQXVCLElBQXZCLEVBQTZCUCxJQUE3QixDQUFQO0FBQ0QsS0FmRDtBQWdCRCxHQTNCRDtBQTRCRCxDOzs7Ozs7Ozs7OztBQy9CRHFOLE1BQU0sQ0FBQ3FLLE1BQVAsQ0FBYztBQUFDd2UsYUFBVyxFQUFDLE1BQUlBO0FBQWpCLENBQWQ7QUFBNkMsSUFBSWhMLE1BQUo7QUFBVzdkLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFFBQVosRUFBcUI7QUFBQ0csU0FBTyxDQUFDRixDQUFELEVBQUc7QUFBQzJkLFVBQU0sR0FBQzNkLENBQVA7QUFBUzs7QUFBckIsQ0FBckIsRUFBNEMsQ0FBNUM7O0FBRWpELFNBQVMyb0IsV0FBVCxHQUF3QjtBQUM3QixNQUFJOE0sYUFBYSxHQUFHLEVBQXBCOztBQUNBLE1BQUk7QUFDRkEsaUJBQWEsQ0FBQ3ovQixJQUFkLENBQW1CM0QsT0FBTyxDQUFDLGVBQUQsQ0FBMUI7QUFDRCxHQUZELENBRUUsT0FBT3ViLENBQVAsRUFBVSxDQUNWO0FBQ0Q7O0FBRUQsTUFBSTtBQUNGLFFBQUk2UyxPQUFPLENBQUMsb0JBQUQsQ0FBWCxFQUFtQztBQUNqQztBQUNBO0FBQ0FnVixtQkFBYSxDQUFDei9CLElBQWQsQ0FBbUI1RCxHQUFHLENBQUNDLE9BQUosQ0FBWSxxREFBWixDQUFuQjtBQUNEO0FBQ0YsR0FORCxDQU1FLE9BQU91YixDQUFQLEVBQVUsQ0FDVDtBQUNGOztBQUVENm5CLGVBQWEsQ0FBQzNpQyxPQUFkLENBQXNCNGlDLFlBQVksSUFBSTtBQUNwQyxRQUFJLE9BQU9BLFlBQVAsS0FBd0IsVUFBNUIsRUFBd0M7QUFDdEM7QUFDRDs7QUFFREEsZ0JBQVksQ0FBRUMsTUFBRCxJQUFZO0FBQ3ZCLFlBQU1DLE1BQU0sR0FBR0QsTUFBTSxDQUFDeHNCLFdBQVAsQ0FBbUJ0VCxTQUFuQixDQUE2QjRELEdBQTVDOztBQUNBazhCLFlBQU0sQ0FBQ3hzQixXQUFQLENBQW1CdFQsU0FBbkIsQ0FBNkI0RCxHQUE3QixHQUFtQyxVQUFVdkIsTUFBVixFQUFrQnc1QixLQUFsQixFQUF5QmxPLE9BQXpCLEVBQWtDO0FBQ25FO0FBQ0FvUyxjQUFNLENBQUMvdUIsSUFBUCxDQUFZLElBQVosRUFBa0IzTyxNQUFsQixFQUEwQnc1QixLQUExQixFQUFpQyxZQUFZO0FBQzNDLGNBQUk1bEIsU0FBUyxDQUFDLENBQUQsQ0FBVCxJQUFnQkEsU0FBUyxDQUFDLENBQUQsQ0FBVCxDQUFha1YsWUFBakMsRUFBK0M7QUFDN0NsVixxQkFBUyxDQUFDLENBQUQsQ0FBVCxDQUFha1YsWUFBYixDQUEwQjRRLGtCQUExQixHQUErQ0YsS0FBL0M7QUFDRDs7QUFFRGxPLGlCQUFPLENBQUN4d0IsS0FBUixDQUFjLElBQWQsRUFBb0I4WSxTQUFwQjtBQUNELFNBTkQ7QUFPRCxPQVREO0FBVUQsS0FaVyxDQUFaO0FBYUQsR0FsQkQ7QUFtQkQsQzs7Ozs7Ozs7Ozs7QUN2Q0RoTSxNQUFNLENBQUNxSyxNQUFQLENBQWM7QUFBQzByQixzQkFBb0IsRUFBQyxNQUFJQSxvQkFBMUI7QUFBK0N0TixZQUFVLEVBQUMsTUFBSUE7QUFBOUQsQ0FBZDtBQUF5RixJQUFJdU4sZUFBSixFQUFvQnBtQixNQUFwQjtBQUEyQjVQLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQysxQixpQkFBZSxDQUFDOTFCLENBQUQsRUFBRztBQUFDODFCLG1CQUFlLEdBQUM5MUIsQ0FBaEI7QUFBa0IsR0FBdEM7O0FBQXVDMFAsUUFBTSxDQUFDMVAsQ0FBRCxFQUFHO0FBQUMwUCxVQUFNLEdBQUMxUCxDQUFQO0FBQVM7O0FBQTFELENBQTVCLEVBQXdGLENBQXhGO0FBQTJGLElBQUkyZCxNQUFKO0FBQVc3ZCxNQUFNLENBQUNDLElBQVAsQ0FBWSxRQUFaLEVBQXFCO0FBQUNHLFNBQU8sQ0FBQ0YsQ0FBRCxFQUFHO0FBQUMyZCxVQUFNLEdBQUMzZCxDQUFQO0FBQVM7O0FBQXJCLENBQXJCLEVBQTRDLENBQTVDO0FBRzFOO0FBQ0ErMUIsYUFBYSxHQUFHLElBQWhCLEMsQ0FDQTs7QUFDQUMseUJBQXlCLEdBQUcsSUFBNUI7QUFFQSxNQUFNQyxvQkFBb0IsR0FBRyxDQUFDLENBQUNILGVBQWUsQ0FBQ0ksaUJBQS9DLEMsQ0FFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ08sU0FBU0wsb0JBQVQsR0FBaUM7QUFDdEMsUUFBTU0sY0FBYyxHQUFHem1CLE1BQU0sQ0FBQzBtQixrQkFBUCxDQUEwQjl1QixLQUExQixDQUFnQzVULE1BQXZEO0FBQ0EsTUFBSTJpQyxPQUFPLEdBQUcsS0FBZDtBQUNBLE1BQUlDLFlBQVksR0FBRzNZLE1BQU0sQ0FBQ29ELE9BQTFCO0FBRUFyUixRQUFNLENBQUMwbUIsa0JBQVAsQ0FBMEJHLEdBQTFCLENBQThCLENBQUNDLElBQUQsRUFBT0MsSUFBUCxFQUFhQyxJQUFiLEtBQXNCO0FBQ2xETCxXQUFPLEdBQUcxWSxNQUFNLENBQUNvRCxPQUFQLElBQWtCcEQsTUFBTSxDQUFDb0QsT0FBUCxLQUFtQnVWLFlBQS9DLENBRGtELENBR2xEO0FBQ0E7O0FBQ0FJLFFBQUk7QUFDTCxHQU5EOztBQVFBLE1BQUlobkIsTUFBTSxDQUFDMG1CLGtCQUFQLENBQTBCOXVCLEtBQTFCLENBQWdDNnVCLGNBQWhDLENBQUosRUFBcUQ7QUFDbkQsUUFBSTNTLE9BQU8sR0FBRzlULE1BQU0sQ0FBQzBtQixrQkFBUCxDQUEwQjl1QixLQUExQixDQUFnQzZ1QixjQUFoQyxFQUFnRHZQLE1BQTlELENBRG1ELENBR25EO0FBQ0E7QUFDQTtBQUNBOztBQUNBLFdBQU9sWCxNQUFNLENBQUMwbUIsa0JBQVAsQ0FBMEI5dUIsS0FBMUIsQ0FBZ0M1VCxNQUFoQyxHQUF5Q3lpQyxjQUFoRCxFQUFnRTtBQUM5RHptQixZQUFNLENBQUMwbUIsa0JBQVAsQ0FBMEI5dUIsS0FBMUIsQ0FBZ0NxdkIsR0FBaEM7QUFDRDs7QUFFRG5ULFdBQU8sQ0FBQyxFQUFELEVBQUssRUFBTCxFQUFTLE1BQU0sQ0FBRSxDQUFqQixDQUFQO0FBQ0Q7O0FBRUQsU0FBTzZTLE9BQVA7QUFDRDs7QUFFRCxNQUFNTyxVQUFVLEdBQUdoSyxNQUFNLEVBQXpCOztBQUVPLFNBQWVyRSxVQUFmO0FBQUEsa0NBQTRCO0FBQ2pDLFFBQUksQ0FBQ3NOLG9CQUFvQixFQUFyQixJQUEyQixDQUFDSSxvQkFBaEMsRUFBc0Q7QUFDcEQ7QUFDRDs7QUFFRCxVQUFNWSxRQUFRLEdBQUd4a0MsT0FBTyxDQUFDLFVBQUQsQ0FBeEI7O0FBRUF5akMsbUJBQWUsQ0FBQ2dCLCtCQUFoQixDQUFnRCxxQkFBaEQsRUFBdUUsVUFBVUMsT0FBVixFQUFtQjtBQUN4RjtBQUVBLFVBQUlBLE9BQU8sQ0FBQ0gsVUFBRCxDQUFYLEVBQXlCO0FBQ3ZCRyxlQUFPLENBQUNILFVBQUQsQ0FBUCxDQUFvQkksVUFBcEIsR0FBaUMsSUFBakM7QUFDRCxPQUx1RixDQU94RjtBQUNBOzs7QUFDQSxhQUFPLEtBQVA7QUFDRCxLQVZELEVBUGlDLENBbUJqQztBQUNBOztBQUNBLFFBQUlDLHFCQUFxQixHQUFHdm5CLE1BQU0sQ0FBQ3duQixpQkFBbkM7O0FBQ0F4bkIsVUFBTSxDQUFDd25CLGlCQUFQLEdBQTJCLFVBQVVwdkIsR0FBVixFQUFlO0FBQ3hDLFVBQUl1RixNQUFNLEdBQUc0cEIscUJBQXFCLENBQUNqa0MsS0FBdEIsQ0FBNEIsSUFBNUIsRUFBa0M4WSxTQUFsQyxDQUFiOztBQUVBLFVBQUl1QixNQUFNLElBQUl2RixHQUFHLENBQUNrWixZQUFsQixFQUFnQztBQUM5QjNULGNBQU0sQ0FBQ3VwQixVQUFELENBQU4sR0FBcUI5dUIsR0FBRyxDQUFDa1osWUFBekI7QUFDRDs7QUFFRCxhQUFPM1QsTUFBUDtBQUNELEtBUkQsQ0F0QmlDLENBZ0NqQztBQUNBOzs7QUFDQXFDLFVBQU0sQ0FBQzBtQixrQkFBUCxDQUEwQjl1QixLQUExQixDQUFnQzFVLE9BQWhDLENBQXdDO0FBQ3RDOCtCLFdBQUssRUFBRSxFQUQrQjtBQUV0QzlLLFlBQU0sRUFBRSxDQUFDOWUsR0FBRCxFQUFNN1MsR0FBTixFQUFXeWhDLElBQVgsS0FBb0I7QUFDNUIsY0FBTXY5QixJQUFJLEdBQUcwOUIsUUFBUSxDQUFDL3VCLEdBQUQsQ0FBUixDQUFjcXZCLFFBQTNCO0FBQ0EsY0FBTXQ3QixLQUFLLEdBQUdqSyxNQUFNLENBQUN5bUIsTUFBUCxDQUFjcmdCLEtBQWQsV0FBdUI4UCxHQUFHLENBQUM1UCxNQUEzQixjQUFxQ2lCLElBQXJDLEdBQTZDLE1BQTdDLENBQWQ7O0FBRUEsY0FBTTNELE9BQU8sR0FBRzVELE1BQU0sQ0FBQ3ltQixNQUFQLENBQWNOLG1CQUFkLENBQWtDalEsR0FBRyxDQUFDdFMsT0FBdEMsQ0FBaEI7O0FBQ0E1RCxjQUFNLENBQUN5bUIsTUFBUCxDQUFjM0MsS0FBZCxDQUFvQjdaLEtBQXBCLEVBQTJCLE9BQTNCLEVBQW9DO0FBQ2xDK1EsYUFBRyxFQUFFOUUsR0FBRyxDQUFDOEUsR0FEeUI7QUFFbEMxVSxnQkFBTSxFQUFFNFAsR0FBRyxDQUFDNVAsTUFGc0I7QUFHbEMxQyxpQkFBTyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsT0FBZjtBQUh5QixTQUFwQztBQUtBc1MsV0FBRyxDQUFDa1osWUFBSixHQUFtQjtBQUFFbmxCO0FBQUYsU0FBbkI7QUFFQTVHLFdBQUcsQ0FBQzRMLEVBQUosQ0FBTyxRQUFQLEVBQWlCLE1BQU07QUFDckIsY0FBSWlILEdBQUcsQ0FBQ2taLFlBQUosQ0FBaUJvVyxVQUFyQixFQUFpQztBQUMvQnhsQyxrQkFBTSxDQUFDeW1CLE1BQVAsQ0FBYy9CLFFBQWQsQ0FBdUJ6YSxLQUF2QixFQUE4QmlNLEdBQUcsQ0FBQ2taLFlBQUosQ0FBaUJvVyxVQUEvQztBQUNEOztBQUVEeGxDLGdCQUFNLENBQUN5bUIsTUFBUCxDQUFjOUIsWUFBZCxDQUEyQjFhLEtBQTNCOztBQUVBLGNBQUlpTSxHQUFHLENBQUNrWixZQUFKLENBQWlCcVcsUUFBckIsRUFBK0I7QUFDN0J4N0IsaUJBQUssQ0FBQzFDLElBQU4sYUFBZ0IyTyxHQUFHLENBQUM1UCxNQUFwQjtBQUNELFdBRkQsTUFFTyxJQUFJNFAsR0FBRyxDQUFDa1osWUFBSixDQUFpQjRRLGtCQUFyQixFQUF5QztBQUM5Qy8xQixpQkFBSyxDQUFDMUMsSUFBTixhQUFnQjJPLEdBQUcsQ0FBQzVQLE1BQXBCLGNBQThCNFAsR0FBRyxDQUFDa1osWUFBSixDQUFpQjRRLGtCQUEvQztBQUNELFdBRk0sTUFFQSxJQUFJOXBCLEdBQUcsQ0FBQ2taLFlBQUosQ0FBaUJnVyxVQUFyQixFQUFpQztBQUN0Q243QixpQkFBSyxDQUFDMUMsSUFBTixhQUFnQjJPLEdBQUcsQ0FBQzVQLE1BQXBCO0FBQ0Q7O0FBRUQsZ0JBQU1vL0IsTUFBTSxHQUFHeHZCLEdBQUcsQ0FBQ3RTLE9BQUosQ0FBWSxjQUFaLE1BQWdDLGtCQUEvQztBQUNBLGdCQUFNK2hDLFlBQVksR0FBR3p2QixHQUFHLENBQUN0UyxPQUFKLENBQVksZ0JBQVosSUFBZ0MsQ0FBaEMsSUFBcUNzUyxHQUFHLENBQUN0UyxPQUFKLENBQVksZ0JBQVosSUFBZ0N1Z0MsYUFBMUYsQ0FoQnFCLENBa0JyQjtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLGNBQUlqdUIsR0FBRyxDQUFDNVAsTUFBSixLQUFlLE1BQWYsSUFBeUI0UCxHQUFHLENBQUMyRixJQUE3QixJQUFxQzZwQixNQUFyQyxJQUErQ0MsWUFBbkQsRUFBaUU7QUFDL0QsZ0JBQUk7QUFDRixrQkFBSTlwQixJQUFJLEdBQUdoWSxJQUFJLENBQUNDLFNBQUwsQ0FBZW9TLEdBQUcsQ0FBQzJGLElBQW5CLENBQVgsQ0FERSxDQUdGO0FBQ0E7O0FBQ0Esa0JBQUlBLElBQUksQ0FBQy9aLE1BQUwsR0FBY3NpQyx5QkFBbEIsRUFBNkM7QUFDM0NuNkIscUJBQUssQ0FBQzRMLE1BQU4sQ0FBYSxDQUFiLEVBQWdCdFMsSUFBaEIsQ0FBcUJzWSxJQUFyQixHQUE0QkEsSUFBNUI7QUFDRDtBQUNGLGFBUkQsQ0FRRSxPQUFPRyxDQUFQLEVBQVUsQ0FDVjtBQUNEO0FBQ0YsV0FuQ29CLENBcUNyQjs7O0FBQ0FoYyxnQkFBTSxDQUFDeW1CLE1BQVAsQ0FBYzNDLEtBQWQsQ0FBb0I3WixLQUFwQixFQUEyQixVQUEzQjtBQUNBLGNBQUkyN0IsS0FBSyxHQUFHNWxDLE1BQU0sQ0FBQ3ltQixNQUFQLENBQWNsQixVQUFkLENBQXlCdGIsS0FBekIsQ0FBWjtBQUNBakssZ0JBQU0sQ0FBQ2lzQixNQUFQLENBQWNNLElBQWQsQ0FBbUJ0VyxjQUFuQixDQUFrQzJ2QixLQUFsQyxFQUF5QzF2QixHQUF6QyxFQUE4QzdTLEdBQTlDO0FBQ0QsU0F6Q0Q7QUEyQ0F5aEMsWUFBSTtBQUNMO0FBMUR1QyxLQUF4Qzs7QUE4REEsYUFBU2UsV0FBVCxDQUFxQmpVLE9BQXJCLEVBQThCO0FBQzVCO0FBQ0E7QUFDQSxVQUFJa1UsWUFBWSxHQUFHbFUsT0FBTyxDQUFDOXZCLE1BQVIsS0FBbUIsQ0FBdEM7O0FBRUEsZUFBU2lrQyxPQUFULENBQWlCN3ZCLEdBQWpCLEVBQXNCN1MsR0FBdEIsRUFBMkJ5aEMsSUFBM0IsRUFBaUM7QUFDL0IsWUFBSXBnQyxLQUFKOztBQUNBLFlBQUlvaEMsWUFBSixFQUFrQjtBQUNoQnBoQyxlQUFLLEdBQUd3UixHQUFSO0FBQ0FBLGFBQUcsR0FBRzdTLEdBQU47QUFDQUEsYUFBRyxHQUFHeWhDLElBQU47QUFDQUEsY0FBSSxHQUFHNXFCLFNBQVMsQ0FBQyxDQUFELENBQWhCO0FBQ0Q7O0FBRUQsY0FBTWlTLFVBQVUsR0FBR2pXLEdBQUcsQ0FBQ2taLFlBQXZCOztBQUNBcHZCLGNBQU0sQ0FBQ3F2QixRQUFQLENBQWdCbEQsVUFBaEI7O0FBRUEsWUFBSTZaLFVBQVUsR0FBRyxLQUFqQixDQVorQixDQWEvQjs7QUFDQSxpQkFBU0MsV0FBVCxHQUE4QjtBQUM1QixjQUFJOVosVUFBVSxJQUFJQSxVQUFVLENBQUNxWixVQUE3QixFQUF5QztBQUN2Q3hsQyxrQkFBTSxDQUFDeW1CLE1BQVAsQ0FBYy9CLFFBQWQsQ0FBdUJ4TyxHQUFHLENBQUNrWixZQUFKLENBQWlCbmxCLEtBQXhDLEVBQStDaU0sR0FBRyxDQUFDa1osWUFBSixDQUFpQm9XLFVBQWhFO0FBQ0F0dkIsZUFBRyxDQUFDa1osWUFBSixDQUFpQm9XLFVBQWpCLEdBQThCLElBQTlCO0FBQ0Q7O0FBRURRLG9CQUFVLEdBQUcsSUFBYjtBQUNBbEIsY0FBSSxDQUFDLFlBQUQsQ0FBSjtBQUNEOztBQUVELFlBQUlvQixnQkFBSjs7QUFFQSxZQUFJSixZQUFKLEVBQWtCO0FBQ2hCSSwwQkFBZ0IsR0FBR3RVLE9BQU8sQ0FBQzNjLElBQVIsQ0FBYSxJQUFiLEVBQW1CdlEsS0FBbkIsRUFBMEJ3UixHQUExQixFQUErQjdTLEdBQS9CLEVBQW9DNGlDLFdBQXBDLENBQW5CO0FBQ0QsU0FGRCxNQUVPO0FBQ0xDLDBCQUFnQixHQUFHdFUsT0FBTyxDQUFDM2MsSUFBUixDQUFhLElBQWIsRUFBbUJpQixHQUFuQixFQUF3QjdTLEdBQXhCLEVBQTZCNGlDLFdBQTdCLENBQW5CO0FBQ0Q7O0FBRUQsWUFBSUMsZ0JBQWdCLElBQUksT0FBT0EsZ0JBQWdCLENBQUNsdkIsSUFBeEIsS0FBaUMsVUFBekQsRUFBcUU7QUFDbkVrdkIsMEJBQWdCLENBQUNsdkIsSUFBakIsQ0FBc0IsTUFBTTtBQUMxQjtBQUNBO0FBQ0EsZ0JBQUltVixVQUFVLElBQUksQ0FBQzlvQixHQUFHLENBQUM4aUMsUUFBbkIsSUFBK0IsQ0FBQ0gsVUFBcEMsRUFBZ0Q7QUFDOUMsb0JBQU1oaUIsU0FBUyxHQUFHaGtCLE1BQU0sQ0FBQ3ltQixNQUFQLENBQWN4QyxZQUFkLENBQTJCa0ksVUFBVSxDQUFDbGlCLEtBQXRDLENBQWxCOztBQUNBLGtCQUFJK1osU0FBUyxDQUFDRyxLQUFkLEVBQXFCO0FBQ25CO0FBQ0E7QUFDQWdJLDBCQUFVLENBQUNxWixVQUFYLEdBQXdCeGxDLE1BQU0sQ0FBQ3ltQixNQUFQLENBQWMzQyxLQUFkLENBQW9CcUksVUFBVSxDQUFDbGlCLEtBQS9CLEVBQXNDLE9BQXRDLENBQXhCO0FBQ0Q7QUFDRjtBQUNGLFdBWEQ7QUFZRDs7QUFFRCxlQUFPaThCLGdCQUFQO0FBQ0Q7O0FBRUQsVUFBSUosWUFBSixFQUFrQjtBQUNoQixlQUFPLFVBQVVwaEMsS0FBVixFQUFpQndSLEdBQWpCLEVBQXNCN1MsR0FBdEIsRUFBMkJ5aEMsSUFBM0IsRUFBaUM7QUFDdEMsaUJBQU9pQixPQUFPLENBQUNyaEMsS0FBRCxFQUFRd1IsR0FBUixFQUFhN1MsR0FBYixFQUFrQnloQyxJQUFsQixDQUFkO0FBQ0QsU0FGRDtBQUdELE9BSkQsTUFJTztBQUNMLGVBQU8sVUFBVTV1QixHQUFWLEVBQWU3UyxHQUFmLEVBQW9CeWhDLElBQXBCLEVBQTBCO0FBQy9CLGlCQUFPaUIsT0FBTyxDQUFDN3ZCLEdBQUQsRUFBTTdTLEdBQU4sRUFBV3loQyxJQUFYLENBQWQ7QUFDRCxTQUZEO0FBR0Q7QUFDRjs7QUFFRCxhQUFTc0IsV0FBVCxDQUFxQkMsR0FBckIsRUFBMEJDLFNBQTFCLEVBQXFDO0FBQ25DLFVBQUlDLE1BQU0sR0FBR0YsR0FBRyxDQUFDMUIsR0FBakI7O0FBQ0EsVUFBSTJCLFNBQUosRUFBZTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQUQsV0FBRyxDQUFDM3dCLEtBQUosQ0FBVXhVLE9BQVYsQ0FBa0JvUyxLQUFLLElBQUk7QUFDekIsY0FBSWt6QixjQUFjLEdBQUdYLFdBQVcsQ0FBQ3Z5QixLQUFLLENBQUMwaEIsTUFBUCxDQUFoQzs7QUFDQSxjQUFJMWhCLEtBQUssQ0FBQzBoQixNQUFOLENBQWFsekIsTUFBYixJQUF1QixDQUEzQixFQUE4QjtBQUM1QndSLGlCQUFLLENBQUMwaEIsTUFBTixHQUFlLFVBQVV0d0IsS0FBVixFQUFpQndSLEdBQWpCLEVBQXNCN1MsR0FBdEIsRUFBMkJ5aEMsSUFBM0IsRUFBaUM7QUFDOUMscUJBQU9yb0IsT0FBTyxDQUFDZ3FCLFVBQVIsQ0FDTEQsY0FESyxFQUVMLElBRkssRUFHTHRzQixTQUhLLEVBSUwsSUFKSyxDQUFQO0FBTUQsYUFQRDtBQVFELFdBVEQsTUFTTztBQUNMNUcsaUJBQUssQ0FBQzBoQixNQUFOLEdBQWUsVUFBVTllLEdBQVYsRUFBZTdTLEdBQWYsRUFBb0J5aEMsSUFBcEIsRUFBMEI7QUFDdkMscUJBQU9yb0IsT0FBTyxDQUFDZ3FCLFVBQVIsQ0FDTEQsY0FESyxFQUVMLElBRkssRUFHTHRzQixTQUhLLEVBSUwsSUFKSyxDQUFQO0FBTUQsYUFQRDtBQVFEO0FBQ0YsU0FyQkQ7QUFzQkQ7O0FBQ0Rtc0IsU0FBRyxDQUFDMUIsR0FBSixHQUFVLFlBQW1CO0FBQUEsMENBQU45akMsSUFBTTtBQUFOQSxjQUFNO0FBQUE7O0FBQzNCQSxZQUFJLENBQUNBLElBQUksQ0FBQ2lCLE1BQUwsR0FBYyxDQUFmLENBQUosR0FBd0IrakMsV0FBVyxDQUFDaGxDLElBQUksQ0FBQ0EsSUFBSSxDQUFDaUIsTUFBTCxHQUFjLENBQWYsQ0FBTCxDQUFuQztBQUNBLGVBQU95a0MsTUFBTSxDQUFDbmxDLEtBQVAsQ0FBYWlsQyxHQUFiLEVBQWtCeGxDLElBQWxCLENBQVA7QUFDRCxPQUhEO0FBSUQ7O0FBRUR1bEMsZUFBVyxDQUFDdG9CLE1BQU0sQ0FBQzBtQixrQkFBUixFQUE0QixLQUE1QixDQUFYO0FBQ0E0QixlQUFXLENBQUNsQyxlQUFlLENBQUN3QyxzQkFBakIsRUFBeUMsS0FBekMsQ0FBWCxDQTNNaUMsQ0E2TWpDO0FBQ0E7O0FBQ0FOLGVBQVcsQ0FBQ3RvQixNQUFNLENBQUM2b0IsZUFBUixFQUF5QixJQUF6QixDQUFYO0FBRUFQLGVBQVcsQ0FBQ3RvQixNQUFNLENBQUM4b0IsVUFBUixFQUFvQixLQUFwQixDQUFYO0FBRUEsUUFBSUMsd0JBQXdCLEdBQUczQyxlQUFlLENBQUM0QyxxQkFBL0M7QUFDQSxVQUFNQyxhQUFhLEdBQUdsQixXQUFXLENBQUNnQix3QkFBd0IsQ0FBQ3ZuQixJQUF6QixDQUE4QjRrQixlQUE5QixFQUErQ0EsZUFBZSxDQUFDSSxpQkFBL0QsQ0FBRCxDQUFqQzs7QUFDQUosbUJBQWUsQ0FBQzRDLHFCQUFoQixHQUF3QyxVQUFVRSxZQUFWLEVBQXdCOXdCLEdBQXhCLEVBQTZCN1MsR0FBN0IsRUFBa0N5aEMsSUFBbEMsRUFBd0M7QUFDOUUsVUFBSTV1QixHQUFHLENBQUNrWixZQUFSLEVBQXNCO0FBQ3BCbFosV0FBRyxDQUFDa1osWUFBSixDQUFpQnFXLFFBQWpCLEdBQTRCLElBQTVCO0FBQ0Q7O0FBRUQsYUFBT3NCLGFBQWEsQ0FBQzd3QixHQUFELEVBQU03UyxHQUFOLEVBQVcsWUFBWTtBQUN6QztBQUNBO0FBQ0E2UyxXQUFHLENBQUNrWixZQUFKLENBQWlCcVcsUUFBakIsR0FBNEIsS0FBNUI7QUFDQSxlQUFPWCxJQUFJLENBQUMxakMsS0FBTCxDQUFXLElBQVgsRUFBaUI4WSxTQUFqQixDQUFQO0FBQ0QsT0FMbUIsQ0FBcEI7QUFNRCxLQVhEO0FBWUQsR0FqT007QUFBQSxDOzs7Ozs7Ozs7OztBQ2hEUCxTQUFTK3NCLGdCQUFULENBQTJCMS9CLElBQTNCLEVBQWlDO0FBQy9CLFNBQU9BLElBQUksQ0FBQzIvQixPQUFMLENBQWEsU0FBYixFQUF3QixRQUF4QixDQUFQO0FBQ0Q7O0FBRURsbkMsTUFBTSxDQUFDbW5DLFNBQVAsR0FBbUIsVUFBVWhtQixHQUFWLEVBQWU7QUFDaEMsTUFBSWxoQixPQUFPLEdBQUcsRUFBZDs7QUFDQSxPQUFJLElBQUlzSCxJQUFSLElBQWdCNFosR0FBaEIsRUFBcUI7QUFDbkIsUUFBSXhaLEtBQUssR0FBR3daLEdBQUcsQ0FBQzVaLElBQUQsQ0FBZjtBQUNBLFFBQUk2L0IsY0FBYyxHQUFHSCxnQkFBZ0IsQ0FBQzEvQixJQUFELENBQXJDO0FBQ0EsUUFBSWtHLElBQUksR0FBR3pOLE1BQU0sQ0FBQ21uQyxTQUFQLENBQWlCRSxRQUFqQixDQUEwQkQsY0FBMUIsQ0FBWDs7QUFFQSxRQUFHMzVCLElBQUksSUFBSTlGLEtBQVgsRUFBa0I7QUFDaEIxSCxhQUFPLENBQUN3TixJQUFJLENBQUNsRyxJQUFOLENBQVAsR0FBcUJrRyxJQUFJLENBQUM2NUIsTUFBTCxDQUFZMy9CLEtBQVosQ0FBckI7QUFDRDtBQUNGOztBQUVELFNBQU8xSCxPQUFQO0FBQ0QsQ0FiRDs7QUFnQkFELE1BQU0sQ0FBQ21uQyxTQUFQLENBQWlCenNCLFFBQWpCLEdBQTRCLFVBQVU2c0IsR0FBVixFQUFlO0FBQ3pDLE1BQUloZSxHQUFHLEdBQUc3TyxRQUFRLENBQUM2c0IsR0FBRCxDQUFsQjtBQUNBLE1BQUdoZSxHQUFHLElBQUlBLEdBQUcsS0FBSyxDQUFsQixFQUFxQixPQUFPQSxHQUFQO0FBQ3JCLFFBQU0sSUFBSTVuQixLQUFKLENBQVUsMkJBQXlCNG5CLEdBQXpCLEdBQTZCLG1CQUF2QyxDQUFOO0FBQ0QsQ0FKRDs7QUFPQXZwQixNQUFNLENBQUNtbkMsU0FBUCxDQUFpQkssU0FBakIsR0FBNkIsVUFBVUQsR0FBVixFQUFlO0FBQzFDQSxLQUFHLEdBQUdBLEdBQUcsQ0FBQ0UsV0FBSixFQUFOO0FBQ0EsTUFBR0YsR0FBRyxLQUFLLE1BQVgsRUFBbUIsT0FBTyxJQUFQO0FBQ25CLE1BQUdBLEdBQUcsS0FBSyxPQUFYLEVBQW9CLE9BQU8sS0FBUDtBQUNwQixRQUFNLElBQUk1bEMsS0FBSixDQUFVLDBCQUF3QjRsQyxHQUF4QixHQUE0QixtQkFBdEMsQ0FBTjtBQUNELENBTEQ7O0FBUUF2bkMsTUFBTSxDQUFDbW5DLFNBQVAsQ0FBaUJsQyxRQUFqQixHQUE0QixVQUFVc0MsR0FBVixFQUFlO0FBQ3pDLFNBQU9BLEdBQVA7QUFDRCxDQUZEOztBQUtBdm5DLE1BQU0sQ0FBQ21uQyxTQUFQLENBQWlCTyxXQUFqQixHQUErQixVQUFVSCxHQUFWLEVBQWU7QUFDNUMsU0FBT0EsR0FBUDtBQUNELENBRkQ7O0FBS0F2bkMsTUFBTSxDQUFDbW5DLFNBQVAsQ0FBaUJFLFFBQWpCLEdBQTRCO0FBQzFCO0FBQ0FNLGNBQVksRUFBRTtBQUNacGdDLFFBQUksRUFBRSxPQURNO0FBRVorL0IsVUFBTSxFQUFFdG5DLE1BQU0sQ0FBQ21uQyxTQUFQLENBQWlCTztBQUZiLEdBRlk7QUFNMUJFLGtCQUFnQixFQUFFO0FBQ2hCcmdDLFFBQUksRUFBRSxXQURVO0FBRWhCKy9CLFVBQU0sRUFBRXRuQyxNQUFNLENBQUNtbkMsU0FBUCxDQUFpQk87QUFGVCxHQU5RO0FBVTFCO0FBQ0FHLHdDQUFzQyxFQUFFO0FBQ3RDdGdDLFFBQUksRUFBRSx1QkFEZ0M7QUFFdEMrL0IsVUFBTSxFQUFFdG5DLE1BQU0sQ0FBQ21uQyxTQUFQLENBQWlCenNCO0FBRmEsR0FYZDtBQWUxQjtBQUNBb3RCLG1DQUFpQyxFQUFFO0FBQ2pDdmdDLFFBQUksRUFBRSxtQkFEMkI7QUFFakMrL0IsVUFBTSxFQUFFdG5DLE1BQU0sQ0FBQ21uQyxTQUFQLENBQWlCenNCO0FBRlEsR0FoQlQ7QUFvQjFCO0FBQ0FxdEIsdUNBQXFDLEVBQUU7QUFDckN4Z0MsUUFBSSxFQUFFLHNCQUQrQjtBQUVyQysvQixVQUFNLEVBQUV0bkMsTUFBTSxDQUFDbW5DLFNBQVAsQ0FBaUJ6c0I7QUFGWSxHQXJCYjtBQXlCMUI7QUFDQXN0QixrQ0FBZ0MsRUFBRTtBQUNoQ3pnQyxRQUFJLEVBQUUsa0JBRDBCO0FBRWhDKy9CLFVBQU0sRUFBRXRuQyxNQUFNLENBQUNtbkMsU0FBUCxDQUFpQks7QUFGTyxHQTFCUjtBQThCMUI7QUFDQVMscUNBQW1DLEVBQUU7QUFDbkMxZ0MsUUFBSSxFQUFFLHFCQUQ2QjtBQUVuQysvQixVQUFNLEVBQUV0bkMsTUFBTSxDQUFDbW5DLFNBQVAsQ0FBaUJLO0FBRlUsR0EvQlg7QUFtQzFCO0FBQ0FVLHdCQUFzQixFQUFFO0FBQ3RCM2dDLFFBQUksRUFBRSxVQURnQjtBQUV0QisvQixVQUFNLEVBQUV0bkMsTUFBTSxDQUFDbW5DLFNBQVAsQ0FBaUJsQztBQUZILEdBcENFO0FBd0MxQjtBQUNBa0Qsd0JBQXNCLEVBQUU7QUFDdEI1Z0MsUUFBSSxFQUFFLFVBRGdCO0FBRXRCKy9CLFVBQU0sRUFBRXRuQyxNQUFNLENBQUNtbkMsU0FBUCxDQUFpQk87QUFGSCxHQXpDRTtBQTZDMUI7QUFDQVUsK0JBQTZCLEVBQUU7QUFDN0I3Z0MsUUFBSSxFQUFFLGdCQUR1QjtBQUU3QisvQixVQUFNLEVBQUV0bkMsTUFBTSxDQUFDbW5DLFNBQVAsQ0FBaUJ6c0I7QUFGSSxHQTlDTDtBQWtEMUI7QUFDQTJ0QixxQkFBbUIsRUFBRTtBQUNuQjlnQyxRQUFJLEVBQUUsT0FEYTtBQUVuQisvQixVQUFNLEVBQUV0bkMsTUFBTSxDQUFDbW5DLFNBQVAsQ0FBaUJsQztBQUZOLEdBbkRLO0FBdUQxQjtBQUNBcUQsd0NBQXNDLEVBQUU7QUFDdEMvZ0MsUUFBSSxFQUFFLHVCQURnQztBQUV0QysvQixVQUFNLEVBQUV0bkMsTUFBTSxDQUFDbW5DLFNBQVAsQ0FBaUJ6c0I7QUFGYSxHQXhEZDtBQTREMUI7QUFDQTZ0QiwwQkFBd0IsRUFBRTtBQUN4QmhoQyxRQUFJLEVBQUUsa0JBRGtCO0FBRXhCKy9CLFVBQU0sRUFBRXRuQyxNQUFNLENBQUNtbkMsU0FBUCxDQUFpQks7QUFGRCxHQTdEQTtBQWlFMUJnQix5QkFBdUIsRUFBRTtBQUN2QmpoQyxRQUFJLEVBQUUsaUJBRGlCO0FBRXZCKy9CLFVBQU0sRUFBRXRuQyxNQUFNLENBQUNtbkMsU0FBUCxDQUFpQk87QUFGRixHQWpFQztBQXFFMUJlLHlCQUF1QixFQUFFO0FBQ3ZCbGhDLFFBQUksRUFBRSxpQkFEaUI7QUFFdkIrL0IsVUFBTSxFQUFFdG5DLE1BQU0sQ0FBQ21uQyxTQUFQLENBQWlCSztBQUZGO0FBckVDLENBQTVCLEM7Ozs7Ozs7Ozs7O0FDN0NBeG5DLE1BQU0sQ0FBQzBvQyxlQUFQLEdBQXlCLFlBQVc7QUFDbEMsTUFBSXpvQyxPQUFPLEdBQUdELE1BQU0sQ0FBQ21uQyxTQUFQLENBQWlCOTNCLE9BQU8sQ0FBQzhSLEdBQXpCLENBQWQ7O0FBQ0EsTUFBR2xoQixPQUFPLENBQUMrVSxLQUFSLElBQWlCL1UsT0FBTyxDQUFDMHNCLFNBQTVCLEVBQXVDO0FBRXJDM3NCLFVBQU0sQ0FBQzBzQixPQUFQLENBQ0V6c0IsT0FBTyxDQUFDK1UsS0FEVixFQUVFL1UsT0FBTyxDQUFDMHNCLFNBRlYsRUFHRTFzQixPQUhGOztBQU1BRCxVQUFNLENBQUMwc0IsT0FBUCxHQUFpQixZQUFXO0FBQzFCLFlBQU0sSUFBSS9xQixLQUFKLENBQVUsZ0ZBQVYsQ0FBTjtBQUNELEtBRkQ7QUFHRDtBQUNGLENBZEQ7O0FBaUJBM0IsTUFBTSxDQUFDMm9DLG9CQUFQLEdBQThCLFlBQVk7QUFDeEMsTUFBSUMsYUFBYSxHQUFHem9DLE1BQU0sQ0FBQzBvQyxRQUFQLENBQWdCQyxLQUFoQixJQUF5QjNvQyxNQUFNLENBQUMwb0MsUUFBUCxDQUFnQmhiLE1BQTdEOztBQUVBLE1BQ0UrYSxhQUFhLElBQ2JBLGFBQWEsQ0FBQzV6QixLQURkLElBRUE0ekIsYUFBYSxDQUFDamMsU0FIaEIsRUFJRTtBQUNBM3NCLFVBQU0sQ0FBQzBzQixPQUFQLENBQ0VrYyxhQUFhLENBQUM1ekIsS0FEaEIsRUFFRTR6QixhQUFhLENBQUNqYyxTQUZoQixFQUdFaWMsYUFBYSxDQUFDM29DLE9BQWQsSUFBeUIsRUFIM0I7O0FBTUFELFVBQU0sQ0FBQzBzQixPQUFQLEdBQWlCLFlBQVc7QUFDMUIsWUFBTSxJQUFJL3FCLEtBQUosQ0FBVSwwRUFBVixDQUFOO0FBQ0QsS0FGRDtBQUdEO0FBQ0YsQ0FsQkQsQyxDQXFCQTs7O0FBQ0EzQixNQUFNLENBQUMwb0MsZUFBUDs7QUFDQTFvQyxNQUFNLENBQUMyb0Msb0JBQVAsRzs7Ozs7Ozs7Ozs7QUN4Q0EsSUFBSXhvQyxNQUFKO0FBQVcrTixNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNoTyxRQUFNLENBQUNpTyxDQUFELEVBQUc7QUFBQ2pPLFVBQU0sR0FBQ2lPLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFFWCxNQUFNMjZCLG1CQUFtQixHQUFHLENBQzFCLHNCQUQwQixFQUUxQixpQkFGMEIsRUFHMUIsb0JBSDBCLENBQTVCO0FBTUE1b0MsTUFBTSxDQUFDNHRCLE9BQVAsQ0FBZSxNQUFNO0FBQ25CZ2IscUJBQW1CLENBQUM3bkMsT0FBcEIsQ0FBNkJxRyxJQUFELElBQVU7QUFDcEMsUUFBSUEsSUFBSSxJQUFJc25CLE9BQVosRUFBcUI7QUFDbkIxckIsYUFBTyxDQUFDNFgsR0FBUiw0Q0FBZ0R4VCxJQUFoRDtBQUNEO0FBQ0YsR0FKRDtBQUtELENBTkQsRSIsImZpbGUiOiIvcGFja2FnZXMvbW9udGlhcG1fYWdlbnQuanMiLCJzb3VyY2VzQ29udGVudCI6WyJnZXRDbGllbnRBcmNoVmVyc2lvbiA9IGZ1bmN0aW9uIChhcmNoKSB7XG4gIGNvbnN0IGF1dG91cGRhdGUgPSBfX21ldGVvcl9ydW50aW1lX2NvbmZpZ19fLmF1dG91cGRhdGVcblxuICBpZiAoYXV0b3VwZGF0ZSkge1xuICAgIHJldHVybiBhdXRvdXBkYXRlLnZlcnNpb25zW2FyY2hdID8gYXV0b3VwZGF0ZS52ZXJzaW9uc1thcmNoXS52ZXJzaW9uIDogJ25vbmUnO1xuICB9XG5cbiAgLy8gTWV0ZW9yIDEuNyBhbmQgb2xkZXIgZGlkIG5vdCBoYXZlIGFuIGBhdXRvdXBkYXRlYCBvYmplY3QuXG4gIHN3aXRjaCAoYXJjaCkge1xuICAgIGNhc2UgJ2NvcmRvdmEud2ViJzpcbiAgICAgIHJldHVybiBfX21ldGVvcl9ydW50aW1lX2NvbmZpZ19fLmF1dG91cGRhdGVWZXJzaW9uQ29yZG92YTtcbiAgICBjYXNlICd3ZWIuYnJvd3Nlcic6XG4gICAgY2FzZSAnd2ViLmJyb3dzZXIubGVnYWN5JzpcbiAgICAgIC8vIE1ldGVvciAxLjcgYWx3YXlzIHVzZWQgdGhlIHdlYi5icm93c2VyLmxlZ2FjeSB2ZXJzaW9uXG4gICAgICByZXR1cm4gX19tZXRlb3JfcnVudGltZV9jb25maWdfXy5hdXRvdXBkYXRlVmVyc2lvbjtcblxuICAgIGRlZmF1bHQ6XG4gICAgICByZXR1cm4gJ25vbmUnO1xuICB9XG59XG4iLCJLYWRpcmEgPSB7fTtcbkthZGlyYS5vcHRpb25zID0ge307XG5cbk1vbnRpID0gS2FkaXJhO1xuXG5pZihNZXRlb3Iud3JhcEFzeW5jKSB7XG4gIEthZGlyYS5fd3JhcEFzeW5jID0gTWV0ZW9yLndyYXBBc3luYztcbn0gZWxzZSB7XG4gIEthZGlyYS5fd3JhcEFzeW5jID0gTWV0ZW9yLl93cmFwQXN5bmM7XG59XG5cbmlmKE1ldGVvci5pc1NlcnZlcikge1xuICB2YXIgRXZlbnRFbWl0dGVyID0gTnBtLnJlcXVpcmUoJ2V2ZW50cycpLkV2ZW50RW1pdHRlcjtcbiAgdmFyIGV2ZW50QnVzID0gbmV3IEV2ZW50RW1pdHRlcigpO1xuICBldmVudEJ1cy5zZXRNYXhMaXN0ZW5lcnMoMCk7XG5cbiAgdmFyIGJ1aWxkQXJncyA9IGZ1bmN0aW9uKGFyZ3MpIHtcbiAgICB2YXIgZXZlbnROYW1lID0gYXJnc1swXSArICctJyArIGFyZ3NbMV07XG4gICAgdmFyIGFyZ3MgPSBhcmdzLnNsaWNlKDIpO1xuICAgIGFyZ3MudW5zaGlmdChldmVudE5hbWUpO1xuICAgIHJldHVybiBhcmdzO1xuICB9O1xuICBcbiAgS2FkaXJhLkV2ZW50QnVzID0ge307XG4gIFsnb24nLCAnZW1pdCcsICdyZW1vdmVMaXN0ZW5lcicsICdyZW1vdmVBbGxMaXN0ZW5lcnMnXS5mb3JFYWNoKGZ1bmN0aW9uKG0pIHtcbiAgICBLYWRpcmEuRXZlbnRCdXNbbV0gPSBmdW5jdGlvbiguLi5hcmdzKSB7XG4gICAgICB2YXIgYXJncyA9IGJ1aWxkQXJncyhhcmdzKTtcbiAgICAgIHJldHVybiBldmVudEJ1c1ttXS5hcHBseShldmVudEJ1cywgYXJncyk7XG4gICAgfTtcbiAgfSk7XG59IiwidmFyIGNvbW1vbkVyclJlZ0V4cHMgPSBbXG4gIC9jb25uZWN0aW9uIHRpbWVvdXRcXC4gbm8gKFxcdyopIGhlYXJ0YmVhdCByZWNlaXZlZC9pLFxuICAvSU5WQUxJRF9TVEFURV9FUlIvaSxcbl07XG5cbkthZGlyYS5lcnJvckZpbHRlcnMgPSB7XG4gIGZpbHRlclZhbGlkYXRpb25FcnJvcnM6IGZ1bmN0aW9uKHR5cGUsIG1lc3NhZ2UsIGVycikge1xuICAgIGlmKGVyciAmJiBlcnIgaW5zdGFuY2VvZiBNZXRlb3IuRXJyb3IpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICB9LFxuXG4gIGZpbHRlckNvbW1vbk1ldGVvckVycm9yczogZnVuY3Rpb24odHlwZSwgbWVzc2FnZSkge1xuICAgIGZvcih2YXIgbGM9MDsgbGM8Y29tbW9uRXJyUmVnRXhwcy5sZW5ndGg7IGxjKyspIHtcbiAgICAgIHZhciByZWdFeHAgPSBjb21tb25FcnJSZWdFeHBzW2xjXTtcbiAgICAgIGlmKHJlZ0V4cC50ZXN0KG1lc3NhZ2UpKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbn07IiwiS2FkaXJhLnNlbmQgPSBmdW5jdGlvbiAocGF5bG9hZCwgcGF0aCwgY2FsbGJhY2spIHtcbiAgaWYoIUthZGlyYS5jb25uZWN0ZWQpICB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiWW91IG5lZWQgdG8gY29ubmVjdCB3aXRoIEthZGlyYSBmaXJzdCwgYmVmb3JlIHNlbmRpbmcgbWVzc2FnZXMhXCIpO1xuICB9XG5cbiAgcGF0aCA9IChwYXRoLnN1YnN0cigwLCAxKSAhPSAnLycpPyBcIi9cIiArIHBhdGggOiBwYXRoO1xuICB2YXIgZW5kcG9pbnQgPSBLYWRpcmEub3B0aW9ucy5lbmRwb2ludCArIHBhdGg7XG4gIHZhciByZXRyeUNvdW50ID0gMDtcbiAgdmFyIHJldHJ5ID0gbmV3IFJldHJ5KHtcbiAgICBtaW5Db3VudDogMSxcbiAgICBtaW5UaW1lb3V0OiAwLFxuICAgIGJhc2VUaW1lb3V0OiAxMDAwKjUsXG4gICAgbWF4VGltZW91dDogMTAwMCo2MCxcbiAgfSk7XG5cbiAgdmFyIHNlbmRGdW5jdGlvbiA9IEthZGlyYS5fZ2V0U2VuZEZ1bmN0aW9uKCk7XG4gIHRyeVRvU2VuZCgpO1xuXG4gIGZ1bmN0aW9uIHRyeVRvU2VuZChlcnIpIHtcbiAgICBpZihyZXRyeUNvdW50IDwgNSkge1xuICAgICAgcmV0cnkucmV0cnlMYXRlcihyZXRyeUNvdW50KyssIHNlbmQpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zb2xlLndhcm4oJ0Vycm9yIHNlbmRpbmcgZXJyb3IgdHJhY2VzIHRvIE1vbnRpIEFQTSBzZXJ2ZXInKTtcbiAgICAgIGlmKGNhbGxiYWNrKSBjYWxsYmFjayhlcnIpO1xuICAgIH1cbiAgfVxuXG4gIGZ1bmN0aW9uIHNlbmQoKSB7XG4gICAgc2VuZEZ1bmN0aW9uKGVuZHBvaW50LCBwYXlsb2FkLCBmdW5jdGlvbihlcnIsIHJlcykge1xuICAgICAgaWYoZXJyICYmICFyZXMpIHtcbiAgICAgICAgdHJ5VG9TZW5kKGVycik7XG4gICAgICB9IGVsc2UgaWYocmVzLnN0YXR1c0NvZGUgPT0gMjAwKSB7XG4gICAgICAgIGlmKGNhbGxiYWNrKSBjYWxsYmFjayhudWxsLCByZXMuZGF0YSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBpZihjYWxsYmFjaykgY2FsbGJhY2sobmV3IE1ldGVvci5FcnJvcihyZXMuc3RhdHVzQ29kZSwgcmVzLmNvbnRlbnQpKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxufTtcblxuS2FkaXJhLl9nZXRTZW5kRnVuY3Rpb24gPSBmdW5jdGlvbigpIHtcbiAgcmV0dXJuIChNZXRlb3IuaXNTZXJ2ZXIpPyBLYWRpcmEuX3NlcnZlclNlbmQgOiBLYWRpcmEuX2NsaWVudFNlbmQ7XG59O1xuXG5LYWRpcmEuX2NsaWVudFNlbmQgPSBmdW5jdGlvbiAoZW5kcG9pbnQsIHBheWxvYWQsIGNhbGxiYWNrKSB7XG4gIGh0dHBSZXF1ZXN0KCdQT1NUJywgZW5kcG9pbnQsIHtcbiAgICBoZWFkZXJzOiB7XG4gICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nXG4gICAgfSxcbiAgICBjb250ZW50OiBKU09OLnN0cmluZ2lmeShwYXlsb2FkKVxuICB9LCBjYWxsYmFjayk7XG59XG5cbkthZGlyYS5fc2VydmVyU2VuZCA9IGZ1bmN0aW9uICgpIHtcbiAgdGhyb3cgbmV3IEVycm9yKCdLYWRpcmEuX3NlcnZlclNlbmQgaXMgbm90IHN1cHBvcnRlZC4gVXNlIGNvcmVBcGkgaW5zdGVhZC4nKTtcbn1cbiIsIkJhc2VFcnJvck1vZGVsID0gZnVuY3Rpb24ob3B0aW9ucykge1xuICB0aGlzLl9maWx0ZXJzID0gW107XG59O1xuXG5CYXNlRXJyb3JNb2RlbC5wcm90b3R5cGUuYWRkRmlsdGVyID0gZnVuY3Rpb24oZmlsdGVyKSB7XG4gIGlmKHR5cGVvZiBmaWx0ZXIgPT09ICdmdW5jdGlvbicpIHtcbiAgICB0aGlzLl9maWx0ZXJzLnB1c2goZmlsdGVyKTtcbiAgfSBlbHNlIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJFcnJvciBmaWx0ZXIgbXVzdCBiZSBhIGZ1bmN0aW9uXCIpO1xuICB9XG59O1xuXG5CYXNlRXJyb3JNb2RlbC5wcm90b3R5cGUucmVtb3ZlRmlsdGVyID0gZnVuY3Rpb24oZmlsdGVyKSB7XG4gIHZhciBpbmRleCA9IHRoaXMuX2ZpbHRlcnMuaW5kZXhPZihmaWx0ZXIpO1xuICBpZihpbmRleCA+PSAwKSB7XG4gICAgdGhpcy5fZmlsdGVycy5zcGxpY2UoaW5kZXgsIDEpO1xuICB9XG59O1xuXG5CYXNlRXJyb3JNb2RlbC5wcm90b3R5cGUuYXBwbHlGaWx0ZXJzID0gZnVuY3Rpb24odHlwZSwgbWVzc2FnZSwgZXJyb3IsIHN1YlR5cGUpIHtcbiAgZm9yKHZhciBsYz0wOyBsYzx0aGlzLl9maWx0ZXJzLmxlbmd0aDsgbGMrKykge1xuICAgIHZhciBmaWx0ZXIgPSB0aGlzLl9maWx0ZXJzW2xjXTtcbiAgICB0cnkge1xuICAgICAgdmFyIHZhbGlkYXRlZCA9IGZpbHRlcih0eXBlLCBtZXNzYWdlLCBlcnJvciwgc3ViVHlwZSk7XG4gICAgICBpZighdmFsaWRhdGVkKSByZXR1cm4gZmFsc2U7XG4gICAgfSBjYXRjaCAoZXgpIHtcbiAgICAgIC8vIHdlIG5lZWQgdG8gcmVtb3ZlIHRoaXMgZmlsdGVyXG4gICAgICAvLyB3ZSBtYXkgZW5kZWQgdXAgaW4gYSBlcnJvciBjeWNsZVxuICAgICAgdGhpcy5fZmlsdGVycy5zcGxpY2UobGMsIDEpO1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiYW4gZXJyb3IgdGhyb3duIGZyb20gYSBmaWx0ZXIgeW91J3ZlIHN1cGxpZWRcIiwgZXgubWVzc2FnZSk7XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIHRydWU7XG59OyIsIkthZGlyYU1vZGVsID0gZnVuY3Rpb24oKSB7XG5cbn07XG5cbkthZGlyYU1vZGVsLnByb3RvdHlwZS5fZ2V0RGF0ZUlkID0gZnVuY3Rpb24odGltZXN0YW1wKSB7XG4gIHZhciByZW1haW5kZXIgPSB0aW1lc3RhbXAgJSAoMTAwMCAqIDYwKTtcbiAgdmFyIGRhdGVJZCA9IHRpbWVzdGFtcCAtIHJlbWFpbmRlcjtcbiAgcmV0dXJuIGRhdGVJZDtcbn07IiwiY29uc3QgeyBERFNrZXRjaCB9ID0gcmVxdWlyZSgnbW9udGktYXBtLXNrZXRjaGVzLWpzJyk7XG5cbnZhciBNRVRIT0RfTUVUUklDU19GSUVMRFMgPSBbJ3dhaXQnLCAnZGInLCAnaHR0cCcsICdlbWFpbCcsICdhc3luYycsICdjb21wdXRlJywgJ3RvdGFsJ107XG5cbk1ldGhvZHNNb2RlbCA9IGZ1bmN0aW9uIChtZXRyaWNzVGhyZXNob2xkKSB7XG4gIHRoaXMubWV0aG9kTWV0cmljc0J5TWludXRlID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgdGhpcy5lcnJvck1hcCA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG5cbiAgdGhpcy5fbWV0cmljc1RocmVzaG9sZCA9IF8uZXh0ZW5kKHtcbiAgICBcIndhaXRcIjogMTAwLFxuICAgIFwiZGJcIjogMTAwLFxuICAgIFwiaHR0cFwiOiAxMDAwLFxuICAgIFwiZW1haWxcIjogMTAwLFxuICAgIFwiYXN5bmNcIjogMTAwLFxuICAgIFwiY29tcHV0ZVwiOiAxMDAsXG4gICAgXCJ0b3RhbFwiOiAyMDBcbiAgfSwgbWV0cmljc1RocmVzaG9sZCB8fCBPYmplY3QuY3JlYXRlKG51bGwpKTtcblxuICAvL3N0b3JlIG1heCB0aW1lIGVsYXBzZWQgbWV0aG9kcyBmb3IgZWFjaCBtZXRob2QsIGV2ZW50KG1ldHJpY3MtZmllbGQpXG4gIHRoaXMubWF4RXZlbnRUaW1lc0Zvck1ldGhvZHMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuXG4gIHRoaXMudHJhY2VyU3RvcmUgPSBuZXcgVHJhY2VyU3RvcmUoe1xuICAgIGludGVydmFsOiAxMDAwICogNjAsIC8vcHJvY2VzcyB0cmFjZXMgZXZlcnkgbWludXRlXG4gICAgbWF4VG90YWxQb2ludHM6IDMwLCAvL2ZvciAzMCBtaW51dGVzXG4gICAgYXJjaGl2ZUV2ZXJ5OiA1IC8vYWx3YXlzIHRyYWNlIGZvciBldmVyeSA1IG1pbnV0ZXMsXG4gIH0pO1xuXG4gIHRoaXMudHJhY2VyU3RvcmUuc3RhcnQoKTtcbn07XG5cbl8uZXh0ZW5kKE1ldGhvZHNNb2RlbC5wcm90b3R5cGUsIEthZGlyYU1vZGVsLnByb3RvdHlwZSk7XG5cbk1ldGhvZHNNb2RlbC5wcm90b3R5cGUuX2dldE1ldHJpY3MgPSBmdW5jdGlvbih0aW1lc3RhbXAsIG1ldGhvZCkge1xuICB2YXIgZGF0ZUlkID0gdGhpcy5fZ2V0RGF0ZUlkKHRpbWVzdGFtcCk7XG5cbiAgaWYoIXRoaXMubWV0aG9kTWV0cmljc0J5TWludXRlW2RhdGVJZF0pIHtcbiAgICB0aGlzLm1ldGhvZE1ldHJpY3NCeU1pbnV0ZVtkYXRlSWRdID0ge1xuICAgICAgbWV0aG9kczogT2JqZWN0LmNyZWF0ZShudWxsKSxcbiAgICB9O1xuICB9XG5cbiAgdmFyIG1ldGhvZHMgPSB0aGlzLm1ldGhvZE1ldHJpY3NCeU1pbnV0ZVtkYXRlSWRdLm1ldGhvZHM7XG5cbiAgLy9pbml0aWFsaXplIG1ldGhvZFxuICBpZighbWV0aG9kc1ttZXRob2RdKSB7XG4gICAgbWV0aG9kc1ttZXRob2RdID0ge1xuICAgICAgY291bnQ6IDAsXG4gICAgICBlcnJvcnM6IDAsXG4gICAgICBmZXRjaGVkRG9jU2l6ZTogMCxcbiAgICAgIHNlbnRNc2dTaXplOiAwLFxuICAgICAgaGlzdG9ncmFtOiBuZXcgRERTa2V0Y2goe1xuICAgICAgICBhbHBoYTogMC4wMlxuICAgICAgfSlcbiAgICB9O1xuXG4gICAgTUVUSE9EX01FVFJJQ1NfRklFTERTLmZvckVhY2goZnVuY3Rpb24oZmllbGQpIHtcbiAgICAgIG1ldGhvZHNbbWV0aG9kXVtmaWVsZF0gPSAwO1xuICAgIH0pO1xuICB9XG5cbiAgcmV0dXJuIHRoaXMubWV0aG9kTWV0cmljc0J5TWludXRlW2RhdGVJZF0ubWV0aG9kc1ttZXRob2RdO1xufTtcblxuTWV0aG9kc01vZGVsLnByb3RvdHlwZS5zZXRTdGFydFRpbWUgPSBmdW5jdGlvbih0aW1lc3RhbXApIHtcbiAgdGhpcy5tZXRyaWNzQnlNaW51dGVbZGF0ZUlkXS5zdGFydFRpbWUgPSB0aW1lc3RhbXA7XG59XG5cbk1ldGhvZHNNb2RlbC5wcm90b3R5cGUucHJvY2Vzc01ldGhvZCA9IGZ1bmN0aW9uKG1ldGhvZFRyYWNlKSB7XG4gIHZhciBkYXRlSWQgPSB0aGlzLl9nZXREYXRlSWQobWV0aG9kVHJhY2UuYXQpO1xuXG4gIC8vYXBwZW5kIG1ldHJpY3MgdG8gcHJldmlvdXMgdmFsdWVzXG4gIHRoaXMuX2FwcGVuZE1ldHJpY3MoZGF0ZUlkLCBtZXRob2RUcmFjZSk7XG4gIGlmKG1ldGhvZFRyYWNlLmVycm9yZWQpIHtcbiAgICB0aGlzLm1ldGhvZE1ldHJpY3NCeU1pbnV0ZVtkYXRlSWRdLm1ldGhvZHNbbWV0aG9kVHJhY2UubmFtZV0uZXJyb3JzICsrXG4gIH1cblxuICB0aGlzLnRyYWNlclN0b3JlLmFkZFRyYWNlKG1ldGhvZFRyYWNlKTtcbn07XG5cbk1ldGhvZHNNb2RlbC5wcm90b3R5cGUuX2FwcGVuZE1ldHJpY3MgPSBmdW5jdGlvbihpZCwgbWV0aG9kVHJhY2UpIHtcbiAgdmFyIG1ldGhvZE1ldHJpY3MgPSB0aGlzLl9nZXRNZXRyaWNzKGlkLCBtZXRob2RUcmFjZS5uYW1lKVxuXG4gIC8vIHN0YXJ0VGltZSBuZWVkcyB0byBiZSBjb252ZXJ0ZWQgaW50byBzZXJ2ZXJUaW1lIGJlZm9yZSBzZW5kaW5nXG4gIGlmKCF0aGlzLm1ldGhvZE1ldHJpY3NCeU1pbnV0ZVtpZF0uc3RhcnRUaW1lKXtcbiAgICB0aGlzLm1ldGhvZE1ldHJpY3NCeU1pbnV0ZVtpZF0uc3RhcnRUaW1lID0gbWV0aG9kVHJhY2UuYXQ7XG4gIH1cblxuICAvL21lcmdlXG4gIE1FVEhPRF9NRVRSSUNTX0ZJRUxEUy5mb3JFYWNoKGZ1bmN0aW9uKGZpZWxkKSB7XG4gICAgdmFyIHZhbHVlID0gbWV0aG9kVHJhY2UubWV0cmljc1tmaWVsZF07XG4gICAgaWYodmFsdWUgPiAwKSB7XG4gICAgICBtZXRob2RNZXRyaWNzW2ZpZWxkXSArPSB2YWx1ZTtcbiAgICB9XG4gIH0pO1xuXG4gIG1ldGhvZE1ldHJpY3MuY291bnQrKztcbiAgbWV0aG9kTWV0cmljcy5oaXN0b2dyYW0uYWRkKG1ldGhvZFRyYWNlLm1ldHJpY3MudG90YWwpO1xuICB0aGlzLm1ldGhvZE1ldHJpY3NCeU1pbnV0ZVtpZF0uZW5kVGltZSA9IG1ldGhvZFRyYWNlLm1ldHJpY3MuYXQ7XG59O1xuXG5NZXRob2RzTW9kZWwucHJvdG90eXBlLnRyYWNrRG9jU2l6ZSA9IGZ1bmN0aW9uKG1ldGhvZCwgc2l6ZSkge1xuICB2YXIgdGltZXN0YW1wID0gTnRwLl9ub3coKTtcbiAgdmFyIGRhdGVJZCA9IHRoaXMuX2dldERhdGVJZCh0aW1lc3RhbXApO1xuXG4gIHZhciBtZXRob2RNZXRyaWNzID0gdGhpcy5fZ2V0TWV0cmljcyhkYXRlSWQsIG1ldGhvZCk7XG4gIG1ldGhvZE1ldHJpY3MuZmV0Y2hlZERvY1NpemUgKz0gc2l6ZTtcbn1cblxuTWV0aG9kc01vZGVsLnByb3RvdHlwZS50cmFja01zZ1NpemUgPSBmdW5jdGlvbihtZXRob2QsIHNpemUpIHtcbiAgdmFyIHRpbWVzdGFtcCA9IE50cC5fbm93KCk7XG4gIHZhciBkYXRlSWQgPSB0aGlzLl9nZXREYXRlSWQodGltZXN0YW1wKTtcblxuICB2YXIgbWV0aG9kTWV0cmljcyA9IHRoaXMuX2dldE1ldHJpY3MoZGF0ZUlkLCBtZXRob2QpO1xuICBtZXRob2RNZXRyaWNzLnNlbnRNc2dTaXplICs9IHNpemU7XG59XG5cbi8qXG4gIFRoZXJlIGFyZSB0d28gdHlwZXMgb2YgZGF0YVxuXG4gIDEuIG1ldGhvZE1ldHJpY3MgLSBtZXRyaWNzIGFib3V0IHRoZSBtZXRob2RzIChmb3IgZXZlcnkgMTAgc2VjcylcbiAgMi4gbWV0aG9kUmVxdWVzdHMgLSByYXcgbWV0aG9kIHJlcXVlc3QuIG5vcm1hbGx5IG1heCwgbWluIGZvciBldmVyeSAxIG1pbiBhbmQgZXJyb3JzIGFsd2F5c1xuKi9cbk1ldGhvZHNNb2RlbC5wcm90b3R5cGUuYnVpbGRQYXlsb2FkID0gZnVuY3Rpb24oYnVpbGREZXRhaWxlZEluZm8pIHtcbiAgdmFyIHBheWxvYWQgPSB7XG4gICAgbWV0aG9kTWV0cmljczogW10sXG4gICAgbWV0aG9kUmVxdWVzdHM6IFtdXG4gIH07XG5cbiAgLy9oYW5kbGluZyBtZXRyaWNzXG4gIHZhciBtZXRob2RNZXRyaWNzQnlNaW51dGUgPSB0aGlzLm1ldGhvZE1ldHJpY3NCeU1pbnV0ZTtcbiAgdGhpcy5tZXRob2RNZXRyaWNzQnlNaW51dGUgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuXG4gIC8vY3JlYXRlIGZpbmFsIHBheWxvZCBmb3IgbWV0aG9kTWV0cmljc1xuICBmb3IodmFyIGtleSBpbiBtZXRob2RNZXRyaWNzQnlNaW51dGUpIHtcbiAgICB2YXIgbWV0aG9kTWV0cmljcyA9IG1ldGhvZE1ldHJpY3NCeU1pbnV0ZVtrZXldO1xuICAgIC8vIGNvbnZlcnRpbmcgc3RhcnRUaW1lIGludG8gdGhlIGFjdHVhbCBzZXJ2ZXJUaW1lXG4gICAgdmFyIHN0YXJ0VGltZSA9IG1ldGhvZE1ldHJpY3Muc3RhcnRUaW1lO1xuICAgIG1ldGhvZE1ldHJpY3Muc3RhcnRUaW1lID0gS2FkaXJhLnN5bmNlZERhdGUuc3luY1RpbWUoc3RhcnRUaW1lKTtcblxuICAgIGZvcih2YXIgbWV0aG9kTmFtZSBpbiBtZXRob2RNZXRyaWNzLm1ldGhvZHMpIHtcbiAgICAgIE1FVEhPRF9NRVRSSUNTX0ZJRUxEUy5mb3JFYWNoKGZ1bmN0aW9uKGZpZWxkKSB7XG4gICAgICAgIG1ldGhvZE1ldHJpY3MubWV0aG9kc1ttZXRob2ROYW1lXVtmaWVsZF0gLz1cbiAgICAgICAgICBtZXRob2RNZXRyaWNzLm1ldGhvZHNbbWV0aG9kTmFtZV0uY291bnQ7XG4gICAgICB9KTtcbiAgICB9XG5cbiAgICBwYXlsb2FkLm1ldGhvZE1ldHJpY3MucHVzaChtZXRob2RNZXRyaWNzQnlNaW51dGVba2V5XSk7XG4gIH1cblxuICAvL2NvbGxlY3QgdHJhY2VzIGFuZCBzZW5kIHRoZW0gd2l0aCB0aGUgcGF5bG9hZFxuICBwYXlsb2FkLm1ldGhvZFJlcXVlc3RzID0gdGhpcy50cmFjZXJTdG9yZS5jb2xsZWN0VHJhY2VzKCk7XG5cbiAgcmV0dXJuIHBheWxvYWQ7XG59O1xuIiwidmFyIGxvZ2dlciA9IE5wbS5yZXF1aXJlKCdkZWJ1ZycpKCdrYWRpcmE6cHVic3ViJyk7XG5jb25zdCB7IEREU2tldGNoIH0gPSByZXF1aXJlKCdtb250aS1hcG0tc2tldGNoZXMtanMnKTtcblxuUHVic3ViTW9kZWwgPSBmdW5jdGlvbigpIHtcbiAgdGhpcy5tZXRyaWNzQnlNaW51dGUgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuICB0aGlzLnN1YnNjcmlwdGlvbnMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuXG4gIHRoaXMudHJhY2VyU3RvcmUgPSBuZXcgVHJhY2VyU3RvcmUoe1xuICAgIGludGVydmFsOiAxMDAwICogNjAsIC8vcHJvY2VzcyB0cmFjZXMgZXZlcnkgbWludXRlXG4gICAgbWF4VG90YWxQb2ludHM6IDMwLCAvL2ZvciAzMCBtaW51dGVzXG4gICAgYXJjaGl2ZUV2ZXJ5OiA1IC8vYWx3YXlzIHRyYWNlIGZvciBldmVyeSA1IG1pbnV0ZXMsXG4gIH0pO1xuXG4gIHRoaXMudHJhY2VyU3RvcmUuc3RhcnQoKTtcbn1cblxuUHVic3ViTW9kZWwucHJvdG90eXBlLl90cmFja1N1YiA9IGZ1bmN0aW9uKHNlc3Npb24sIG1zZykge1xuICBsb2dnZXIoJ1NVQjonLCBzZXNzaW9uLmlkLCBtc2cuaWQsIG1zZy5uYW1lLCBtc2cucGFyYW1zKTtcbiAgdmFyIHB1YmxpY2F0aW9uID0gdGhpcy5fZ2V0UHVibGljYXRpb25OYW1lKG1zZy5uYW1lKTtcbiAgdmFyIHN1YnNjcmlwdGlvbklkID0gbXNnLmlkO1xuICB2YXIgdGltZXN0YW1wID0gTnRwLl9ub3coKTtcbiAgdmFyIG1ldHJpY3MgPSB0aGlzLl9nZXRNZXRyaWNzKHRpbWVzdGFtcCwgcHVibGljYXRpb24pO1xuXG4gIG1ldHJpY3Muc3VicysrO1xuICB0aGlzLnN1YnNjcmlwdGlvbnNbbXNnLmlkXSA9IHtcbiAgICAvLyBXZSB1c2UgbG9jYWxUaW1lIGhlcmUsIGJlY2F1c2Ugd2hlbiB3ZSB1c2VkIHN5bmVkVGltZSB3ZSBtaWdodCBnZXRcbiAgICAvLyBtaW51cyBvciBtb3JlIHRoYW4gd2UndmUgZXhwZWN0ZWRcbiAgICAvLyAgIChiZWZvcmUgc2VydmVyVGltZSBkaWZmIGNoYW5nZWQgb3ZlcnRpbWUpXG4gICAgc3RhcnRUaW1lOiB0aW1lc3RhbXAsXG4gICAgcHVibGljYXRpb246IHB1YmxpY2F0aW9uLFxuICAgIHBhcmFtczogbXNnLnBhcmFtcyxcbiAgICBpZDogbXNnLmlkXG4gIH07XG5cbiAgLy9zZXQgc2Vzc2lvbiBzdGFydGVkVGltZVxuICBzZXNzaW9uLl9zdGFydFRpbWUgPSBzZXNzaW9uLl9zdGFydFRpbWUgfHwgdGltZXN0YW1wO1xufTtcblxuXy5leHRlbmQoUHVic3ViTW9kZWwucHJvdG90eXBlLCBLYWRpcmFNb2RlbC5wcm90b3R5cGUpO1xuXG5QdWJzdWJNb2RlbC5wcm90b3R5cGUuX3RyYWNrVW5zdWIgPSBmdW5jdGlvbihzZXNzaW9uLCBzdWIpIHtcbiAgbG9nZ2VyKCdVTlNVQjonLCBzZXNzaW9uLmlkLCBzdWIuX3N1YnNjcmlwdGlvbklkKTtcbiAgdmFyIHB1YmxpY2F0aW9uID0gdGhpcy5fZ2V0UHVibGljYXRpb25OYW1lKHN1Yi5fbmFtZSk7XG4gIHZhciBzdWJzY3JpcHRpb25JZCA9IHN1Yi5fc3Vic2NyaXB0aW9uSWQ7XG4gIHZhciBzdWJzY3JpcHRpb25TdGF0ZSA9IHRoaXMuc3Vic2NyaXB0aW9uc1tzdWJzY3JpcHRpb25JZF07XG5cbiAgdmFyIHN0YXJ0VGltZSA9IG51bGw7XG4gIC8vc29tZXRpbWUsIHdlIGRvbid0IGhhdmUgdGhlc2Ugc3RhdGVzXG4gIGlmKHN1YnNjcmlwdGlvblN0YXRlKSB7XG4gICAgc3RhcnRUaW1lID0gc3Vic2NyaXB0aW9uU3RhdGUuc3RhcnRUaW1lO1xuICB9IGVsc2Uge1xuICAgIC8vaWYgdGhpcyBpcyBudWxsIHN1YnNjcmlwdGlvbiwgd2hpY2ggaXMgc3RhcnRlZCBhdXRvbWF0aWNhbGx5XG4gICAgLy9oZW5jZSwgd2UgZG9uJ3QgaGF2ZSBhIHN0YXRlXG4gICAgc3RhcnRUaW1lID0gc2Vzc2lvbi5fc3RhcnRUaW1lO1xuICB9XG5cbiAgLy9pbiBjYXNlLCB3ZSBjYW4ndCBnZXQgdGhlIHN0YXJ0VGltZVxuICBpZihzdGFydFRpbWUpIHtcbiAgICB2YXIgdGltZXN0YW1wID0gTnRwLl9ub3coKTtcbiAgICB2YXIgbWV0cmljcyA9IHRoaXMuX2dldE1ldHJpY3ModGltZXN0YW1wLCBwdWJsaWNhdGlvbik7XG4gICAgLy90cmFjayB0aGUgY291bnRcbiAgICBpZihzdWIuX25hbWUgIT0gbnVsbCkge1xuICAgICAgLy8gd2UgY2FuJ3QgdHJhY2sgc3VicyBmb3IgYG51bGxgIHB1YmxpY2F0aW9ucy5cbiAgICAgIC8vIHNvIHdlIHNob3VsZCBub3QgdHJhY2sgdW5zdWJzIHRvb1xuICAgICAgbWV0cmljcy51bnN1YnMrKztcbiAgICB9XG4gICAgLy91c2UgdGhlIGN1cnJlbnQgZGF0ZSB0byBnZXQgdGhlIGxpZmVUaW1lIG9mIHRoZSBzdWJzY3JpcHRpb25cbiAgICBtZXRyaWNzLmxpZmVUaW1lICs9IHRpbWVzdGFtcCAtIHN0YXJ0VGltZTtcbiAgICAvL3RoaXMgaXMgcGxhY2Ugd2UgY2FuIGNsZWFuIHRoZSBzdWJzY3JpcHRpb25TdGF0ZSBpZiBleGlzdHNcbiAgICBkZWxldGUgdGhpcy5zdWJzY3JpcHRpb25zW3N1YnNjcmlwdGlvbklkXTtcbiAgfVxufTtcblxuUHVic3ViTW9kZWwucHJvdG90eXBlLl90cmFja1JlYWR5ID0gZnVuY3Rpb24oc2Vzc2lvbiwgc3ViLCB0cmFjZSkge1xuICBsb2dnZXIoJ1JFQURZOicsIHNlc3Npb24uaWQsIHN1Yi5fc3Vic2NyaXB0aW9uSWQpO1xuICAvL3VzZSB0aGUgY3VycmVudCB0aW1lIHRvIHRyYWNrIHRoZSByZXNwb25zZSB0aW1lXG4gIHZhciBwdWJsaWNhdGlvbiA9IHRoaXMuX2dldFB1YmxpY2F0aW9uTmFtZShzdWIuX25hbWUpO1xuICB2YXIgc3Vic2NyaXB0aW9uSWQgPSBzdWIuX3N1YnNjcmlwdGlvbklkO1xuICB2YXIgdGltZXN0YW1wID0gTnRwLl9ub3coKTtcbiAgdmFyIG1ldHJpY3MgPSB0aGlzLl9nZXRNZXRyaWNzKHRpbWVzdGFtcCwgcHVibGljYXRpb24pO1xuXG4gIHZhciBzdWJzY3JpcHRpb25TdGF0ZSA9IHRoaXMuc3Vic2NyaXB0aW9uc1tzdWJzY3JpcHRpb25JZF07XG4gIGlmKHN1YnNjcmlwdGlvblN0YXRlICYmICFzdWJzY3JpcHRpb25TdGF0ZS5yZWFkeVRyYWNrZWQpIHtcbiAgICB2YXIgcmVzVGltZSA9IHRpbWVzdGFtcCAtIHN1YnNjcmlwdGlvblN0YXRlLnN0YXJ0VGltZVxuICAgIG1ldHJpY3MucmVzVGltZSArPSByZXNUaW1lO1xuICAgIHN1YnNjcmlwdGlvblN0YXRlLnJlYWR5VHJhY2tlZCA9IHRydWU7XG4gICAgbWV0cmljcy5oaXN0b2dyYW0uYWRkKHJlc1RpbWUpO1xuICB9XG5cbiAgaWYodHJhY2UpIHtcbiAgICB0aGlzLnRyYWNlclN0b3JlLmFkZFRyYWNlKHRyYWNlKTtcbiAgfVxufTtcblxuUHVic3ViTW9kZWwucHJvdG90eXBlLl90cmFja0Vycm9yID0gZnVuY3Rpb24oc2Vzc2lvbiwgc3ViLCB0cmFjZSkge1xuICBsb2dnZXIoJ0VSUk9SOicsIHNlc3Npb24uaWQsIHN1Yi5fc3Vic2NyaXB0aW9uSWQpO1xuICAvL3VzZSB0aGUgY3VycmVudCB0aW1lIHRvIHRyYWNrIHRoZSByZXNwb25zZSB0aW1lXG4gIHZhciBwdWJsaWNhdGlvbiA9IHRoaXMuX2dldFB1YmxpY2F0aW9uTmFtZShzdWIuX25hbWUpO1xuICB2YXIgc3Vic2NyaXB0aW9uSWQgPSBzdWIuX3N1YnNjcmlwdGlvbklkO1xuICB2YXIgdGltZXN0YW1wID0gTnRwLl9ub3coKTtcbiAgdmFyIG1ldHJpY3MgPSB0aGlzLl9nZXRNZXRyaWNzKHRpbWVzdGFtcCwgcHVibGljYXRpb24pO1xuXG4gIG1ldHJpY3MuZXJyb3JzKys7XG5cbiAgaWYodHJhY2UpIHtcbiAgICB0aGlzLnRyYWNlclN0b3JlLmFkZFRyYWNlKHRyYWNlKTtcbiAgfVxufTtcblxuUHVic3ViTW9kZWwucHJvdG90eXBlLl9nZXRNZXRyaWNzID0gZnVuY3Rpb24odGltZXN0YW1wLCBwdWJsaWNhdGlvbikge1xuICB2YXIgZGF0ZUlkID0gdGhpcy5fZ2V0RGF0ZUlkKHRpbWVzdGFtcCk7XG5cbiAgaWYoIXRoaXMubWV0cmljc0J5TWludXRlW2RhdGVJZF0pIHtcbiAgICB0aGlzLm1ldHJpY3NCeU1pbnV0ZVtkYXRlSWRdID0ge1xuICAgICAgLy8gc3RhcnRUaW1lIG5lZWRzIHRvIGJlIGNvbnZlcnQgdG8gc2VydmVyVGltZSBiZWZvcmUgc2VuZGluZyB0byB0aGUgc2VydmVyXG4gICAgICBzdGFydFRpbWU6IHRpbWVzdGFtcCxcbiAgICAgIHB1YnM6IE9iamVjdC5jcmVhdGUobnVsbClcbiAgICB9O1xuICB9XG5cbiAgaWYoIXRoaXMubWV0cmljc0J5TWludXRlW2RhdGVJZF0ucHVic1twdWJsaWNhdGlvbl0pIHtcbiAgICB0aGlzLm1ldHJpY3NCeU1pbnV0ZVtkYXRlSWRdLnB1YnNbcHVibGljYXRpb25dID0ge1xuICAgICAgc3ViczogMCxcbiAgICAgIHVuc3ViczogMCxcbiAgICAgIHJlc1RpbWU6IDAsXG4gICAgICBhY3RpdmVTdWJzOiAwLFxuICAgICAgYWN0aXZlRG9jczogMCxcbiAgICAgIGxpZmVUaW1lOiAwLFxuICAgICAgdG90YWxPYnNlcnZlcnM6IDAsXG4gICAgICBjYWNoZWRPYnNlcnZlcnM6IDAsXG4gICAgICBjcmVhdGVkT2JzZXJ2ZXJzOiAwLFxuICAgICAgZGVsZXRlZE9ic2VydmVyczogMCxcbiAgICAgIGVycm9yczogMCxcbiAgICAgIG9ic2VydmVyTGlmZXRpbWU6IDAsXG4gICAgICBwb2xsZWREb2N1bWVudHM6IDAsXG4gICAgICBvcGxvZ1VwZGF0ZWREb2N1bWVudHM6IDAsXG4gICAgICBvcGxvZ0luc2VydGVkRG9jdW1lbnRzOiAwLFxuICAgICAgb3Bsb2dEZWxldGVkRG9jdW1lbnRzOiAwLFxuICAgICAgaW5pdGlhbGx5QWRkZWREb2N1bWVudHM6IDAsXG4gICAgICBsaXZlQWRkZWREb2N1bWVudHM6IDAsXG4gICAgICBsaXZlQ2hhbmdlZERvY3VtZW50czogMCxcbiAgICAgIGxpdmVSZW1vdmVkRG9jdW1lbnRzOiAwLFxuICAgICAgcG9sbGVkRG9jU2l6ZTogMCxcbiAgICAgIGZldGNoZWREb2NTaXplOiAwLFxuICAgICAgaW5pdGlhbGx5RmV0Y2hlZERvY1NpemU6IDAsXG4gICAgICBsaXZlRmV0Y2hlZERvY1NpemU6IDAsXG4gICAgICBpbml0aWFsbHlTZW50TXNnU2l6ZTogMCxcbiAgICAgIGxpdmVTZW50TXNnU2l6ZTogMCxcbiAgICAgIGhpc3RvZ3JhbTogbmV3IEREU2tldGNoKHtcbiAgICAgICAgYWxwaGE6IDAuMDJcbiAgICAgIH0pXG4gICAgfTtcbiAgfVxuXG4gIHJldHVybiB0aGlzLm1ldHJpY3NCeU1pbnV0ZVtkYXRlSWRdLnB1YnNbcHVibGljYXRpb25dO1xufTtcblxuUHVic3ViTW9kZWwucHJvdG90eXBlLl9nZXRQdWJsaWNhdGlvbk5hbWUgPSBmdW5jdGlvbihuYW1lKSB7XG4gIHJldHVybiBuYW1lIHx8IFwibnVsbChhdXRvcHVibGlzaClcIjtcbn07XG5cblB1YnN1Yk1vZGVsLnByb3RvdHlwZS5fZ2V0U3Vic2NyaXB0aW9uSW5mbyA9IGZ1bmN0aW9uKCkge1xuICB2YXIgc2VsZiA9IHRoaXM7XG4gIHZhciBhY3RpdmVTdWJzID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgdmFyIGFjdGl2ZURvY3MgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuICB2YXIgdG90YWxEb2NzU2VudCA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIHZhciB0b3RhbERhdGFTZW50ID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgdmFyIHRvdGFsT2JzZXJ2ZXJzID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgdmFyIGNhY2hlZE9ic2VydmVycyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG5cbiAgaXRlcmF0ZShNZXRlb3Iuc2VydmVyLnNlc3Npb25zLCBzZXNzaW9uID0+IHtcbiAgICBpdGVyYXRlKHNlc3Npb24uX25hbWVkU3VicywgY291bnRTdWJEYXRhKTtcbiAgICBpdGVyYXRlKHNlc3Npb24uX3VuaXZlcnNhbFN1YnMsIGNvdW50U3ViRGF0YSk7XG4gIH0pO1xuXG4gIHZhciBhdmdPYnNlcnZlclJldXNlID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgXy5lYWNoKHRvdGFsT2JzZXJ2ZXJzLCBmdW5jdGlvbih2YWx1ZSwgcHVibGljYXRpb24pIHtcbiAgICBhdmdPYnNlcnZlclJldXNlW3B1YmxpY2F0aW9uXSA9IGNhY2hlZE9ic2VydmVyc1twdWJsaWNhdGlvbl0gLyB0b3RhbE9ic2VydmVyc1twdWJsaWNhdGlvbl07XG4gIH0pO1xuXG4gIHJldHVybiB7XG4gICAgYWN0aXZlU3ViczogYWN0aXZlU3VicyxcbiAgICBhY3RpdmVEb2NzOiBhY3RpdmVEb2NzLFxuICAgIGF2Z09ic2VydmVyUmV1c2U6IGF2Z09ic2VydmVyUmV1c2VcbiAgfTtcblxuICBmdW5jdGlvbiBjb3VudFN1YkRhdGEgKHN1Yikge1xuICAgIHZhciBwdWJsaWNhdGlvbiA9IHNlbGYuX2dldFB1YmxpY2F0aW9uTmFtZShzdWIuX25hbWUpO1xuICAgIGNvdW50U3Vic2NyaXB0aW9ucyhzdWIsIHB1YmxpY2F0aW9uKTtcbiAgICBjb3VudERvY3VtZW50cyhzdWIsIHB1YmxpY2F0aW9uKTtcbiAgICBjb3VudE9ic2VydmVycyhzdWIsIHB1YmxpY2F0aW9uKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIGNvdW50U3Vic2NyaXB0aW9ucyAoc3ViLCBwdWJsaWNhdGlvbikge1xuICAgIGFjdGl2ZVN1YnNbcHVibGljYXRpb25dID0gYWN0aXZlU3Vic1twdWJsaWNhdGlvbl0gfHwgMDtcbiAgICBhY3RpdmVTdWJzW3B1YmxpY2F0aW9uXSsrO1xuICB9XG5cbiAgZnVuY3Rpb24gY291bnREb2N1bWVudHMgKHN1YiwgcHVibGljYXRpb24pIHtcbiAgICBhY3RpdmVEb2NzW3B1YmxpY2F0aW9uXSA9IGFjdGl2ZURvY3NbcHVibGljYXRpb25dIHx8IDA7XG4gICAgaXRlcmF0ZShzdWIuX2RvY3VtZW50cywgY29sbGVjdGlvbiA9PiB7XG4gICAgICBhY3RpdmVEb2NzW3B1YmxpY2F0aW9uXSArPSBjb3VudEtleXMoY29sbGVjdGlvbik7XG4gICAgfSk7XG4gIH1cblxuICBmdW5jdGlvbiBjb3VudE9ic2VydmVycyhzdWIsIHB1YmxpY2F0aW9uKSB7XG4gICAgdG90YWxPYnNlcnZlcnNbcHVibGljYXRpb25dID0gdG90YWxPYnNlcnZlcnNbcHVibGljYXRpb25dIHx8IDA7XG4gICAgY2FjaGVkT2JzZXJ2ZXJzW3B1YmxpY2F0aW9uXSA9IGNhY2hlZE9ic2VydmVyc1twdWJsaWNhdGlvbl0gfHwgMDtcblxuICAgIHRvdGFsT2JzZXJ2ZXJzW3B1YmxpY2F0aW9uXSArPSBzdWIuX3RvdGFsT2JzZXJ2ZXJzO1xuICAgIGNhY2hlZE9ic2VydmVyc1twdWJsaWNhdGlvbl0gKz0gc3ViLl9jYWNoZWRPYnNlcnZlcnM7XG4gIH1cbn1cblxuUHVic3ViTW9kZWwucHJvdG90eXBlLmJ1aWxkUGF5bG9hZCA9IGZ1bmN0aW9uKGJ1aWxkRGV0YWlsSW5mbykge1xuICB2YXIgbWV0cmljc0J5TWludXRlID0gdGhpcy5tZXRyaWNzQnlNaW51dGU7XG4gIHRoaXMubWV0cmljc0J5TWludXRlID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcblxuICB2YXIgcGF5bG9hZCA9IHtcbiAgICBwdWJNZXRyaWNzOiBbXVxuICB9O1xuXG4gIHZhciBzdWJzY3JpcHRpb25EYXRhID0gdGhpcy5fZ2V0U3Vic2NyaXB0aW9uSW5mbygpO1xuICB2YXIgYWN0aXZlU3VicyA9IHN1YnNjcmlwdGlvbkRhdGEuYWN0aXZlU3VicztcbiAgdmFyIGFjdGl2ZURvY3MgPSBzdWJzY3JpcHRpb25EYXRhLmFjdGl2ZURvY3M7XG4gIHZhciBhdmdPYnNlcnZlclJldXNlID0gc3Vic2NyaXB0aW9uRGF0YS5hdmdPYnNlcnZlclJldXNlO1xuXG4gIC8vdG8gdGhlIGF2ZXJhZ2luZ1xuICBmb3IodmFyIGRhdGVJZCBpbiBtZXRyaWNzQnlNaW51dGUpIHtcbiAgICB2YXIgZGF0ZU1ldHJpY3MgPSBtZXRyaWNzQnlNaW51dGVbZGF0ZUlkXTtcbiAgICAvLyBXZSBuZWVkIHRvIGNvbnZlcnQgc3RhcnRUaW1lIGludG8gYWN0dWFsIHNlcnZlclRpbWVcbiAgICBkYXRlTWV0cmljcy5zdGFydFRpbWUgPSBLYWRpcmEuc3luY2VkRGF0ZS5zeW5jVGltZShkYXRlTWV0cmljcy5zdGFydFRpbWUpO1xuXG4gICAgZm9yKHZhciBwdWJsaWNhdGlvbiBpbiBtZXRyaWNzQnlNaW51dGVbZGF0ZUlkXS5wdWJzKSB7XG4gICAgICB2YXIgc2luZ2xlUHViTWV0cmljcyA9IG1ldHJpY3NCeU1pbnV0ZVtkYXRlSWRdLnB1YnNbcHVibGljYXRpb25dO1xuICAgICAgLy8gV2Ugb25seSBjYWxjdWxhdGUgcmVzVGltZSBmb3IgbmV3IHN1YnNjcmlwdGlvbnNcbiAgICAgIHNpbmdsZVB1Yk1ldHJpY3MucmVzVGltZSAvPSBzaW5nbGVQdWJNZXRyaWNzLnN1YnM7XG4gICAgICBzaW5nbGVQdWJNZXRyaWNzLnJlc1RpbWUgPSBzaW5nbGVQdWJNZXRyaWNzLnJlc1RpbWUgfHwgMDtcbiAgICAgIC8vIFdlIG9ubHkgdHJhY2sgbGlmZVRpbWUgaW4gdGhlIHVuc3Vic1xuICAgICAgc2luZ2xlUHViTWV0cmljcy5saWZlVGltZSAvPSBzaW5nbGVQdWJNZXRyaWNzLnVuc3VicztcbiAgICAgIHNpbmdsZVB1Yk1ldHJpY3MubGlmZVRpbWUgPSBzaW5nbGVQdWJNZXRyaWNzLmxpZmVUaW1lIHx8IDA7XG5cbiAgICAgIC8vIENvdW50IHRoZSBhdmVyYWdlIGZvciBvYnNlcnZlciBsaWZldGltZVxuICAgICAgaWYoc2luZ2xlUHViTWV0cmljcy5kZWxldGVkT2JzZXJ2ZXJzID4gMCkge1xuICAgICAgICBzaW5nbGVQdWJNZXRyaWNzLm9ic2VydmVyTGlmZXRpbWUgLz0gc2luZ2xlUHViTWV0cmljcy5kZWxldGVkT2JzZXJ2ZXJzO1xuICAgICAgfVxuXG4gICAgICAvLyBJZiB0aGVyZSBhcmUgdHdvIG9yZSBtb3JlIGRhdGVJZHMsIHdlIHdpbGwgYmUgdXNpbmcgdGhlIGN1cnJlbnRDb3VudCBmb3IgYWxsIG9mIHRoZW0uXG4gICAgICAvLyBXZSBjYW4gY29tZSB1cCB3aXRoIGEgYmV0dGVyIHNvbHV0aW9uIGxhdGVyIG9uLlxuICAgICAgc2luZ2xlUHViTWV0cmljcy5hY3RpdmVTdWJzID0gYWN0aXZlU3Vic1twdWJsaWNhdGlvbl0gfHwgMDtcbiAgICAgIHNpbmdsZVB1Yk1ldHJpY3MuYWN0aXZlRG9jcyA9IGFjdGl2ZURvY3NbcHVibGljYXRpb25dIHx8IDA7XG4gICAgICBzaW5nbGVQdWJNZXRyaWNzLmF2Z09ic2VydmVyUmV1c2UgPSBhdmdPYnNlcnZlclJldXNlW3B1YmxpY2F0aW9uXSB8fCAwO1xuICAgIH1cblxuICAgIHBheWxvYWQucHViTWV0cmljcy5wdXNoKG1ldHJpY3NCeU1pbnV0ZVtkYXRlSWRdKTtcbiAgfVxuXG4gIC8vY29sbGVjdCB0cmFjZXMgYW5kIHNlbmQgdGhlbSB3aXRoIHRoZSBwYXlsb2FkXG4gIHBheWxvYWQucHViUmVxdWVzdHMgPSB0aGlzLnRyYWNlclN0b3JlLmNvbGxlY3RUcmFjZXMoKTtcblxuICByZXR1cm4gcGF5bG9hZDtcbn07XG5cblB1YnN1Yk1vZGVsLnByb3RvdHlwZS5pbmNyZW1lbnRIYW5kbGVDb3VudCA9IGZ1bmN0aW9uKHRyYWNlLCBpc0NhY2hlZCkge1xuICB2YXIgdGltZXN0YW1wID0gTnRwLl9ub3coKTtcbiAgdmFyIHB1YmxpY2F0aW9uTmFtZSA9IHRoaXMuX2dldFB1YmxpY2F0aW9uTmFtZSh0cmFjZS5uYW1lKTtcbiAgdmFyIHB1YmxpY2F0aW9uID0gdGhpcy5fZ2V0TWV0cmljcyh0aW1lc3RhbXAsIHB1YmxpY2F0aW9uTmFtZSk7XG5cbiAgdmFyIHNlc3Npb24gPSBnZXRQcm9wZXJ0eShNZXRlb3Iuc2VydmVyLnNlc3Npb25zLCB0cmFjZS5zZXNzaW9uKTtcbiAgaWYoc2Vzc2lvbikge1xuICAgIHZhciBzdWIgPSBnZXRQcm9wZXJ0eShzZXNzaW9uLl9uYW1lZFN1YnMsIHRyYWNlLmlkKTtcbiAgICBpZihzdWIpIHtcbiAgICAgIHN1Yi5fdG90YWxPYnNlcnZlcnMgPSBzdWIuX3RvdGFsT2JzZXJ2ZXJzIHx8IDA7XG4gICAgICBzdWIuX2NhY2hlZE9ic2VydmVycyA9IHN1Yi5fY2FjaGVkT2JzZXJ2ZXJzIHx8IDA7XG4gICAgfVxuICB9XG4gIC8vIG5vdCBzdXJlLCB3ZSBuZWVkIHRvIGRvIHRoaXM/IEJ1dCBJIGRvbid0IG5lZWQgdG8gYnJlYWsgdGhlIGhvd2V2ZXJcbiAgc3ViID0gc3ViIHx8IHtfdG90YWxPYnNlcnZlcnM6MCAsIF9jYWNoZWRPYnNlcnZlcnM6IDB9O1xuXG4gIHB1YmxpY2F0aW9uLnRvdGFsT2JzZXJ2ZXJzKys7XG4gIHN1Yi5fdG90YWxPYnNlcnZlcnMrKztcbiAgaWYoaXNDYWNoZWQpIHtcbiAgICBwdWJsaWNhdGlvbi5jYWNoZWRPYnNlcnZlcnMrKztcbiAgICBzdWIuX2NhY2hlZE9ic2VydmVycysrO1xuICB9XG59XG5cblB1YnN1Yk1vZGVsLnByb3RvdHlwZS50cmFja0NyZWF0ZWRPYnNlcnZlciA9IGZ1bmN0aW9uKGluZm8pIHtcbiAgdmFyIHRpbWVzdGFtcCA9IE50cC5fbm93KCk7XG4gIHZhciBwdWJsaWNhdGlvbk5hbWUgPSB0aGlzLl9nZXRQdWJsaWNhdGlvbk5hbWUoaW5mby5uYW1lKTtcbiAgdmFyIHB1YmxpY2F0aW9uID0gdGhpcy5fZ2V0TWV0cmljcyh0aW1lc3RhbXAsIHB1YmxpY2F0aW9uTmFtZSk7XG4gIHB1YmxpY2F0aW9uLmNyZWF0ZWRPYnNlcnZlcnMrKztcbn1cblxuUHVic3ViTW9kZWwucHJvdG90eXBlLnRyYWNrRGVsZXRlZE9ic2VydmVyID0gZnVuY3Rpb24oaW5mbykge1xuICB2YXIgdGltZXN0YW1wID0gTnRwLl9ub3coKTtcbiAgdmFyIHB1YmxpY2F0aW9uTmFtZSA9IHRoaXMuX2dldFB1YmxpY2F0aW9uTmFtZShpbmZvLm5hbWUpO1xuICB2YXIgcHVibGljYXRpb24gPSB0aGlzLl9nZXRNZXRyaWNzKHRpbWVzdGFtcCwgcHVibGljYXRpb25OYW1lKTtcbiAgcHVibGljYXRpb24uZGVsZXRlZE9ic2VydmVycysrO1xuICBwdWJsaWNhdGlvbi5vYnNlcnZlckxpZmV0aW1lICs9IChuZXcgRGF0ZSgpKS5nZXRUaW1lKCkgLSBpbmZvLnN0YXJ0VGltZTtcbn1cblxuUHVic3ViTW9kZWwucHJvdG90eXBlLnRyYWNrRG9jdW1lbnRDaGFuZ2VzID0gZnVuY3Rpb24oaW5mbywgb3ApIHtcbiAgLy8gSXQncyBwb3NzaWJlbCB0aGF0IGluZm8gdG8gYmUgbnVsbFxuICAvLyBTcGVjaWFsbHkgd2hlbiBnZXR0aW5nIGNoYW5nZXMgYXQgdGhlIHZlcnkgYmVnaW5pbmcuXG4gIC8vIFRoaXMgbWF5IGJlIGZhbHNlLCBidXQgbmljZSB0byBoYXZlIGEgY2hlY2tcbiAgaWYoIWluZm8pIHtcbiAgICByZXR1cm5cbiAgfVxuXG4gIHZhciB0aW1lc3RhbXAgPSBOdHAuX25vdygpO1xuICB2YXIgcHVibGljYXRpb25OYW1lID0gdGhpcy5fZ2V0UHVibGljYXRpb25OYW1lKGluZm8ubmFtZSk7XG4gIHZhciBwdWJsaWNhdGlvbiA9IHRoaXMuX2dldE1ldHJpY3ModGltZXN0YW1wLCBwdWJsaWNhdGlvbk5hbWUpO1xuICBpZihvcC5vcCA9PT0gXCJkXCIpIHtcbiAgICBwdWJsaWNhdGlvbi5vcGxvZ0RlbGV0ZWREb2N1bWVudHMrKztcbiAgfSBlbHNlIGlmKG9wLm9wID09PSBcImlcIikge1xuICAgIHB1YmxpY2F0aW9uLm9wbG9nSW5zZXJ0ZWREb2N1bWVudHMrKztcbiAgfSBlbHNlIGlmKG9wLm9wID09PSBcInVcIikge1xuICAgIHB1YmxpY2F0aW9uLm9wbG9nVXBkYXRlZERvY3VtZW50cysrO1xuICB9XG59XG5cblB1YnN1Yk1vZGVsLnByb3RvdHlwZS50cmFja1BvbGxlZERvY3VtZW50cyA9IGZ1bmN0aW9uKGluZm8sIGNvdW50KSB7XG4gIHZhciB0aW1lc3RhbXAgPSBOdHAuX25vdygpO1xuICB2YXIgcHVibGljYXRpb25OYW1lID0gdGhpcy5fZ2V0UHVibGljYXRpb25OYW1lKGluZm8ubmFtZSk7XG4gIHZhciBwdWJsaWNhdGlvbiA9IHRoaXMuX2dldE1ldHJpY3ModGltZXN0YW1wLCBwdWJsaWNhdGlvbk5hbWUpO1xuICBwdWJsaWNhdGlvbi5wb2xsZWREb2N1bWVudHMgKz0gY291bnQ7XG59XG5cblB1YnN1Yk1vZGVsLnByb3RvdHlwZS50cmFja0xpdmVVcGRhdGVzID0gZnVuY3Rpb24oaW5mbywgdHlwZSwgY291bnQpIHtcbiAgdmFyIHRpbWVzdGFtcCA9IE50cC5fbm93KCk7XG4gIHZhciBwdWJsaWNhdGlvbk5hbWUgPSB0aGlzLl9nZXRQdWJsaWNhdGlvbk5hbWUoaW5mby5uYW1lKTtcbiAgdmFyIHB1YmxpY2F0aW9uID0gdGhpcy5fZ2V0TWV0cmljcyh0aW1lc3RhbXAsIHB1YmxpY2F0aW9uTmFtZSk7XG5cbiAgaWYodHlwZSA9PT0gXCJfYWRkUHVibGlzaGVkXCIpIHtcbiAgICBwdWJsaWNhdGlvbi5saXZlQWRkZWREb2N1bWVudHMgKz0gY291bnQ7XG4gIH0gZWxzZSBpZih0eXBlID09PSBcIl9yZW1vdmVQdWJsaXNoZWRcIikge1xuICAgIHB1YmxpY2F0aW9uLmxpdmVSZW1vdmVkRG9jdW1lbnRzICs9IGNvdW50O1xuICB9IGVsc2UgaWYodHlwZSA9PT0gXCJfY2hhbmdlUHVibGlzaGVkXCIpIHtcbiAgICBwdWJsaWNhdGlvbi5saXZlQ2hhbmdlZERvY3VtZW50cyArPSBjb3VudDtcbiAgfSBlbHNlIGlmKHR5cGUgPT09IFwiX2luaXRpYWxBZGRzXCIpIHtcbiAgICBwdWJsaWNhdGlvbi5pbml0aWFsbHlBZGRlZERvY3VtZW50cyArPSBjb3VudDtcbiAgfSBlbHNlIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJLYWRpcmE6IFVua25vd24gbGl2ZSB1cGRhdGUgdHlwZVwiKTtcbiAgfVxufVxuXG5QdWJzdWJNb2RlbC5wcm90b3R5cGUudHJhY2tEb2NTaXplID0gZnVuY3Rpb24obmFtZSwgdHlwZSwgc2l6ZSkge1xuICB2YXIgdGltZXN0YW1wID0gTnRwLl9ub3coKTtcbiAgdmFyIHB1YmxpY2F0aW9uTmFtZSA9IHRoaXMuX2dldFB1YmxpY2F0aW9uTmFtZShuYW1lKTtcbiAgdmFyIHB1YmxpY2F0aW9uID0gdGhpcy5fZ2V0TWV0cmljcyh0aW1lc3RhbXAsIHB1YmxpY2F0aW9uTmFtZSk7XG5cbiAgaWYodHlwZSA9PT0gXCJwb2xsZWRGZXRjaGVzXCIpIHtcbiAgICBwdWJsaWNhdGlvbi5wb2xsZWREb2NTaXplICs9IHNpemU7XG4gIH0gZWxzZSBpZih0eXBlID09PSBcImxpdmVGZXRjaGVzXCIpIHtcbiAgICBwdWJsaWNhdGlvbi5saXZlRmV0Y2hlZERvY1NpemUgKz0gc2l6ZTtcbiAgfSBlbHNlIGlmKHR5cGUgPT09IFwiY3Vyc29yRmV0Y2hlc1wiKSB7XG4gICAgcHVibGljYXRpb24uZmV0Y2hlZERvY1NpemUgKz0gc2l6ZTtcbiAgfSBlbHNlIGlmKHR5cGUgPT09IFwiaW5pdGlhbEZldGNoZXNcIikge1xuICAgIHB1YmxpY2F0aW9uLmluaXRpYWxseUZldGNoZWREb2NTaXplICs9IHNpemU7XG4gIH0gZWxzZSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiS2FkaXJhOiBVbmtub3duIGRvY3MgZmV0Y2hlZCB0eXBlXCIpO1xuICB9XG59XG5cblB1YnN1Yk1vZGVsLnByb3RvdHlwZS50cmFja01zZ1NpemUgPSBmdW5jdGlvbihuYW1lLCB0eXBlLCBzaXplKSB7XG4gIHZhciB0aW1lc3RhbXAgPSBOdHAuX25vdygpO1xuICB2YXIgcHVibGljYXRpb25OYW1lID0gdGhpcy5fZ2V0UHVibGljYXRpb25OYW1lKG5hbWUpO1xuICB2YXIgcHVibGljYXRpb24gPSB0aGlzLl9nZXRNZXRyaWNzKHRpbWVzdGFtcCwgcHVibGljYXRpb25OYW1lKTtcblxuICBpZih0eXBlID09PSBcImxpdmVTZW50XCIpIHtcbiAgICBwdWJsaWNhdGlvbi5saXZlU2VudE1zZ1NpemUgKz0gc2l6ZTtcbiAgfSBlbHNlIGlmKHR5cGUgPT09IFwiaW5pdGlhbFNlbnRcIikge1xuICAgIHB1YmxpY2F0aW9uLmluaXRpYWxseVNlbnRNc2dTaXplICs9IHNpemU7XG4gIH0gZWxzZSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiS2FkaXJhOiBVbmtub3duIGRvY3MgZmV0Y2hlZCB0eXBlXCIpO1xuICB9XG59XG4iLCJ2YXIgRXZlbnRMb29wTW9uaXRvciA9IE5wbS5yZXF1aXJlKCdldmxvb3AtbW9uaXRvcicpO1xuaW1wb3J0IHsgY3JlYXRlSGlzdG9ncmFtIH0gZnJvbSAnLi4vdXRpbHMuanMnO1xuaW1wb3J0IEdDTWV0cmljcyBmcm9tICcuLi9oaWphY2svZ2MuanMnO1xuaW1wb3J0IHsgZ2V0RmliZXJNZXRyaWNzLCByZXNldEZpYmVyTWV0cmljcyB9IGZyb20gJy4uL2hpamFjay9hc3luYy5qcyc7XG5pbXBvcnQgeyBnZXRNb25nb0RyaXZlclN0YXRzLCByZXNldE1vbmdvRHJpdmVyU3RhdHMgfSBmcm9tICcuLi9oaWphY2svbW9uZ28tZHJpdmVyLWV2ZW50cy5qcyc7XG5cblN5c3RlbU1vZGVsID0gZnVuY3Rpb24gKCkge1xuICB0aGlzLnN0YXJ0VGltZSA9IE50cC5fbm93KCk7XG4gIHRoaXMubmV3U2Vzc2lvbnMgPSAwO1xuICB0aGlzLnNlc3Npb25UaW1lb3V0ID0gMTAwMCAqIDYwICogMzA7IC8vMzAgbWluXG5cbiAgdGhpcy5ldmxvb3BIaXN0b2dyYW0gPSBjcmVhdGVIaXN0b2dyYW0oKTtcbiAgdGhpcy5ldmxvb3BNb25pdG9yID0gbmV3IEV2ZW50TG9vcE1vbml0b3IoMjAwKTtcbiAgdGhpcy5ldmxvb3BNb25pdG9yLnN0YXJ0KCk7XG4gIHRoaXMuZXZsb29wTW9uaXRvci5vbignbGFnJywgbGFnID0+IHtcbiAgICAvLyBzdG9yZSBhcyBtaWNyb3NlY29uZFxuICAgIHRoaXMuZXZsb29wSGlzdG9ncmFtLmFkZChsYWcgKiAxMDAwKTtcbiAgfSk7XG5cbiAgdGhpcy5nY01ldHJpY3MgPSBuZXcgR0NNZXRyaWNzKCk7XG4gIHRoaXMuZ2NNZXRyaWNzLnN0YXJ0KCk7XG5cblxuICB0aGlzLmNwdVRpbWUgPSBwcm9jZXNzLmhydGltZSgpO1xuICB0aGlzLnByZXZpb3VzQ3B1VXNhZ2UgPSBwcm9jZXNzLmNwdVVzYWdlKCk7XG4gIHRoaXMuY3B1SGlzdG9yeSA9IFtdO1xuICB0aGlzLmN1cnJlbnRDcHVVc2FnZSA9IDA7XG5cbiAgc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgIHRoaXMuY3B1VXNhZ2UoKTtcbiAgfSwgMjAwMCk7XG59XG5cbl8uZXh0ZW5kKFN5c3RlbU1vZGVsLnByb3RvdHlwZSwgS2FkaXJhTW9kZWwucHJvdG90eXBlKTtcblxuU3lzdGVtTW9kZWwucHJvdG90eXBlLmJ1aWxkUGF5bG9hZCA9IGZ1bmN0aW9uKCkge1xuICB2YXIgbWV0cmljcyA9IHt9O1xuICB2YXIgbm93ID0gTnRwLl9ub3coKTtcbiAgbWV0cmljcy5zdGFydFRpbWUgPSBLYWRpcmEuc3luY2VkRGF0ZS5zeW5jVGltZSh0aGlzLnN0YXJ0VGltZSk7XG4gIG1ldHJpY3MuZW5kVGltZSA9IEthZGlyYS5zeW5jZWREYXRlLnN5bmNUaW1lKG5vdyk7XG4gIG1ldHJpY3Muc2Vzc2lvbnMgPSBjb3VudEtleXMoTWV0ZW9yLnNlcnZlci5zZXNzaW9ucyk7XG5cbiAgbGV0IG1lbW9yeVVzYWdlID0gcHJvY2Vzcy5tZW1vcnlVc2FnZSgpO1xuICBtZXRyaWNzLm1lbW9yeSA9IG1lbW9yeVVzYWdlLnJzcyAvICgxMDI0KjEwMjQpO1xuICBtZXRyaWNzLm1lbW9yeUFycmF5QnVmZmVycyA9IChtZW1vcnlVc2FnZS5hcnJheUJ1ZmZlcnMgfHwgMCkgLyAoMTAyNCoxMDI0KTtcbiAgbWV0cmljcy5tZW1vcnlFeHRlcm5hbCA9IG1lbW9yeVVzYWdlLmV4dGVybmFsIC8gKDEwMjQqMTAyNCk7XG4gIG1ldHJpY3MubWVtb3J5SGVhcFVzZWQgPSBtZW1vcnlVc2FnZS5oZWFwVXNlZCAvICgxMDI0KjEwMjQpO1xuICBtZXRyaWNzLm1lbW9yeUhlYXBUb3RhbCA9IG1lbW9yeVVzYWdlLmhlYXBUb3RhbCAvICgxMDI0KjEwMjQpO1xuXG4gIG1ldHJpY3MubmV3U2Vzc2lvbnMgPSB0aGlzLm5ld1Nlc3Npb25zO1xuICB0aGlzLm5ld1Nlc3Npb25zID0gMDtcblxuICBtZXRyaWNzLmFjdGl2ZVJlcXVlc3RzID0gcHJvY2Vzcy5fZ2V0QWN0aXZlUmVxdWVzdHMoKS5sZW5ndGg7XG4gIG1ldHJpY3MuYWN0aXZlSGFuZGxlcyA9IHByb2Nlc3MuX2dldEFjdGl2ZUhhbmRsZXMoKS5sZW5ndGg7XG5cbiAgLy8gdHJhY2sgZXZlbnRsb29wIG1ldHJpY3NcbiAgbWV0cmljcy5wY3RFdmxvb3BCbG9jayA9IHRoaXMuZXZsb29wTW9uaXRvci5zdGF0dXMoKS5wY3RCbG9jaztcbiAgbWV0cmljcy5ldmxvb3BIaXN0b2dyYW0gPSB0aGlzLmV2bG9vcEhpc3RvZ3JhbTtcbiAgdGhpcy5ldmxvb3BIaXN0b2dyYW0gPSBjcmVhdGVIaXN0b2dyYW0oKTtcblxuICBtZXRyaWNzLmdjTWFqb3JEdXJhdGlvbiA9IHRoaXMuZ2NNZXRyaWNzLm1ldHJpY3MuZ2NNYWpvcjtcbiAgbWV0cmljcy5nY01pbm9yRHVyYXRpb24gPSB0aGlzLmdjTWV0cmljcy5tZXRyaWNzLmdjTWlub3I7XG4gIG1ldHJpY3MuZ2NJbmNyZW1lbnRhbER1cmF0aW9uID0gdGhpcy5nY01ldHJpY3MubWV0cmljcy5nY0luY3JlbWVudGFsO1xuICBtZXRyaWNzLmdjV2Vha0NCRHVyYXRpb24gPSB0aGlzLmdjTWV0cmljcy5tZXRyaWNzLmdjV2Vha0NCO1xuICB0aGlzLmdjTWV0cmljcy5yZXNldCgpO1xuXG4gIGNvbnN0IGRyaXZlck1ldHJpY3MgPSBnZXRNb25nb0RyaXZlclN0YXRzKCk7XG4gIHJlc2V0TW9uZ29Ecml2ZXJTdGF0cygpO1xuXG4gIG1ldHJpY3MubW9uZ29Qb29sU2l6ZSA9IGRyaXZlck1ldHJpY3MucG9vbFNpemU7XG4gIG1ldHJpY3MubW9uZ29Qb29sUHJpbWFyeUNoZWNrb3V0cyA9IGRyaXZlck1ldHJpY3MucHJpbWFyeUNoZWNrb3V0cztcbiAgbWV0cmljcy5tb25nb1Bvb2xPdGhlckNoZWNrb3V0cyA9IGRyaXZlck1ldHJpY3Mub3RoZXJDaGVja291dHM7XG4gIG1ldHJpY3MubW9uZ29Qb29sQ2hlY2tvdXRUaW1lID0gZHJpdmVyTWV0cmljcy5jaGVja291dFRpbWU7XG4gIG1ldHJpY3MubW9uZ29Qb29sTWF4Q2hlY2tvdXRUaW1lID0gZHJpdmVyTWV0cmljcy5tYXhDaGVja291dFRpbWU7XG4gIG1ldHJpY3MubW9uZ29Qb29sUGVuZGluZyA9IGRyaXZlck1ldHJpY3MucGVuZGluZztcbiAgbWV0cmljcy5tb25nb1Bvb2xDaGVja2VkT3V0Q29ubmVjdGlvbnMgPSBkcml2ZXJNZXRyaWNzLmNoZWNrZWRPdXQ7XG4gIG1ldHJpY3MubW9uZ29Qb29sQ3JlYXRlZENvbm5lY3Rpb25zID0gZHJpdmVyTWV0cmljcy5jcmVhdGVkO1xuXG4gIGNvbnN0IGZpYmVyTWV0cmljcyA9IGdldEZpYmVyTWV0cmljcygpO1xuICByZXNldEZpYmVyTWV0cmljcygpO1xuICBtZXRyaWNzLmNyZWF0ZWRGaWJlcnMgPSBmaWJlck1ldHJpY3MuY3JlYXRlZDtcbiAgbWV0cmljcy5hY3RpdmVGaWJlcnMgPSBmaWJlck1ldHJpY3MuYWN0aXZlO1xuICBtZXRyaWNzLmZpYmVyUG9vbFNpemUgPSBmaWJlck1ldHJpY3MucG9vbFNpemU7XG5cbiAgbWV0cmljcy5wY3B1ID0gMDtcbiAgbWV0cmljcy5wY3B1VXNlciA9IDA7XG4gIG1ldHJpY3MucGNwdVN5c3RlbSA9IDA7XG5cbiAgaWYgKHRoaXMuY3B1SGlzdG9yeS5sZW5ndGggPiAwKSB7XG4gICAgbGV0IGxhc3RDcHVVc2FnZSA9IHRoaXMuY3B1SGlzdG9yeVt0aGlzLmNwdUhpc3RvcnkubGVuZ3RoIC0gMV07XG4gICAgbWV0cmljcy5wY3B1ID0gbGFzdENwdVVzYWdlLnVzYWdlICogMTAwO1xuICAgIG1ldHJpY3MucGNwdVVzZXIgPSBsYXN0Q3B1VXNhZ2UudXNlciAqIDEwMDtcbiAgICBtZXRyaWNzLnBjcHVTeXN0ZW0gPSBsYXN0Q3B1VXNhZ2Uuc3lzICogMTAwO1xuICB9XG5cbiAgbWV0cmljcy5jcHVIaXN0b3J5ID0gdGhpcy5jcHVIaXN0b3J5Lm1hcChlbnRyeSA9PiB7XG4gICAgcmV0dXJuIHtcbiAgICAgIHRpbWU6IEthZGlyYS5zeW5jZWREYXRlLnN5bmNUaW1lKGVudHJ5LnRpbWUpLFxuICAgICAgdXNhZ2U6IGVudHJ5LnVzYWdlLFxuICAgICAgc3lzOiBlbnRyeS5zeXMsXG4gICAgICB1c2VyOiBlbnRyeS51c2VyXG4gICAgfTtcbiAgfSk7XG5cbiAgdGhpcy5jcHVIaXN0b3J5ID0gW107XG4gIHRoaXMuc3RhcnRUaW1lID0gbm93O1xuICByZXR1cm4ge3N5c3RlbU1ldHJpY3M6IFttZXRyaWNzXX07XG59O1xuXG5mdW5jdGlvbiBocnRpbWVUb01TKGhydGltZSkge1xuICByZXR1cm4gaHJ0aW1lWzBdICogMTAwMCArIGhydGltZVsxXSAvIDEwMDAwMDA7XG59XG5cblN5c3RlbU1vZGVsLnByb3RvdHlwZS5jcHVVc2FnZSA9IGZ1bmN0aW9uKCkge1xuICB2YXIgZWxhcFRpbWVNUyA9IGhydGltZVRvTVMocHJvY2Vzcy5ocnRpbWUodGhpcy5jcHVUaW1lKSk7XG4gIHZhciBlbGFwVXNhZ2UgPSBwcm9jZXNzLmNwdVVzYWdlKHRoaXMucHJldmlvdXNDcHVVc2FnZSk7XG4gIHZhciBlbGFwVXNlck1TID0gZWxhcFVzYWdlLnVzZXIgLyAxMDAwO1xuICB2YXIgZWxhcFN5c3RNUyA9IGVsYXBVc2FnZS5zeXN0ZW0gLyAxMDAwO1xuICB2YXIgdG90YWxVc2FnZU1TID0gZWxhcFVzZXJNUyArIGVsYXBTeXN0TVM7XG4gIHZhciB0b3RhbFVzYWdlUGVyY2VudCA9IHRvdGFsVXNhZ2VNUyAvIGVsYXBUaW1lTVM7XG5cbiAgdGhpcy5jcHVIaXN0b3J5LnB1c2goe1xuICAgIHRpbWU6IE50cC5fbm93KCksXG4gICAgdXNhZ2U6IHRvdGFsVXNhZ2VQZXJjZW50LFxuICAgIHVzZXI6IGVsYXBVc2VyTVMgLyBlbGFwVGltZU1TLFxuICAgIHN5czogZWxhcFN5c3RNUyAvIGVsYXBVc2FnZS5zeXN0ZW1cbiAgfSk7XG5cbiAgdGhpcy5jdXJyZW50Q3B1VXNhZ2UgPSB0b3RhbFVzYWdlUGVyY2VudCAqIDEwMDtcbiAgS2FkaXJhLmRvY1N6Q2FjaGUuc2V0UGNwdSh0aGlzLmN1cnJlbnRDcHVVc2FnZSk7XG5cbiAgdGhpcy5jcHVUaW1lID0gcHJvY2Vzcy5ocnRpbWUoKTtcbiAgdGhpcy5wcmV2aW91c0NwdVVzYWdlID0gcHJvY2Vzcy5jcHVVc2FnZSgpO1xufVxuXG5TeXN0ZW1Nb2RlbC5wcm90b3R5cGUuaGFuZGxlU2Vzc2lvbkFjdGl2aXR5ID0gZnVuY3Rpb24obXNnLCBzZXNzaW9uKSB7XG4gIGlmKG1zZy5tc2cgPT09ICdjb25uZWN0JyAmJiAhbXNnLnNlc3Npb24pIHtcbiAgICB0aGlzLmNvdW50TmV3U2Vzc2lvbihzZXNzaW9uKTtcbiAgfSBlbHNlIGlmKFsnc3ViJywgJ21ldGhvZCddLmluZGV4T2YobXNnLm1zZykgIT0gLTEpIHtcbiAgICBpZighdGhpcy5pc1Nlc3Npb25BY3RpdmUoc2Vzc2lvbikpIHtcbiAgICAgIHRoaXMuY291bnROZXdTZXNzaW9uKHNlc3Npb24pO1xuICAgIH1cbiAgfVxuICBzZXNzaW9uLl9hY3RpdmVBdCA9IERhdGUubm93KCk7XG59XG5cblN5c3RlbU1vZGVsLnByb3RvdHlwZS5jb3VudE5ld1Nlc3Npb24gPSBmdW5jdGlvbihzZXNzaW9uKSB7XG4gIGlmKCFpc0xvY2FsQWRkcmVzcyhzZXNzaW9uLnNvY2tldCkpIHtcbiAgICB0aGlzLm5ld1Nlc3Npb25zKys7XG4gIH1cbn1cblxuU3lzdGVtTW9kZWwucHJvdG90eXBlLmlzU2Vzc2lvbkFjdGl2ZSA9IGZ1bmN0aW9uKHNlc3Npb24pIHtcbiAgdmFyIGluYWN0aXZlVGltZSA9IERhdGUubm93KCkgLSBzZXNzaW9uLl9hY3RpdmVBdDtcbiAgcmV0dXJuIGluYWN0aXZlVGltZSA8IHRoaXMuc2Vzc2lvblRpbWVvdXQ7XG59XG5cbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gLy9cblxuLy8gaHR0cDovL3JlZ2V4MTAxLmNvbS9yL2lGM3lSMy8yXG52YXIgaXNMb2NhbEhvc3RSZWdleCA9IC9eKD86LipcXC5sb2NhbHxsb2NhbGhvc3QpKD86XFw6XFxkKyk/fDEyNyg/OlxcLlxcZHsxLDN9KXszfXwxOTJcXC4xNjgoPzpcXC5cXGR7MSwzfSl7Mn18MTAoPzpcXC5cXGR7MSwzfSl7M318MTcyXFwuKD86MVs2LTldfDJcXGR8M1swLTFdKSg/OlxcLlxcZHsxLDN9KXsyfSQvO1xuXG4vLyBodHRwOi8vcmVnZXgxMDEuY29tL3IvaE01Z0Q4LzFcbnZhciBpc0xvY2FsQWRkcmVzc1JlZ2V4ID0gL14xMjcoPzpcXC5cXGR7MSwzfSl7M318MTkyXFwuMTY4KD86XFwuXFxkezEsM30pezJ9fDEwKD86XFwuXFxkezEsM30pezN9fDE3MlxcLig/OjFbNi05XXwyXFxkfDNbMC0xXSkoPzpcXC5cXGR7MSwzfSl7Mn0kLztcblxuZnVuY3Rpb24gaXNMb2NhbEFkZHJlc3MgKHNvY2tldCkge1xuICB2YXIgaG9zdCA9IHNvY2tldC5oZWFkZXJzWydob3N0J107XG4gIGlmKGhvc3QpIHJldHVybiBpc0xvY2FsSG9zdFJlZ2V4LnRlc3QoaG9zdCk7XG4gIHZhciBhZGRyZXNzID0gc29ja2V0LmhlYWRlcnNbJ3gtZm9yd2FyZGVkLWZvciddIHx8IHNvY2tldC5yZW1vdGVBZGRyZXNzO1xuICBpZihhZGRyZXNzKSByZXR1cm4gaXNMb2NhbEFkZHJlc3NSZWdleC50ZXN0KGFkZHJlc3MpO1xufVxuIiwiRXJyb3JNb2RlbCA9IGZ1bmN0aW9uIChhcHBJZCkge1xuICBCYXNlRXJyb3JNb2RlbC5jYWxsKHRoaXMpO1xuICB2YXIgc2VsZiA9IHRoaXM7XG4gIHRoaXMuYXBwSWQgPSBhcHBJZDtcbiAgdGhpcy5lcnJvcnMgPSB7fTtcbiAgdGhpcy5zdGFydFRpbWUgPSBEYXRlLm5vdygpO1xuICB0aGlzLm1heEVycm9ycyA9IDEwO1xufVxuXG5PYmplY3QuYXNzaWduKEVycm9yTW9kZWwucHJvdG90eXBlLCBLYWRpcmFNb2RlbC5wcm90b3R5cGUpO1xuT2JqZWN0LmFzc2lnbihFcnJvck1vZGVsLnByb3RvdHlwZSwgQmFzZUVycm9yTW9kZWwucHJvdG90eXBlKTtcblxuRXJyb3JNb2RlbC5wcm90b3R5cGUuYnVpbGRQYXlsb2FkID0gZnVuY3Rpb24oKSB7XG4gIHZhciBtZXRyaWNzID0gXy52YWx1ZXModGhpcy5lcnJvcnMpO1xuICB0aGlzLnN0YXJ0VGltZSA9IE50cC5fbm93KCk7XG5cbiAgbWV0cmljcy5mb3JFYWNoKGZ1bmN0aW9uIChtZXRyaWMpIHtcbiAgICBtZXRyaWMuc3RhcnRUaW1lID0gS2FkaXJhLnN5bmNlZERhdGUuc3luY1RpbWUobWV0cmljLnN0YXJ0VGltZSlcbiAgfSk7XG5cbiAgdGhpcy5lcnJvcnMgPSB7fTtcbiAgcmV0dXJuIHtlcnJvcnM6IG1ldHJpY3N9O1xufTtcblxuRXJyb3JNb2RlbC5wcm90b3R5cGUuZXJyb3JDb3VudCA9IGZ1bmN0aW9uICgpIHtcbiAgcmV0dXJuIF8udmFsdWVzKHRoaXMuZXJyb3JzKS5sZW5ndGg7XG59O1xuXG5FcnJvck1vZGVsLnByb3RvdHlwZS50cmFja0Vycm9yID0gZnVuY3Rpb24oZXgsIHRyYWNlKSB7XG4gIHZhciBrZXkgPSB0cmFjZS50eXBlICsgJzonICsgZXgubWVzc2FnZTtcbiAgaWYodGhpcy5lcnJvcnNba2V5XSkge1xuICAgIHRoaXMuZXJyb3JzW2tleV0uY291bnQrKztcbiAgfSBlbHNlIGlmICh0aGlzLmVycm9yQ291bnQoKSA8IHRoaXMubWF4RXJyb3JzKSB7XG4gICAgdmFyIGVycm9yRGVmID0gdGhpcy5fZm9ybWF0RXJyb3IoZXgsIHRyYWNlKTtcbiAgICBpZih0aGlzLmFwcGx5RmlsdGVycyhlcnJvckRlZi50eXBlLCBlcnJvckRlZi5uYW1lLCBleCwgZXJyb3JEZWYuc3ViVHlwZSkpIHtcbiAgICAgIHRoaXMuZXJyb3JzW2tleV0gPSB0aGlzLl9mb3JtYXRFcnJvcihleCwgdHJhY2UpO1xuICAgIH1cbiAgfVxufTtcblxuRXJyb3JNb2RlbC5wcm90b3R5cGUuX2Zvcm1hdEVycm9yID0gZnVuY3Rpb24oZXgsIHRyYWNlKSB7XG4gIHZhciB0aW1lID0gRGF0ZS5ub3coKTtcbiAgdmFyIHN0YWNrID0gZXguc3RhY2s7XG5cbiAgLy8gdG8gZ2V0IE1ldGVvcidzIEVycm9yIGRldGFpbHNcbiAgaWYoZXguZGV0YWlscykge1xuICAgIHN0YWNrID0gXCJEZXRhaWxzOiBcIiArIGV4LmRldGFpbHMgKyBcIlxcclxcblwiICsgc3RhY2s7XG4gIH1cblxuICAvLyBVcGRhdGUgdHJhY2UncyBlcnJvciBldmVudCB3aXRoIHRoZSBuZXh0IHN0YWNrXG4gIHZhciBlcnJvckV2ZW50ID0gdHJhY2UuZXZlbnRzICYmIHRyYWNlLmV2ZW50c1t0cmFjZS5ldmVudHMubGVuZ3RoIC0xXTtcbiAgdmFyIGVycm9yT2JqZWN0ID0gZXJyb3JFdmVudCAmJiBlcnJvckV2ZW50WzJdICYmIGVycm9yRXZlbnRbMl0uZXJyb3I7XG5cbiAgaWYoZXJyb3JPYmplY3QpIHtcbiAgICBlcnJvck9iamVjdC5zdGFjayA9IHN0YWNrO1xuICB9XG5cbiAgcmV0dXJuIHtcbiAgICBhcHBJZDogdGhpcy5hcHBJZCxcbiAgICBuYW1lOiBleC5tZXNzYWdlLFxuICAgIHR5cGU6IHRyYWNlLnR5cGUsXG4gICAgc3RhcnRUaW1lOiB0aW1lLFxuICAgIHN1YlR5cGU6IHRyYWNlLnN1YlR5cGUgfHwgdHJhY2UubmFtZSxcbiAgICB0cmFjZTogdHJhY2UsXG4gICAgc3RhY2tzOiBbe3N0YWNrOiBzdGFja31dLFxuICAgIGNvdW50OiAxXG4gIH1cbn07XG4iLCJjb25zdCB7IEREU2tldGNoIH0gPSByZXF1aXJlKCdtb250aS1hcG0tc2tldGNoZXMtanMnKTtcblxuY29uc3QgTUVUSE9EX01FVFJJQ1NfRklFTERTID0gWydkYicsICdodHRwJywgJ2VtYWlsJywgJ2FzeW5jJywgJ2NvbXB1dGUnLCAndG90YWwnLCAnZnMnXTtcblxuXG5jb25zdCBIdHRwTW9kZWwgPSBmdW5jdGlvbiAoKSB7XG4gIHRoaXMubWV0cmljc0J5TWludXRlID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgdGhpcy50cmFjZXJTdG9yZSA9IG5ldyBUcmFjZXJTdG9yZSh7XG4gICAgaW50ZXJ2YWw6IDEwMDAgKiAxMCxcbiAgICBtYXhUb3RhbFBvaW50czogMzAsXG4gICAgYXJjaGl2ZUV2ZXJ5OiAxMFxuICB9KTtcblxuICB0aGlzLnRyYWNlclN0b3JlLnN0YXJ0KCk7XG59XG5cbl8uZXh0ZW5kKEh0dHBNb2RlbC5wcm90b3R5cGUsIEthZGlyYU1vZGVsLnByb3RvdHlwZSk7XG5cbkh0dHBNb2RlbC5wcm90b3R5cGUucHJvY2Vzc1JlcXVlc3QgPSBmdW5jdGlvbiAodHJhY2UsIHJlcSwgcmVzKSB7XG4gIGNvbnN0IGRhdGVJZCA9IHRoaXMuX2dldERhdGVJZCh0cmFjZS5hdCk7XG4gIHRoaXMuX2FwcGVuZE1ldHJpY3MoZGF0ZUlkLCB0cmFjZSwgcmVzKTtcbiAgdGhpcy50cmFjZXJTdG9yZS5hZGRUcmFjZSh0cmFjZSk7XG59XG5cbkh0dHBNb2RlbC5wcm90b3R5cGUuX2dldE1ldHJpY3MgPSBmdW5jdGlvbiAodGltZXN0YW1wLCByb3V0ZUlkKSB7XG4gIGNvbnN0IGRhdGVJZCA9IHRoaXMuX2dldERhdGVJZCh0aW1lc3RhbXApO1xuXG4gIGlmICghdGhpcy5tZXRyaWNzQnlNaW51dGVbZGF0ZUlkXSkge1xuICAgIHRoaXMubWV0cmljc0J5TWludXRlW2RhdGVJZF0gPSB7XG4gICAgICByb3V0ZXM6IE9iamVjdC5jcmVhdGUobnVsbClcbiAgICB9O1xuICB9XG5cbiAgY29uc3Qgcm91dGVzID0gdGhpcy5tZXRyaWNzQnlNaW51dGVbZGF0ZUlkXS5yb3V0ZXM7XG5cbiAgaWYgKCFyb3V0ZXNbcm91dGVJZF0pIHtcbiAgICByb3V0ZXNbcm91dGVJZF0gPSB7XG4gICAgICBoaXN0b2dyYW06IG5ldyBERFNrZXRjaCh7XG4gICAgICAgIGFscGhhOiAwLjAyLFxuICAgICAgfSksXG4gICAgICBjb3VudDogMCxcbiAgICAgIGVycm9yczogMCxcbiAgICAgIHN0YXR1c0NvZGVzOiBPYmplY3QuY3JlYXRlKG51bGwpXG4gICAgfTtcblxuICAgIE1FVEhPRF9NRVRSSUNTX0ZJRUxEUy5mb3JFYWNoKGZ1bmN0aW9uIChmaWVsZCkge1xuICAgICAgcm91dGVzW3JvdXRlSWRdW2ZpZWxkXSA9IDA7XG4gICAgfSk7XG4gIH1cblxuICByZXR1cm4gdGhpcy5tZXRyaWNzQnlNaW51dGVbZGF0ZUlkXS5yb3V0ZXNbcm91dGVJZF07XG59XG5cbkh0dHBNb2RlbC5wcm90b3R5cGUuX2FwcGVuZE1ldHJpY3MgPSBmdW5jdGlvbiAoZGF0ZUlkLCB0cmFjZSwgcmVzKSB7XG4gIHZhciByZXF1ZXN0TWV0cmljcyA9IHRoaXMuX2dldE1ldHJpY3MoZGF0ZUlkLCB0cmFjZS5uYW1lKTtcblxuICBpZiAoIXRoaXMubWV0cmljc0J5TWludXRlW2RhdGVJZF0uc3RhcnRUaW1lKSB7XG4gICAgdGhpcy5tZXRyaWNzQnlNaW51dGVbZGF0ZUlkXS5zdGFydFRpbWUgPSB0cmFjZS5hdDtcbiAgfVxuXG4gIC8vIG1lcmdlXG4gIE1FVEhPRF9NRVRSSUNTX0ZJRUxEUy5mb3JFYWNoKGZpZWxkID0+IHtcbiAgICB2YXIgdmFsdWUgPSB0cmFjZS5tZXRyaWNzW2ZpZWxkXTtcbiAgICBpZiAodmFsdWUgPiAwKSB7XG4gICAgICByZXF1ZXN0TWV0cmljc1tmaWVsZF0gKz0gdmFsdWU7XG4gICAgfVxuICB9KTtcblxuICBjb25zdCBzdGF0dXNDb2RlID0gcmVzLnN0YXR1c0NvZGU7XG4gIGxldCBzdGF0dXNNZXRyaWM7XG5cbiAgaWYgKHN0YXR1c0NvZGUgPCAyMDApIHtcbiAgICBzdGF0dXNNZXRyaWMgPSAnMXh4JztcbiAgfSBlbHNlIGlmIChzdGF0dXNDb2RlIDwgMzAwKSB7XG4gICAgc3RhdHVzTWV0cmljID0gJzJ4eCc7XG4gIH0gZWxzZSBpZiAoc3RhdHVzQ29kZSA8IDQwMCkge1xuICAgIHN0YXR1c01ldHJpYyA9ICczeHgnO1xuICB9IGVsc2UgaWYgKHN0YXR1c0NvZGUgPCA1MDApIHtcbiAgICBzdGF0dXNNZXRyaWMgPSAnNHh4JztcbiAgfSBlbHNlIGlmIChzdGF0dXNDb2RlIDwgNjAwKSB7XG4gICAgc3RhdHVzTWV0cmljID0gJzV4eCc7XG4gIH1cblxuICByZXF1ZXN0TWV0cmljcy5zdGF0dXNDb2Rlc1tzdGF0dXNNZXRyaWNdID0gcmVxdWVzdE1ldHJpY3Muc3RhdHVzQ29kZXNbc3RhdHVzTWV0cmljXSB8fCAwO1xuICByZXF1ZXN0TWV0cmljcy5zdGF0dXNDb2Rlc1tzdGF0dXNNZXRyaWNdICs9IDE7XG5cbiAgcmVxdWVzdE1ldHJpY3MuY291bnQgKz0gMTtcbiAgcmVxdWVzdE1ldHJpY3MuaGlzdG9ncmFtLmFkZCh0cmFjZS5tZXRyaWNzLnRvdGFsKTtcbiAgdGhpcy5tZXRyaWNzQnlNaW51dGVbZGF0ZUlkXS5lbmRUaW1lID0gdHJhY2UubWV0cmljcy5hdDtcbn1cblxuSHR0cE1vZGVsLnByb3RvdHlwZS5idWlsZFBheWxvYWQgPSBmdW5jdGlvbigpIHtcbiAgdmFyIHBheWxvYWQgPSB7XG4gICAgaHR0cE1ldHJpY3M6IFtdLFxuICAgIGh0dHBSZXF1ZXN0czogW11cbiAgfTtcblxuICB2YXIgbWV0cmljc0J5TWludXRlID0gdGhpcy5tZXRyaWNzQnlNaW51dGU7XG4gIHRoaXMubWV0cmljc0J5TWludXRlID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcblxuICBmb3IodmFyIGtleSBpbiBtZXRyaWNzQnlNaW51dGUpIHtcbiAgICB2YXIgbWV0cmljcyA9IG1ldHJpY3NCeU1pbnV0ZVtrZXldO1xuICAgIC8vIGNvbnZlcnQgc3RhcnRUaW1lIGludG8gdGhlIGFjdHVhbCBzZXJ2ZXJUaW1lXG4gICAgdmFyIHN0YXJ0VGltZSA9IG1ldHJpY3Muc3RhcnRUaW1lO1xuICAgIG1ldHJpY3Muc3RhcnRUaW1lID0gS2FkaXJhLnN5bmNlZERhdGUuc3luY1RpbWUoc3RhcnRUaW1lKTtcblxuICAgIGZvcih2YXIgcmVxdWVzdE5hbWUgaW4gbWV0cmljcy5yb3V0ZXMpIHtcbiAgICAgIE1FVEhPRF9NRVRSSUNTX0ZJRUxEUy5mb3JFYWNoKGZ1bmN0aW9uIChmaWVsZCkge1xuICAgICAgICBtZXRyaWNzLnJvdXRlc1tyZXF1ZXN0TmFtZV1bZmllbGRdIC89IG1ldHJpY3Mucm91dGVzW3JlcXVlc3ROYW1lXS5jb3VudDtcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIHBheWxvYWQuaHR0cE1ldHJpY3MucHVzaChtZXRyaWNzQnlNaW51dGVba2V5XSk7XG4gIH1cblxuICBwYXlsb2FkLmh0dHBSZXF1ZXN0cyA9IHRoaXMudHJhY2VyU3RvcmUuY29sbGVjdFRyYWNlcygpO1xuXG4gIHJldHVybiBwYXlsb2FkO1xufVxuXG5leHBvcnQgZGVmYXVsdCBIdHRwTW9kZWw7XG4iLCJ2YXIgSm9icyA9IEthZGlyYS5Kb2JzID0ge307XG5cbkpvYnMuZ2V0QXN5bmMgPSBmdW5jdGlvbihpZCwgY2FsbGJhY2spIHtcbiAgS2FkaXJhLmNvcmVBcGkuZ2V0Sm9iKGlkKVxuICAgIC50aGVuKGZ1bmN0aW9uKGRhdGEpIHtcbiAgICAgIGNhbGxiYWNrKG51bGwsIGRhdGEpO1xuICAgIH0pXG4gICAgLmNhdGNoKGZ1bmN0aW9uKGVycikge1xuICAgICAgY2FsbGJhY2soZXJyKVxuICAgIH0pO1xufTtcblxuXG5Kb2JzLnNldEFzeW5jID0gZnVuY3Rpb24oaWQsIGNoYW5nZXMsIGNhbGxiYWNrKSB7XG4gIEthZGlyYS5jb3JlQXBpLnVwZGF0ZUpvYihpZCwgY2hhbmdlcylcbiAgICAudGhlbihmdW5jdGlvbihkYXRhKSB7XG4gICAgICBjYWxsYmFjayhudWxsLCBkYXRhKTtcbiAgICB9KVxuICAgIC5jYXRjaChmdW5jdGlvbihlcnIpIHtcbiAgICAgIGNhbGxiYWNrKGVycilcbiAgICB9KTtcbn07XG5cbkpvYnMuc2V0ID0gS2FkaXJhLl93cmFwQXN5bmMoSm9icy5zZXRBc3luYyk7XG5Kb2JzLmdldCA9IEthZGlyYS5fd3JhcEFzeW5jKEpvYnMuZ2V0QXN5bmMpO1xuIiwiLy8gUmV0cnkgbG9naWMgd2l0aCBhbiBleHBvbmVudGlhbCBiYWNrb2ZmLlxuLy9cbi8vIG9wdGlvbnM6XG4vLyAgYmFzZVRpbWVvdXQ6IHRpbWUgZm9yIGluaXRpYWwgcmVjb25uZWN0IGF0dGVtcHQgKG1zKS5cbi8vICBleHBvbmVudDogZXhwb25lbnRpYWwgZmFjdG9yIHRvIGluY3JlYXNlIHRpbWVvdXQgZWFjaCBhdHRlbXB0LlxuLy8gIG1heFRpbWVvdXQ6IG1heGltdW0gdGltZSBiZXR3ZWVuIHJldHJpZXMgKG1zKS5cbi8vICBtaW5Db3VudDogaG93IG1hbnkgdGltZXMgdG8gcmVjb25uZWN0IFwiaW5zdGFudGx5XCIuXG4vLyAgbWluVGltZW91dDogdGltZSB0byB3YWl0IGZvciB0aGUgZmlyc3QgYG1pbkNvdW50YCByZXRyaWVzIChtcykuXG4vLyAgZnV6ejogZmFjdG9yIHRvIHJhbmRvbWl6ZSByZXRyeSB0aW1lcyBieSAodG8gYXZvaWQgcmV0cnkgc3Rvcm1zKS5cblxuLy9UT0RPOiByZW1vdmUgdGhpcyBjbGFzcyBhbmQgdXNlIE1ldGVvciBSZXRyeSBpbiBhIGxhdGVyIHZlcnNpb24gb2YgbWV0ZW9yLlxuXG5SZXRyeSA9IGNsYXNzIHtcbiAgY29uc3RydWN0b3IgKHtcbiAgICBiYXNlVGltZW91dCA9IDEwMDAsIC8vIDEgc2Vjb25kXG4gICAgZXhwb25lbnQgPSAyLjIsXG4gICAgLy8gVGhlIGRlZmF1bHQgaXMgaGlnaC1pc2ggdG8gZW5zdXJlIGEgc2VydmVyIGNhbiByZWNvdmVyIGZyb20gYVxuICAgIC8vIGZhaWx1cmUgY2F1c2VkIGJ5IGxvYWQuXG4gICAgbWF4VGltZW91dCA9IDUgKiA2MDAwMCwgLy8gNSBtaW51dGVzXG4gICAgbWluVGltZW91dCA9IDEwLFxuICAgIG1pbkNvdW50ID0gMixcbiAgICBmdXp6ID0gMC41LCAvLyArLSAyNSVcbiAgfSA9IHt9KSB7XG4gICAgdGhpcy5iYXNlVGltZW91dCA9IGJhc2VUaW1lb3V0O1xuICAgIHRoaXMuZXhwb25lbnQgPSBleHBvbmVudDtcbiAgICB0aGlzLm1heFRpbWVvdXQgPSBtYXhUaW1lb3V0O1xuICAgIHRoaXMubWluVGltZW91dCA9IG1pblRpbWVvdXQ7XG4gICAgdGhpcy5taW5Db3VudCA9IG1pbkNvdW50O1xuICAgIHRoaXMuZnV6eiA9IGZ1eno7XG4gICAgdGhpcy5yZXRyeVRpbWVyID0gbnVsbDtcbiAgfVxuXG4gIC8vIFJlc2V0IGEgcGVuZGluZyByZXRyeSwgaWYgYW55LlxuICBjbGVhcigpIHtcbiAgICBpZih0aGlzLnJldHJ5VGltZXIpXG4gICAgICBjbGVhclRpbWVvdXQodGhpcy5yZXRyeVRpbWVyKTtcbiAgICB0aGlzLnJldHJ5VGltZXIgPSBudWxsO1xuICB9XG5cbiAgLy8gQ2FsY3VsYXRlIGhvdyBsb25nIHRvIHdhaXQgaW4gbWlsbGlzZWNvbmRzIHRvIHJldHJ5LCBiYXNlZCBvbiB0aGVcbiAgLy8gYGNvdW50YCBvZiB3aGljaCByZXRyeSB0aGlzIGlzLlxuICBfdGltZW91dChjb3VudCkge1xuICAgIGlmKGNvdW50IDwgdGhpcy5taW5Db3VudClcbiAgICAgIHJldHVybiB0aGlzLm1pblRpbWVvdXQ7XG5cbiAgICBsZXQgdGltZW91dCA9IE1hdGgubWluKFxuICAgICAgdGhpcy5tYXhUaW1lb3V0LFxuICAgICAgdGhpcy5iYXNlVGltZW91dCAqIE1hdGgucG93KHRoaXMuZXhwb25lbnQsIGNvdW50KSk7XG4gICAgLy8gZnV6eiB0aGUgdGltZW91dCByYW5kb21seSwgdG8gYXZvaWQgcmVjb25uZWN0IHN0b3JtcyB3aGVuIGFcbiAgICAvLyBzZXJ2ZXIgZ29lcyBkb3duLlxuICAgIHRpbWVvdXQgPSB0aW1lb3V0ICogKChSYW5kb20uZnJhY3Rpb24oKSAqIHRoaXMuZnV6eikgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICgxIC0gdGhpcy5mdXp6LzIpKTtcbiAgICByZXR1cm4gTWF0aC5jZWlsKHRpbWVvdXQpO1xuICB9XG5cbiAgLy8gQ2FsbCBgZm5gIGFmdGVyIGEgZGVsYXksIGJhc2VkIG9uIHRoZSBgY291bnRgIG9mIHdoaWNoIHJldHJ5IHRoaXMgaXMuXG4gIHJldHJ5TGF0ZXIoY291bnQsIGZuKSB7XG4gICAgY29uc3QgdGltZW91dCA9IHRoaXMuX3RpbWVvdXQoY291bnQpO1xuICAgIGlmKHRoaXMucmV0cnlUaW1lcilcbiAgICAgIGNsZWFyVGltZW91dCh0aGlzLnJldHJ5VGltZXIpO1xuXG4gICAgdGhpcy5yZXRyeVRpbWVyID0gc2V0VGltZW91dChmbiwgdGltZW91dCk7XG4gICAgcmV0dXJuIHRpbWVvdXQ7XG4gIH1cblxufVxuXG4iLCJjb25zdCB7IEREU2tldGNoIH0gPSByZXF1aXJlKCdtb250aS1hcG0tc2tldGNoZXMtanMnKTtcblxuSGF2ZUFzeW5jQ2FsbGJhY2sgPSBmdW5jdGlvbihhcmdzKSB7XG4gIHZhciBsYXN0QXJnID0gYXJnc1thcmdzLmxlbmd0aCAtMV07XG4gIHJldHVybiAodHlwZW9mIGxhc3RBcmcpID09ICdmdW5jdGlvbic7XG59O1xuXG5VbmlxdWVJZCA9IGZ1bmN0aW9uKHN0YXJ0KSB7XG4gIHRoaXMuaWQgPSAwO1xufVxuXG5VbmlxdWVJZC5wcm90b3R5cGUuZ2V0ID0gZnVuY3Rpb24oKSB7XG4gIHJldHVybiBcIlwiICsgdGhpcy5pZCsrO1xufTtcblxuRGVmYXVsdFVuaXF1ZUlkID0gbmV3IFVuaXF1ZUlkKCk7XG5cbi8vIGNyZWF0ZXMgYSBzdGFjayB0cmFjZSwgcmVtb3ZpbmcgZnJhbWVzIGluIG1vbnRpYXBtOmFnZW50J3MgY29kZVxuQ3JlYXRlVXNlclN0YWNrID0gZnVuY3Rpb24gKGVycm9yKSB7XG4gIGNvbnN0IHN0YWNrID0gKGVycm9yIHx8IG5ldyBFcnJvcigpKS5zdGFjay5zcGxpdCgnXFxuJyk7XG4gIGxldCB0b1JlbW92ZSA9IDE7XG5cbiAgLy8gRmluZCBob3cgbWFueSBmcmFtZXMgbmVlZCB0byBiZSByZW1vdmVkXG4gIC8vIHRvIG1ha2UgdGhlIHVzZXIncyBjb2RlIHRoZSBmaXJzdCBmcmFtZVxuICBmb3IgKDsgdG9SZW1vdmUgPCBzdGFjay5sZW5ndGg7IHRvUmVtb3ZlKyspIHtcbiAgICBpZiAoc3RhY2tbdG9SZW1vdmVdLmluZGV4T2YoJ21vbnRpYXBtOmFnZW50JykgPT09IC0xKSB7XG4gICAgICBicmVhaztcbiAgICB9XG4gIH1cblxuICByZXR1cm4gc3RhY2suc2xpY2UodG9SZW1vdmUpLmpvaW4oJ1xcbicpO1xufVxuXG4vLyBPcHRpbWl6ZWQgdmVyc2lvbiBvZiBhcHBseSB3aGljaCB0cmllcyB0byBjYWxsIGFzIHBvc3NpYmxlIGFzIGl0IGNhblxuLy8gVGhlbiBmYWxsIGJhY2sgdG8gYXBwbHlcbi8vIFRoaXMgaXMgYmVjYXVzZSwgdjggaXMgdmVyeSBzbG93IHRvIGludm9rZSBhcHBseS5cbk9wdGltaXplZEFwcGx5ID0gZnVuY3Rpb24gT3B0aW1pemVkQXBwbHkoY29udGV4dCwgZm4sIGFyZ3MpIHtcbiAgdmFyIGEgPSBhcmdzO1xuICBzd2l0Y2goYS5sZW5ndGgpIHtcbiAgICBjYXNlIDA6XG4gICAgICByZXR1cm4gZm4uY2FsbChjb250ZXh0KTtcbiAgICBjYXNlIDE6XG4gICAgICByZXR1cm4gZm4uY2FsbChjb250ZXh0LCBhWzBdKTtcbiAgICBjYXNlIDI6XG4gICAgICByZXR1cm4gZm4uY2FsbChjb250ZXh0LCBhWzBdLCBhWzFdKTtcbiAgICBjYXNlIDM6XG4gICAgICByZXR1cm4gZm4uY2FsbChjb250ZXh0LCBhWzBdLCBhWzFdLCBhWzJdKTtcbiAgICBjYXNlIDQ6XG4gICAgICByZXR1cm4gZm4uY2FsbChjb250ZXh0LCBhWzBdLCBhWzFdLCBhWzJdLCBhWzNdKTtcbiAgICBjYXNlIDU6XG4gICAgICByZXR1cm4gZm4uY2FsbChjb250ZXh0LCBhWzBdLCBhWzFdLCBhWzJdLCBhWzNdLCBhWzRdKTtcbiAgICBkZWZhdWx0OlxuICAgICAgcmV0dXJuIGZuLmFwcGx5KGNvbnRleHQsIGEpO1xuICB9XG59XG5cbmdldENsaWVudFZlcnNpb25zID0gZnVuY3Rpb24gKCkge1xuICByZXR1cm4ge1xuICAgICd3ZWIuY29yZG92YSc6IGdldENsaWVudEFyY2hWZXJzaW9uKCd3ZWIuY29yZG92YScpLFxuICAgICd3ZWIuYnJvd3Nlcic6IGdldENsaWVudEFyY2hWZXJzaW9uKCd3ZWIuYnJvd3NlcicpLFxuICAgICd3ZWIuYnJvd3Nlci5sZWdhY3knOiBnZXRDbGllbnRBcmNoVmVyc2lvbignd2ViLmJyb3dzZXIubGVnYWN5JylcbiAgfVxufVxuXG4vLyBSZXR1cm5zIG51bWJlciBvZiBrZXlzIG9mIGFuIG9iamVjdCwgb3Igc2l6ZSBvZiBhIE1hcCBvciBTZXRcbmNvdW50S2V5cyA9IGZ1bmN0aW9uIChvYmopIHtcbiAgaWYgKG9iaiBpbnN0YW5jZW9mIE1hcCB8fCBvYmogaW5zdGFuY2VvZiBTZXQpIHtcbiAgICByZXR1cm4gb2JqLnNpemU7XG4gIH1cblxuICByZXR1cm4gT2JqZWN0LmtleXMob2JqKS5sZW5ndGg7XG59XG5cbi8vIEl0ZXJhdGVzIG9iamVjdHMgYW5kIG1hcHMuXG4vLyBDYWxsYmFjayBpcyBjYWxsZWQgd2l0aCBhIHZhbHVlIGFuZCBrZXlcbml0ZXJhdGUgPSBmdW5jdGlvbiAob2JqLCBjYWxsYmFjaykge1xuICBpZiAob2JqIGluc3RhbmNlb2YgTWFwKSB7XG4gICAgcmV0dXJuIG9iai5mb3JFYWNoKGNhbGxiYWNrKTtcbiAgfVxuXG4gIGZvciAodmFyIGtleSBpbiBvYmopIHtcbiAgICB2YXIgdmFsdWUgPSBvYmpba2V5XTtcbiAgICBjYWxsYmFjayh2YWx1ZSwga2V5KTtcbiAgfVxufVxuXG4vLyBSZXR1cm5zIGEgcHJvcGVydHkgZnJvbSBhbiBvYmplY3QsIG9yIGFuIGVudHJ5IGZyb20gYSBtYXBcbmdldFByb3BlcnR5ID0gZnVuY3Rpb24gKG9iaiwga2V5KSB7XG4gIGlmIChvYmogaW5zdGFuY2VvZiBNYXApIHtcbiAgICByZXR1cm4gb2JqLmdldChrZXkpO1xuICB9XG5cbiAgcmV0dXJuIG9ialtrZXldO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlSGlzdG9ncmFtICgpIHtcbiAgcmV0dXJuIG5ldyBERFNrZXRjaCh7XG4gICAgYWxwaGE6IDAuMDJcbiAgfSk7XG59XG4iLCJ2YXIgbG9nZ2VyID0gZ2V0TG9nZ2VyKCk7XG5cbk50cCA9IGZ1bmN0aW9uIChlbmRwb2ludCkge1xuICB0aGlzLnBhdGggPSAnL3NpbXBsZW50cC9zeW5jJztcbiAgdGhpcy5zZXRFbmRwb2ludChlbmRwb2ludCk7XG4gIHRoaXMuZGlmZiA9IDA7XG4gIHRoaXMuc3luY2VkID0gZmFsc2U7XG4gIHRoaXMucmVTeW5jQ291bnQgPSAwO1xuICB0aGlzLnJlU3luYyA9IG5ldyBSZXRyeSh7XG4gICAgYmFzZVRpbWVvdXQ6IDEwMDAqNjAsXG4gICAgbWF4VGltZW91dDogMTAwMCo2MCoxMCxcbiAgICBtaW5Db3VudDogMFxuICB9KTtcbn1cblxuTnRwLl9ub3cgPSBmdW5jdGlvbigpIHtcbiAgdmFyIG5vdyA9IERhdGUubm93KCk7XG4gIGlmKHR5cGVvZiBub3cgPT0gJ251bWJlcicpIHtcbiAgICByZXR1cm4gbm93O1xuICB9IGVsc2UgaWYobm93IGluc3RhbmNlb2YgRGF0ZSkge1xuICAgIC8vIHNvbWUgZXh0ZW5hbCBKUyBsaWJyYXJpZXMgb3ZlcnJpZGUgRGF0ZS5ub3cgYW5kIHJldHVybnMgYSBEYXRlIG9iamVjdFxuICAgIC8vIHdoaWNoIGRpcmVjdGx5IGFmZmVjdCB1cy4gU28gd2UgbmVlZCB0byBwcmVwYXJlIGZvciB0aGF0XG4gICAgcmV0dXJuIG5vdy5nZXRUaW1lKCk7XG4gIH0gZWxzZSB7XG4gICAgLy8gdHJ1c3QgbWUuIEkndmUgc2VlbiBub3cgPT09IHVuZGVmaW5lZFxuICAgIHJldHVybiAobmV3IERhdGUoKSkuZ2V0VGltZSgpO1xuICB9XG59O1xuXG5OdHAucHJvdG90eXBlLnNldEVuZHBvaW50ID0gZnVuY3Rpb24oZW5kcG9pbnQpIHtcbiAgdGhpcy5lbmRwb2ludCA9IGVuZHBvaW50ID8gZW5kcG9pbnQgKyB0aGlzLnBhdGggOiBudWxsO1xufTtcblxuTnRwLnByb3RvdHlwZS5nZXRUaW1lID0gZnVuY3Rpb24oKSB7XG4gIHJldHVybiBOdHAuX25vdygpICsgTWF0aC5yb3VuZCh0aGlzLmRpZmYpO1xufTtcblxuTnRwLnByb3RvdHlwZS5zeW5jVGltZSA9IGZ1bmN0aW9uKGxvY2FsVGltZSkge1xuICByZXR1cm4gbG9jYWxUaW1lICsgTWF0aC5jZWlsKHRoaXMuZGlmZik7XG59O1xuXG5OdHAucHJvdG90eXBlLnN5bmMgPSBmdW5jdGlvbigpIHtcbiAgaWYgKHRoaXMuZW5kcG9pbnQgPT09IG51bGwpIHtcbiAgICByZXR1cm47XG4gIH1cblxuICBsb2dnZXIoJ2luaXQgc3luYycpO1xuICB2YXIgc2VsZiA9IHRoaXM7XG4gIHZhciByZXRyeUNvdW50ID0gMDtcbiAgdmFyIHJldHJ5ID0gbmV3IFJldHJ5KHtcbiAgICBiYXNlVGltZW91dDogMTAwMCoyMCxcbiAgICBtYXhUaW1lb3V0OiAxMDAwKjYwLFxuICAgIG1pbkNvdW50OiAxLFxuICAgIG1pblRpbWVvdXQ6IDBcbiAgfSk7XG4gIHN5bmNUaW1lKCk7XG5cbiAgZnVuY3Rpb24gc3luY1RpbWUgKCkge1xuICAgIGlmKHJldHJ5Q291bnQ8NSkge1xuICAgICAgbG9nZ2VyKCdhdHRlbXB0IHRpbWUgc3luYyB3aXRoIHNlcnZlcicsIHJldHJ5Q291bnQpO1xuICAgICAgLy8gaWYgd2Ugc2VuZCAwIHRvIHRoZSByZXRyeUxhdGVyLCBjYWNoZURucyB3aWxsIHJ1biBpbW1lZGlhdGVseVxuICAgICAgcmV0cnkucmV0cnlMYXRlcihyZXRyeUNvdW50KyssIGNhY2hlRG5zKTtcbiAgICB9IGVsc2Uge1xuICAgICAgbG9nZ2VyKCdtYXhpbXVtIHJldHJpZXMgcmVhY2hlZCcpO1xuICAgICAgc2VsZi5yZVN5bmMucmV0cnlMYXRlcihzZWxmLnJlU3luY0NvdW50KyssIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIGFyZ3MgPSBbXS5zbGljZS5jYWxsKGFyZ3VtZW50cyk7XG4gICAgICAgIHNlbGYuc3luYy5hcHBseShzZWxmLCBhcmdzKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuXG4gIC8vIGZpcnN0IGF0dGVtcHQgaXMgdG8gY2FjaGUgZG5zLiBTbywgY2FsY3VsYXRpb24gZG9lcyBub3RcbiAgLy8gaW5jbHVkZSBETlMgcmVzb2x1dGlvbiB0aW1lXG4gIGZ1bmN0aW9uIGNhY2hlRG5zICgpIHtcbiAgICBzZWxmLmdldFNlcnZlclRpbWUoZnVuY3Rpb24oZXJyKSB7XG4gICAgICBpZighZXJyKSB7XG4gICAgICAgIGNhbGN1bGF0ZVRpbWVEaWZmKCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzeW5jVGltZSgpO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG5cbiAgZnVuY3Rpb24gY2FsY3VsYXRlVGltZURpZmYgKCkge1xuICAgIHZhciBjbGllbnRTdGFydFRpbWUgPSAobmV3IERhdGUoKSkuZ2V0VGltZSgpO1xuICAgIHNlbGYuZ2V0U2VydmVyVGltZShmdW5jdGlvbihlcnIsIHNlcnZlclRpbWUpIHtcbiAgICAgIGlmKCFlcnIgJiYgc2VydmVyVGltZSkge1xuICAgICAgICAvLyAoRGF0ZS5ub3coKSArIGNsaWVudFN0YXJ0VGltZSkvMiA6IE1pZHBvaW50IGJldHdlZW4gcmVxIGFuZCByZXNcbiAgICAgICAgdmFyIG5ldHdvcmtUaW1lID0gKChuZXcgRGF0ZSgpKS5nZXRUaW1lKCkgLSBjbGllbnRTdGFydFRpbWUpLzJcbiAgICAgICAgdmFyIHNlcnZlclN0YXJ0VGltZSA9IHNlcnZlclRpbWUgLSBuZXR3b3JrVGltZTtcbiAgICAgICAgc2VsZi5kaWZmID0gc2VydmVyU3RhcnRUaW1lIC0gY2xpZW50U3RhcnRUaW1lO1xuICAgICAgICBzZWxmLnN5bmNlZCA9IHRydWU7XG4gICAgICAgIC8vIHdlIG5lZWQgdG8gc2VuZCAxIGludG8gcmV0cnlMYXRlci5cbiAgICAgICAgc2VsZi5yZVN5bmMucmV0cnlMYXRlcihzZWxmLnJlU3luY0NvdW50KyssIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICB2YXIgYXJncyA9IFtdLnNsaWNlLmNhbGwoYXJndW1lbnRzKTtcbiAgICAgICAgICBzZWxmLnN5bmMuYXBwbHkoc2VsZiwgYXJncyk7XG4gICAgICAgIH0pO1xuICAgICAgICBsb2dnZXIoJ3N1Y2Nlc3NmdWxseSB1cGRhdGVkIGRpZmYgdmFsdWUnLCBzZWxmLmRpZmYpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc3luY1RpbWUoKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxufVxuXG5OdHAucHJvdG90eXBlLmdldFNlcnZlclRpbWUgPSBmdW5jdGlvbihjYWxsYmFjaykge1xuICB2YXIgc2VsZiA9IHRoaXM7XG5cbiAgaWYgKHNlbGYuZW5kcG9pbnQgPT09IG51bGwpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ2dldFNlcnZlclRpbWUgcmVxdWlyZXMgdGhlIGVuZHBvaW50IHRvIGJlIHNldCcpO1xuICB9XG5cbiAgaWYoTWV0ZW9yLmlzU2VydmVyKSB7XG4gICAgS2FkaXJhLmNvcmVBcGkuZ2V0KHNlbGYucGF0aCwgeyBub1JldHJpZXM6IHRydWUgfSkudGhlbihjb250ZW50ID0+IHtcbiAgICAgIHZhciBzZXJ2ZXJUaW1lID0gcGFyc2VJbnQoY29udGVudCk7XG4gICAgICBjYWxsYmFjayhudWxsLCBzZXJ2ZXJUaW1lKTtcbiAgICB9KVxuICAgIC5jYXRjaChlcnIgPT4ge1xuICAgICAgY2FsbGJhY2soZXJyKTtcbiAgICB9KTtcbiAgfSBlbHNlIHtcbiAgICBodHRwUmVxdWVzdCgnR0VUJywgc2VsZi5lbmRwb2ludCArIGA/bm9DYWNoZT0ke25ldyBEYXRlKCkuZ2V0VGltZSgpfS0ke01hdGgucmFuZG9tKCl9YCwgZnVuY3Rpb24oZXJyLCByZXMpIHtcbiAgICAgIGlmIChlcnIpIHtcbiAgICAgICAgY2FsbGJhY2soZXJyKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHZhciBzZXJ2ZXJUaW1lID0gcGFyc2VJbnQocmVzLmNvbnRlbnQpO1xuICAgICAgICBjYWxsYmFjayhudWxsLCBzZXJ2ZXJUaW1lKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxufTtcblxuZnVuY3Rpb24gZ2V0TG9nZ2VyKCkge1xuICBpZihNZXRlb3IuaXNTZXJ2ZXIpIHtcbiAgICByZXR1cm4gTnBtLnJlcXVpcmUoJ2RlYnVnJykoXCJrYWRpcmE6bnRwXCIpO1xuICB9IGVsc2Uge1xuICAgIHJldHVybiBmdW5jdGlvbihtZXNzYWdlKSB7XG4gICAgICB2YXIgY2FuTG9nS2FkaXJhID1cbiAgICAgICAgTWV0ZW9yLl9sb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnTE9HX0tBRElSQScpICE9PSBudWxsXG4gICAgICAgICYmIHR5cGVvZiBjb25zb2xlICE9PSAndW5kZWZpbmVkJztcblxuICAgICAgaWYoY2FuTG9nS2FkaXJhKSB7XG4gICAgICAgIGlmKG1lc3NhZ2UpIHtcbiAgICAgICAgICBtZXNzYWdlID0gXCJrYWRpcmE6bnRwIFwiICsgbWVzc2FnZTtcbiAgICAgICAgICBhcmd1bWVudHNbMF0gPSBtZXNzYWdlO1xuICAgICAgICB9XG4gICAgICAgIGNvbnNvbGUubG9nLmFwcGx5KGNvbnNvbGUsIGFyZ3VtZW50cyk7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG4iLCJ2YXIgdXJsID0gTnBtLnJlcXVpcmUoJ3VybCcpO1xudmFyIHBhdGggPSBOcG0ucmVxdWlyZSgncGF0aCcpO1xudmFyIGZzID0gTnBtLnJlcXVpcmUoJ2ZzJyk7XG52YXIgbG9nZ2VyID0gTnBtLnJlcXVpcmUoJ2RlYnVnJykoJ2thZGlyYTphcG06c291cmNlbWFwcycpO1xuXG4vLyBNZXRlb3IgMS43IGFuZCBvbGRlciB1c2VkIGNsaWVudFBhdGhzXG52YXIgY2xpZW50UGF0aHMgPSBfX21ldGVvcl9ib290c3RyYXBfXy5jb25maWdKc29uLmNsaWVudFBhdGhzO1xudmFyIGNsaWVudEFyY2hzID0gIF9fbWV0ZW9yX2Jvb3RzdHJhcF9fLmNvbmZpZ0pzb24uY2xpZW50QXJjaHM7XG52YXIgc2VydmVyRGlyID0gX19tZXRlb3JfYm9vdHN0cmFwX18uc2VydmVyRGlyO1xudmFyIGFic0NsaWVudFBhdGhzXG5cbmlmIChjbGllbnRBcmNocykge1xuICBhYnNDbGllbnRQYXRocyA9IGNsaWVudEFyY2hzLnJlZHVjZSgocmVzdWx0LCBhcmNoKSA9PiB7XG4gICAgcmVzdWx0W2FyY2hdID0gcGF0aC5yZXNvbHZlKHBhdGguZGlybmFtZShzZXJ2ZXJEaXIpLCBhcmNoKVxuXG4gICAgcmV0dXJuIHJlc3VsdFxuICB9LCB7fSlcbn0gZWxzZSB7XG4gIGFic0NsaWVudFBhdGhzID0gT2JqZWN0LmtleXMoY2xpZW50UGF0aHMpLnJlZHVjZSgocmVzdWx0LCBrZXkpID0+IHtcbiAgICByZXN1bHRba2V5XSA9IHBhdGgucmVzb2x2ZShzZXJ2ZXJEaXIsIHBhdGguZGlybmFtZShjbGllbnRQYXRoc1trZXldKSk7XG5cbiAgICByZXR1cm4gcmVzdWx0O1xuICB9LCB7fSk7XG59XG5cbmhhbmRsZUFwaVJlc3BvbnNlID0gZnVuY3Rpb24gKGJvZHkgPSB7fSkge1xuICB2YXIgdW5hdmFpbGFibGUgPSBbXTtcblxuICBpZiAodHlwZW9mIGJvZHkgPT09ICdzdHJpbmcnKSB7XG4gICAgdHJ5IHtcbiAgICAgIGJvZHkgPSBKU09OLnBhcnNlKGJvZHkpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGxvZ2dlcignZmFpbGVkIHBhcnNpbmcgYm9keScsIGUsIGJvZHkpXG4gICAgICByZXR1cm47XG4gICAgfVxuICB9XG5cbiAgdmFyIG5lZWRlZFNvdXJjZW1hcHMgPSBib2R5Lm5lZWRlZFNvdXJjZW1hcHMgfHwgW11cbiAgbG9nZ2VyKCdib2R5JywgbmVlZGVkU291cmNlbWFwcylcblxuICB2YXIgcHJvbWlzZXMgPSBuZWVkZWRTb3VyY2VtYXBzLm1hcCgoc291cmNlbWFwKSA9PiB7XG4gICAgaWYgKCFLYWRpcmEub3B0aW9ucy51cGxvYWRTb3VyY2VNYXBzKSB7XG4gICAgICByZXR1cm4gdW5hdmFpbGFibGUucHVzaChzb3VyY2VtYXApXG4gICAgfVxuXG4gICAgcmV0dXJuIGdldFNvdXJjZW1hcFBhdGgoc291cmNlbWFwLmFyY2gsIHNvdXJjZW1hcC5maWxlLnBhdGgpXG4gICAgICAudGhlbihmdW5jdGlvbiAoc291cmNlTWFwUGF0aCkge1xuICAgICAgICBpZiAoc291cmNlTWFwUGF0aCA9PT0gbnVsbCkge1xuICAgICAgICAgIHVuYXZhaWxhYmxlLnB1c2goc291cmNlbWFwKVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHNlbmRTb3VyY2VtYXAoc291cmNlbWFwLCBzb3VyY2VNYXBQYXRoKVxuICAgICAgICB9XG4gICAgICB9KVxuICB9KVxuXG4gIFByb21pc2UuYWxsKHByb21pc2VzKS50aGVuKGZ1bmN0aW9uICgpIHtcbiAgICBpZiAodW5hdmFpbGFibGUubGVuZ3RoID4gMCkge1xuICAgICAgbG9nZ2VyKCdzZW5kaW5nIHVuYXZhaWxhYmxlIHNvdXJjZW1hcHMnLCB1bmF2YWlsYWJsZSlcbiAgICAgIEthZGlyYS5jb3JlQXBpLnNlbmREYXRhKHtcbiAgICAgICAgdW5hdmFpbGFibGVTb3VyY2VtYXBzOiB1bmF2YWlsYWJsZVxuICAgICAgfSlcbiAgICAgIC50aGVuKGZ1bmN0aW9uIChib2R5KSB7XG4gICAgICAgIGhhbmRsZUFwaVJlc3BvbnNlKGJvZHkpO1xuICAgICAgfSlcbiAgICAgIC5jYXRjaChmdW5jdGlvbiAoZXJyKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKCdNb250aSBBUE06IHVuYWJsZSB0byBzZW5kIGRhdGEnLCBlcnIpO1xuICAgICAgfSk7XG4gICAgfVxuICB9KVxuXG59XG5cbmZ1bmN0aW9uIHNlbmRTb3VyY2VtYXAoc291cmNlbWFwLCBzb3VyY2VtYXBQYXRoKSB7XG4gIGxvZ2dlcignU2VuZGluZyBzb3VyY2VtYXAnLCBzb3VyY2VtYXAsIHNvdXJjZW1hcFBhdGgpXG5cbiAgdmFyIHN0cmVhbSA9IGZzLmNyZWF0ZVJlYWRTdHJlYW0oc291cmNlbWFwUGF0aCk7XG5cbiAgc3RyZWFtLm9uKCdlcnJvcicsIChlcnIpID0+IHtcbiAgICBjb25zb2xlLmxvZygnTW9udGkgQVBNOiBlcnJvciB3aGlsZSB1cGxvYWRpbmcgc291cmNlbWFwJywgZXJyKVxuICB9KTtcblxuICB2YXIgYXJjaCA9IHNvdXJjZW1hcC5hcmNoO1xuICB2YXIgYXJjaFZlcnNpb24gPSBzb3VyY2VtYXAuYXJjaFZlcnNpb247XG4gIHZhciBmaWxlID0gZW5jb2RlVVJJQ29tcG9uZW50KHNvdXJjZW1hcC5maWxlLnBhdGgpO1xuICBcbiAgS2FkaXJhLmNvcmVBcGkuc2VuZFN0cmVhbShgL3NvdXJjZW1hcD9hcmNoPSR7YXJjaH0mYXJjaFZlcnNpb249JHthcmNoVmVyc2lvbn0mZmlsZT0ke2ZpbGV9YCwgc3RyZWFtKVxuICAgIC5jYXRjaChmdW5jdGlvbiAoZXJyKSB7XG4gICAgICBjb25zb2xlLmxvZygnTW9udGkgQVBNOiBlcnJvciB1cGxvYWRpbmcgc291cmNlbWFwJywgZXJyKTtcbiAgICB9KTtcbn1cblxuZnVuY3Rpb24gcHJlcGFyZVBhdGggKHVybFBhdGgpIHtcbiAgdXJsUGF0aCA9IHBhdGgucG9zaXgubm9ybWFsaXplKHVybFBhdGgpO1xuXG4gIGlmICh1cmxQYXRoWzBdID09PSAnLycpIHtcbiAgICB1cmxQYXRoID0gdXJsUGF0aC5zbGljZSgxKTtcbiAgfVxuXG4gIHJldHVybiB1cmxQYXRoO1xufVxuXG5mdW5jdGlvbiBjaGVja0ZvckR5bmFtaWNJbXBvcnQgKGFyY2gsIHVybFBhdGgpIHtcbiAgY29uc3QgZmlsZVBhdGggPSBwcmVwYXJlUGF0aCh1cmxQYXRoKTtcblxuICByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUpIHtcbiAgICBjb25zdCBhcmNoUGF0aCA9IGFic0NsaWVudFBhdGhzW2FyY2hdXG4gICAgY29uc3QgZHluYW1pY1BhdGggPSBwYXRoLmpvaW4oYXJjaFBhdGgsICdkeW5hbWljJywgZmlsZVBhdGgpICsgJy5tYXAnXG5cbiAgICBmcy5zdGF0KGR5bmFtaWNQYXRoLCBmdW5jdGlvbiAoZXJyKSB7XG4gICAgICByZXNvbHZlKGVyciA/IG51bGwgOiBkeW5hbWljUGF0aCk7XG4gICAgfSk7XG4gIH0pO1xufVxuXG5mdW5jdGlvbiBnZXRTb3VyY2VtYXBQYXRoKGFyY2gsIHVybFBhdGgpIHtcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICB2YXIgY2xpZW50UHJvZ3JhbSA9IFdlYkFwcC5jbGllbnRQcm9ncmFtc1thcmNoXTtcbiAgXG4gICAgaWYgKCFjbGllbnRQcm9ncmFtIHx8ICFjbGllbnRQcm9ncmFtLm1hbmlmZXN0KSB7XG4gICAgICByZXR1cm4gcmVzb2x2ZShudWxsKTtcbiAgICB9XG5cbiAgICB2YXIgZmlsZUluZm8gPSBjbGllbnRQcm9ncmFtLm1hbmlmZXN0LmZpbmQoKGZpbGUpID0+IHtcbiAgICAgIHJldHVybiBmaWxlLnVybCAmJiBmaWxlLnVybC5zdGFydHNXaXRoKHVybFBhdGgpO1xuICAgIH0pO1xuXG4gICAgaWYgKGZpbGVJbmZvICYmIGZpbGVJbmZvLnNvdXJjZU1hcCkge1xuICAgICAgcmV0dXJuIHJlc29sdmUocGF0aC5qb2luKFxuICAgICAgICBhYnNDbGllbnRQYXRoc1thcmNoXSxcbiAgICAgICAgZmlsZUluZm8uc291cmNlTWFwXG4gICAgICApKTtcbiAgICB9XG5cbiAgICBjaGVja0ZvckR5bmFtaWNJbXBvcnQoYXJjaCwgdXJsUGF0aCkudGhlbihyZXNvbHZlKS5jYXRjaChyZWplY3QpXG4gIH0pO1xufVxuIiwidmFyIFdBSVRPTl9NRVNTQUdFX0ZJRUxEUyA9IFsnbXNnJywgJ2lkJywgJ21ldGhvZCcsICduYW1lJywgJ3dhaXRUaW1lJ107XG5cbi8vIFRoaXMgaXMgd2F5IGhvdyB3ZSBjYW4gYnVpbGQgd2FpdFRpbWUgYW5kIGl0J3MgYnJlYWtkb3duXG5XYWl0VGltZUJ1aWxkZXIgPSBmdW5jdGlvbigpIHtcbiAgdGhpcy5fd2FpdExpc3RTdG9yZSA9IHt9O1xuICB0aGlzLl9jdXJyZW50UHJvY2Vzc2luZ01lc3NhZ2VzID0ge307XG4gIHRoaXMuX21lc3NhZ2VDYWNoZSA9IHt9O1xufTtcblxuV2FpdFRpbWVCdWlsZGVyLnByb3RvdHlwZS5yZWdpc3RlciA9IGZ1bmN0aW9uKHNlc3Npb24sIG1zZ0lkKSB7XG4gIHZhciBzZWxmID0gdGhpcztcbiAgdmFyIG1haW5LZXkgPSBzZWxmLl9nZXRNZXNzYWdlS2V5KHNlc3Npb24uaWQsIG1zZ0lkKTtcblxuICB2YXIgaW5RdWV1ZSA9IHNlc3Npb24uaW5RdWV1ZSB8fCBbXTtcbiAgaWYodHlwZW9mIGluUXVldWUudG9BcnJheSA9PT0gJ2Z1bmN0aW9uJykge1xuICAgIC8vIGxhdGVzdCB2ZXJzaW9uIG9mIE1ldGVvciB1c2VzIGEgZG91YmxlLWVuZGVkLXF1ZXVlIGZvciB0aGUgaW5RdWV1ZVxuICAgIC8vIGluZm86IGh0dHBzOi8vd3d3Lm5wbWpzLmNvbS9wYWNrYWdlL2RvdWJsZS1lbmRlZC1xdWV1ZVxuICAgIGluUXVldWUgPSBpblF1ZXVlLnRvQXJyYXkoKTtcbiAgfVxuXG4gIHZhciB3YWl0TGlzdCA9IGluUXVldWUubWFwKGZ1bmN0aW9uKG1zZykge1xuICAgIHZhciBrZXkgPSBzZWxmLl9nZXRNZXNzYWdlS2V5KHNlc3Npb24uaWQsIG1zZy5pZCk7XG4gICAgcmV0dXJuIHNlbGYuX2dldENhY2hlTWVzc2FnZShrZXksIG1zZyk7XG4gIH0pO1xuXG4gIHdhaXRMaXN0ID0gd2FpdExpc3QgfHwgW107XG5cbiAgLy9hZGQgY3VycmVudGx5IHByb2Nlc3NpbmcgZGRwIG1lc3NhZ2UgaWYgZXhpc3RzXG4gIHZhciBjdXJyZW50bHlQcm9jZXNzaW5nTWVzc2FnZSA9IHRoaXMuX2N1cnJlbnRQcm9jZXNzaW5nTWVzc2FnZXNbc2Vzc2lvbi5pZF07XG4gIGlmKGN1cnJlbnRseVByb2Nlc3NpbmdNZXNzYWdlKSB7XG4gICAgdmFyIGtleSA9IHNlbGYuX2dldE1lc3NhZ2VLZXkoc2Vzc2lvbi5pZCwgY3VycmVudGx5UHJvY2Vzc2luZ01lc3NhZ2UuaWQpO1xuICAgIHdhaXRMaXN0LnVuc2hpZnQodGhpcy5fZ2V0Q2FjaGVNZXNzYWdlKGtleSwgY3VycmVudGx5UHJvY2Vzc2luZ01lc3NhZ2UpKTtcbiAgfVxuXG4gIHRoaXMuX3dhaXRMaXN0U3RvcmVbbWFpbktleV0gPSB3YWl0TGlzdDtcbn07XG5cbldhaXRUaW1lQnVpbGRlci5wcm90b3R5cGUuYnVpbGQgPSBmdW5jdGlvbihzZXNzaW9uLCBtc2dJZCkge1xuICB2YXIgbWFpbktleSA9IHRoaXMuX2dldE1lc3NhZ2VLZXkoc2Vzc2lvbi5pZCwgbXNnSWQpO1xuICB2YXIgd2FpdExpc3QgPSB0aGlzLl93YWl0TGlzdFN0b3JlW21haW5LZXldIHx8IFtdO1xuICBkZWxldGUgdGhpcy5fd2FpdExpc3RTdG9yZVttYWluS2V5XTtcblxuICB2YXIgZmlsdGVyZWRXYWl0TGlzdCA9ICB3YWl0TGlzdC5tYXAodGhpcy5fY2xlYW5DYWNoZU1lc3NhZ2UuYmluZCh0aGlzKSk7XG4gIHJldHVybiBmaWx0ZXJlZFdhaXRMaXN0O1xufTtcblxuV2FpdFRpbWVCdWlsZGVyLnByb3RvdHlwZS5fZ2V0TWVzc2FnZUtleSA9IGZ1bmN0aW9uKHNlc3Npb25JZCwgbXNnSWQpIHtcbiAgcmV0dXJuIHNlc3Npb25JZCArIFwiOjpcIiArIG1zZ0lkO1xufTtcblxuV2FpdFRpbWVCdWlsZGVyLnByb3RvdHlwZS5fZ2V0Q2FjaGVNZXNzYWdlID0gZnVuY3Rpb24oa2V5LCBtc2cpIHtcbiAgdmFyIHNlbGYgPSB0aGlzO1xuICB2YXIgY2FjaGVkTWVzc2FnZSA9IHNlbGYuX21lc3NhZ2VDYWNoZVtrZXldO1xuICBpZighY2FjaGVkTWVzc2FnZSkge1xuICAgIHNlbGYuX21lc3NhZ2VDYWNoZVtrZXldID0gY2FjaGVkTWVzc2FnZSA9IF8ucGljayhtc2csIFdBSVRPTl9NRVNTQUdFX0ZJRUxEUyk7XG4gICAgY2FjaGVkTWVzc2FnZS5fa2V5ID0ga2V5O1xuICAgIGNhY2hlZE1lc3NhZ2UuX3JlZ2lzdGVyZWQgPSAxO1xuICB9IGVsc2Uge1xuICAgIGNhY2hlZE1lc3NhZ2UuX3JlZ2lzdGVyZWQrKztcbiAgfVxuXG4gIHJldHVybiBjYWNoZWRNZXNzYWdlO1xufTtcblxuV2FpdFRpbWVCdWlsZGVyLnByb3RvdHlwZS5fY2xlYW5DYWNoZU1lc3NhZ2UgPSBmdW5jdGlvbihtc2cpIHtcbiAgbXNnLl9yZWdpc3RlcmVkLS07XG4gIGlmKG1zZy5fcmVnaXN0ZXJlZCA9PSAwKSB7XG4gICAgZGVsZXRlIHRoaXMuX21lc3NhZ2VDYWNoZVttc2cuX2tleV07XG4gIH1cblxuICAvLyBuZWVkIHRvIHNlbmQgYSBjbGVhbiBzZXQgb2Ygb2JqZWN0c1xuICAvLyBvdGhlcndpc2UgcmVnaXN0ZXIgY2FuIGdvIHdpdGggdGhpc1xuICByZXR1cm4gXy5waWNrKG1zZywgV0FJVE9OX01FU1NBR0VfRklFTERTKTtcbn07XG5cbldhaXRUaW1lQnVpbGRlci5wcm90b3R5cGUudHJhY2tXYWl0VGltZSA9IGZ1bmN0aW9uKHNlc3Npb24sIG1zZywgdW5ibG9jaykge1xuICB2YXIgc2VsZiA9IHRoaXM7XG4gIHZhciBzdGFydGVkID0gRGF0ZS5ub3coKTtcbiAgc2VsZi5fY3VycmVudFByb2Nlc3NpbmdNZXNzYWdlc1tzZXNzaW9uLmlkXSA9IG1zZztcblxuICB2YXIgdW5ibG9ja2VkID0gZmFsc2U7XG4gIHZhciB3cmFwcGVkVW5ibG9jayA9IGZ1bmN0aW9uKCkge1xuICAgIGlmKCF1bmJsb2NrZWQpIHtcbiAgICAgIHZhciB3YWl0VGltZSA9IERhdGUubm93KCkgLSBzdGFydGVkO1xuICAgICAgdmFyIGtleSA9IHNlbGYuX2dldE1lc3NhZ2VLZXkoc2Vzc2lvbi5pZCwgbXNnLmlkKTtcbiAgICAgIHZhciBjYWNoZWRNZXNzYWdlID0gc2VsZi5fbWVzc2FnZUNhY2hlW2tleV07XG4gICAgICBpZihjYWNoZWRNZXNzYWdlKSB7XG4gICAgICAgIGNhY2hlZE1lc3NhZ2Uud2FpdFRpbWUgPSB3YWl0VGltZTtcbiAgICAgIH1cbiAgICAgIGRlbGV0ZSBzZWxmLl9jdXJyZW50UHJvY2Vzc2luZ01lc3NhZ2VzW3Nlc3Npb24uaWRdO1xuICAgICAgdW5ibG9ja2VkID0gdHJ1ZTtcbiAgICAgIHVuYmxvY2soKTtcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIHdyYXBwZWRVbmJsb2NrO1xufTsiLCIvLyBleHBvc2UgZm9yIHRlc3RpbmcgcHVycG9zZVxuT3Bsb2dDaGVjayA9IHt9O1xuXG5PcGxvZ0NoZWNrLl8wNzAgPSBmdW5jdGlvbihjdXJzb3JEZXNjcmlwdGlvbikge1xuICB2YXIgb3B0aW9ucyA9IGN1cnNvckRlc2NyaXB0aW9uLm9wdGlvbnM7XG4gIGlmIChvcHRpb25zLmxpbWl0KSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGNvZGU6IFwiMDcwX0xJTUlUX05PVF9TVVBQT1JURURcIixcbiAgICAgIHJlYXNvbjogXCJNZXRlb3IgMC43LjAgZG9lcyBub3Qgc3VwcG9ydCBsaW1pdCB3aXRoIG9wbG9nLlwiLFxuICAgICAgc29sdXRpb246IFwiVXBncmFkZSB5b3VyIGFwcCB0byBNZXRlb3IgdmVyc2lvbiAwLjcuMiBvciBsYXRlci5cIlxuICAgIH1cbiAgfTtcblxuICB2YXIgZXhpc3RzJCA9IF8uYW55KGN1cnNvckRlc2NyaXB0aW9uLnNlbGVjdG9yLCBmdW5jdGlvbiAodmFsdWUsIGZpZWxkKSB7XG4gICAgaWYgKGZpZWxkLnN1YnN0cigwLCAxKSA9PT0gJyQnKVxuICAgICAgcmV0dXJuIHRydWU7XG4gIH0pO1xuXG4gIGlmKGV4aXN0cyQpIHtcbiAgICByZXR1cm4ge1xuICAgICAgY29kZTogXCIwNzBfJF9OT1RfU1VQUE9SVEVEXCIsXG4gICAgICByZWFzb246IFwiTWV0ZW9yIDAuNy4wIHN1cHBvcnRzIG9ubHkgZXF1YWwgY2hlY2tzIHdpdGggb3Bsb2cuXCIsXG4gICAgICBzb2x1dGlvbjogXCJVcGdyYWRlIHlvdXIgYXBwIHRvIE1ldGVvciB2ZXJzaW9uIDAuNy4yIG9yIGxhdGVyLlwiXG4gICAgfVxuICB9O1xuXG4gIHZhciBvbmx5U2NhbGVycyA9IF8uYWxsKGN1cnNvckRlc2NyaXB0aW9uLnNlbGVjdG9yLCBmdW5jdGlvbiAodmFsdWUsIGZpZWxkKSB7XG4gICAgcmV0dXJuIHR5cGVvZiB2YWx1ZSA9PT0gXCJzdHJpbmdcIiB8fFxuICAgICAgdHlwZW9mIHZhbHVlID09PSBcIm51bWJlclwiIHx8XG4gICAgICB0eXBlb2YgdmFsdWUgPT09IFwiYm9vbGVhblwiIHx8XG4gICAgICB2YWx1ZSA9PT0gbnVsbCB8fFxuICAgICAgdmFsdWUgaW5zdGFuY2VvZiBNZXRlb3IuQ29sbGVjdGlvbi5PYmplY3RJRDtcbiAgfSk7XG5cbiAgaWYoIW9ubHlTY2FsZXJzKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGNvZGU6IFwiMDcwX09OTFlfU0NBTEVSU1wiLFxuICAgICAgcmVhc29uOiBcIk1ldGVvciAwLjcuMCBvbmx5IHN1cHBvcnRzIHNjYWxlcnMgYXMgY29tcGFyYXRvcnMuXCIsXG4gICAgICBzb2x1dGlvbjogXCJVcGdyYWRlIHlvdXIgYXBwIHRvIE1ldGVvciB2ZXJzaW9uIDAuNy4yIG9yIGxhdGVyLlwiXG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIHRydWU7XG59O1xuXG5PcGxvZ0NoZWNrLl8wNzEgPSBmdW5jdGlvbihjdXJzb3JEZXNjcmlwdGlvbikge1xuICB2YXIgb3B0aW9ucyA9IGN1cnNvckRlc2NyaXB0aW9uLm9wdGlvbnM7XG4gIHZhciBtYXRjaGVyID0gbmV3IE1pbmltb25nby5NYXRjaGVyKGN1cnNvckRlc2NyaXB0aW9uLnNlbGVjdG9yKTtcbiAgaWYgKG9wdGlvbnMubGltaXQpIHtcbiAgICByZXR1cm4ge1xuICAgICAgY29kZTogXCIwNzFfTElNSVRfTk9UX1NVUFBPUlRFRFwiLFxuICAgICAgcmVhc29uOiBcIk1ldGVvciAwLjcuMSBkb2VzIG5vdCBzdXBwb3J0IGxpbWl0IHdpdGggb3Bsb2cuXCIsXG4gICAgICBzb2x1dGlvbjogXCJVcGdyYWRlIHlvdXIgYXBwIHRvIE1ldGVvciB2ZXJzaW9uIDAuNy4yIG9yIGxhdGVyLlwiXG4gICAgfVxuICB9O1xuXG4gIHJldHVybiB0cnVlO1xufTtcblxuXG5PcGxvZ0NoZWNrLmVudiA9IGZ1bmN0aW9uKCkge1xuICBpZighcHJvY2Vzcy5lbnYuTU9OR09fT1BMT0dfVVJMKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGNvZGU6IFwiTk9fRU5WXCIsXG4gICAgICByZWFzb246IFwiWW91IGhhdmVuJ3QgYWRkZWQgb3Bsb2cgc3VwcG9ydCBmb3IgeW91ciB0aGUgTWV0ZW9yIGFwcC5cIixcbiAgICAgIHNvbHV0aW9uOiBcIkFkZCBvcGxvZyBzdXBwb3J0IGZvciB5b3VyIE1ldGVvciBhcHAuIHNlZTogaHR0cDovL2dvby5nbC9DbzFqSmNcIlxuICAgIH1cbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxufTtcblxuT3Bsb2dDaGVjay5kaXNhYmxlT3Bsb2cgPSBmdW5jdGlvbihjdXJzb3JEZXNjcmlwdGlvbikge1xuICBpZihjdXJzb3JEZXNjcmlwdGlvbi5vcHRpb25zLl9kaXNhYmxlT3Bsb2cpIHtcbiAgICByZXR1cm4ge1xuICAgICAgY29kZTogXCJESVNBQkxFX09QTE9HXCIsXG4gICAgICByZWFzb246IFwiWW91J3ZlIGRpc2FibGUgb3Bsb2cgZm9yIHRoaXMgY3Vyc29yIGV4cGxpY2l0bHkgd2l0aCBfZGlzYWJsZU9wbG9nIG9wdGlvbi5cIlxuICAgIH07XG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbn07XG5cbi8vIHdoZW4gY3JlYXRpbmcgTWluaW1vbmdvLk1hdGNoZXIgb2JqZWN0LCBpZiB0aGF0J3MgdGhyb3dzIGFuIGV4Y2VwdGlvblxuLy8gbWV0ZW9yIHdvbid0IGRvIHRoZSBvcGxvZyBzdXBwb3J0XG5PcGxvZ0NoZWNrLm1pbmlNb25nb01hdGNoZXIgPSBmdW5jdGlvbihjdXJzb3JEZXNjcmlwdGlvbikge1xuICBpZihNaW5pbW9uZ28uTWF0Y2hlcikge1xuICAgIHRyeSB7XG4gICAgICB2YXIgbWF0Y2hlciA9IG5ldyBNaW5pbW9uZ28uTWF0Y2hlcihjdXJzb3JEZXNjcmlwdGlvbi5zZWxlY3Rvcik7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9IGNhdGNoKGV4KSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBjb2RlOiBcIk1JTklNT05HT19NQVRDSEVSX0VSUk9SXCIsXG4gICAgICAgIHJlYXNvbjogXCJUaGVyZSdzIHNvbWV0aGluZyB3cm9uZyBpbiB5b3VyIG1vbmdvIHF1ZXJ5OiBcIiArICBleC5tZXNzYWdlLFxuICAgICAgICBzb2x1dGlvbjogXCJDaGVjayB5b3VyIHNlbGVjdG9yIGFuZCBjaGFuZ2UgaXQgYWNjb3JkaW5nbHkuXCJcbiAgICAgIH07XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIC8vIElmIHRoZXJlIGlzIG5vIE1pbmltb25nby5NYXRjaGVyLCB3ZSBkb24ndCBuZWVkIHRvIGNoZWNrIHRoaXNcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxufTtcblxuT3Bsb2dDaGVjay5taW5pTW9uZ29Tb3J0ZXIgPSBmdW5jdGlvbihjdXJzb3JEZXNjcmlwdGlvbikge1xuICB2YXIgbWF0Y2hlciA9IG5ldyBNaW5pbW9uZ28uTWF0Y2hlcihjdXJzb3JEZXNjcmlwdGlvbi5zZWxlY3Rvcik7XG4gIGlmKE1pbmltb25nby5Tb3J0ZXIgJiYgY3Vyc29yRGVzY3JpcHRpb24ub3B0aW9ucy5zb3J0KSB7XG4gICAgdHJ5IHtcbiAgICAgIHZhciBzb3J0ZXIgPSBuZXcgTWluaW1vbmdvLlNvcnRlcihcbiAgICAgICAgY3Vyc29yRGVzY3JpcHRpb24ub3B0aW9ucy5zb3J0LFxuICAgICAgICB7IG1hdGNoZXI6IG1hdGNoZXIgfVxuICAgICAgKTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH0gY2F0Y2goZXgpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGNvZGU6IFwiTUlOSU1PTkdPX1NPUlRFUl9FUlJPUlwiLFxuICAgICAgICByZWFzb246IFwiU29tZSBvZiB5b3VyIHNvcnQgc3BlY2lmaWVycyBhcmUgbm90IHN1cHBvcnRlZDogXCIgKyBleC5tZXNzYWdlLFxuICAgICAgICBzb2x1dGlvbjogXCJDaGVjayB5b3VyIHNvcnQgc3BlY2lmaWVycyBhbmQgY2hhZ2UgdGhlbSBhY2NvcmRpbmdseS5cIlxuICAgICAgfVxuICAgIH1cbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxufTtcblxuT3Bsb2dDaGVjay5maWVsZHMgPSBmdW5jdGlvbihjdXJzb3JEZXNjcmlwdGlvbikge1xuICB2YXIgb3B0aW9ucyA9IGN1cnNvckRlc2NyaXB0aW9uLm9wdGlvbnM7XG4gIGlmKG9wdGlvbnMuZmllbGRzKSB7XG4gICAgdHJ5IHtcbiAgICAgIExvY2FsQ29sbGVjdGlvbi5fY2hlY2tTdXBwb3J0ZWRQcm9qZWN0aW9uKG9wdGlvbnMuZmllbGRzKTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGlmIChlLm5hbWUgPT09IFwiTWluaW1vbmdvRXJyb3JcIikge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIGNvZGU6IFwiTk9UX1NVUFBPUlRFRF9GSUVMRFNcIixcbiAgICAgICAgICByZWFzb246IFwiU29tZSBvZiB0aGUgZmllbGQgZmlsdGVycyBhcmUgbm90IHN1cHBvcnRlZDogXCIgKyBlLm1lc3NhZ2UsXG4gICAgICAgICAgc29sdXRpb246IFwiVHJ5IHJlbW92aW5nIHRob3NlIGZpZWxkIGZpbHRlcnMuXCJcbiAgICAgICAgfTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRocm93IGU7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIHJldHVybiB0cnVlO1xufTtcblxuT3Bsb2dDaGVjay5za2lwID0gZnVuY3Rpb24oY3Vyc29yRGVzY3JpcHRpb24pIHtcbiAgaWYoY3Vyc29yRGVzY3JpcHRpb24ub3B0aW9ucy5za2lwKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGNvZGU6IFwiU0tJUF9OT1RfU1VQUE9SVEVEXCIsXG4gICAgICByZWFzb246IFwiU2tpcCBkb2VzIG5vdCBzdXBwb3J0IHdpdGggb3Bsb2cuXCIsXG4gICAgICBzb2x1dGlvbjogXCJUcnkgdG8gYXZvaWQgdXNpbmcgc2tpcC4gVXNlIHJhbmdlIHF1ZXJpZXMgaW5zdGVhZDogaHR0cDovL2dvby5nbC9iNTIyQXZcIlxuICAgIH07XG4gIH1cblxuICByZXR1cm4gdHJ1ZTtcbn07XG5cbk9wbG9nQ2hlY2sud2hlcmUgPSBmdW5jdGlvbihjdXJzb3JEZXNjcmlwdGlvbikge1xuICB2YXIgbWF0Y2hlciA9IG5ldyBNaW5pbW9uZ28uTWF0Y2hlcihjdXJzb3JEZXNjcmlwdGlvbi5zZWxlY3Rvcik7XG4gIGlmKG1hdGNoZXIuaGFzV2hlcmUoKSkge1xuICAgIHJldHVybiB7XG4gICAgICBjb2RlOiBcIldIRVJFX05PVF9TVVBQT1JURURcIixcbiAgICAgIHJlYXNvbjogXCJNZXRlb3IgZG9lcyBub3Qgc3VwcG9ydCBxdWVyaWVzIHdpdGggJHdoZXJlLlwiLFxuICAgICAgc29sdXRpb246IFwiVHJ5IHRvIHJlbW92ZSAkd2hlcmUgZnJvbSB5b3VyIHF1ZXJ5LiBVc2Ugc29tZSBhbHRlcm5hdGl2ZS5cIlxuICAgIH1cbiAgfTtcblxuICByZXR1cm4gdHJ1ZTtcbn07XG5cbk9wbG9nQ2hlY2suZ2VvID0gZnVuY3Rpb24oY3Vyc29yRGVzY3JpcHRpb24pIHtcbiAgdmFyIG1hdGNoZXIgPSBuZXcgTWluaW1vbmdvLk1hdGNoZXIoY3Vyc29yRGVzY3JpcHRpb24uc2VsZWN0b3IpO1xuXG4gIGlmKG1hdGNoZXIuaGFzR2VvUXVlcnkoKSkge1xuICAgIHJldHVybiB7XG4gICAgICBjb2RlOiBcIkdFT19OT1RfU1VQUE9SVEVEXCIsXG4gICAgICByZWFzb246IFwiTWV0ZW9yIGRvZXMgbm90IHN1cHBvcnQgcXVlcmllcyB3aXRoIGdlbyBwYXJ0aWFsIG9wZXJhdG9ycy5cIixcbiAgICAgIHNvbHV0aW9uOiBcIlRyeSB0byByZW1vdmUgZ2VvIHBhcnRpYWwgb3BlcmF0b3JzIGZyb20geW91ciBxdWVyeSBpZiBwb3NzaWJsZS5cIlxuICAgIH1cbiAgfTtcblxuICByZXR1cm4gdHJ1ZTtcbn07XG5cbk9wbG9nQ2hlY2subGltaXRCdXROb1NvcnQgPSBmdW5jdGlvbihjdXJzb3JEZXNjcmlwdGlvbikge1xuICB2YXIgb3B0aW9ucyA9IGN1cnNvckRlc2NyaXB0aW9uLm9wdGlvbnM7XG5cbiAgaWYoKG9wdGlvbnMubGltaXQgJiYgIW9wdGlvbnMuc29ydCkpIHtcbiAgICByZXR1cm4ge1xuICAgICAgY29kZTogXCJMSU1JVF9OT19TT1JUXCIsXG4gICAgICByZWFzb246IFwiTWV0ZW9yIG9wbG9nIGltcGxlbWVudGF0aW9uIGRvZXMgbm90IHN1cHBvcnQgbGltaXQgd2l0aG91dCBhIHNvcnQgc3BlY2lmaWVyLlwiLFxuICAgICAgc29sdXRpb246IFwiVHJ5IGFkZGluZyBhIHNvcnQgc3BlY2lmaWVyLlwiXG4gICAgfVxuICB9O1xuXG4gIHJldHVybiB0cnVlO1xufTtcblxuT3Bsb2dDaGVjay5vbGRlclZlcnNpb24gPSBmdW5jdGlvbihjdXJzb3JEZXNjcmlwdGlvbiwgZHJpdmVyKSB7XG4gIGlmKGRyaXZlciAmJiAhZHJpdmVyLmNvbnN0cnVjdG9yLmN1cnNvclN1cHBvcnRlZCkge1xuICAgIHJldHVybiB7XG4gICAgICBjb2RlOiBcIk9MREVSX1ZFUlNJT05cIixcbiAgICAgIHJlYXNvbjogXCJZb3VyIE1ldGVvciB2ZXJzaW9uIGRvZXMgbm90IGhhdmUgb3Bsb2cgc3VwcG9ydC5cIixcbiAgICAgIHNvbHV0aW9uOiBcIlVwZ3JhZGUgeW91ciBhcHAgdG8gTWV0ZW9yIHZlcnNpb24gMC43LjIgb3IgbGF0ZXIuXCJcbiAgICB9O1xuICB9XG4gIHJldHVybiB0cnVlO1xufTtcblxuT3Bsb2dDaGVjay5naXRDaGVja291dCA9IGZ1bmN0aW9uKGN1cnNvckRlc2NyaXB0aW9uLCBkcml2ZXIpIHtcbiAgaWYoIU1ldGVvci5yZWxlYXNlKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGNvZGU6IFwiR0lUX0NIRUNLT1VUXCIsXG4gICAgICByZWFzb246IFwiU2VlbXMgbGlrZSB5b3VyIE1ldGVvciB2ZXJzaW9uIGlzIGJhc2VkIG9uIGEgR2l0IGNoZWNrb3V0IGFuZCBpdCBkb2Vzbid0IGhhdmUgdGhlIG9wbG9nIHN1cHBvcnQuXCIsXG4gICAgICBzb2x1dGlvbjogXCJUcnkgdG8gdXBncmFkZSB5b3VyIE1ldGVvciB2ZXJzaW9uLlwiXG4gICAgfTtcbiAgfVxuICByZXR1cm4gdHJ1ZTtcbn07XG5cbnZhciBwcmVSdW5uaW5nTWF0Y2hlcnMgPSBbXG4gIE9wbG9nQ2hlY2suZW52LFxuICBPcGxvZ0NoZWNrLmRpc2FibGVPcGxvZyxcbiAgT3Bsb2dDaGVjay5taW5pTW9uZ29NYXRjaGVyXG5dO1xuXG52YXIgZ2xvYmFsTWF0Y2hlcnMgPSBbXG4gIE9wbG9nQ2hlY2suZmllbGRzLFxuICBPcGxvZ0NoZWNrLnNraXAsXG4gIE9wbG9nQ2hlY2sud2hlcmUsXG4gIE9wbG9nQ2hlY2suZ2VvLFxuICBPcGxvZ0NoZWNrLmxpbWl0QnV0Tm9Tb3J0LFxuICBPcGxvZ0NoZWNrLm1pbmlNb25nb1NvcnRlcixcbiAgT3Bsb2dDaGVjay5vbGRlclZlcnNpb24sXG4gIE9wbG9nQ2hlY2suZ2l0Q2hlY2tvdXRcbl07XG5cbnZhciB2ZXJzaW9uTWF0Y2hlcnMgPSBbXG4gIFsvXjBcXC43XFwuMS8sIE9wbG9nQ2hlY2suXzA3MV0sXG4gIFsvXjBcXC43XFwuMC8sIE9wbG9nQ2hlY2suXzA3MF0sXG5dO1xuXG5LYWRpcmEuY2hlY2tXaHlOb09wbG9nID0gZnVuY3Rpb24oY3Vyc29yRGVzY3JpcHRpb24sIG9ic2VydmVyRHJpdmVyKSB7XG4gIGlmKHR5cGVvZiBNaW5pbW9uZ28gPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICByZXR1cm4ge1xuICAgICAgY29kZTogXCJDQU5OT1RfREVURUNUXCIsXG4gICAgICByZWFzb246IFwiWW91IGFyZSBydW5uaW5nIGFuIG9sZGVyIE1ldGVvciB2ZXJzaW9uIGFuZCBLYWRpcmEgY2FuJ3QgY2hlY2sgb3Bsb2cgc3RhdGUuXCIsXG4gICAgICBzb2x1dGlvbjogXCJUcnkgdXBkYXRpbmcgeW91ciBNZXRlb3IgYXBwXCJcbiAgICB9XG4gIH1cblxuICB2YXIgcmVzdWx0ID0gcnVuTWF0Y2hlcnMocHJlUnVubmluZ01hdGNoZXJzLCBjdXJzb3JEZXNjcmlwdGlvbiwgb2JzZXJ2ZXJEcml2ZXIpO1xuICBpZihyZXN1bHQgIT09IHRydWUpIHtcbiAgICByZXR1cm4gcmVzdWx0O1xuICB9XG5cbiAgdmFyIG1ldGVvclZlcnNpb24gPSBNZXRlb3IucmVsZWFzZTtcbiAgZm9yKHZhciBsYz0wOyBsYzx2ZXJzaW9uTWF0Y2hlcnMubGVuZ3RoOyBsYysrKSB7XG4gICAgdmFyIG1hdGNoZXJJbmZvID0gdmVyc2lvbk1hdGNoZXJzW2xjXTtcbiAgICBpZihtYXRjaGVySW5mb1swXS50ZXN0KG1ldGVvclZlcnNpb24pKSB7XG4gICAgICB2YXIgbWF0Y2hlZCA9IG1hdGNoZXJJbmZvWzFdKGN1cnNvckRlc2NyaXB0aW9uLCBvYnNlcnZlckRyaXZlcik7XG4gICAgICBpZihtYXRjaGVkICE9PSB0cnVlKSB7XG4gICAgICAgIHJldHVybiBtYXRjaGVkO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHJlc3VsdCA9IHJ1bk1hdGNoZXJzKGdsb2JhbE1hdGNoZXJzLCBjdXJzb3JEZXNjcmlwdGlvbiwgb2JzZXJ2ZXJEcml2ZXIpO1xuICBpZihyZXN1bHQgIT09IHRydWUpIHtcbiAgICByZXR1cm4gcmVzdWx0O1xuICB9XG5cbiAgcmV0dXJuIHtcbiAgICBjb2RlOiBcIk9QTE9HX1NVUFBPUlRFRFwiLFxuICAgIHJlYXNvbjogXCJUaGlzIHF1ZXJ5IHNob3VsZCBzdXBwb3J0IG9wbG9nLiBJdCdzIHdlaXJkIGlmIGl0J3Mgbm90LlwiLFxuICAgIHNvbHV0aW9uOiBcIlBsZWFzZSBjb250YWN0IEthZGlyYSBzdXBwb3J0IGFuZCBsZXQncyBkaXNjdXNzLlwiXG4gIH07XG59O1xuXG5mdW5jdGlvbiBydW5NYXRjaGVycyhtYXRjaGVyTGlzdCwgY3Vyc29yRGVzY3JpcHRpb24sIG9ic2VydmVyRHJpdmVyKSB7XG4gIGZvcih2YXIgbGM9MDsgbGM8bWF0Y2hlckxpc3QubGVuZ3RoOyBsYysrKSB7XG4gICAgdmFyIG1hdGNoZXIgPSBtYXRjaGVyTGlzdFtsY107XG4gICAgdmFyIG1hdGNoZWQgPSBtYXRjaGVyKGN1cnNvckRlc2NyaXB0aW9uLCBvYnNlcnZlckRyaXZlcik7XG4gICAgaWYobWF0Y2hlZCAhPT0gdHJ1ZSkge1xuICAgICAgcmV0dXJuIG1hdGNoZWQ7XG4gICAgfVxuICB9XG4gIHJldHVybiB0cnVlO1xufVxuIiwidmFyIGV2ZW50TG9nZ2VyID0gTnBtLnJlcXVpcmUoJ2RlYnVnJykoJ2thZGlyYTp0cmFjZXInKTtcbnZhciBSRVBFVElUSVZFX0VWRU5UUyA9IHsnZGInOiB0cnVlLCAnaHR0cCc6IHRydWUsICdlbWFpbCc6IHRydWUsICd3YWl0JzogdHJ1ZSwgJ2FzeW5jJzogdHJ1ZSwgJ2N1c3RvbSc6IHRydWUsICdmcyc6IHRydWV9O1xudmFyIFRSQUNFX1RZUEVTID0gWydzdWInLCAnbWV0aG9kJywgJ2h0dHAnXTtcbnZhciBNQVhfVFJBQ0VfRVZFTlRTID0gMTUwMDtcblxuVHJhY2VyID0gZnVuY3Rpb24gVHJhY2VyKCkge1xuICB0aGlzLl9maWx0ZXJzID0gW107XG4gIHRoaXMuX2ZpbHRlckZpZWxkcyA9IFsncGFzc3dvcmQnXTtcbiAgdGhpcy5tYXhBcnJheUl0ZW1zVG9GaWx0ZXIgPSAyMDtcbn07XG5cbi8vSW4gdGhlIGZ1dHVyZSwgd2UgbWlnaHQgd2FuJ3QgdG8gdHJhY2sgaW5uZXIgZmliZXIgZXZlbnRzIHRvby5cbi8vVGhlbiB3ZSBjYW4ndCBzZXJpYWxpemUgdGhlIG9iamVjdCB3aXRoIG1ldGhvZHNcbi8vVGhhdCdzIHdoeSB3ZSB1c2UgdGhpcyBtZXRob2Qgb2YgcmV0dXJuaW5nIHRoZSBkYXRhXG5UcmFjZXIucHJvdG90eXBlLnN0YXJ0ID0gZnVuY3Rpb24gKG5hbWUsIHR5cGUsIHtcbiAgc2Vzc2lvbklkLFxuICBtc2dJZCxcbiAgdXNlcklkXG59ID0ge30pIHtcblxuICAvLyBmb3IgYmFja3dhcmQgY29tcGF0aWJpbGl0eVxuICBpZiAodHlwZW9mIG5hbWUgPT09ICdvYmplY3QnICYmIHR5cGVvZiB0eXBlID09PSAnb2JqZWN0Jykge1xuICAgIGxldCBzZXNzaW9uID0gbmFtZTtcbiAgICBsZXQgbXNnID0gdHlwZTtcbiAgICBzZXNzaW9uSWQgPSBzZXNzaW9uLmlkO1xuICAgIG1zZ0lkID0gbXNnLmlkO1xuICAgIHVzZXJJZCA9IHNlc3Npb24udXNlcklkO1xuXG4gICAgaWYobXNnLm1zZyA9PSAnbWV0aG9kJykge1xuICAgICAgdHlwZSA9ICdtZXRob2QnO1xuICAgICAgbmFtZSA9IG1zZy5tZXRob2Q7XG4gICAgfSBlbHNlIGlmKG1zZy5tc2cgPT0gJ3N1YicpIHtcbiAgICAgIHR5cGUgPSAnc3ViJztcbiAgICAgIG5hbWUgPSBtc2cubmFtZTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICB9XG5cbiAgaWYgKFRSQUNFX1RZUEVTLmluZGV4T2YodHlwZSkgPT09IC0xKSB7XG4gICAgY29uc29sZS53YXJuKGBNb250aSBBUE06IHVua25vd24gdHJhY2UgdHlwZSBcIiR7dHlwZX1cImApO1xuICAgIHJldHVybiBudWxsO1xuICB9XG5cblxuICB2YXIgdHJhY2VJbmZvID0ge1xuICAgIF9pZDogYCR7c2Vzc2lvbklkfTo6JHttc2dJZCB8fCBEZWZhdWx0VW5pcXVlSWQuZ2V0KCl9YCxcbiAgICB0eXBlLFxuICAgIG5hbWUsXG4gICAgc2Vzc2lvbjogc2Vzc2lvbklkLFxuICAgIGlkOiBtc2dJZCxcbiAgICBldmVudHM6IFtdLFxuICAgIHVzZXJJZCxcbiAgfTtcblxuICByZXR1cm4gdHJhY2VJbmZvO1xufTtcblxuVHJhY2VyLnByb3RvdHlwZS5ldmVudCA9IGZ1bmN0aW9uICh0cmFjZUluZm8sIHR5cGUsIGRhdGEsIG1ldGFEYXRhKSB7XG4gIC8vIGRvIG5vdCBhbGxvdyB0byBwcm9jZWVkLCBpZiBhbHJlYWR5IGNvbXBsZXRlZCBvciBlcnJvcmVkXG4gIHZhciBsYXN0RXZlbnQgPSB0aGlzLmdldExhc3RFdmVudCh0cmFjZUluZm8pO1xuXG4gIGlmKFxuICAgIC8vIHRyYWNlIGNvbXBsZXRlZCBidXQgaGFzIG5vdCBiZWVuIHByb2Nlc3NlZFxuICAgIGxhc3RFdmVudCAmJlxuICAgIFsnY29tcGxldGUnLCAnZXJyb3InXS5pbmRleE9mKGxhc3RFdmVudC50eXBlKSA+PSAwIHx8XG4gICAgLy8gdHJhY2UgY29tcGxldGVkIGFuZCBwcm9jZXNzZWQuXG4gICAgdHJhY2VJbmZvLmlzRXZlbnRzUHJvY2Vzc2VkXG4gICAgKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgdmFyIGV2ZW50ID0ge1xuICAgIHR5cGUsXG4gICAgYXQ6IE50cC5fbm93KCksXG4gICAgZW5kQXQ6IG51bGwsXG4gICAgbmVzdGVkOiBbXSxcbiAgfTtcblxuICAvLyBzcGVjaWFsIGhhbmRsaW5nIGZvciBldmVudHMgdGhhdCBhcmUgbm90IHJlcGV0aXRpdmVcbiAgaWYgKCFSRVBFVElUSVZFX0VWRU5UU1t0eXBlXSkge1xuICAgIGV2ZW50LmVuZEF0ID0gZXZlbnQuYXQ7XG4gIH1cblxuICBpZihkYXRhKSB7XG4gICAgdmFyIGluZm8gPSBfLnBpY2sodHJhY2VJbmZvLCAndHlwZScsICduYW1lJylcbiAgICBldmVudC5kYXRhID0gdGhpcy5fYXBwbHlGaWx0ZXJzKHR5cGUsIGRhdGEsIGluZm8sIFwic3RhcnRcIik7XG4gIH1cblxuICBpZiAobWV0YURhdGEgJiYgbWV0YURhdGEubmFtZSkge1xuICAgIGV2ZW50Lm5hbWUgPSBtZXRhRGF0YS5uYW1lXG4gIH1cblxuICBpZiAoS2FkaXJhLm9wdGlvbnMuZXZlbnRTdGFja1RyYWNlKSB7XG4gICAgZXZlbnQuc3RhY2sgPSBDcmVhdGVVc2VyU3RhY2soKVxuICB9XG4gIFxuICBldmVudExvZ2dlcihcIiVzICVzXCIsIHR5cGUsIHRyYWNlSW5mby5faWQpO1xuXG4gIGlmIChsYXN0RXZlbnQgJiYgIWxhc3RFdmVudC5lbmRBdCkge1xuICAgIGlmICghbGFzdEV2ZW50Lm5lc3RlZCkge1xuICAgICAgY29uc29sZS5lcnJvcignTW9udGk6IGludmFsaWQgdHJhY2UuIFBsZWFzZSBzaGFyZSB0aGUgdHJhY2UgYmVsb3cgYXQnKTtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ01vbnRpOiBodHRwczovL2dpdGh1Yi5jb20vbW9udGktYXBtL21vbnRpLWFwbS1hZ2VudC9pc3N1ZXMvMTQnKTtcbiAgICAgIGNvbnNvbGUuZGlyKHRyYWNlSW5mbywgeyBkZXB0aDogMTAgfSk7XG4gICAgfVxuICAgIHZhciBsYXN0TmVzdGVkID0gbGFzdEV2ZW50Lm5lc3RlZFtsYXN0RXZlbnQubmVzdGVkLmxlbmd0aCAtIDFdO1xuXG4gICAgLy8gT25seSBuZXN0IG9uZSBsZXZlbFxuICAgIGlmICghbGFzdE5lc3RlZCB8fCBsYXN0TmVzdGVkLmVuZEF0KSB7XG4gICAgICBsYXN0RXZlbnQubmVzdGVkLnB1c2goZXZlbnQpO1xuICAgICAgcmV0dXJuIGV2ZW50O1xuICAgIH1cblxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBcbiAgdHJhY2VJbmZvLmV2ZW50cy5wdXNoKGV2ZW50KTtcblxuICByZXR1cm4gZXZlbnQ7XG59O1xuXG5UcmFjZXIucHJvdG90eXBlLmV2ZW50RW5kID0gZnVuY3Rpb24odHJhY2VJbmZvLCBldmVudCwgZGF0YSkge1xuICBpZiAoZXZlbnQuZW5kQXQpIHtcbiAgICAvLyBFdmVudCBhbHJlYWR5IGVuZGVkIG9yIGlzIG5vdCBhIHJlcGl0aXRpdmUgZXZlbnRcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cblxuICBldmVudC5lbmRBdCA9IE50cC5fbm93KCk7XG5cbiAgaWYoZGF0YSkge1xuICAgIHZhciBpbmZvID0gXy5waWNrKHRyYWNlSW5mbywgJ3R5cGUnLCAnbmFtZScpXG4gICAgZXZlbnQuZGF0YSA9IE9iamVjdC5hc3NpZ24oXG4gICAgICBldmVudC5kYXRhIHx8IHt9LFxuICAgICAgdGhpcy5fYXBwbHlGaWx0ZXJzKGAke2V2ZW50LnR5cGV9ZW5kYCwgZGF0YSwgaW5mbywgJ2VuZCcpXG4gICAgKTtcbiAgfVxuICBldmVudExvZ2dlcihcIiVzICVzXCIsIGV2ZW50LnR5cGUgKyAnZW5kJywgdHJhY2VJbmZvLl9pZCk7XG5cbiAgcmV0dXJuIHRydWU7XG59O1xuXG5UcmFjZXIucHJvdG90eXBlLmdldExhc3RFdmVudCA9IGZ1bmN0aW9uKHRyYWNlSW5mbykge1xuICByZXR1cm4gdHJhY2VJbmZvLmV2ZW50c1t0cmFjZUluZm8uZXZlbnRzLmxlbmd0aCAtMV1cbn07XG5cblRyYWNlci5wcm90b3R5cGUuZW5kTGFzdEV2ZW50ID0gZnVuY3Rpb24odHJhY2VJbmZvKSB7XG4gIHZhciBsYXN0RXZlbnQgPSB0aGlzLmdldExhc3RFdmVudCh0cmFjZUluZm8pO1xuXG4gIGlmICghbGFzdEV2ZW50LmVuZEF0KSB7XG4gICAgdGhpcy5ldmVudEVuZCh0cmFjZUluZm8sIGxhc3RFdmVudCk7XG4gICAgbGFzdEV2ZW50LmZvcmNlZEVuZCA9IHRydWU7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufTtcblxuLy8gTW9zdCBvZiB0aGUgdGltZSwgYWxsIG9mIHRoZSBuZXN0ZWQgZXZlbnRzIGFyZSBhc3luY1xuLy8gd2hpY2ggaXMgbm90IGhlbHBmdWwuIFRoaXMgcmV0dXJucyB0cnVlIGlmXG4vLyB0aGVyZSBhcmUgbmVzdGVkIGV2ZW50cyBvdGhlciB0aGFuIGFzeW5jLlxuVHJhY2VyLnByb3RvdHlwZS5faGFzVXNlZnVsTmVzdGVkID0gZnVuY3Rpb24gKGV2ZW50KSB7XG4gIHJldHVybiAhZXZlbnQubmVzdGVkLmV2ZXJ5KGV2ZW50ID0+IHtcbiAgICByZXR1cm4gZXZlbnQudHlwZSA9PT0gJ2FzeW5jJztcbiAgfSk7XG59XG5cblRyYWNlci5wcm90b3R5cGUuYnVpbGRFdmVudCA9IGZ1bmN0aW9uKGV2ZW50LCBkZXB0aCA9IDAsIHRyYWNlKSB7XG4gIHZhciBlbGFwc2VkVGltZUZvckV2ZW50ID0gZXZlbnQuZW5kQXQgLSBldmVudC5hdDtcbiAgdmFyIGJ1aWx0RXZlbnQgPSBbZXZlbnQudHlwZV07XG4gIHZhciBuZXN0ZWQgPSBbXTtcblxuICBidWlsdEV2ZW50LnB1c2goZWxhcHNlZFRpbWVGb3JFdmVudCk7XG4gIGJ1aWx0RXZlbnQucHVzaChldmVudC5kYXRhIHx8IHt9KTtcbiAgXG4gIGlmIChldmVudC5uZXN0ZWQubGVuZ3RoICYmIHRoaXMuX2hhc1VzZWZ1bE5lc3RlZChldmVudCkpIHtcbiAgICBsZXQgcHJldkVuZCA9IGV2ZW50LmF0O1xuICAgIGZvcihsZXQgaSA9IDA7IGkgPCBldmVudC5uZXN0ZWQubGVuZ3RoOyBpKyspIHtcbiAgICAgIHZhciBuZXN0ZWRFdmVudCA9IGV2ZW50Lm5lc3RlZFtpXTtcbiAgICAgIGlmICghbmVzdGVkRXZlbnQuZW5kQXQpIHtcbiAgICAgICAgdGhpcy5ldmVudEVuZCh0cmFjZSwgbmVzdGVkRXZlbnQpO1xuICAgICAgICBuZXN0ZWRFdmVudC5mb3JjZWRFbmQgPSB0cnVlO1xuICAgICAgfVxuXG4gICAgICB2YXIgY29tcHV0ZVRpbWUgPSBuZXN0ZWRFdmVudC5hdCAtIHByZXZFbmQ7XG4gICAgICBpZiAoY29tcHV0ZVRpbWUgPiAwKSB7XG4gICAgICAgIG5lc3RlZC5wdXNoKFsnY29tcHV0ZScsIGNvbXB1dGVUaW1lXSk7XG4gICAgICB9XG5cbiAgICAgIG5lc3RlZC5wdXNoKHRoaXMuYnVpbGRFdmVudChuZXN0ZWRFdmVudCwgZGVwdGggKyAxLCB0cmFjZSkpO1xuICAgICAgcHJldkVuZCA9IG5lc3RlZEV2ZW50LmVuZEF0O1xuICAgIH1cbiAgfVxuXG5cbiAgaWYgKFxuICAgIG5lc3RlZC5sZW5ndGggfHxcbiAgICBldmVudC5zdGFjayB8fFxuICAgIGV2ZW50LmZvcmNlZEVuZCB8fFxuICAgIGV2ZW50Lm5hbWVcbiAgKSB7XG4gICAgYnVpbHRFdmVudC5wdXNoKHtcbiAgICAgIHN0YWNrOiBldmVudC5zdGFjayxcbiAgICAgIG5lc3RlZDogbmVzdGVkLmxlbmd0aCA/IG5lc3RlZCA6IHVuZGVmaW5lZCxcbiAgICAgIGZvcmNlZEVuZDogZXZlbnQuZm9yY2VkRW5kLFxuICAgICAgbmFtZTogZXZlbnQubmFtZVxuICAgIH0pO1xuICB9XG5cbiAgcmV0dXJuIGJ1aWx0RXZlbnQ7XG59XG5cblRyYWNlci5wcm90b3R5cGUuYnVpbGRUcmFjZSA9IGZ1bmN0aW9uICh0cmFjZUluZm8pIHtcbiAgdmFyIGZpcnN0RXZlbnQgPSB0cmFjZUluZm8uZXZlbnRzWzBdO1xuICB2YXIgbGFzdEV2ZW50ID0gdHJhY2VJbmZvLmV2ZW50c1t0cmFjZUluZm8uZXZlbnRzLmxlbmd0aCAtIDFdO1xuICB2YXIgcHJvY2Vzc2VkRXZlbnRzID0gW107XG5cbiAgaWYgKGZpcnN0RXZlbnQudHlwZSAhPT0gJ3N0YXJ0Jykge1xuICAgIGNvbnNvbGUud2FybignTW9udGkgQVBNOiB0cmFjZSBoYXMgbm90IHN0YXJ0ZWQgeWV0Jyk7XG4gICAgcmV0dXJuIG51bGw7XG4gIH0gZWxzZSBpZiAobGFzdEV2ZW50LnR5cGUgIT09ICdjb21wbGV0ZScgJiYgbGFzdEV2ZW50LnR5cGUgIT09ICdlcnJvcicpIHtcbiAgICAvL3RyYWNlIGlzIG5vdCBjb21wbGV0ZWQgb3IgZXJyb3JlZCB5ZXRcbiAgICBjb25zb2xlLndhcm4oJ01vbnRpIEFQTTogdHJhY2UgaGFzIG5vdCBjb21wbGV0ZWQgb3IgZXJyb3JlZCB5ZXQnKTtcbiAgICByZXR1cm4gbnVsbDtcbiAgfSBlbHNlIHtcbiAgICAvL2J1aWxkIHRoZSBtZXRyaWNzXG4gICAgdHJhY2VJbmZvLmVycm9yZWQgPSBsYXN0RXZlbnQudHlwZSA9PT0gJ2Vycm9yJztcbiAgICB0cmFjZUluZm8uYXQgPSBmaXJzdEV2ZW50LmF0O1xuXG4gICAgdmFyIG1ldHJpY3MgPSB7XG4gICAgICB0b3RhbDogbGFzdEV2ZW50LmF0IC0gZmlyc3RFdmVudC5hdCxcbiAgICB9O1xuXG4gICAgdmFyIHRvdGFsTm9uQ29tcHV0ZSA9IDA7XG5cbiAgICBmaXJzdEV2ZW50ID0gWydzdGFydCcsIDBdO1xuICAgIGlmICh0cmFjZUluZm8uZXZlbnRzWzBdLmRhdGEpIHtcbiAgICAgIGZpcnN0RXZlbnQucHVzaCh0cmFjZUluZm8uZXZlbnRzWzBdLmRhdGEpO1xuICAgIH1cbiAgICBwcm9jZXNzZWRFdmVudHMucHVzaChmaXJzdEV2ZW50KTtcblxuICAgIGZvciAodmFyIGxjID0gMTsgbGMgPCB0cmFjZUluZm8uZXZlbnRzLmxlbmd0aCAtIDE7IGxjICs9IDEpIHtcbiAgICAgIHZhciBwcmV2RXZlbnQgPSB0cmFjZUluZm8uZXZlbnRzW2xjIC0gMV07XG4gICAgICB2YXIgZXZlbnQgPSB0cmFjZUluZm8uZXZlbnRzW2xjXTtcblxuICAgICAgaWYgKCFldmVudC5lbmRBdCkge1xuICAgICAgICBjb25zb2xlLmVycm9yKCdNb250aSBBUE06IG5vIGVuZCBldmVudCBmb3IgdHlwZTogJywgZXZlbnQudHlwZSk7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgICAgfVxuXG4gICAgICB2YXIgY29tcHV0ZVRpbWUgPSBldmVudC5hdCAtIHByZXZFdmVudC5lbmRBdDtcbiAgICAgIGlmIChjb21wdXRlVGltZSA+IDApIHtcbiAgICAgICAgcHJvY2Vzc2VkRXZlbnRzLnB1c2goWydjb21wdXRlJywgY29tcHV0ZVRpbWVdKTtcbiAgICAgIH1cbiAgICAgIHZhciBidWlsdEV2ZW50ID0gdGhpcy5idWlsZEV2ZW50KGV2ZW50LCAwLCB0cmFjZUluZm8pO1xuICAgICAgcHJvY2Vzc2VkRXZlbnRzLnB1c2goYnVpbHRFdmVudCk7XG5cbiAgICAgIG1ldHJpY3NbZXZlbnQudHlwZV0gPSBtZXRyaWNzW2V2ZW50LnR5cGVdIHx8IDA7XG4gICAgICBtZXRyaWNzW2V2ZW50LnR5cGVdICs9IGJ1aWx0RXZlbnRbMV07XG4gICAgICB0b3RhbE5vbkNvbXB1dGUgKz0gYnVpbHRFdmVudFsxXTtcbiAgICB9XG4gIH1cblxuICBjb21wdXRlVGltZSA9IGxhc3RFdmVudC5hdCAtIHRyYWNlSW5mby5ldmVudHNbdHJhY2VJbmZvLmV2ZW50cy5sZW5ndGggLSAyXS5lbmRBdDtcbiAgaWYoY29tcHV0ZVRpbWUgPiAwKSBwcm9jZXNzZWRFdmVudHMucHVzaChbJ2NvbXB1dGUnLCBjb21wdXRlVGltZV0pO1xuXG4gIHZhciBsYXN0RXZlbnREYXRhID0gW2xhc3RFdmVudC50eXBlLCAwXTtcbiAgaWYobGFzdEV2ZW50LmRhdGEpIGxhc3RFdmVudERhdGEucHVzaChsYXN0RXZlbnQuZGF0YSk7XG4gIHByb2Nlc3NlZEV2ZW50cy5wdXNoKGxhc3RFdmVudERhdGEpO1xuXG4gIGlmIChwcm9jZXNzZWRFdmVudHMubGVuZ3RoID4gTUFYX1RSQUNFX0VWRU5UUykge1xuICAgIGNvbnN0IHJlbW92ZUNvdW50ID0gcHJvY2Vzc2VkRXZlbnRzLmxlbmd0aCAtIE1BWF9UUkFDRV9FVkVOVFNcbiAgICBwcm9jZXNzZWRFdmVudHMuc3BsaWNlKE1BWF9UUkFDRV9FVkVOVFMsIHJlbW92ZUNvdW50KTtcbiAgfVxuXG4gIG1ldHJpY3MuY29tcHV0ZSA9IG1ldHJpY3MudG90YWwgLSB0b3RhbE5vbkNvbXB1dGU7XG4gIHRyYWNlSW5mby5tZXRyaWNzID0gbWV0cmljcztcbiAgdHJhY2VJbmZvLmV2ZW50cyA9IHByb2Nlc3NlZEV2ZW50cztcbiAgdHJhY2VJbmZvLmlzRXZlbnRzUHJvY2Vzc2VkID0gdHJ1ZTtcbiAgcmV0dXJuIHRyYWNlSW5mbztcbn07XG5cblRyYWNlci5wcm90b3R5cGUuYWRkRmlsdGVyID0gZnVuY3Rpb24oZmlsdGVyRm4pIHtcbiAgdGhpcy5fZmlsdGVycy5wdXNoKGZpbHRlckZuKTtcbn07XG5cblRyYWNlci5wcm90b3R5cGUucmVkYWN0RmllbGQgPSBmdW5jdGlvbiAoZmllbGQpIHtcbiAgdGhpcy5fZmlsdGVyRmllbGRzLnB1c2goZmllbGQpO1xufTtcblxuVHJhY2VyLnByb3RvdHlwZS5fYXBwbHlGaWx0ZXJzID0gZnVuY3Rpb24oZXZlbnRUeXBlLCBkYXRhLCBpbmZvKSB7XG4gIHRoaXMuX2ZpbHRlcnMuZm9yRWFjaChmdW5jdGlvbihmaWx0ZXJGbikge1xuICAgIGRhdGEgPSBmaWx0ZXJGbihldmVudFR5cGUsIF8uY2xvbmUoZGF0YSksIGluZm8pO1xuICB9KTtcblxuICByZXR1cm4gZGF0YTtcbn07XG5cblRyYWNlci5wcm90b3R5cGUuX2FwcGx5T2JqZWN0RmlsdGVycyA9IGZ1bmN0aW9uICh0b0ZpbHRlcikge1xuICBjb25zdCBmaWx0ZXJPYmplY3QgPSAob2JqKSA9PiB7XG4gICAgbGV0IGNsb25lZDtcbiAgICB0aGlzLl9maWx0ZXJGaWVsZHMuZm9yRWFjaChmdW5jdGlvbiAoZmllbGQpIHtcbiAgICAgIGlmIChmaWVsZCBpbiBvYmopIHtcbiAgICAgICAgY2xvbmVkID0gY2xvbmVkIHx8IE9iamVjdC5hc3NpZ24oe30sIG9iaik7XG4gICAgICAgIGNsb25lZFtmaWVsZF0gPSAnTW9udGk6IHJlZGFjdGVkJztcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIHJldHVybiBjbG9uZWQ7XG4gIH1cblxuICBpZiAoQXJyYXkuaXNBcnJheSh0b0ZpbHRlcikpIHtcbiAgICBsZXQgY2xvbmVkO1xuICAgIC8vIFRoZXJlIGNvdWxkIGJlIHRob3VzYW5kcyBvciBtb3JlIGl0ZW1zIGluIHRoZSBhcnJheSwgYW5kIHRoaXMgdXN1YWxseSBydW5zXG4gICAgLy8gYmVmb3JlIHRoZSBkYXRhIGlzIHZhbGlkYXRlZC4gRm9yIHBlcmZvcm1hbmNlIHJlYXNvbnMgd2UgbGltaXQgaG93XG4gICAgLy8gbWFueSB0byBjaGVja1xuICAgIGxldCBsZW5ndGggPSBNYXRoLm1pbih0b0ZpbHRlci5sZW5ndGgsIHRoaXMubWF4QXJyYXlJdGVtc1RvRmlsdGVyKTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxlbmd0aDsgaSsrKSB7XG4gICAgICBpZiAodHlwZW9mIHRvRmlsdGVyW2ldID09PSAnb2JqZWN0JyAmJiB0b0ZpbHRlcltpXSAhPT0gbnVsbCkge1xuICAgICAgICBsZXQgcmVzdWx0ID0gZmlsdGVyT2JqZWN0KHRvRmlsdGVyW2ldKTtcbiAgICAgICAgaWYgKHJlc3VsdCkge1xuICAgICAgICAgIGNsb25lZCA9IGNsb25lZCB8fCBbLi4udG9GaWx0ZXJdO1xuICAgICAgICAgIGNsb25lZFtpXSA9IHJlc3VsdDtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBjbG9uZWQgfHwgdG9GaWx0ZXI7XG4gIH1cblxuICByZXR1cm4gZmlsdGVyT2JqZWN0KHRvRmlsdGVyKSB8fCB0b0ZpbHRlcjtcbn1cblxuS2FkaXJhLnRyYWNlciA9IG5ldyBUcmFjZXIoKTtcbi8vIG5lZWQgdG8gZXhwb3NlIFRyYWNlciB0byBwcm92aWRlIGRlZmF1bHQgc2V0IG9mIGZpbHRlcnNcbkthZGlyYS5UcmFjZXIgPSBUcmFjZXI7XG4iLCIvLyBzdHJpcCBzZW5zaXRpdmUgZGF0YSBzZW50IHRvIE1vbnRpIEFQTSBlbmdpbmUuXG4vLyBwb3NzaWJsZSB0byBsaW1pdCB0eXBlcyBieSBwcm92aWRpbmcgYW4gYXJyYXkgb2YgdHlwZXMgdG8gc3RyaXBcbi8vIHBvc3NpYmxlIHR5cGVzIGFyZTogXCJzdGFydFwiLCBcImRiXCIsIFwiaHR0cFwiLCBcImVtYWlsXCJcblRyYWNlci5zdHJpcFNlbnNpdGl2ZSA9IGZ1bmN0aW9uIHN0cmlwU2Vuc2l0aXZlKHR5cGVzVG9TdHJpcCwgcmVjZWl2ZXJUeXBlLCBuYW1lKSB7XG4gIHR5cGVzVG9TdHJpcCA9ICB0eXBlc1RvU3RyaXAgfHwgW107XG5cbiAgdmFyIHN0cmlwcGVkVHlwZXMgPSB7fTtcbiAgdHlwZXNUb1N0cmlwLmZvckVhY2goZnVuY3Rpb24odHlwZSkge1xuICAgIHN0cmlwcGVkVHlwZXNbdHlwZV0gPSB0cnVlO1xuICB9KTtcblxuICByZXR1cm4gZnVuY3Rpb24gKHR5cGUsIGRhdGEsIGluZm8pIHtcbiAgICBpZih0eXBlc1RvU3RyaXAubGVuZ3RoID4gMCAmJiAhc3RyaXBwZWRUeXBlc1t0eXBlXSlcbiAgICAgIHJldHVybiBkYXRhO1xuXG4gICAgaWYocmVjZWl2ZXJUeXBlICYmIHJlY2VpdmVyVHlwZSAhPSBpbmZvLnR5cGUpXG4gICAgICByZXR1cm4gZGF0YTtcblxuICAgIGlmKG5hbWUgJiYgbmFtZSAhPSBpbmZvLm5hbWUpXG4gICAgICByZXR1cm4gZGF0YTtcblxuICAgIGlmKHR5cGUgPT0gXCJzdGFydFwiKSB7XG4gICAgICBpZiAoZGF0YS5wYXJhbXMpIHtcbiAgICAgICAgZGF0YS5wYXJhbXMgPSBcIltzdHJpcHBlZF1cIjtcbiAgICAgIH1cbiAgICAgIGlmIChkYXRhLmhlYWRlcnMpIHtcbiAgICAgICAgZGF0YS5oZWFkZXJzID0gXCJbc3RyaXBwZWRdXCI7XG4gICAgICB9XG4gICAgICBpZiAoZGF0YS5ib2R5KSB7XG4gICAgICAgIGRhdGEuYm9keSA9IFwiW3N0cmlwcGVkXVwiO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZih0eXBlID09IFwiZGJcIikge1xuICAgICAgZGF0YS5zZWxlY3RvciA9IFwiW3N0cmlwcGVkXVwiO1xuICAgIH0gZWxzZSBpZih0eXBlID09IFwiaHR0cFwiKSB7XG4gICAgICBkYXRhLnVybCA9IFwiW3N0cmlwcGVkXVwiO1xuICAgIH0gZWxzZSBpZih0eXBlID09IFwiZW1haWxcIikge1xuICAgICAgW1wiZnJvbVwiLCBcInRvXCIsIFwiY2NcIiwgXCJiY2NcIiwgXCJyZXBseVRvXCJdLmZvckVhY2goZnVuY3Rpb24oaXRlbSkge1xuICAgICAgICBpZihkYXRhW2l0ZW1dKSB7XG4gICAgICAgICAgZGF0YVtpdGVtXSA9IFwiW3N0cmlwcGVkXVwiO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9XG5cbiAgICByZXR1cm4gZGF0YTtcbiAgfTtcbn07XG5cbi8vIFN0cmlwIHNlbnNpdGl2ZSBkYXRhIHNlbnQgdG8gTW9udGkgQVBNIGVuZ2luZS5cbi8vIEluIGNvbnRyYXN0IHRvIHN0cmlwU2Vuc2l0aXZlLCB0aGlzIG9uZSBoYXMgYW4gYWxsb3cgbGlzdCBvZiB3aGF0IHRvIGtlZXBcbi8vIHRvIGd1YXJkIGFnYWluc3QgZm9yZ2V0dGluZyB0byBzdHJpcCBuZXcgZmllbGRzXG4vLyBJbiB0aGUgZnV0dXJlIHRoaXMgb25lIG1pZ2h0IHJlcGxhY2UgVHJhY2VyLnN0cmlwU2Vuc2l0aXZlXG4vLyBvcHRpb25zXG5UcmFjZXIuc3RyaXBTZW5zaXRpdmVUaG9yb3VnaCA9IGZ1bmN0aW9uIHN0cmlwU2Vuc2l0aXZlKCkge1xuICByZXR1cm4gZnVuY3Rpb24gKHR5cGUsIGRhdGEpIHtcbiAgICBsZXQgZmllbGRzVG9LZWVwID0gW107XG5cbiAgICBpZiAodHlwZSA9PSBcInN0YXJ0XCIpIHtcbiAgICAgIGZpZWxkc1RvS2VlcCA9IFsndXNlcklkJ107XG4gICAgfSBlbHNlIGlmICh0eXBlID09PSAnd2FpdGVuZCcpIHtcbiAgICAgIGZpZWxkc1RvS2VlcCA9IFsgJ3dhaXRPbicgXTtcbiAgICB9IGVsc2UgaWYgKHR5cGUgPT0gXCJkYlwiKSB7XG4gICAgICBmaWVsZHNUb0tlZXAgPSBbXG4gICAgICAgICdjb2xsJywgJ2Z1bmMnLCAnY3Vyc29yJywgJ2xpbWl0JywgJ2RvY3NGZXRjaGVkJywgJ2RvY1NpemUnLCAnb3Bsb2cnLFxuICAgICAgICAnZmllbGRzJywgJ3dhc011bHRpcGxleGVyUmVhZHknLCAncXVldWVMZW5ndGgnLCAnZWxhcHNlZFBvbGxpbmdUaW1lJyxcbiAgICAgICAgJ25vT2ZDYWNoZWREb2NzJ1xuICAgICAgXTtcbiAgICB9IGVsc2UgaWYgKHR5cGUgPT0gXCJodHRwXCIpIHtcbiAgICAgIGZpZWxkc1RvS2VlcCA9IFsnbWV0aG9kJywgJ3N0YXR1c0NvZGUnXTtcbiAgICB9IGVsc2UgaWYgKHR5cGUgPT0gXCJlbWFpbFwiKSB7XG4gICAgICBmaWVsZHNUb0tlZXAgPSBbXTtcbiAgICB9IGVsc2UgaWYgKHR5cGUgPT09ICdjdXN0b20nKSB7XG4gICAgICAvLyBUaGlzIGlzIHN1cHBsaWVkIGJ5IHRoZSB1c2VyIHNvIHdlIGFzc3VtZSB0aGV5IGFyZSBvbmx5IGdpdmluZyBkYXRhIHRoYXQgY2FuIGJlIHNlbnRcbiAgICAgIGZpZWxkc1RvS2VlcCA9IE9iamVjdC5rZXlzKGRhdGEpO1xuICAgIH0gZWxzZSBpZiAodHlwZSA9PT0gJ2Vycm9yJykge1xuICAgICAgZmllbGRzVG9LZWVwID0gWydlcnJvciddO1xuICAgIH1cblxuICAgIE9iamVjdC5rZXlzKGRhdGEpLmZvckVhY2goa2V5ID0+IHtcbiAgICAgIGlmIChmaWVsZHNUb0tlZXAuaW5kZXhPZihrZXkpID09PSAtMSkge1xuICAgICAgICBkYXRhW2tleV0gPSAnW3N0cmlwcGVkXSc7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICByZXR1cm4gZGF0YTtcbiAgfTtcbn07XG5cbi8vIHN0cmlwIHNlbGVjdG9ycyBvbmx5IGZyb20gdGhlIGdpdmVuIGxpc3Qgb2YgY29sbGVjdGlvbiBuYW1lc1xuVHJhY2VyLnN0cmlwU2VsZWN0b3JzID0gZnVuY3Rpb24gc3RyaXBTZWxlY3RvcnMoY29sbGVjdGlvbkxpc3QsIHJlY2VpdmVyVHlwZSwgbmFtZSkge1xuICBjb2xsZWN0aW9uTGlzdCA9IGNvbGxlY3Rpb25MaXN0IHx8IFtdO1xuXG4gIHZhciBjb2xsTWFwID0ge307XG4gIGNvbGxlY3Rpb25MaXN0LmZvckVhY2goZnVuY3Rpb24oY29sbE5hbWUpIHtcbiAgICBjb2xsTWFwW2NvbGxOYW1lXSA9IHRydWU7XG4gIH0pO1xuXG4gIHJldHVybiBmdW5jdGlvbih0eXBlLCBkYXRhLCBpbmZvKSB7XG4gICAgaWYodHlwZSAhPSBcImRiXCIgfHwgKGRhdGEgJiYgIWNvbGxNYXBbZGF0YS5jb2xsXSkpIHtcbiAgICAgIHJldHVybiBkYXRhXG4gICAgfVxuXG4gICAgaWYocmVjZWl2ZXJUeXBlICYmIHJlY2VpdmVyVHlwZSAhPSBpbmZvLnR5cGUpXG4gICAgICByZXR1cm4gZGF0YTtcblxuICAgIGlmKG5hbWUgJiYgbmFtZSAhPSBpbmZvLm5hbWUpXG4gICAgICByZXR1cm4gZGF0YTtcblxuICAgIGRhdGEuc2VsZWN0b3IgPSBcIltzdHJpcHBlZF1cIjtcbiAgICByZXR1cm4gZGF0YTtcbiAgfTtcbn1cbiIsInZhciBsb2dnZXIgPSBOcG0ucmVxdWlyZSgnZGVidWcnKSgna2FkaXJhOnRzJyk7XG5cblRyYWNlclN0b3JlID0gZnVuY3Rpb24gVHJhY2VyU3RvcmUob3B0aW9ucykge1xuICBvcHRpb25zID0gb3B0aW9ucyB8fCB7fTtcblxuICB0aGlzLm1heFRvdGFsUG9pbnRzID0gb3B0aW9ucy5tYXhUb3RhbFBvaW50cyB8fCAzMDtcbiAgdGhpcy5pbnRlcnZhbCA9IG9wdGlvbnMuaW50ZXJ2YWwgfHwgMTAwMCAqIDYwO1xuICB0aGlzLmFyY2hpdmVFdmVyeSA9IG9wdGlvbnMuYXJjaGl2ZUV2ZXJ5IHx8IHRoaXMubWF4VG90YWxQb2ludHMgLyA2O1xuXG4gIC8vc3RvcmUgbWF4IHRvdGFsIG9uIHRoZSBwYXN0IDMwIG1pbnV0ZXMgKG9yIHBhc3QgMzAgaXRlbXMpXG4gIHRoaXMubWF4VG90YWxzID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgLy9zdG9yZSB0aGUgbWF4IHRyYWNlIG9mIHRoZSBjdXJyZW50IGludGVydmFsXG4gIHRoaXMuY3VycmVudE1heFRyYWNlID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgLy9hcmNoaXZlIGZvciB0aGUgdHJhY2VzXG4gIHRoaXMudHJhY2VBcmNoaXZlID0gW107XG5cbiAgdGhpcy5wcm9jZXNzZWRDbnQgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuXG4gIC8vZ3JvdXAgZXJyb3JzIGJ5IG1lc3NhZ2VzIGJldHdlZW4gYW4gaW50ZXJ2YWxcbiAgdGhpcy5lcnJvck1hcCA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG59O1xuXG5UcmFjZXJTdG9yZS5wcm90b3R5cGUuYWRkVHJhY2UgPSBmdW5jdGlvbih0cmFjZSkge1xuICB2YXIga2luZCA9IFt0cmFjZS50eXBlLCB0cmFjZS5uYW1lXS5qb2luKCc6OicpO1xuICBpZighdGhpcy5jdXJyZW50TWF4VHJhY2Vba2luZF0pIHtcbiAgICB0aGlzLmN1cnJlbnRNYXhUcmFjZVtraW5kXSA9IEVKU09OLmNsb25lKHRyYWNlKTtcbiAgfSBlbHNlIGlmKHRoaXMuY3VycmVudE1heFRyYWNlW2tpbmRdLm1ldHJpY3MudG90YWwgPCB0cmFjZS5tZXRyaWNzLnRvdGFsKSB7XG4gICAgdGhpcy5jdXJyZW50TWF4VHJhY2Vba2luZF0gPSBFSlNPTi5jbG9uZSh0cmFjZSk7XG4gIH0gZWxzZSBpZih0cmFjZS5lcnJvcmVkKSB7XG4gICAgdGhpcy5faGFuZGxlRXJyb3JzKHRyYWNlKTtcbiAgfVxufTtcblxuVHJhY2VyU3RvcmUucHJvdG90eXBlLmNvbGxlY3RUcmFjZXMgPSBmdW5jdGlvbigpIHtcbiAgdmFyIHRyYWNlcyA9IHRoaXMudHJhY2VBcmNoaXZlO1xuICB0aGlzLnRyYWNlQXJjaGl2ZSA9IFtdO1xuXG4gIC8vIGNvbnZlcnQgYXQodGltZXN0YW1wKSBpbnRvIHRoZSBhY3R1YWwgc2VydmVyVGltZVxuICB0cmFjZXMuZm9yRWFjaChmdW5jdGlvbih0cmFjZSkge1xuICAgIHRyYWNlLmF0ID0gS2FkaXJhLnN5bmNlZERhdGUuc3luY1RpbWUodHJhY2UuYXQpO1xuICB9KTtcbiAgcmV0dXJuIHRyYWNlcztcbn07XG5cblRyYWNlclN0b3JlLnByb3RvdHlwZS5zdGFydCA9IGZ1bmN0aW9uKCkge1xuICB0aGlzLl90aW1lb3V0SGFuZGxlciA9IHNldEludGVydmFsKHRoaXMucHJvY2Vzc1RyYWNlcy5iaW5kKHRoaXMpLCB0aGlzLmludGVydmFsKTtcbn07XG5cblRyYWNlclN0b3JlLnByb3RvdHlwZS5zdG9wID0gZnVuY3Rpb24oKSB7XG4gIGlmKHRoaXMuX3RpbWVvdXRIYW5kbGVyKSB7XG4gICAgY2xlYXJJbnRlcnZhbCh0aGlzLl90aW1lb3V0SGFuZGxlcik7XG4gIH1cbn07XG5cblRyYWNlclN0b3JlLnByb3RvdHlwZS5faGFuZGxlRXJyb3JzID0gZnVuY3Rpb24odHJhY2UpIHtcbiAgLy8gc2VuZGluZyBlcnJvciByZXF1ZXN0cyBhcyBpdCBpc1xuICB2YXIgbGFzdEV2ZW50ID0gdHJhY2UuZXZlbnRzW3RyYWNlLmV2ZW50cy5sZW5ndGggLTFdO1xuICBpZihsYXN0RXZlbnQgJiYgbGFzdEV2ZW50WzJdKSB7XG4gICAgdmFyIGVycm9yID0gbGFzdEV2ZW50WzJdLmVycm9yO1xuXG4gICAgLy8gZ3JvdXBpbmcgZXJyb3JzIG9jY3VyZWQgKHJlc2V0IGFmdGVyIHByb2Nlc3NUcmFjZXMpXG4gICAgdmFyIGVycm9yS2V5ID0gW3RyYWNlLnR5cGUsIHRyYWNlLm5hbWUsIGVycm9yLm1lc3NhZ2VdLmpvaW4oXCI6OlwiKTtcbiAgICBpZighdGhpcy5lcnJvck1hcFtlcnJvcktleV0pIHtcbiAgICAgIHZhciBlcnJvcmVkVHJhY2UgPSBFSlNPTi5jbG9uZSh0cmFjZSk7XG4gICAgICB0aGlzLmVycm9yTWFwW2Vycm9yS2V5XSA9IGVycm9yZWRUcmFjZTtcblxuICAgICAgdGhpcy50cmFjZUFyY2hpdmUucHVzaChlcnJvcmVkVHJhY2UpO1xuICAgIH1cbiAgfSBlbHNlIHtcbiAgICBsb2dnZXIoJ2xhc3QgZXZlbnRzIGlzIG5vdCBhbiBlcnJvcjogJywgSlNPTi5zdHJpbmdpZnkodHJhY2UuZXZlbnRzKSk7XG4gIH1cbn07XG5cblRyYWNlclN0b3JlLnByb3RvdHlwZS5wcm9jZXNzVHJhY2VzID0gZnVuY3Rpb24oKSB7XG4gIHZhciBzZWxmID0gdGhpcztcbiAgXG4gIGxldCBraW5kcyA9IG5ldyBTZXQoKTtcbiAgT2JqZWN0LmtleXModGhpcy5tYXhUb3RhbHMpLmZvckVhY2goa2V5ID0+IHtcbiAgICBraW5kcy5hZGQoa2V5KTtcbiAgfSk7XG4gIE9iamVjdC5rZXlzKHRoaXMuY3VycmVudE1heFRyYWNlKS5mb3JFYWNoKGtleSA9PiB7XG4gICAga2luZHMuYWRkKGtleSk7XG4gIH0pO1xuXG4gIGZvciAoa2luZCBvZiBraW5kcykge1xuICAgIHNlbGYucHJvY2Vzc2VkQ250W2tpbmRdID0gc2VsZi5wcm9jZXNzZWRDbnRba2luZF0gfHwgMDtcbiAgICB2YXIgY3VycmVudE1heFRyYWNlID0gc2VsZi5jdXJyZW50TWF4VHJhY2Vba2luZF07XG4gICAgdmFyIGN1cnJlbnRNYXhUb3RhbCA9IGN1cnJlbnRNYXhUcmFjZT8gY3VycmVudE1heFRyYWNlLm1ldHJpY3MudG90YWwgOiAwO1xuXG4gICAgc2VsZi5tYXhUb3RhbHNba2luZF0gPSBzZWxmLm1heFRvdGFsc1traW5kXSB8fCBbXTtcbiAgICAvL2FkZCB0aGUgY3VycmVudCBtYXhQb2ludFxuICAgIHNlbGYubWF4VG90YWxzW2tpbmRdLnB1c2goY3VycmVudE1heFRvdGFsKTtcbiAgICB2YXIgZXhjZWVkaW5nUG9pbnRzID0gc2VsZi5tYXhUb3RhbHNba2luZF0ubGVuZ3RoIC0gc2VsZi5tYXhUb3RhbFBvaW50cztcbiAgICBpZihleGNlZWRpbmdQb2ludHMgPiAwKSB7XG4gICAgICBzZWxmLm1heFRvdGFsc1traW5kXS5zcGxpY2UoMCwgZXhjZWVkaW5nUG9pbnRzKTtcbiAgICB9XG5cbiAgICB2YXIgYXJjaGl2ZURlZmF1bHQgPSAoc2VsZi5wcm9jZXNzZWRDbnRba2luZF0gJSBzZWxmLmFyY2hpdmVFdmVyeSkgPT0gMDtcbiAgICBzZWxmLnByb2Nlc3NlZENudFtraW5kXSsrO1xuXG4gICAgdmFyIGNhbkFyY2hpdmUgPSBhcmNoaXZlRGVmYXVsdFxuICAgICAgfHwgc2VsZi5faXNUcmFjZU91dGxpZXIoa2luZCwgY3VycmVudE1heFRyYWNlKTtcblxuICAgIGlmKGNhbkFyY2hpdmUgJiYgY3VycmVudE1heFRyYWNlKSB7XG4gICAgICBzZWxmLnRyYWNlQXJjaGl2ZS5wdXNoKGN1cnJlbnRNYXhUcmFjZSk7XG4gICAgfVxuXG4gICAgLy9yZXNldCBjdXJyZW50TWF4VHJhY2VcbiAgICBzZWxmLmN1cnJlbnRNYXhUcmFjZVtraW5kXSA9IG51bGw7XG4gIH07XG5cbiAgLy9yZXNldCB0aGUgZXJyb3JNYXBcbiAgc2VsZi5lcnJvck1hcCA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG59O1xuXG5UcmFjZXJTdG9yZS5wcm90b3R5cGUuX2lzVHJhY2VPdXRsaWVyID0gZnVuY3Rpb24oa2luZCwgdHJhY2UpIHtcbiAgaWYodHJhY2UpIHtcbiAgICB2YXIgZGF0YVNldCA9IHRoaXMubWF4VG90YWxzW2tpbmRdO1xuICAgIHJldHVybiB0aGlzLl9pc091dGxpZXIoZGF0YVNldCwgdHJhY2UubWV0cmljcy50b3RhbCwgMyk7XG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG59O1xuXG4vKlxuICBEYXRhIHBvaW50IG11c3QgZXhpc3RzIGluIHRoZSBkYXRhU2V0XG4qL1xuVHJhY2VyU3RvcmUucHJvdG90eXBlLl9pc091dGxpZXIgPSBmdW5jdGlvbihkYXRhU2V0LCBkYXRhUG9pbnQsIG1heE1hZFopIHtcbiAgdmFyIG1lZGlhbiA9IHRoaXMuX2dldE1lZGlhbihkYXRhU2V0KTtcbiAgdmFyIG1hZCA9IHRoaXMuX2NhbGN1bGF0ZU1hZChkYXRhU2V0LCBtZWRpYW4pO1xuICB2YXIgbWFkWiA9IHRoaXMuX2Z1bmNNZWRpYW5EZXZpYXRpb24obWVkaWFuKShkYXRhUG9pbnQpIC8gbWFkO1xuXG4gIHJldHVybiBtYWRaID4gbWF4TWFkWjtcbn07XG5cblRyYWNlclN0b3JlLnByb3RvdHlwZS5fZ2V0TWVkaWFuID0gZnVuY3Rpb24oZGF0YVNldCkge1xuICB2YXIgc29ydGVkRGF0YVNldCA9IF8uY2xvbmUoZGF0YVNldCkuc29ydChmdW5jdGlvbihhLCBiKSB7XG4gICAgcmV0dXJuIGEtYjtcbiAgfSk7XG4gIHJldHVybiB0aGlzLl9waWNrUXVhcnRpbGUoc29ydGVkRGF0YVNldCwgMik7XG59O1xuXG5UcmFjZXJTdG9yZS5wcm90b3R5cGUuX3BpY2tRdWFydGlsZSA9IGZ1bmN0aW9uKGRhdGFTZXQsIG51bSkge1xuICB2YXIgcG9zID0gKChkYXRhU2V0Lmxlbmd0aCArIDEpICogbnVtKSAvIDQ7XG4gIGlmKHBvcyAlIDEgPT0gMCkge1xuICAgIHJldHVybiBkYXRhU2V0W3BvcyAtMV07XG4gIH0gZWxzZSB7XG4gICAgcG9zID0gcG9zIC0gKHBvcyAlIDEpO1xuICAgIHJldHVybiAoZGF0YVNldFtwb3MgLTFdICsgZGF0YVNldFtwb3NdKS8yXG4gIH1cbn07XG5cblRyYWNlclN0b3JlLnByb3RvdHlwZS5fY2FsY3VsYXRlTWFkID0gZnVuY3Rpb24oZGF0YVNldCwgbWVkaWFuKSB7XG4gIHZhciBtZWRpYW5EZXZpYXRpb25zID0gXy5tYXAoZGF0YVNldCwgdGhpcy5fZnVuY01lZGlhbkRldmlhdGlvbihtZWRpYW4pKTtcbiAgdmFyIG1hZCA9IHRoaXMuX2dldE1lZGlhbihtZWRpYW5EZXZpYXRpb25zKTtcblxuICByZXR1cm4gbWFkO1xufTtcblxuVHJhY2VyU3RvcmUucHJvdG90eXBlLl9mdW5jTWVkaWFuRGV2aWF0aW9uID0gZnVuY3Rpb24obWVkaWFuKSB7XG4gIHJldHVybiBmdW5jdGlvbih4KSB7XG4gICAgcmV0dXJuIE1hdGguYWJzKG1lZGlhbiAtIHgpO1xuICB9O1xufTtcblxuVHJhY2VyU3RvcmUucHJvdG90eXBlLl9nZXRNZWFuID0gZnVuY3Rpb24oZGF0YVBvaW50cykge1xuICBpZihkYXRhUG9pbnRzLmxlbmd0aCA+IDApIHtcbiAgICB2YXIgdG90YWwgPSAwO1xuICAgIGRhdGFQb2ludHMuZm9yRWFjaChmdW5jdGlvbihwb2ludCkge1xuICAgICAgdG90YWwgKz0gcG9pbnQ7XG4gICAgfSk7XG4gICAgcmV0dXJuIHRvdGFsL2RhdGFQb2ludHMubGVuZ3RoO1xuICB9IGVsc2Uge1xuICAgIHJldHVybiAwO1xuICB9XG59O1xuIiwidmFyIExSVSA9IE5wbS5yZXF1aXJlKCdscnUtY2FjaGUnKTtcbnZhciBjcnlwdG8gPSBOcG0ucmVxdWlyZSgnY3J5cHRvJyk7XG52YXIganNvblN0cmluZ2lmeSA9IE5wbS5yZXF1aXJlKCdqc29uLXN0cmluZ2lmeS1zYWZlJyk7XG5cbkRvY1N6Q2FjaGUgPSBmdW5jdGlvbiAobWF4SXRlbXMsIG1heFZhbHVlcykge1xuICB0aGlzLml0ZW1zID0gbmV3IExSVSh7bWF4OiBtYXhJdGVtc30pO1xuICB0aGlzLm1heFZhbHVlcyA9IG1heFZhbHVlcztcbiAgdGhpcy5jcHVVc2FnZSA9IDA7XG59XG5cbi8vIFRoaXMgaXMgY2FsbGVkIGZyb20gU3lzdGVtTW9kZWwucHJvdG90eXBlLmNwdVVzYWdlIGFuZCBzYXZlcyBjcHUgdXNhZ2UuXG5Eb2NTekNhY2hlLnByb3RvdHlwZS5zZXRQY3B1ID0gZnVuY3Rpb24gKHBjcHUpIHtcbiAgdGhpcy5jcHVVc2FnZSA9IHBjcHU7XG59O1xuXG5Eb2NTekNhY2hlLnByb3RvdHlwZS5nZXRTaXplID0gZnVuY3Rpb24gKGNvbGwsIHF1ZXJ5LCBvcHRzLCBkYXRhKSB7XG4gIC8vIElmIHRoZSBkYXRhc2V0IGlzIG51bGwgb3IgZW1wdHkgd2UgY2FuJ3QgY2FsY3VsYXRlIHRoZSBzaXplXG4gIC8vIERvIG5vdCBwcm9jZXNzIHRoaXMgZGF0YSBhbmQgcmV0dXJuIDAgYXMgdGhlIGRvY3VtZW50IHNpemUuXG4gIGlmICghKGRhdGEgJiYgKGRhdGEubGVuZ3RoIHx8ICh0eXBlb2YgZGF0YS5zaXplID09PSAnZnVuY3Rpb24nICYmIGRhdGEuc2l6ZSgpKSkpKSB7XG4gICAgcmV0dXJuIDA7XG4gIH1cblxuICB2YXIga2V5ID0gdGhpcy5nZXRLZXkoY29sbCwgcXVlcnksIG9wdHMpO1xuICB2YXIgaXRlbSA9IHRoaXMuaXRlbXMuZ2V0KGtleSk7XG5cbiAgaWYgKCFpdGVtKSB7XG4gICAgaXRlbSA9IG5ldyBEb2NTekNhY2hlSXRlbSh0aGlzLm1heFZhbHVlcyk7XG4gICAgdGhpcy5pdGVtcy5zZXQoa2V5LCBpdGVtKTtcbiAgfVxuXG4gIGlmICh0aGlzLm5lZWRzVXBkYXRlKGl0ZW0pKSB7XG4gICAgdmFyIGRvYyA9IHt9O1xuICAgIGlmKHR5cGVvZiBkYXRhLmdldCA9PT0gJ2Z1bmN0aW9uJyl7XG4gICAgICAvLyBUaGlzIGlzIGFuIElkTWFwXG4gICAgICBkYXRhLmZvckVhY2goZnVuY3Rpb24oZWxlbWVudCl7XG4gICAgICAgIGRvYyA9IGVsZW1lbnQ7XG4gICAgICAgIHJldHVybiBmYWxzZTsgLy8gcmV0dXJuIGZhbHNlIHRvIHN0b3AgbG9vcC4gV2Ugb25seSBuZWVkIG9uZSBkb2MuXG4gICAgICB9KVxuICAgIH0gZWxzZSB7XG4gICAgICBkb2MgPSBkYXRhWzBdO1xuICAgIH1cbiAgICB2YXIgc2l6ZSA9IEJ1ZmZlci5ieXRlTGVuZ3RoKGpzb25TdHJpbmdpZnkoZG9jKSwgJ3V0ZjgnKTtcbiAgICBpdGVtLmFkZERhdGEoc2l6ZSk7XG4gIH1cblxuICByZXR1cm4gaXRlbS5nZXRWYWx1ZSgpO1xufTtcblxuRG9jU3pDYWNoZS5wcm90b3R5cGUuZ2V0S2V5ID0gZnVuY3Rpb24gKGNvbGwsIHF1ZXJ5LCBvcHRzKSB7XG4gIHJldHVybiBqc29uU3RyaW5naWZ5KFtjb2xsLCBxdWVyeSwgb3B0c10pO1xufTtcblxuLy8gcmV0dXJucyBhIHNjb3JlIGJldHdlZW4gMCBhbmQgMSBmb3IgYSBjYWNoZSBpdGVtXG4vLyB0aGlzIHNjb3JlIGlzIGRldGVybWluZWQgYnk6XG4vLyAgKiBhdmFpbGFibGUgY2FjaGUgaXRlbSBzbG90c1xuLy8gICogdGltZSBzaW5jZSBsYXN0IHVwZGF0ZWRcbi8vICAqIGNwdSB1c2FnZSBvZiB0aGUgYXBwbGljYXRpb25cbkRvY1N6Q2FjaGUucHJvdG90eXBlLmdldEl0ZW1TY29yZSA9IGZ1bmN0aW9uIChpdGVtKSB7XG4gIHJldHVybiBbXG4gICAgKGl0ZW0ubWF4VmFsdWVzIC0gaXRlbS52YWx1ZXMubGVuZ3RoKS9pdGVtLm1heFZhbHVlcyxcbiAgICAoRGF0ZS5ub3coKSAtIGl0ZW0udXBkYXRlZCkgLyA2MDAwMCxcbiAgICAoMTAwIC0gdGhpcy5jcHVVc2FnZSkgLyAxMDAsXG4gIF0ubWFwKGZ1bmN0aW9uIChzY29yZSkge1xuICAgIHJldHVybiBzY29yZSA+IDEgPyAxIDogc2NvcmU7XG4gIH0pLnJlZHVjZShmdW5jdGlvbiAodG90YWwsIHNjb3JlKSB7XG4gICAgcmV0dXJuICh0b3RhbCB8fCAwKSArIHNjb3JlO1xuICB9KSAvIDM7XG59O1xuXG5Eb2NTekNhY2hlLnByb3RvdHlwZS5uZWVkc1VwZGF0ZSA9IGZ1bmN0aW9uIChpdGVtKSB7XG4gIC8vIGhhbmRsZSBuZXdseSBtYWRlIGl0ZW1zXG4gIGlmICghaXRlbS52YWx1ZXMubGVuZ3RoKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cblxuICB2YXIgY3VycmVudFRpbWUgPSBEYXRlLm5vdygpO1xuICB2YXIgdGltZVNpbmNlVXBkYXRlID0gY3VycmVudFRpbWUgLSBpdGVtLnVwZGF0ZWQ7XG4gIGlmICh0aW1lU2luY2VVcGRhdGUgPiAxMDAwKjYwKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cblxuICByZXR1cm4gdGhpcy5nZXRJdGVtU2NvcmUoaXRlbSkgPiAwLjU7XG59O1xuXG5cbkRvY1N6Q2FjaGVJdGVtID0gZnVuY3Rpb24gKG1heFZhbHVlcykge1xuICB0aGlzLm1heFZhbHVlcyA9IG1heFZhbHVlcztcbiAgdGhpcy51cGRhdGVkID0gMDtcbiAgdGhpcy52YWx1ZXMgPSBbXTtcbn1cblxuRG9jU3pDYWNoZUl0ZW0ucHJvdG90eXBlLmFkZERhdGEgPSBmdW5jdGlvbiAodmFsdWUpIHtcbiAgdGhpcy52YWx1ZXMucHVzaCh2YWx1ZSk7XG4gIHRoaXMudXBkYXRlZCA9IERhdGUubm93KCk7XG5cbiAgaWYgKHRoaXMudmFsdWVzLmxlbmd0aCA+IHRoaXMubWF4VmFsdWVzKSB7XG4gICAgdGhpcy52YWx1ZXMuc2hpZnQoKTtcbiAgfVxufTtcblxuRG9jU3pDYWNoZUl0ZW0ucHJvdG90eXBlLmdldFZhbHVlID0gZnVuY3Rpb24gKCkge1xuICBmdW5jdGlvbiBzb3J0TnVtYmVyKGEsIGIpIHtcbiAgICByZXR1cm4gYSAtIGI7XG4gIH1cbiAgdmFyIHNvcnRlZCA9IHRoaXMudmFsdWVzLnNvcnQoc29ydE51bWJlcik7XG4gIHZhciBtZWRpYW4gPSAwO1xuXG4gIGlmIChzb3J0ZWQubGVuZ3RoICUgMiA9PT0gMCkge1xuICAgIHZhciBpZHggPSBzb3J0ZWQubGVuZ3RoIC8gMjtcbiAgICBtZWRpYW4gPSAoc29ydGVkW2lkeF0gKyBzb3J0ZWRbaWR4LTFdKSAvIDI7XG4gIH0gZWxzZSB7XG4gICAgdmFyIGlkeCA9IE1hdGguZmxvb3Ioc29ydGVkLmxlbmd0aCAvIDIpO1xuICAgIG1lZGlhbiA9IHNvcnRlZFtpZHhdO1xuICB9XG5cbiAgcmV0dXJuIG1lZGlhbjtcbn07XG4iLCJpbXBvcnQgSHR0cE1vZGVsIGZyb20gXCIuL21vZGVscy9odHRwXCI7XG5pbXBvcnQgcGFja2FnZU1hcCBmcm9tICcuLy5tZXRlb3ItcGFja2FnZS12ZXJzaW9ucyc7XG5cbnZhciBob3N0bmFtZSA9IE5wbS5yZXF1aXJlKCdvcycpLmhvc3RuYW1lKCk7XG52YXIgbG9nZ2VyID0gTnBtLnJlcXVpcmUoJ2RlYnVnJykoJ2thZGlyYTphcG0nKTtcbnZhciBGaWJlcnMgPSBOcG0ucmVxdWlyZSgnZmliZXJzJyk7XG5cbnZhciBLYWRpcmFDb3JlID0gTnBtLnJlcXVpcmUoJ21vbnRpLWFwbS1jb3JlJykuS2FkaXJhO1xuXG5LYWRpcmEubW9kZWxzID0ge307XG5LYWRpcmEub3B0aW9ucyA9IHt9O1xuS2FkaXJhLmVudiA9IHtcbiAgY3VycmVudFN1YjogbnVsbCwgLy8ga2VlcCBjdXJyZW50IHN1YnNjcmlwdGlvbiBpbnNpZGUgZGRwXG4gIGthZGlyYUluZm86IG5ldyBNZXRlb3IuRW52aXJvbm1lbnRWYXJpYWJsZSgpLFxufTtcbkthZGlyYS53YWl0VGltZUJ1aWxkZXIgPSBuZXcgV2FpdFRpbWVCdWlsZGVyKCk7XG5LYWRpcmEuZXJyb3JzID0gW107XG5LYWRpcmEuZXJyb3JzLmFkZEZpbHRlciA9IEthZGlyYS5lcnJvcnMucHVzaC5iaW5kKEthZGlyYS5lcnJvcnMpO1xuXG5LYWRpcmEubW9kZWxzLm1ldGhvZHMgPSBuZXcgTWV0aG9kc01vZGVsKCk7XG5LYWRpcmEubW9kZWxzLnB1YnN1YiA9IG5ldyBQdWJzdWJNb2RlbCgpO1xuS2FkaXJhLm1vZGVscy5zeXN0ZW0gPSBuZXcgU3lzdGVtTW9kZWwoKTtcbkthZGlyYS5tb2RlbHMuaHR0cCA9IG5ldyBIdHRwTW9kZWwoKTtcbkthZGlyYS5kb2NTekNhY2hlID0gbmV3IERvY1N6Q2FjaGUoMTAwMDAwLCAxMCk7XG5LYWRpcmEuc3luY2VkRGF0ZSA9IG5ldyBOdHAoKTtcblxuLy8gSWYgdGhlIGFnZW50IGlzIG5vdCBjb25uZWN0ZWQsIHdlIHN0aWxsIHdhbnQgdG8gYnVpbGQgdGhlIHBheWxvYWQgb2NjYXNpb25hbGx5XG4vLyBzaW5jZSBidWlsZGluZyB0aGUgcGF5bG9hZCBkb2VzIHNvbWUgY2xlYW51cCB0byBwcmV2ZW50IG1lbW9yeSBsZWFrc1xuLy8gT25jZSBjb25uZWN0ZWQsIHRoaXMgaW50ZXJ2YWwgaXMgY2xlYXJlZFxubGV0IGJ1aWxkSW50ZXJ2YWwgPSBNZXRlb3Iuc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICBLYWRpcmEuX2J1aWxkUGF5bG9hZCgpO1xufSwgMTAwMCAqIDYwKTtcblxuXG5LYWRpcmEuY29ubmVjdCA9IGZ1bmN0aW9uKGFwcElkLCBhcHBTZWNyZXQsIG9wdGlvbnMpIHtcbiAgb3B0aW9ucyA9IG9wdGlvbnMgfHwge307XG4gIG9wdGlvbnMuYXBwSWQgPSBhcHBJZDtcbiAgb3B0aW9ucy5hcHBTZWNyZXQgPSBhcHBTZWNyZXQ7XG4gIG9wdGlvbnMucGF5bG9hZFRpbWVvdXQgPSBvcHRpb25zLnBheWxvYWRUaW1lb3V0IHx8IDEwMDAgKiAyMDtcbiAgb3B0aW9ucy5lbmRwb2ludCA9IG9wdGlvbnMuZW5kcG9pbnQgfHwgXCJodHRwczovL2VuZ2luZS5tb250aWFwbS5jb21cIjtcbiAgb3B0aW9ucy5jbGllbnRFbmdpbmVTeW5jRGVsYXkgPSBvcHRpb25zLmNsaWVudEVuZ2luZVN5bmNEZWxheSB8fCAxMDAwMDtcbiAgb3B0aW9ucy50aHJlc2hvbGRzID0gb3B0aW9ucy50aHJlc2hvbGRzIHx8IHt9O1xuICBvcHRpb25zLmlzSG9zdE5hbWVTZXQgPSAhIW9wdGlvbnMuaG9zdG5hbWU7XG4gIG9wdGlvbnMuaG9zdG5hbWUgPSBvcHRpb25zLmhvc3RuYW1lIHx8IGhvc3RuYW1lO1xuICBvcHRpb25zLnByb3h5ID0gb3B0aW9ucy5wcm94eSB8fCBudWxsO1xuICBvcHRpb25zLnJlY29yZElQQWRkcmVzcyA9IG9wdGlvbnMucmVjb3JkSVBBZGRyZXNzIHx8ICdmdWxsJztcbiAgb3B0aW9ucy5ldmVudFN0YWNrVHJhY2UgPSBvcHRpb25zLmV2ZW50U3RhY2tUcmFjZSB8fCBmYWxzZTtcblxuICBpZihvcHRpb25zLmRvY3VtZW50U2l6ZUNhY2hlU2l6ZSkge1xuICAgIEthZGlyYS5kb2NTekNhY2hlID0gbmV3IERvY1N6Q2FjaGUob3B0aW9ucy5kb2N1bWVudFNpemVDYWNoZVNpemUsIDEwKTtcbiAgfVxuXG4gIC8vIHJlbW92ZSB0cmFpbGluZyBzbGFzaCBmcm9tIGVuZHBvaW50IHVybCAoaWYgYW55KVxuICBpZihfLmxhc3Qob3B0aW9ucy5lbmRwb2ludCkgPT09ICcvJykge1xuICAgIG9wdGlvbnMuZW5kcG9pbnQgPSBvcHRpb25zLmVuZHBvaW50LnN1YnN0cigwLCBvcHRpb25zLmVuZHBvaW50Lmxlbmd0aCAtIDEpO1xuICB9XG5cbiAgLy8gZXJyb3IgdHJhY2tpbmcgaXMgZW5hYmxlZCBieSBkZWZhdWx0XG4gIGlmKG9wdGlvbnMuZW5hYmxlRXJyb3JUcmFja2luZyA9PT0gdW5kZWZpbmVkKSB7XG4gICAgb3B0aW9ucy5lbmFibGVFcnJvclRyYWNraW5nID0gdHJ1ZTtcbiAgfVxuXG4gIC8vIHVwbG9hZGluZyBzb3VyY2VtYXBzIGlzIGVuYWJsZWQgYnkgZGVmYXVsdCBpbiBwcm9kdWN0aW9uXG4gIGlmIChvcHRpb25zLnVwbG9hZFNvdXJjZU1hcHMgPT09IHVuZGVmaW5lZCAmJiBNZXRlb3IuaXNQcm9kdWN0aW9uKSB7XG4gICAgb3B0aW9ucy51cGxvYWRTb3VyY2VNYXBzID0gdHJ1ZTtcbiAgfVxuXG4gIEthZGlyYS5vcHRpb25zID0gb3B0aW9ucztcbiAgS2FkaXJhLm9wdGlvbnMuYXV0aEhlYWRlcnMgPSB7XG4gICAgJ0tBRElSQS1BUFAtSUQnOiBLYWRpcmEub3B0aW9ucy5hcHBJZCxcbiAgICAnS0FESVJBLUFQUC1TRUNSRVQnOiBLYWRpcmEub3B0aW9ucy5hcHBTZWNyZXRcbiAgfTtcblxuICBpZiAoYXBwSWQgJiYgYXBwU2VjcmV0KSB7XG4gICAgb3B0aW9ucy5hcHBJZCA9IG9wdGlvbnMuYXBwSWQudHJpbSgpO1xuICAgIG9wdGlvbnMuYXBwU2VjcmV0ID0gb3B0aW9ucy5hcHBTZWNyZXQudHJpbSgpO1xuXG4gICAgS2FkaXJhLmNvcmVBcGkgPSBuZXcgS2FkaXJhQ29yZSh7XG4gICAgICBhcHBJZDogb3B0aW9ucy5hcHBJZCxcbiAgICAgIGFwcFNlY3JldDogb3B0aW9ucy5hcHBTZWNyZXQsXG4gICAgICBlbmRwb2ludDogb3B0aW9ucy5lbmRwb2ludCxcbiAgICAgIGhvc3RuYW1lOiBvcHRpb25zLmhvc3RuYW1lLFxuICAgICAgYWdlbnRWZXJzaW9uOiBwYWNrYWdlTWFwWydtb250aWFwbTphZ2VudCddIHx8ICc8dW5rbm93bj4nXG4gICAgfSk7XG5cbiAgICBLYWRpcmEuY29yZUFwaS5fY2hlY2tBdXRoKClcbiAgICAgIC50aGVuKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgbG9nZ2VyKCdjb25uZWN0ZWQgdG8gYXBwOiAnLCBhcHBJZCk7XG4gICAgICAgIGNvbnNvbGUubG9nKCdNb250aSBBUE06IFN1Y2Nlc3NmdWxseSBjb25uZWN0ZWQnKTtcbiAgICAgICAgS2FkaXJhLl9zZW5kQXBwU3RhdHMoKTtcbiAgICAgICAgS2FkaXJhLl9zY2hlZHVsZVBheWxvYWRTZW5kKCk7XG4gICAgICB9KVxuICAgICAgLmNhdGNoKGZ1bmN0aW9uIChlcnIpIHtcbiAgICAgICAgaWYgKGVyci5tZXNzYWdlID09PSBcIlVuYXV0aG9yaXplZFwiKSB7XG4gICAgICAgICAgY29uc29sZS5sb2coJ01vbnRpIEFQTTogYXV0aGVudGljYXRpb24gZmFpbGVkIC0gY2hlY2sgeW91ciBhcHBJZCAmIGFwcFNlY3JldCcpXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY29uc29sZS5sb2coJ01vbnRpIEFQTTogdW5hYmxlIHRvIGNvbm5lY3QuICcgKyBlcnIubWVzc2FnZSk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICB9IGVsc2Uge1xuICAgIHRocm93IG5ldyBFcnJvcignTW9udGkgQVBNOiByZXF1aXJlZCBhcHBJZCBhbmQgYXBwU2VjcmV0Jyk7XG4gIH1cblxuICBLYWRpcmEuc3luY2VkRGF0ZSA9IG5ldyBOdHAob3B0aW9ucy5lbmRwb2ludCk7XG4gIEthZGlyYS5zeW5jZWREYXRlLnN5bmMoKTtcbiAgS2FkaXJhLm1vZGVscy5lcnJvciA9IG5ldyBFcnJvck1vZGVsKGFwcElkKTtcblxuICAvLyBoYW5kbGUgcHJlLWFkZGVkIGZpbHRlcnNcbiAgdmFyIGFkZEZpbHRlckZuID0gS2FkaXJhLm1vZGVscy5lcnJvci5hZGRGaWx0ZXIuYmluZChLYWRpcmEubW9kZWxzLmVycm9yKTtcbiAgS2FkaXJhLmVycm9ycy5mb3JFYWNoKGFkZEZpbHRlckZuKTtcbiAgS2FkaXJhLmVycm9ycyA9IEthZGlyYS5tb2RlbHMuZXJyb3I7XG5cbiAgLy8gc2V0dGluZyBydW50aW1lIGluZm8sIHdoaWNoIHdpbGwgYmUgc2VudCB0byBrYWRpcmFcbiAgX19tZXRlb3JfcnVudGltZV9jb25maWdfXy5rYWRpcmEgPSB7XG4gICAgYXBwSWQ6IGFwcElkLFxuICAgIGVuZHBvaW50OiBvcHRpb25zLmVuZHBvaW50LFxuICAgIGNsaWVudEVuZ2luZVN5bmNEZWxheTogb3B0aW9ucy5jbGllbnRFbmdpbmVTeW5jRGVsYXksXG4gICAgcmVjb3JkSVBBZGRyZXNzOiBvcHRpb25zLnJlY29yZElQQWRkcmVzcyxcbiAgfTtcblxuICBpZihvcHRpb25zLmVuYWJsZUVycm9yVHJhY2tpbmcpIHtcbiAgICBLYWRpcmEuZW5hYmxlRXJyb3JUcmFja2luZygpO1xuICB9IGVsc2Uge1xuICAgIEthZGlyYS5kaXNhYmxlRXJyb3JUcmFja2luZygpO1xuICB9XG5cbiAgLy8gc3RhcnQgdHJhY2tpbmcgZXJyb3JzXG4gIE1ldGVvci5zdGFydHVwKGZ1bmN0aW9uICgpIHtcbiAgICBUcmFja1VuY2F1Z2h0RXhjZXB0aW9ucygpO1xuICAgIFRyYWNrVW5oYW5kbGVkUmVqZWN0aW9ucygpO1xuICAgIFRyYWNrTWV0ZW9yRGVidWcoKTtcbiAgfSlcblxuICBNZXRlb3IucHVibGlzaChudWxsLCBmdW5jdGlvbiAoKSB7XG4gICAgdmFyIG9wdGlvbnMgPSBfX21ldGVvcl9ydW50aW1lX2NvbmZpZ19fLmthZGlyYTtcbiAgICB0aGlzLmFkZGVkKCdrYWRpcmFfc2V0dGluZ3MnLCBSYW5kb20uaWQoKSwgb3B0aW9ucyk7XG4gICAgdGhpcy5yZWFkeSgpO1xuICB9KTtcblxuICAvLyBub3RpZnkgd2UndmUgY29ubmVjdGVkXG4gIEthZGlyYS5jb25uZWN0ZWQgPSB0cnVlO1xufTtcblxuLy90cmFjayBob3cgbWFueSB0aW1lcyB3ZSd2ZSBzZW50IHRoZSBkYXRhIChvbmNlIHBlciBtaW51dGUpXG5LYWRpcmEuX2J1aWxkUGF5bG9hZCA9IGZ1bmN0aW9uICgpIHtcbiAgdmFyIHBheWxvYWQgPSB7aG9zdDogS2FkaXJhLm9wdGlvbnMuaG9zdG5hbWUsIGNsaWVudFZlcnNpb25zOiBnZXRDbGllbnRWZXJzaW9ucygpfTtcbiAgdmFyIGJ1aWxkRGV0YWlsZWRJbmZvID0gS2FkaXJhLl9pc0RldGFpbGVkSW5mbygpO1xuICBfLmV4dGVuZChwYXlsb2FkLCBLYWRpcmEubW9kZWxzLm1ldGhvZHMuYnVpbGRQYXlsb2FkKGJ1aWxkRGV0YWlsZWRJbmZvKSk7XG4gIF8uZXh0ZW5kKHBheWxvYWQsIEthZGlyYS5tb2RlbHMucHVic3ViLmJ1aWxkUGF5bG9hZChidWlsZERldGFpbGVkSW5mbykpO1xuICBfLmV4dGVuZChwYXlsb2FkLCBLYWRpcmEubW9kZWxzLnN5c3RlbS5idWlsZFBheWxvYWQoKSk7XG4gIF8uZXh0ZW5kKHBheWxvYWQsIEthZGlyYS5tb2RlbHMuaHR0cC5idWlsZFBheWxvYWQoKSk7XG5cbiAgaWYoS2FkaXJhLm9wdGlvbnMuZW5hYmxlRXJyb3JUcmFja2luZykge1xuICAgIF8uZXh0ZW5kKHBheWxvYWQsIEthZGlyYS5tb2RlbHMuZXJyb3IuYnVpbGRQYXlsb2FkKCkpO1xuICB9XG5cbiAgcmV0dXJuIHBheWxvYWQ7XG59XG5cbkthZGlyYS5fY291bnREYXRhU2VudCA9IDA7XG5LYWRpcmEuX2RldGFpbEluZm9TZW50SW50ZXJ2YWwgPSBNYXRoLmNlaWwoKDEwMDAqNjApIC8gS2FkaXJhLm9wdGlvbnMucGF5bG9hZFRpbWVvdXQpO1xuS2FkaXJhLl9pc0RldGFpbGVkSW5mbyA9IGZ1bmN0aW9uICgpIHtcbiAgcmV0dXJuIChLYWRpcmEuX2NvdW50RGF0YVNlbnQrKyAlIEthZGlyYS5fZGV0YWlsSW5mb1NlbnRJbnRlcnZhbCkgPT0gMDtcbn1cblxuS2FkaXJhLl9zZW5kQXBwU3RhdHMgPSBmdW5jdGlvbiAoKSB7XG4gIHZhciBhcHBTdGF0cyA9IHt9O1xuICBhcHBTdGF0cy5yZWxlYXNlID0gTWV0ZW9yLnJlbGVhc2U7XG4gIGFwcFN0YXRzLnByb3RvY29sVmVyc2lvbiA9ICcxLjAuMCc7XG4gIGFwcFN0YXRzLnBhY2thZ2VWZXJzaW9ucyA9IFtdO1xuICBhcHBTdGF0cy5jbGllbnRWZXJzaW9ucyA9IGdldENsaWVudFZlcnNpb25zKCk7XG5cbiAgXy5lYWNoKFBhY2thZ2UsIGZ1bmN0aW9uICh2LCBuYW1lKSB7XG4gICAgYXBwU3RhdHMucGFja2FnZVZlcnNpb25zLnB1c2goe1xuICAgICAgbmFtZTogbmFtZSxcbiAgICAgIHZlcnNpb246IHBhY2thZ2VNYXBbbmFtZV0gfHwgbnVsbFxuICAgIH0pO1xuICB9KTtcblxuICBLYWRpcmEuY29yZUFwaS5zZW5kRGF0YSh7XG4gICAgc3RhcnRUaW1lOiBuZXcgRGF0ZSgpLFxuICAgIGFwcFN0YXRzOiBhcHBTdGF0c1xuICB9KS50aGVuKGZ1bmN0aW9uKGJvZHkpIHtcbiAgICBoYW5kbGVBcGlSZXNwb25zZShib2R5KTtcbiAgfSkuY2F0Y2goZnVuY3Rpb24oZXJyKSB7XG4gICAgY29uc29sZS5lcnJvcignTW9udGkgQVBNIEVycm9yIG9uIHNlbmRpbmcgYXBwU3RhdHM6JywgZXJyLm1lc3NhZ2UpO1xuICB9KTtcbn1cblxuS2FkaXJhLl9zY2hlZHVsZVBheWxvYWRTZW5kID0gZnVuY3Rpb24gKCkge1xuICBjbGVhckludGVydmFsKGJ1aWxkSW50ZXJ2YWwpO1xuXG4gIHNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xuICAgIEthZGlyYS5fc2NoZWR1bGVQYXlsb2FkU2VuZCgpO1xuICAgIEthZGlyYS5fc2VuZFBheWxvYWQoKTtcbiAgfSwgS2FkaXJhLm9wdGlvbnMucGF5bG9hZFRpbWVvdXQpO1xufVxuXG5LYWRpcmEuX3NlbmRQYXlsb2FkID0gZnVuY3Rpb24gKCkge1xuICBuZXcgRmliZXJzKGZ1bmN0aW9uKCkge1xuICAgIHZhciBwYXlsb2FkID0gS2FkaXJhLl9idWlsZFBheWxvYWQoKTtcbiAgICBLYWRpcmEuY29yZUFwaS5zZW5kRGF0YShwYXlsb2FkKVxuICAgIC50aGVuKGZ1bmN0aW9uIChib2R5KSB7XG4gICAgICBoYW5kbGVBcGlSZXNwb25zZShib2R5KTtcbiAgICB9KVxuICAgIC5jYXRjaChmdW5jdGlvbihlcnIpIHtcbiAgICAgIGNvbnNvbGUubG9nKCdNb250aSBBUE0gRXJyb3I6JywgZXJyLm1lc3NhZ2UpO1xuICAgIH0pO1xuICB9KS5ydW4oKTtcbn1cblxuLy8gdGhpcyByZXR1cm4gdGhlIF9fa2FkaXJhSW5mbyBmcm9tIHRoZSBjdXJyZW50IEZpYmVyIGJ5IGRlZmF1bHRcbi8vIGlmIGNhbGxlZCB3aXRoIDJuZCBhcmd1bWVudCBhcyB0cnVlLCBpdCB3aWxsIGdldCB0aGUga2FkaXJhIGluZm8gZnJvbVxuLy8gTWV0ZW9yLkVudmlyb25tZW50VmFyaWFibGVcbi8vXG4vLyBXQVJOTklORzogcmV0dXJuZWQgaW5mbyBvYmplY3QgaXMgdGhlIHJlZmVyZW5jZSBvYmplY3QuXG4vLyAgQ2hhbmdpbmcgaXQgbWlnaHQgY2F1c2UgaXNzdWVzIHdoZW4gYnVpbGRpbmcgdHJhY2VzLiBTbyB1c2Ugd2l0aCBjYXJlXG5LYWRpcmEuX2dldEluZm8gPSBmdW5jdGlvbihjdXJyZW50RmliZXIsIHVzZUVudmlyb25tZW50VmFyaWFibGUpIHtcbiAgY3VycmVudEZpYmVyID0gY3VycmVudEZpYmVyIHx8IEZpYmVycy5jdXJyZW50O1xuICBpZihjdXJyZW50RmliZXIpIHtcbiAgICBpZih1c2VFbnZpcm9ubWVudFZhcmlhYmxlKSB7XG4gICAgICByZXR1cm4gS2FkaXJhLmVudi5rYWRpcmFJbmZvLmdldCgpO1xuICAgIH1cbiAgICByZXR1cm4gY3VycmVudEZpYmVyLl9fa2FkaXJhSW5mbztcbiAgfVxufTtcblxuLy8gdGhpcyBkb2VzIG5vdCBjbG9uZSB0aGUgaW5mbyBvYmplY3QuIFNvLCB1c2Ugd2l0aCBjYXJlXG5LYWRpcmEuX3NldEluZm8gPSBmdW5jdGlvbihpbmZvKSB7XG4gIEZpYmVycy5jdXJyZW50Ll9fa2FkaXJhSW5mbyA9IGluZm87XG59O1xuXG5LYWRpcmEuc3RhcnRDb250aW51b3VzUHJvZmlsaW5nID0gZnVuY3Rpb24gKCkge1xuICBNb250aVByb2ZpbGVyLnN0YXJ0Q29udGludW91cyhmdW5jdGlvbiBvblByb2ZpbGUoeyBwcm9maWxlLCBzdGFydFRpbWUsIGVuZFRpbWUgfSkge1xuICAgIGlmICghS2FkaXJhLmNvbm5lY3RlZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIEthZGlyYS5jb3JlQXBpLnNlbmREYXRhKHsgcHJvZmlsZXM6IFt7cHJvZmlsZSwgc3RhcnRUaW1lLCBlbmRUaW1lIH1dfSlcbiAgICAgIC5jYXRjaChlID0+IGNvbnNvbGUubG9nKCdNb250aTogZXJyIHNlbmRpbmcgY3B1IHByb2ZpbGUnLCBlKSk7XG4gIH0pO1xufVxuXG5LYWRpcmEuZW5hYmxlRXJyb3JUcmFja2luZyA9IGZ1bmN0aW9uICgpIHtcbiAgX19tZXRlb3JfcnVudGltZV9jb25maWdfXy5rYWRpcmEuZW5hYmxlRXJyb3JUcmFja2luZyA9IHRydWU7XG4gIEthZGlyYS5vcHRpb25zLmVuYWJsZUVycm9yVHJhY2tpbmcgPSB0cnVlO1xufTtcblxuS2FkaXJhLmRpc2FibGVFcnJvclRyYWNraW5nID0gZnVuY3Rpb24gKCkge1xuICBfX21ldGVvcl9ydW50aW1lX2NvbmZpZ19fLmthZGlyYS5lbmFibGVFcnJvclRyYWNraW5nID0gZmFsc2U7XG4gIEthZGlyYS5vcHRpb25zLmVuYWJsZUVycm9yVHJhY2tpbmcgPSBmYWxzZTtcbn07XG5cbkthZGlyYS50cmFja0Vycm9yID0gZnVuY3Rpb24gKHR5cGUsIG1lc3NhZ2UsIG9wdGlvbnMpIHtcbiAgaWYoS2FkaXJhLm9wdGlvbnMuZW5hYmxlRXJyb3JUcmFja2luZyAmJiB0eXBlICYmIG1lc3NhZ2UpIHtcbiAgICBvcHRpb25zID0gb3B0aW9ucyB8fCB7fTtcbiAgICBvcHRpb25zLnN1YlR5cGUgPSBvcHRpb25zLnN1YlR5cGUgfHwgJ3NlcnZlcic7XG4gICAgb3B0aW9ucy5zdGFja3MgPSBvcHRpb25zLnN0YWNrcyB8fCAnJztcbiAgICB2YXIgZXJyb3IgPSB7bWVzc2FnZTogbWVzc2FnZSwgc3RhY2s6IG9wdGlvbnMuc3RhY2tzfTtcbiAgICB2YXIgdHJhY2UgPSB7XG4gICAgICB0eXBlOiB0eXBlLFxuICAgICAgc3ViVHlwZTogb3B0aW9ucy5zdWJUeXBlLFxuICAgICAgbmFtZTogbWVzc2FnZSxcbiAgICAgIGVycm9yZWQ6IHRydWUsXG4gICAgICBhdDogS2FkaXJhLnN5bmNlZERhdGUuZ2V0VGltZSgpLFxuICAgICAgZXZlbnRzOiBbWydzdGFydCcsIDAsIHt9XSwgWydlcnJvcicsIDAsIHtlcnJvcjogZXJyb3J9XV0sXG4gICAgICBtZXRyaWNzOiB7dG90YWw6IDB9XG4gICAgfTtcbiAgICBLYWRpcmEubW9kZWxzLmVycm9yLnRyYWNrRXJyb3IoZXJyb3IsIHRyYWNlKTtcbiAgfVxufVxuXG5LYWRpcmEuaWdub3JlRXJyb3JUcmFja2luZyA9IGZ1bmN0aW9uIChlcnIpIHtcbiAgZXJyLl9za2lwS2FkaXJhID0gdHJ1ZTtcbn1cblxuS2FkaXJhLnN0YXJ0RXZlbnQgPSBmdW5jdGlvbiAobmFtZSwgZGF0YSA9IHt9KSB7XG4gIHZhciBrYWRpcmFJbmZvID0gS2FkaXJhLl9nZXRJbmZvKCk7XG4gIGlmKGthZGlyYUluZm8pIHtcbiAgICByZXR1cm4gS2FkaXJhLnRyYWNlci5ldmVudChrYWRpcmFJbmZvLnRyYWNlLCAnY3VzdG9tJywgZGF0YSwgeyBuYW1lIH0pO1xuICB9XG5cbiAgcmV0dXJuIGZhbHNlXG59XG5cbkthZGlyYS5lbmRFdmVudCA9IGZ1bmN0aW9uIChldmVudCwgZGF0YSkge1xuICB2YXIga2FkaXJhSW5mbyA9IEthZGlyYS5fZ2V0SW5mbygpO1xuXG4gIC8vIFRoZSBldmVudCBjb3VsZCBiZSBmYWxzZSBpZiBpdCBjb3VsZCBub3QgYmUgc3RhcnRlZC5cbiAgLy8gSGFuZGxlIGl0IGhlcmUgaW5zdGVhZCBvZiByZXF1aXJpbmcgdGhlIGFwcCB0by5cbiAgaWYgKGthZGlyYUluZm8gJiYgZXZlbnQpIHtcbiAgICBLYWRpcmEudHJhY2VyLmV2ZW50RW5kKGthZGlyYUluZm8udHJhY2UsIGV2ZW50LCBkYXRhKTtcbiAgfVxufVxuIiwidmFyIEZpYmVyID0gTnBtLnJlcXVpcmUoJ2ZpYmVycycpO1xuXG53cmFwU2VydmVyID0gZnVuY3Rpb24oc2VydmVyUHJvdG8pIHtcbiAgdmFyIG9yaWdpbmFsSGFuZGxlQ29ubmVjdCA9IHNlcnZlclByb3RvLl9oYW5kbGVDb25uZWN0XG4gIHNlcnZlclByb3RvLl9oYW5kbGVDb25uZWN0ID0gZnVuY3Rpb24oc29ja2V0LCBtc2cpIHtcbiAgICBvcmlnaW5hbEhhbmRsZUNvbm5lY3QuY2FsbCh0aGlzLCBzb2NrZXQsIG1zZyk7XG4gICAgdmFyIHNlc3Npb24gPSBzb2NrZXQuX21ldGVvclNlc3Npb247XG4gICAgLy8gc29tZXRpbWVzIGl0IGlzIHBvc3NpYmxlIGZvciBfbWV0ZW9yU2Vzc2lvbiB0byBiZSB1bmRlZmluZWRcbiAgICAvLyBvbmUgc3VjaCByZWFzb24gd291bGQgYmUgaWYgRERQIHZlcnNpb25zIGFyZSBub3QgbWF0Y2hpbmdcbiAgICAvLyBpZiB0aGVuLCB3ZSBzaG91bGQgbm90IHByb2Nlc3MgaXRcbiAgICBpZighc2Vzc2lvbikge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIEthZGlyYS5FdmVudEJ1cy5lbWl0KCdzeXN0ZW0nLCAnY3JlYXRlU2Vzc2lvbicsIG1zZywgc29ja2V0Ll9tZXRlb3JTZXNzaW9uKTtcblxuICAgIGlmKEthZGlyYS5jb25uZWN0ZWQpIHtcbiAgICAgIEthZGlyYS5tb2RlbHMuc3lzdGVtLmhhbmRsZVNlc3Npb25BY3Rpdml0eShtc2csIHNvY2tldC5fbWV0ZW9yU2Vzc2lvbik7XG4gICAgfVxuICB9O1xufTtcbiIsImltcG9ydCB7IE1ldGVvckRlYnVnSWdub3JlIH0gZnJvbSBcIi4vZXJyb3JcIjtcblxuY29uc3QgTUFYX1BBUkFNU19MRU5HVEggPSA0MDAwXG5cbndyYXBTZXNzaW9uID0gZnVuY3Rpb24oc2Vzc2lvblByb3RvKSB7XG4gIHZhciBvcmlnaW5hbFByb2Nlc3NNZXNzYWdlID0gc2Vzc2lvblByb3RvLnByb2Nlc3NNZXNzYWdlO1xuICBzZXNzaW9uUHJvdG8ucHJvY2Vzc01lc3NhZ2UgPSBmdW5jdGlvbihtc2cpIHtcbiAgICBpZih0cnVlKSB7XG4gICAgICB2YXIga2FkaXJhSW5mbyA9IHtcbiAgICAgICAgc2Vzc2lvbjogdGhpcy5pZCxcbiAgICAgICAgdXNlcklkOiB0aGlzLnVzZXJJZFxuICAgICAgfTtcblxuICAgICAgaWYobXNnLm1zZyA9PSAnbWV0aG9kJyB8fCBtc2cubXNnID09ICdzdWInKSB7XG4gICAgICAgIGthZGlyYUluZm8udHJhY2UgPSBLYWRpcmEudHJhY2VyLnN0YXJ0KHRoaXMsIG1zZyk7XG4gICAgICAgIEthZGlyYS53YWl0VGltZUJ1aWxkZXIucmVnaXN0ZXIodGhpcywgbXNnLmlkKTtcblxuICAgICAgICBsZXQgcGFyYW1zID0gS2FkaXJhLnRyYWNlci5fYXBwbHlPYmplY3RGaWx0ZXJzKG1zZy5wYXJhbXMgfHwgW10pO1xuICAgICAgICAvLyB1c2UgSlNPTiBpbnN0ZWFkIG9mIEVKU09OIHRvIHNhdmUgdGhlIENQVVxuICAgICAgICBsZXQgc3RyaW5naWZpZWRQYXJhbXMgPSBKU09OLnN0cmluZ2lmeShwYXJhbXMpO1xuXG4gICAgICAgIC8vIFRoZSBwYXJhbXMgY291bGQgYmUgc2V2ZXJhbCBtYiBvciBsYXJnZXIuXG4gICAgICAgIC8vIFRydW5jYXRlIGlmIGl0IGlzIGxhcmdlXG4gICAgICAgIGlmIChzdHJpbmdpZmllZFBhcmFtcy5sZW5ndGggPiBNQVhfUEFSQU1TX0xFTkdUSCkge1xuICAgICAgICAgIHN0cmluZ2lmaWVkUGFyYW1zID0gYE1vbnRpIEFQTTogcGFyYW1zIGFyZSB0b28gYmlnLiBGaXJzdCAke01BWF9QQVJBTVNfTEVOR1RIfSBjaGFyYWN0ZXJzOiAke3N0cmluZ2lmaWVkUGFyYW1zLnNsaWNlKDAsIE1BWF9QQVJBTVNfTEVOR1RIKX1gO1xuICAgICAgICB9XG5cbiAgICAgICAgdmFyIHN0YXJ0RGF0YSA9IHsgdXNlcklkOiB0aGlzLnVzZXJJZCwgcGFyYW1zOiBzdHJpbmdpZmllZFBhcmFtcyB9O1xuICAgICAgICBLYWRpcmEudHJhY2VyLmV2ZW50KGthZGlyYUluZm8udHJhY2UsICdzdGFydCcsIHN0YXJ0RGF0YSk7XG4gICAgICAgIHZhciB3YWl0RXZlbnRJZCA9IEthZGlyYS50cmFjZXIuZXZlbnQoa2FkaXJhSW5mby50cmFjZSwgJ3dhaXQnLCB7fSwga2FkaXJhSW5mbyk7XG4gICAgICAgIG1zZy5fd2FpdEV2ZW50SWQgPSB3YWl0RXZlbnRJZDtcbiAgICAgICAgbXNnLl9fa2FkaXJhSW5mbyA9IGthZGlyYUluZm87XG5cbiAgICAgICAgaWYobXNnLm1zZyA9PSAnc3ViJykge1xuICAgICAgICAgIC8vIHN0YXJ0IHRyYWNraW5nIGluc2lkZSBwcm9jZXNzTWVzc2FnZSBhbGxvd3MgdXMgdG8gaW5kaWNhdGVcbiAgICAgICAgICAvLyB3YWl0IHRpbWUgYXMgd2VsbFxuICAgICAgICAgIEthZGlyYS5FdmVudEJ1cy5lbWl0KCdwdWJzdWInLCAnc3ViUmVjZWl2ZWQnLCB0aGlzLCBtc2cpO1xuICAgICAgICAgIEthZGlyYS5tb2RlbHMucHVic3ViLl90cmFja1N1Yih0aGlzLCBtc2cpO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIC8vIFVwZGF0ZSBzZXNzaW9uIGxhc3QgYWN0aXZlIHRpbWVcbiAgICAgIEthZGlyYS5FdmVudEJ1cy5lbWl0KCdzeXN0ZW0nLCAnZGRwTWVzc2FnZVJlY2VpdmVkJywgdGhpcywgbXNnKTtcbiAgICAgIEthZGlyYS5tb2RlbHMuc3lzdGVtLmhhbmRsZVNlc3Npb25BY3Rpdml0eShtc2csIHRoaXMpO1xuICAgIH1cblxuICAgIHJldHVybiBvcmlnaW5hbFByb2Nlc3NNZXNzYWdlLmNhbGwodGhpcywgbXNnKTtcbiAgfTtcblxuICAvLyBhZGRpbmcgdGhlIG1ldGhvZCBjb250ZXh0IHRvIHRoZSBjdXJyZW50IGZpYmVyXG4gIHZhciBvcmlnaW5hbE1ldGhvZEhhbmRsZXIgPSBzZXNzaW9uUHJvdG8ucHJvdG9jb2xfaGFuZGxlcnMubWV0aG9kO1xuICBzZXNzaW9uUHJvdG8ucHJvdG9jb2xfaGFuZGxlcnMubWV0aG9kID0gZnVuY3Rpb24obXNnLCB1bmJsb2NrKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgIC8vYWRkIGNvbnRleHRcbiAgICB2YXIga2FkaXJhSW5mbyA9IG1zZy5fX2thZGlyYUluZm87XG4gICAgaWYoa2FkaXJhSW5mbykge1xuICAgICAgS2FkaXJhLl9zZXRJbmZvKGthZGlyYUluZm8pO1xuXG4gICAgICAvLyBlbmQgd2FpdCBldmVudFxuICAgICAgdmFyIHdhaXRMaXN0ID0gS2FkaXJhLndhaXRUaW1lQnVpbGRlci5idWlsZCh0aGlzLCBtc2cuaWQpO1xuICAgICAgS2FkaXJhLnRyYWNlci5ldmVudEVuZChrYWRpcmFJbmZvLnRyYWNlLCBtc2cuX3dhaXRFdmVudElkLCB7d2FpdE9uOiB3YWl0TGlzdH0pO1xuXG4gICAgICB1bmJsb2NrID0gS2FkaXJhLndhaXRUaW1lQnVpbGRlci50cmFja1dhaXRUaW1lKHRoaXMsIG1zZywgdW5ibG9jayk7XG4gICAgICB2YXIgcmVzcG9uc2UgPSBLYWRpcmEuZW52LmthZGlyYUluZm8ud2l0aFZhbHVlKGthZGlyYUluZm8sIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuIG9yaWdpbmFsTWV0aG9kSGFuZGxlci5jYWxsKHNlbGYsIG1zZywgdW5ibG9jayk7XG4gICAgICB9KTtcbiAgICAgIHVuYmxvY2soKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdmFyIHJlc3BvbnNlID0gb3JpZ2luYWxNZXRob2RIYW5kbGVyLmNhbGwoc2VsZiwgbXNnLCB1bmJsb2NrKTtcbiAgICB9XG5cbiAgICByZXR1cm4gcmVzcG9uc2U7XG4gIH07XG5cbiAgLy90byBjYXB0dXJlIHRoZSBjdXJyZW50bHkgcHJvY2Vzc2luZyBtZXNzYWdlXG4gIHZhciBvcmdpbmFsU3ViSGFuZGxlciA9IHNlc3Npb25Qcm90by5wcm90b2NvbF9oYW5kbGVycy5zdWI7XG4gIHNlc3Npb25Qcm90by5wcm90b2NvbF9oYW5kbGVycy5zdWIgPSBmdW5jdGlvbihtc2csIHVuYmxvY2spIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgLy9hZGQgY29udGV4dFxuICAgIHZhciBrYWRpcmFJbmZvID0gbXNnLl9fa2FkaXJhSW5mbztcbiAgICBpZihrYWRpcmFJbmZvKSB7XG4gICAgICBLYWRpcmEuX3NldEluZm8oa2FkaXJhSW5mbyk7XG5cbiAgICAgIC8vIGVuZCB3YWl0IGV2ZW50XG4gICAgICB2YXIgd2FpdExpc3QgPSBLYWRpcmEud2FpdFRpbWVCdWlsZGVyLmJ1aWxkKHRoaXMsIG1zZy5pZCk7XG4gICAgICBLYWRpcmEudHJhY2VyLmV2ZW50RW5kKGthZGlyYUluZm8udHJhY2UsIG1zZy5fd2FpdEV2ZW50SWQsIHt3YWl0T246IHdhaXRMaXN0fSk7XG5cbiAgICAgIHVuYmxvY2sgPSBLYWRpcmEud2FpdFRpbWVCdWlsZGVyLnRyYWNrV2FpdFRpbWUodGhpcywgbXNnLCB1bmJsb2NrKTtcbiAgICAgIHZhciByZXNwb25zZSA9IEthZGlyYS5lbnYua2FkaXJhSW5mby53aXRoVmFsdWUoa2FkaXJhSW5mbywgZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gb3JnaW5hbFN1YkhhbmRsZXIuY2FsbChzZWxmLCBtc2csIHVuYmxvY2spO1xuICAgICAgfSk7XG4gICAgICB1bmJsb2NrKCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHZhciByZXNwb25zZSA9IG9yZ2luYWxTdWJIYW5kbGVyLmNhbGwoc2VsZiwgbXNnLCB1bmJsb2NrKTtcbiAgICB9XG5cbiAgICByZXR1cm4gcmVzcG9uc2U7XG4gIH07XG5cbiAgLy90byBjYXB0dXJlIHRoZSBjdXJyZW50bHkgcHJvY2Vzc2luZyBtZXNzYWdlXG4gIHZhciBvcmdpbmFsVW5TdWJIYW5kbGVyID0gc2Vzc2lvblByb3RvLnByb3RvY29sX2hhbmRsZXJzLnVuc3ViO1xuICBzZXNzaW9uUHJvdG8ucHJvdG9jb2xfaGFuZGxlcnMudW5zdWIgPSBmdW5jdGlvbihtc2csIHVuYmxvY2spIHtcbiAgICB1bmJsb2NrID0gS2FkaXJhLndhaXRUaW1lQnVpbGRlci50cmFja1dhaXRUaW1lKHRoaXMsIG1zZywgdW5ibG9jayk7XG4gICAgdmFyIHJlc3BvbnNlID0gb3JnaW5hbFVuU3ViSGFuZGxlci5jYWxsKHRoaXMsIG1zZywgdW5ibG9jayk7XG4gICAgdW5ibG9jaygpO1xuICAgIHJldHVybiByZXNwb25zZTtcbiAgfTtcblxuICAvL3RyYWNrIG1ldGhvZCBlbmRpbmcgKHRvIGdldCB0aGUgcmVzdWx0IG9mIGVycm9yKVxuICB2YXIgb3JpZ2luYWxTZW5kID0gc2Vzc2lvblByb3RvLnNlbmQ7XG4gIHNlc3Npb25Qcm90by5zZW5kID0gZnVuY3Rpb24obXNnKSB7XG4gICAgaWYobXNnLm1zZyA9PSAncmVzdWx0Jykge1xuICAgICAgdmFyIGthZGlyYUluZm8gPSBLYWRpcmEuX2dldEluZm8oKTtcbiAgICAgIGlmKGthZGlyYUluZm8pIHtcbiAgICAgICAgaWYobXNnLmVycm9yKSB7XG4gICAgICAgICAgdmFyIGVycm9yID0gXy5waWNrKG1zZy5lcnJvciwgWydtZXNzYWdlJywgJ3N0YWNrJywgJ2RldGFpbHMnXSk7XG5cbiAgICAgICAgICAvLyBwaWNrIHRoZSBlcnJvciBmcm9tIHRoZSB3cmFwcGVkIG1ldGhvZCBoYW5kbGVyXG4gICAgICAgICAgaWYoa2FkaXJhSW5mbyAmJiBrYWRpcmFJbmZvLmN1cnJlbnRFcnJvcikge1xuICAgICAgICAgICAgLy8gdGhlIGVycm9yIHN0YWNrIGlzIHdyYXBwZWQgc28gTWV0ZW9yLl9kZWJ1ZyBjYW4gaWRlbnRpZnlcbiAgICAgICAgICAgIC8vIHRoaXMgYXMgYSBtZXRob2QgZXJyb3IuXG4gICAgICAgICAgICBlcnJvciA9IF8ucGljayhrYWRpcmFJbmZvLmN1cnJlbnRFcnJvciwgWydtZXNzYWdlJywgJ3N0YWNrJywgJ2RldGFpbHMnXSk7XG4gICAgICAgICAgICAvLyBzZWUgd3JhcE1ldGhvZEhhbmRlckZvckVycm9ycygpIG1ldGhvZCBkZWYgZm9yIG1vcmUgaW5mb1xuICAgICAgICAgICAgaWYoZXJyb3Iuc3RhY2sgJiYgZXJyb3Iuc3RhY2suc3RhY2spIHtcbiAgICAgICAgICAgICAgZXJyb3Iuc3RhY2sgPSBlcnJvci5zdGFjay5zdGFjaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG5cbiAgICAgICAgICBLYWRpcmEudHJhY2VyLmVuZExhc3RFdmVudChrYWRpcmFJbmZvLnRyYWNlKTtcbiAgICAgICAgICBLYWRpcmEudHJhY2VyLmV2ZW50KGthZGlyYUluZm8udHJhY2UsICdlcnJvcicsIHtlcnJvcjogZXJyb3J9KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBLYWRpcmEudHJhY2VyLmVuZExhc3RFdmVudChrYWRpcmFJbmZvLnRyYWNlKTtcbiAgICAgICAgICBLYWRpcmEudHJhY2VyLmV2ZW50KGthZGlyYUluZm8udHJhY2UsICdjb21wbGV0ZScpO1xuICAgICAgICB9XG5cbiAgICAgICAgLy9wcm9jZXNzaW5nIHRoZSBtZXNzYWdlXG4gICAgICAgIHZhciB0cmFjZSA9IEthZGlyYS50cmFjZXIuYnVpbGRUcmFjZShrYWRpcmFJbmZvLnRyYWNlKTtcbiAgICAgICAgS2FkaXJhLkV2ZW50QnVzLmVtaXQoJ21ldGhvZCcsICdtZXRob2RDb21wbGV0ZWQnLCB0cmFjZSwgdGhpcyk7XG4gICAgICAgIEthZGlyYS5tb2RlbHMubWV0aG9kcy5wcm9jZXNzTWV0aG9kKHRyYWNlKTtcblxuICAgICAgICAvLyBlcnJvciBtYXkgb3IgbWF5IG5vdCBleGlzdCBhbmQgZXJyb3IgdHJhY2tpbmcgY2FuIGJlIGRpc2FibGVkXG4gICAgICAgIGlmKGVycm9yICYmIEthZGlyYS5vcHRpb25zLmVuYWJsZUVycm9yVHJhY2tpbmcpIHtcbiAgICAgICAgICBLYWRpcmEubW9kZWxzLmVycm9yLnRyYWNrRXJyb3IoZXJyb3IsIHRyYWNlKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vY2xlYW4gYW5kIG1ha2Ugc3VyZSwgZmliZXIgaXMgY2xlYW5cbiAgICAgICAgLy9ub3Qgc3VyZSB3ZSBuZWVkIHRvIGRvIHRoaXMsIGJ1dCBhIHByZXZlbnRpdmUgbWVhc3VyZVxuICAgICAgICBLYWRpcmEuX3NldEluZm8obnVsbCk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIG9yaWdpbmFsU2VuZC5jYWxsKHRoaXMsIG1zZyk7XG4gIH07XG59O1xuXG4vLyB3cmFwIGV4aXN0aW5nIG1ldGhvZCBoYW5kbGVycyBmb3IgY2FwdHVyaW5nIGVycm9yc1xuXy5lYWNoKE1ldGVvci5zZXJ2ZXIubWV0aG9kX2hhbmRsZXJzLCBmdW5jdGlvbihoYW5kbGVyLCBuYW1lKSB7XG4gIHdyYXBNZXRob2RIYW5kZXJGb3JFcnJvcnMobmFtZSwgaGFuZGxlciwgTWV0ZW9yLnNlcnZlci5tZXRob2RfaGFuZGxlcnMpO1xufSk7XG5cbi8vIHdyYXAgZnV0dXJlIG1ldGhvZCBoYW5kbGVycyBmb3IgY2FwdHVyaW5nIGVycm9yc1xudmFyIG9yaWdpbmFsTWV0ZW9yTWV0aG9kcyA9IE1ldGVvci5tZXRob2RzO1xuTWV0ZW9yLm1ldGhvZHMgPSBmdW5jdGlvbihtZXRob2RNYXApIHtcbiAgXy5lYWNoKG1ldGhvZE1hcCwgZnVuY3Rpb24oaGFuZGxlciwgbmFtZSkge1xuICAgIHdyYXBNZXRob2RIYW5kZXJGb3JFcnJvcnMobmFtZSwgaGFuZGxlciwgbWV0aG9kTWFwKTtcbiAgfSk7XG4gIG9yaWdpbmFsTWV0ZW9yTWV0aG9kcyhtZXRob2RNYXApO1xufTtcblxuXG5mdW5jdGlvbiB3cmFwTWV0aG9kSGFuZGVyRm9yRXJyb3JzKG5hbWUsIG9yaWdpbmFsSGFuZGxlciwgbWV0aG9kTWFwKSB7XG4gIG1ldGhvZE1hcFtuYW1lXSA9IGZ1bmN0aW9uKCkge1xuICAgIHRyeXtcbiAgICAgIHJldHVybiBvcmlnaW5hbEhhbmRsZXIuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbiAgICB9IGNhdGNoKGV4KSB7XG4gICAgICBpZihleCAmJiBLYWRpcmEuX2dldEluZm8oKSkge1xuICAgICAgICAvLyBzb21ldGltZXMgZXJyb3IgbWF5IGJlIGp1c3QgYW4gc3RyaW5nIG9yIGEgcHJpbWl0aXZlXG4gICAgICAgIC8vIGluIHRoYXQgY2FzZSwgd2UgbmVlZCB0byBtYWtlIGl0IGEgcHN1ZWRvIGVycm9yXG4gICAgICAgIGlmKHR5cGVvZiBleCAhPT0gJ29iamVjdCcpIHtcbiAgICAgICAgICBleCA9IHttZXNzYWdlOiBleCwgc3RhY2s6IGV4fTtcbiAgICAgICAgfVxuICAgICAgICAvLyBOb3cgd2UgYXJlIG1hcmtpbmcgdGhpcyBlcnJvciB0byBnZXQgdHJhY2tlZCB2aWEgbWV0aG9kc1xuICAgICAgICAvLyBCdXQsIHRoaXMgYWxzbyB0cmlnZ2VycyBhIE1ldGVvci5kZWJ1ZyBjYWxsIGFuZFxuICAgICAgICAvLyBpdCBvbmx5IGdldHMgdGhlIHN0YWNrXG4gICAgICAgIC8vIFdlIGFsc28gdHJhY2sgTWV0ZW9yLmRlYnVnIGVycm9ycyBhbmQgd2FudCB0byBzdG9wXG4gICAgICAgIC8vIHRyYWNraW5nIHRoaXMgZXJyb3IuIFRoYXQncyB3aHkgd2UgZG8gdGhpc1xuICAgICAgICAvLyBTZWUgTWV0ZW9yLmRlYnVnIGVycm9yIHRyYWNraW5nIGNvZGUgZm9yIG1vcmVcbiAgICAgICAgLy8gSWYgZXJyb3IgdHJhY2tpbmcgaXMgZGlzYWJsZWQsIHdlIGRvIG5vdCBtb2RpZnkgdGhlIHN0YWNrIHNpbmNlXG4gICAgICAgIC8vIGl0IHdvdWxkIGJlIHNob3duIGFzIGFuIG9iamVjdCBpbiB0aGUgbG9nc1xuICAgICAgICBpZiAoS2FkaXJhLm9wdGlvbnMuZW5hYmxlRXJyb3JUcmFja2luZykge1xuICAgICAgICAgIGV4LnN0YWNrID0ge3N0YWNrOiBleC5zdGFjaywgc291cmNlOiAnbWV0aG9kJywgW01ldGVvckRlYnVnSWdub3JlXTogdHJ1ZX07XG4gICAgICAgICAgS2FkaXJhLl9nZXRJbmZvKCkuY3VycmVudEVycm9yID0gZXg7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHRocm93IGV4O1xuICAgIH1cbiAgfVxufVxuIiwiaW1wb3J0IHsgTWV0ZW9yRGVidWdJZ25vcmUgfSBmcm9tIFwiLi9lcnJvclwiO1xuXG53cmFwU3Vic2NyaXB0aW9uID0gZnVuY3Rpb24oc3Vic2NyaXB0aW9uUHJvdG8pIHtcbiAgLy8gSWYgdGhlIHJlYWR5IGV2ZW50IHJ1bnMgb3V0c2lkZSB0aGUgRmliZXIsIEthZGlyYS5fZ2V0SW5mbygpIGRvZXNuJ3Qgd29yay5cbiAgLy8gd2UgbmVlZCBzb21lIG90aGVyIHdheSB0byBzdG9yZSBrYWRpcmFJbmZvIHNvIHdlIGNhbiB1c2UgaXQgYXQgcmVhZHkgaGlqYWNrLlxuICB2YXIgb3JpZ2luYWxSdW5IYW5kbGVyID0gc3Vic2NyaXB0aW9uUHJvdG8uX3J1bkhhbmRsZXI7XG4gIHN1YnNjcmlwdGlvblByb3RvLl9ydW5IYW5kbGVyID0gZnVuY3Rpb24oKSB7XG4gICAgdmFyIGthZGlyYUluZm8gPSBLYWRpcmEuX2dldEluZm8oKTtcbiAgICBpZiAoa2FkaXJhSW5mbykge1xuICAgICAgdGhpcy5fX2thZGlyYUluZm8gPSBrYWRpcmFJbmZvO1xuICAgIH07XG4gICAgb3JpZ2luYWxSdW5IYW5kbGVyLmNhbGwodGhpcyk7XG4gIH1cblxuICB2YXIgb3JpZ2luYWxSZWFkeSA9IHN1YnNjcmlwdGlvblByb3RvLnJlYWR5O1xuICBzdWJzY3JpcHRpb25Qcm90by5yZWFkeSA9IGZ1bmN0aW9uKCkge1xuICAgIC8vIG1ldGVvciBoYXMgYSBmaWVsZCBjYWxsZWQgYF9yZWFkeWAgd2hpY2ggdHJhY2tzIHRoaXNcbiAgICAvLyBidXQgd2UgbmVlZCB0byBtYWtlIGl0IGZ1dHVyZSBwcm9vZlxuICAgIGlmKCF0aGlzLl9hcG1SZWFkeVRyYWNrZWQpIHtcbiAgICAgIHZhciBrYWRpcmFJbmZvID0gS2FkaXJhLl9nZXRJbmZvKCkgfHwgdGhpcy5fX2thZGlyYUluZm87XG4gICAgICBkZWxldGUgdGhpcy5fX2thZGlyYUluZm87XG4gICAgICAvL3NvbWV0aW1lIC5yZWFkeSBjYW4gYmUgY2FsbGVkIGluIHRoZSBjb250ZXh0IG9mIHRoZSBtZXRob2RcbiAgICAgIC8vdGhlbiB3ZSBoYXZlIHNvbWUgcHJvYmxlbXMsIHRoYXQncyB3aHkgd2UgYXJlIGNoZWNraW5nIHRoaXNcbiAgICAgIC8vZWc6LSBBY2NvdW50cy5jcmVhdGVVc2VyXG4gICAgICAvLyBBbHNvLCB3aGVuIHRoZSBzdWJzY3JpcHRpb24gaXMgY3JlYXRlZCBieSBmYXN0IHJlbmRlciwgX3N1YnNjcmlwdGlvbklkIGFuZFxuICAgICAgLy8gdGhlIHRyYWNlLmlkIGFyZSBib3RoIHVuZGVmaW5lZCBidXQgd2UgZG9uJ3Qgd2FudCB0byBjb21wbGV0ZSB0aGUgSFRUUCB0cmFjZSBoZXJlXG4gICAgICBpZihrYWRpcmFJbmZvICYmIHRoaXMuX3N1YnNjcmlwdGlvbklkICYmIHRoaXMuX3N1YnNjcmlwdGlvbklkID09IGthZGlyYUluZm8udHJhY2UuaWQpIHtcbiAgICAgICAgS2FkaXJhLnRyYWNlci5lbmRMYXN0RXZlbnQoa2FkaXJhSW5mby50cmFjZSk7XG4gICAgICAgIEthZGlyYS50cmFjZXIuZXZlbnQoa2FkaXJhSW5mby50cmFjZSwgJ2NvbXBsZXRlJyk7XG4gICAgICAgIHZhciB0cmFjZSA9IEthZGlyYS50cmFjZXIuYnVpbGRUcmFjZShrYWRpcmFJbmZvLnRyYWNlKTtcbiAgICAgIH1cblxuICAgICAgS2FkaXJhLkV2ZW50QnVzLmVtaXQoJ3B1YnN1YicsICdzdWJDb21wbGV0ZWQnLCB0cmFjZSwgdGhpcy5fc2Vzc2lvbiwgdGhpcyk7XG4gICAgICBLYWRpcmEubW9kZWxzLnB1YnN1Yi5fdHJhY2tSZWFkeSh0aGlzLl9zZXNzaW9uLCB0aGlzLCB0cmFjZSk7XG4gICAgICB0aGlzLl9hcG1SZWFkeVRyYWNrZWQgPSB0cnVlO1xuICAgIH1cblxuICAgIC8vIHdlIHN0aWxsIHBhc3MgdGhlIGNvbnRyb2wgdG8gdGhlIG9yaWdpbmFsIGltcGxlbWVudGF0aW9uXG4gICAgLy8gc2luY2UgbXVsdGlwbGUgcmVhZHkgY2FsbHMgYXJlIGhhbmRsZWQgYnkgaXRzZWxmXG4gICAgb3JpZ2luYWxSZWFkeS5jYWxsKHRoaXMpO1xuICB9O1xuXG4gIHZhciBvcmlnaW5hbEVycm9yID0gc3Vic2NyaXB0aW9uUHJvdG8uZXJyb3I7XG4gIHN1YnNjcmlwdGlvblByb3RvLmVycm9yID0gZnVuY3Rpb24oZXJyKSB7XG4gICAgaWYgKHR5cGVvZiBlcnIgPT09ICdzdHJpbmcnKSB7XG4gICAgICBlcnIgPSB7IG1lc3NhZ2U6IGVyciB9O1xuICAgIH1cblxuICAgIHZhciBrYWRpcmFJbmZvID0gS2FkaXJhLl9nZXRJbmZvKCk7XG5cbiAgICBpZiAoa2FkaXJhSW5mbyAmJiB0aGlzLl9zdWJzY3JpcHRpb25JZCAmJiB0aGlzLl9zdWJzY3JpcHRpb25JZCA9PSBrYWRpcmFJbmZvLnRyYWNlLmlkKSB7XG4gICAgICBLYWRpcmEudHJhY2VyLmVuZExhc3RFdmVudChrYWRpcmFJbmZvLnRyYWNlKTtcblxuICAgICAgdmFyIGVycm9yRm9yQXBtID0gXy5waWNrKGVyciwgJ21lc3NhZ2UnLCAnc3RhY2snKTtcbiAgICAgIEthZGlyYS50cmFjZXIuZXZlbnQoa2FkaXJhSW5mby50cmFjZSwgJ2Vycm9yJywge2Vycm9yOiBlcnJvckZvckFwbX0pO1xuICAgICAgdmFyIHRyYWNlID0gS2FkaXJhLnRyYWNlci5idWlsZFRyYWNlKGthZGlyYUluZm8udHJhY2UpO1xuXG4gICAgICBLYWRpcmEubW9kZWxzLnB1YnN1Yi5fdHJhY2tFcnJvcih0aGlzLl9zZXNzaW9uLCB0aGlzLCB0cmFjZSk7XG5cbiAgICAgIC8vIGVycm9yIHRyYWNraW5nIGNhbiBiZSBkaXNhYmxlZCBhbmQgaWYgdGhlcmUgaXMgYSB0cmFjZVxuICAgICAgLy8gdHJhY2Ugc2hvdWxkIGJlIGF2YWlsYWJsZSBhbGwgdGhlIHRpbWUsIGJ1dCBpdCB3b24ndFxuICAgICAgLy8gaWYgc29tZXRoaW5nIHdyb25nIGhhcHBlbmVkIG9uIHRoZSB0cmFjZSBidWlsZGluZ1xuICAgICAgaWYoS2FkaXJhLm9wdGlvbnMuZW5hYmxlRXJyb3JUcmFja2luZyAmJiB0cmFjZSkge1xuICAgICAgICBLYWRpcmEubW9kZWxzLmVycm9yLnRyYWNrRXJyb3IoZXJyLCB0cmFjZSk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gd3JhcCBlcnJvciBzdGFjayBzbyBNZXRlb3IuX2RlYnVnIGNhbiBpZGVudGlmeSBhbmQgaWdub3JlIGl0XG4gICAgLy8gaXQgaXMgbm90IHdyYXBwZWQgd2hlbiBlcnJvciB0cmFja2luZyBpcyBkaXNhYmxlZCBzaW5jZSBpdFxuICAgIC8vIHdvdWxkIGJlIHNob3duIGFzIGFuIG9iamVjdCBpbiB0aGUgbG9nc1xuICAgIGlmIChLYWRpcmEub3B0aW9ucy5lbmFibGVFcnJvclRyYWNraW5nKSB7XG4gICAgICBlcnIuc3RhY2sgPSB7c3RhY2s6IGVyci5zdGFjaywgc291cmNlOiAnc3Vic2NyaXB0aW9uJywgW01ldGVvckRlYnVnSWdub3JlXTogdHJ1ZX07XG4gICAgfVxuICAgIG9yaWdpbmFsRXJyb3IuY2FsbCh0aGlzLCBlcnIpO1xuICB9O1xuXG4gIHZhciBvcmlnaW5hbERlYWN0aXZhdGUgPSBzdWJzY3JpcHRpb25Qcm90by5fZGVhY3RpdmF0ZTtcbiAgc3Vic2NyaXB0aW9uUHJvdG8uX2RlYWN0aXZhdGUgPSBmdW5jdGlvbigpIHtcbiAgICBLYWRpcmEuRXZlbnRCdXMuZW1pdCgncHVic3ViJywgJ3N1YkRlYWN0aXZhdGVkJywgdGhpcy5fc2Vzc2lvbiwgdGhpcyk7XG4gICAgS2FkaXJhLm1vZGVscy5wdWJzdWIuX3RyYWNrVW5zdWIodGhpcy5fc2Vzc2lvbiwgdGhpcyk7XG4gICAgb3JpZ2luYWxEZWFjdGl2YXRlLmNhbGwodGhpcyk7XG4gIH07XG5cbiAgLy9hZGRpbmcgdGhlIGN1cnJlblN1YiBlbnYgdmFyaWFibGVcbiAgWydhZGRlZCcsICdjaGFuZ2VkJywgJ3JlbW92ZWQnXS5mb3JFYWNoKGZ1bmN0aW9uKGZ1bmNOYW1lKSB7XG4gICAgdmFyIG9yaWdpbmFsRnVuYyA9IHN1YnNjcmlwdGlvblByb3RvW2Z1bmNOYW1lXTtcbiAgICBzdWJzY3JpcHRpb25Qcm90b1tmdW5jTmFtZV0gPSBmdW5jdGlvbihjb2xsZWN0aW9uTmFtZSwgaWQsIGZpZWxkcykge1xuICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuXG4gICAgICAvLyB3ZSBuZWVkIHRvIHJ1biB0aGlzIGNvZGUgaW4gYSBmaWJlciBhbmQgdGhhdCdzIGhvdyB3ZSB0cmFja1xuICAgICAgLy8gc3Vic2NyaXB0aW9uIGluZm8uIE1heSBiZSB3ZSBjYW4gZmlndXJlIG91dCwgc29tZSBvdGhlciB3YXkgdG8gZG8gdGhpc1xuICAgICAgLy8gV2UgdXNlIHRoaXMgY3VycmVudGx5IHRvIGdldCB0aGUgcHVibGljYXRpb24gaW5mbyB3aGVuIHRyYWNraW5nIG1lc3NhZ2VcbiAgICAgIC8vIHNpemVzIGF0IHdyYXBfZGRwX3N0cmluZ2lmeS5qc1xuICAgICAgS2FkaXJhLmVudi5jdXJyZW50U3ViID0gc2VsZjtcbiAgICAgIHZhciByZXMgPSBvcmlnaW5hbEZ1bmMuY2FsbChzZWxmLCBjb2xsZWN0aW9uTmFtZSwgaWQsIGZpZWxkcyk7XG4gICAgICBLYWRpcmEuZW52LmN1cnJlbnRTdWIgPSBudWxsO1xuXG4gICAgICByZXR1cm4gcmVzO1xuICAgIH07XG4gIH0pO1xufTtcbiIsIndyYXBPcGxvZ09ic2VydmVEcml2ZXIgPSBmdW5jdGlvbihwcm90bykge1xuICAvLyBUcmFjayB0aGUgcG9sbGVkIGRvY3VtZW50cy4gVGhpcyBpcyByZWZsZWN0IHRvIHRoZSBSQU0gc2l6ZSBhbmRcbiAgLy8gZm9yIHRoZSBDUFUgdXNhZ2UgZGlyZWN0bHlcbiAgdmFyIG9yaWdpbmFsUHVibGlzaE5ld1Jlc3VsdHMgPSBwcm90by5fcHVibGlzaE5ld1Jlc3VsdHM7XG4gIHByb3RvLl9wdWJsaXNoTmV3UmVzdWx0cyA9IGZ1bmN0aW9uKG5ld1Jlc3VsdHMsIG5ld0J1ZmZlcikge1xuICAgIHZhciBjb2xsID0gdGhpcy5fY3Vyc29yRGVzY3JpcHRpb24uY29sbGVjdGlvbk5hbWU7XG4gICAgdmFyIHF1ZXJ5ID0gdGhpcy5fY3Vyc29yRGVzY3JpcHRpb24uc2VsZWN0b3I7XG4gICAgdmFyIG9wdHMgPSB0aGlzLl9jdXJzb3JEZXNjcmlwdGlvbi5vcHRpb25zO1xuICAgIHZhciBkb2NTaXplID0gS2FkaXJhLmRvY1N6Q2FjaGUuZ2V0U2l6ZShjb2xsLCBxdWVyeSwgb3B0cywgbmV3UmVzdWx0cyk7XG4gICAgdmFyIGRvY1NpemUgPSBLYWRpcmEuZG9jU3pDYWNoZS5nZXRTaXplKGNvbGwsIHF1ZXJ5LCBvcHRzLCBuZXdCdWZmZXIpO1xuICAgIHZhciBjb3VudCA9IG5ld1Jlc3VsdHMuc2l6ZSgpICsgbmV3QnVmZmVyLnNpemUoKTtcbiAgICBpZih0aGlzLl9vd25lckluZm8pIHtcbiAgICAgIEthZGlyYS5tb2RlbHMucHVic3ViLnRyYWNrUG9sbGVkRG9jdW1lbnRzKHRoaXMuX293bmVySW5mbywgY291bnQpO1xuICAgICAgS2FkaXJhLm1vZGVscy5wdWJzdWIudHJhY2tEb2NTaXplKHRoaXMuX293bmVySW5mby5uYW1lLCBcInBvbGxlZEZldGNoZXNcIiwgZG9jU2l6ZSpjb3VudCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuX3BvbGxlZERvY3VtZW50cyA9IGNvdW50O1xuICAgICAgdGhpcy5fZG9jU2l6ZSA9IHtcbiAgICAgICAgcG9sbGVkRmV0Y2hlczogZG9jU2l6ZSpjb3VudFxuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gb3JpZ2luYWxQdWJsaXNoTmV3UmVzdWx0cy5jYWxsKHRoaXMsIG5ld1Jlc3VsdHMsIG5ld0J1ZmZlcik7XG4gIH07XG5cbiAgdmFyIG9yaWdpbmFsSGFuZGxlT3Bsb2dFbnRyeVF1ZXJ5aW5nID0gcHJvdG8uX2hhbmRsZU9wbG9nRW50cnlRdWVyeWluZztcbiAgcHJvdG8uX2hhbmRsZU9wbG9nRW50cnlRdWVyeWluZyA9IGZ1bmN0aW9uKG9wKSB7XG4gICAgS2FkaXJhLm1vZGVscy5wdWJzdWIudHJhY2tEb2N1bWVudENoYW5nZXModGhpcy5fb3duZXJJbmZvLCBvcCk7XG4gICAgcmV0dXJuIG9yaWdpbmFsSGFuZGxlT3Bsb2dFbnRyeVF1ZXJ5aW5nLmNhbGwodGhpcywgb3ApO1xuICB9O1xuXG4gIHZhciBvcmlnaW5hbEhhbmRsZU9wbG9nRW50cnlTdGVhZHlPckZldGNoaW5nID0gcHJvdG8uX2hhbmRsZU9wbG9nRW50cnlTdGVhZHlPckZldGNoaW5nO1xuICBwcm90by5faGFuZGxlT3Bsb2dFbnRyeVN0ZWFkeU9yRmV0Y2hpbmcgPSBmdW5jdGlvbihvcCkge1xuICAgIEthZGlyYS5tb2RlbHMucHVic3ViLnRyYWNrRG9jdW1lbnRDaGFuZ2VzKHRoaXMuX293bmVySW5mbywgb3ApO1xuICAgIHJldHVybiBvcmlnaW5hbEhhbmRsZU9wbG9nRW50cnlTdGVhZHlPckZldGNoaW5nLmNhbGwodGhpcywgb3ApO1xuICB9O1xuXG4gIC8vIHRyYWNrIGxpdmUgdXBkYXRlc1xuICBbJ19hZGRQdWJsaXNoZWQnLCAnX3JlbW92ZVB1Ymxpc2hlZCcsICdfY2hhbmdlUHVibGlzaGVkJ10uZm9yRWFjaChmdW5jdGlvbihmbk5hbWUpIHtcbiAgICB2YXIgb3JpZ2luYWxGbiA9IHByb3RvW2ZuTmFtZV07XG4gICAgcHJvdG9bZm5OYW1lXSA9IGZ1bmN0aW9uKGEsIGIsIGMpIHtcbiAgICAgIGlmKHRoaXMuX293bmVySW5mbykge1xuICAgICAgICBLYWRpcmEubW9kZWxzLnB1YnN1Yi50cmFja0xpdmVVcGRhdGVzKHRoaXMuX293bmVySW5mbywgZm5OYW1lLCAxKTtcblxuICAgICAgICBpZihmbk5hbWUgPT09IFwiX2FkZFB1Ymxpc2hlZFwiKSB7XG4gICAgICAgICAgdmFyIGNvbGwgPSB0aGlzLl9jdXJzb3JEZXNjcmlwdGlvbi5jb2xsZWN0aW9uTmFtZTtcbiAgICAgICAgICB2YXIgcXVlcnkgPSB0aGlzLl9jdXJzb3JEZXNjcmlwdGlvbi5zZWxlY3RvcjtcbiAgICAgICAgICB2YXIgb3B0cyA9IHRoaXMuX2N1cnNvckRlc2NyaXB0aW9uLm9wdGlvbnM7XG4gICAgICAgICAgdmFyIGRvY1NpemUgPSBLYWRpcmEuZG9jU3pDYWNoZS5nZXRTaXplKGNvbGwsIHF1ZXJ5LCBvcHRzLCBbYl0pO1xuXG4gICAgICAgICAgS2FkaXJhLm1vZGVscy5wdWJzdWIudHJhY2tEb2NTaXplKHRoaXMuX293bmVySW5mby5uYW1lLCBcImxpdmVGZXRjaGVzXCIsIGRvY1NpemUpO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyBJZiB0aGVyZSBpcyBubyBvd25lckluZm8sIHRoYXQgbWVhbnMgdGhpcyBpcyB0aGUgaW5pdGlhbCBhZGRzXG4gICAgICAgIGlmKCF0aGlzLl9saXZlVXBkYXRlc0NvdW50cykge1xuICAgICAgICAgIHRoaXMuX2xpdmVVcGRhdGVzQ291bnRzID0ge1xuICAgICAgICAgICAgX2luaXRpYWxBZGRzOiAwXG4gICAgICAgICAgfTtcbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMuX2xpdmVVcGRhdGVzQ291bnRzLl9pbml0aWFsQWRkcysrO1xuXG4gICAgICAgIGlmKGZuTmFtZSA9PT0gXCJfYWRkUHVibGlzaGVkXCIpIHtcbiAgICAgICAgICBpZighdGhpcy5fZG9jU2l6ZSkge1xuICAgICAgICAgICAgdGhpcy5fZG9jU2l6ZSA9IHtcbiAgICAgICAgICAgICAgaW5pdGlhbEZldGNoZXM6IDBcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgaWYoIXRoaXMuX2RvY1NpemUuaW5pdGlhbEZldGNoZXMpIHtcbiAgICAgICAgICAgIHRoaXMuX2RvY1NpemUuaW5pdGlhbEZldGNoZXMgPSAwO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIHZhciBjb2xsID0gdGhpcy5fY3Vyc29yRGVzY3JpcHRpb24uY29sbGVjdGlvbk5hbWU7XG4gICAgICAgICAgdmFyIHF1ZXJ5ID0gdGhpcy5fY3Vyc29yRGVzY3JpcHRpb24uc2VsZWN0b3I7XG4gICAgICAgICAgdmFyIG9wdHMgPSB0aGlzLl9jdXJzb3JEZXNjcmlwdGlvbi5vcHRpb25zO1xuICAgICAgICAgIHZhciBkb2NTaXplID0gS2FkaXJhLmRvY1N6Q2FjaGUuZ2V0U2l6ZShjb2xsLCBxdWVyeSwgb3B0cywgW2JdKTtcblxuICAgICAgICAgIHRoaXMuX2RvY1NpemUuaW5pdGlhbEZldGNoZXMgKz0gZG9jU2l6ZTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICByZXR1cm4gb3JpZ2luYWxGbi5jYWxsKHRoaXMsIGEsIGIsIGMpO1xuICAgIH07XG4gIH0pO1xuXG4gIHZhciBvcmlnaW5hbFN0b3AgPSBwcm90by5zdG9wO1xuICBwcm90by5zdG9wID0gZnVuY3Rpb24oKSB7XG4gICAgaWYodGhpcy5fb3duZXJJbmZvICYmIHRoaXMuX293bmVySW5mby50eXBlID09PSAnc3ViJykge1xuICAgICAgS2FkaXJhLkV2ZW50QnVzLmVtaXQoJ3B1YnN1YicsICdvYnNlcnZlckRlbGV0ZWQnLCB0aGlzLl9vd25lckluZm8pO1xuICAgICAgS2FkaXJhLm1vZGVscy5wdWJzdWIudHJhY2tEZWxldGVkT2JzZXJ2ZXIodGhpcy5fb3duZXJJbmZvKTtcbiAgICB9XG5cbiAgICByZXR1cm4gb3JpZ2luYWxTdG9wLmNhbGwodGhpcyk7XG4gIH07XG59O1xuXG53cmFwUG9sbGluZ09ic2VydmVEcml2ZXIgPSBmdW5jdGlvbihwcm90bykge1xuICB2YXIgb3JpZ2luYWxQb2xsTW9uZ28gPSBwcm90by5fcG9sbE1vbmdvO1xuICBwcm90by5fcG9sbE1vbmdvID0gZnVuY3Rpb24oKSB7XG4gICAgdmFyIHN0YXJ0ID0gRGF0ZS5ub3coKTtcbiAgICBvcmlnaW5hbFBvbGxNb25nby5jYWxsKHRoaXMpO1xuXG4gICAgLy8gQ3VycmVudCByZXN1bHQgaXMgc3RvcmVkIGluIHRoZSBmb2xsb3dpbmcgdmFyaWFibGUuXG4gICAgLy8gU28sIHdlIGNhbiB1c2UgdGhhdFxuICAgIC8vIFNvbWV0aW1lcywgaXQncyBwb3NzaWJsZSB0byBnZXQgc2l6ZSBhcyB1bmRlZmluZWQuXG4gICAgLy8gTWF5IGJlIHNvbWV0aGluZyB3aXRoIGRpZmZlcmVudCB2ZXJzaW9uLiBXZSBkb24ndCBuZWVkIHRvIHdvcnJ5IGFib3V0XG4gICAgLy8gdGhpcyBub3dcbiAgICB2YXIgY291bnQgPSAwO1xuICAgIHZhciBkb2NTaXplID0gMDtcblxuICAgIGlmKHRoaXMuX3Jlc3VsdHMgJiYgdGhpcy5fcmVzdWx0cy5zaXplKSB7XG4gICAgICBjb3VudCA9IHRoaXMuX3Jlc3VsdHMuc2l6ZSgpIHx8IDA7XG5cbiAgICAgIHZhciBjb2xsID0gdGhpcy5fY3Vyc29yRGVzY3JpcHRpb24uY29sbGVjdGlvbk5hbWU7XG4gICAgICB2YXIgcXVlcnkgPSB0aGlzLl9jdXJzb3JEZXNjcmlwdGlvbi5zZWxlY3RvcjtcbiAgICAgIHZhciBvcHRzID0gdGhpcy5fY3Vyc29yRGVzY3JpcHRpb24ub3B0aW9ucztcblxuICAgICAgZG9jU2l6ZSA9IEthZGlyYS5kb2NTekNhY2hlLmdldFNpemUoY29sbCwgcXVlcnksIG9wdHMsIHRoaXMuX3Jlc3VsdHMuX21hcCkqY291bnQ7XG4gICAgfVxuXG4gICAgaWYodGhpcy5fb3duZXJJbmZvKSB7XG4gICAgICBLYWRpcmEubW9kZWxzLnB1YnN1Yi50cmFja1BvbGxlZERvY3VtZW50cyh0aGlzLl9vd25lckluZm8sIGNvdW50KTtcbiAgICAgIEthZGlyYS5tb2RlbHMucHVic3ViLnRyYWNrRG9jU2l6ZSh0aGlzLl9vd25lckluZm8ubmFtZSwgXCJwb2xsZWRGZXRjaGVzXCIsIGRvY1NpemUpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLl9wb2xsZWREb2N1bWVudHMgPSBjb3VudDtcbiAgICAgIHRoaXMuX3BvbGxlZERvY1NpemUgPSBkb2NTaXplO1xuICAgIH1cbiAgfTtcblxuICB2YXIgb3JpZ2luYWxTdG9wID0gcHJvdG8uc3RvcDtcbiAgcHJvdG8uc3RvcCA9IGZ1bmN0aW9uKCkge1xuICAgIGlmKHRoaXMuX293bmVySW5mbyAmJiB0aGlzLl9vd25lckluZm8udHlwZSA9PT0gJ3N1YicpIHtcbiAgICAgIEthZGlyYS5FdmVudEJ1cy5lbWl0KCdwdWJzdWInLCAnb2JzZXJ2ZXJEZWxldGVkJywgdGhpcy5fb3duZXJJbmZvKTtcbiAgICAgIEthZGlyYS5tb2RlbHMucHVic3ViLnRyYWNrRGVsZXRlZE9ic2VydmVyKHRoaXMuX293bmVySW5mbyk7XG4gICAgfVxuXG4gICAgcmV0dXJuIG9yaWdpbmFsU3RvcC5jYWxsKHRoaXMpO1xuICB9O1xufTtcblxud3JhcE11bHRpcGxleGVyID0gZnVuY3Rpb24ocHJvdG8pIHtcbiAgdmFyIG9yaWdpbmFsSW5pdGFsQWRkID0gcHJvdG8uYWRkSGFuZGxlQW5kU2VuZEluaXRpYWxBZGRzO1xuICAgcHJvdG8uYWRkSGFuZGxlQW5kU2VuZEluaXRpYWxBZGRzID0gZnVuY3Rpb24oaGFuZGxlKSB7XG4gICAgaWYoIXRoaXMuX2ZpcnN0SW5pdGlhbEFkZFRpbWUpIHtcbiAgICAgIHRoaXMuX2ZpcnN0SW5pdGlhbEFkZFRpbWUgPSBEYXRlLm5vdygpO1xuICAgIH1cblxuICAgIGhhbmRsZS5fd2FzTXVsdGlwbGV4ZXJSZWFkeSA9IHRoaXMuX3JlYWR5KCk7XG4gICAgaGFuZGxlLl9xdWV1ZUxlbmd0aCA9IHRoaXMuX3F1ZXVlLl90YXNrSGFuZGxlcy5sZW5ndGg7XG5cbiAgICBpZighaGFuZGxlLl93YXNNdWx0aXBsZXhlclJlYWR5KSB7XG4gICAgICBoYW5kbGUuX2VsYXBzZWRQb2xsaW5nVGltZSA9IERhdGUubm93KCkgLSB0aGlzLl9maXJzdEluaXRpYWxBZGRUaW1lO1xuICAgIH1cbiAgICByZXR1cm4gb3JpZ2luYWxJbml0YWxBZGQuY2FsbCh0aGlzLCBoYW5kbGUpO1xuICB9O1xufTtcblxud3JhcEZvckNvdW50aW5nT2JzZXJ2ZXJzID0gZnVuY3Rpb24oKSB7XG4gIC8vIHRvIGNvdW50IG9ic2VydmVyc1xuICB2YXIgbW9uZ29Db25uZWN0aW9uUHJvdG8gPSBNZXRlb3JYLk1vbmdvQ29ubmVjdGlvbi5wcm90b3R5cGU7XG4gIHZhciBvcmlnaW5hbE9ic2VydmVDaGFuZ2VzID0gbW9uZ29Db25uZWN0aW9uUHJvdG8uX29ic2VydmVDaGFuZ2VzO1xuICBtb25nb0Nvbm5lY3Rpb25Qcm90by5fb2JzZXJ2ZUNoYW5nZXMgPSBmdW5jdGlvbihjdXJzb3JEZXNjcmlwdGlvbiwgb3JkZXJlZCwgY2FsbGJhY2tzKSB7XG4gICAgdmFyIHJldCA9IG9yaWdpbmFsT2JzZXJ2ZUNoYW5nZXMuY2FsbCh0aGlzLCBjdXJzb3JEZXNjcmlwdGlvbiwgb3JkZXJlZCwgY2FsbGJhY2tzKTtcbiAgICAvLyBnZXQgdGhlIEthZGlyYSBJbmZvIHZpYSB0aGUgTWV0ZW9yLkVudmlyb25tZW50YWxWYXJpYWJsZVxuICAgIHZhciBrYWRpcmFJbmZvID0gS2FkaXJhLl9nZXRJbmZvKG51bGwsIHRydWUpO1xuXG4gICAgaWYoa2FkaXJhSW5mbyAmJiByZXQuX211bHRpcGxleGVyKSB7XG4gICAgICBpZighcmV0Ll9tdWx0aXBsZXhlci5fX2thZGlyYVRyYWNrZWQpIHtcbiAgICAgICAgLy8gbmV3IG11bHRpcGxleGVyXG4gICAgICAgIHJldC5fbXVsdGlwbGV4ZXIuX19rYWRpcmFUcmFja2VkID0gdHJ1ZTtcbiAgICAgICAgS2FkaXJhLkV2ZW50QnVzLmVtaXQoJ3B1YnN1YicsICduZXdTdWJIYW5kbGVDcmVhdGVkJywga2FkaXJhSW5mby50cmFjZSk7XG4gICAgICAgIEthZGlyYS5tb2RlbHMucHVic3ViLmluY3JlbWVudEhhbmRsZUNvdW50KGthZGlyYUluZm8udHJhY2UsIGZhbHNlKTtcbiAgICAgICAgaWYoa2FkaXJhSW5mby50cmFjZS50eXBlID09ICdzdWInKSB7XG4gICAgICAgICAgdmFyIG93bmVySW5mbyA9IHtcbiAgICAgICAgICAgIHR5cGU6IGthZGlyYUluZm8udHJhY2UudHlwZSxcbiAgICAgICAgICAgIG5hbWU6IGthZGlyYUluZm8udHJhY2UubmFtZSxcbiAgICAgICAgICAgIHN0YXJ0VGltZTogKG5ldyBEYXRlKCkpLmdldFRpbWUoKVxuICAgICAgICAgIH07XG5cbiAgICAgICAgICB2YXIgb2JzZXJ2ZXJEcml2ZXIgPSByZXQuX211bHRpcGxleGVyLl9vYnNlcnZlRHJpdmVyO1xuICAgICAgICAgIG9ic2VydmVyRHJpdmVyLl9vd25lckluZm8gPSBvd25lckluZm87XG4gICAgICAgICAgS2FkaXJhLkV2ZW50QnVzLmVtaXQoJ3B1YnN1YicsICdvYnNlcnZlckNyZWF0ZWQnLCBvd25lckluZm8pO1xuICAgICAgICAgIEthZGlyYS5tb2RlbHMucHVic3ViLnRyYWNrQ3JlYXRlZE9ic2VydmVyKG93bmVySW5mbyk7XG5cbiAgICAgICAgICAvLyBXZSBuZWVkIHRvIHNlbmQgaW5pdGlhbGx5IHBvbGxlZCBkb2N1bWVudHMgaWYgdGhlcmUgYXJlXG4gICAgICAgICAgaWYob2JzZXJ2ZXJEcml2ZXIuX3BvbGxlZERvY3VtZW50cykge1xuICAgICAgICAgICAgS2FkaXJhLm1vZGVscy5wdWJzdWIudHJhY2tQb2xsZWREb2N1bWVudHMob3duZXJJbmZvLCBvYnNlcnZlckRyaXZlci5fcG9sbGVkRG9jdW1lbnRzKTtcbiAgICAgICAgICAgIG9ic2VydmVyRHJpdmVyLl9wb2xsZWREb2N1bWVudHMgPSAwO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIC8vIFdlIG5lZWQgdG8gc2VuZCBpbml0aWFsbHkgcG9sbGVkIGRvY3VtZW50cyBpZiB0aGVyZSBhcmVcbiAgICAgICAgICBpZihvYnNlcnZlckRyaXZlci5fcG9sbGVkRG9jU2l6ZSkge1xuICAgICAgICAgICAgS2FkaXJhLm1vZGVscy5wdWJzdWIudHJhY2tEb2NTaXplKG93bmVySW5mby5uYW1lLCBcInBvbGxlZEZldGNoZXNcIiwgb2JzZXJ2ZXJEcml2ZXIuX3BvbGxlZERvY1NpemUpO1xuICAgICAgICAgICAgb2JzZXJ2ZXJEcml2ZXIuX3BvbGxlZERvY1NpemUgPSAwO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIC8vIFByb2Nlc3MgX2xpdmVVcGRhdGVzQ291bnRzXG4gICAgICAgICAgXy5lYWNoKG9ic2VydmVyRHJpdmVyLl9saXZlVXBkYXRlc0NvdW50cywgZnVuY3Rpb24oY291bnQsIGtleSkge1xuICAgICAgICAgICAgS2FkaXJhLm1vZGVscy5wdWJzdWIudHJhY2tMaXZlVXBkYXRlcyhvd25lckluZm8sIGtleSwgY291bnQpO1xuICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgLy8gUHJvY2VzcyBkb2NTaXplXG4gICAgICAgICAgXy5lYWNoKG9ic2VydmVyRHJpdmVyLl9kb2NTaXplLCBmdW5jdGlvbihjb3VudCwga2V5KSB7XG4gICAgICAgICAgICBLYWRpcmEubW9kZWxzLnB1YnN1Yi50cmFja0RvY1NpemUob3duZXJJbmZvLm5hbWUsIGtleSwgY291bnQpO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBLYWRpcmEuRXZlbnRCdXMuZW1pdCgncHVic3ViJywgJ2NhY2hlZFN1YkhhbmRsZUNyZWF0ZWQnLCBrYWRpcmFJbmZvLnRyYWNlKTtcbiAgICAgICAgS2FkaXJhLm1vZGVscy5wdWJzdWIuaW5jcmVtZW50SGFuZGxlQ291bnQoa2FkaXJhSW5mby50cmFjZSwgdHJ1ZSk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIHJldDtcbiAgfVxufTsiLCJ3cmFwU3RyaW5naWZ5RERQID0gZnVuY3Rpb24oKSB7XG4gIHZhciBvcmlnaW5hbFN0cmluZ2lmeUREUCA9IEREUENvbW1vbi5zdHJpbmdpZnlERFA7XG5cbiAgRERQQ29tbW9uLnN0cmluZ2lmeUREUCA9IGZ1bmN0aW9uKG1zZykge1xuICAgIHZhciBtc2dTdHJpbmcgPSBvcmlnaW5hbFN0cmluZ2lmeUREUChtc2cpO1xuICAgIHZhciBtc2dTaXplID0gQnVmZmVyLmJ5dGVMZW5ndGgobXNnU3RyaW5nLCAndXRmOCcpO1xuXG4gICAgdmFyIGthZGlyYUluZm8gPSBLYWRpcmEuX2dldEluZm8obnVsbCwgdHJ1ZSk7XG5cbiAgICBpZihrYWRpcmFJbmZvICYmICFLYWRpcmEuZW52LmN1cnJlbnRTdWIpIHtcbiAgICAgIGlmKGthZGlyYUluZm8udHJhY2UudHlwZSA9PT0gJ21ldGhvZCcpIHtcbiAgICAgICAgS2FkaXJhLm1vZGVscy5tZXRob2RzLnRyYWNrTXNnU2l6ZShrYWRpcmFJbmZvLnRyYWNlLm5hbWUsIG1zZ1NpemUpO1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gbXNnU3RyaW5nO1xuICAgIH1cblxuICAgIC8vICdjdXJyZW50U3ViJyBpcyBzZXQgd2hlbiB3ZSB3cmFwIFN1YnNjcmlwdGlvbiBvYmplY3QgYW5kIG92ZXJyaWRlXG4gICAgLy8gaGFuZGxlcnMgZm9yICdhZGRlZCcsICdjaGFuZ2VkJywgJ3JlbW92ZWQnIGV2ZW50cy4gKHNlZSBsaWIvaGlqYWNrL3dyYXBfc3Vic2NyaXB0aW9uLmpzKVxuICAgIGlmKEthZGlyYS5lbnYuY3VycmVudFN1Yikge1xuICAgICAgaWYoS2FkaXJhLmVudi5jdXJyZW50U3ViLl9fa2FkaXJhSW5mbyl7XG4gICAgICAgIEthZGlyYS5tb2RlbHMucHVic3ViLnRyYWNrTXNnU2l6ZShLYWRpcmEuZW52LmN1cnJlbnRTdWIuX25hbWUsIFwiaW5pdGlhbFNlbnRcIiwgbXNnU2l6ZSk7XG4gICAgICAgIHJldHVybiBtc2dTdHJpbmc7XG4gICAgICB9XG4gICAgICBLYWRpcmEubW9kZWxzLnB1YnN1Yi50cmFja01zZ1NpemUoS2FkaXJhLmVudi5jdXJyZW50U3ViLl9uYW1lLCBcImxpdmVTZW50XCIsIG1zZ1NpemUpO1xuICAgICAgcmV0dXJuIG1zZ1N0cmluZztcbiAgICB9XG5cbiAgICBLYWRpcmEubW9kZWxzLm1ldGhvZHMudHJhY2tNc2dTaXplKFwiPG5vdC1hLW1ldGhvZC1vci1hLXB1Yj5cIiwgbXNnU2l6ZSk7XG4gICAgcmV0dXJuIG1zZ1N0cmluZztcbiAgfVxufVxuIiwiaW1wb3J0IHsgd3JhcFdlYkFwcCB9IGZyb20gXCIuL3dyYXBfd2ViYXBwLmpzXCI7XG5pbXBvcnQgeyB3cmFwRmFzdFJlbmRlciB9IGZyb20gXCIuL2Zhc3RfcmVuZGVyLmpzXCI7XG5pbXBvcnQgeyB3cmFwRnMgfSBmcm9tIFwiLi9mcy5qc1wiO1xuaW1wb3J0IHsgd3JhcFBpY2tlciB9IGZyb20gXCIuL3BpY2tlci5qc1wiO1xuaW1wb3J0IHsgd3JhcFJvdXRlcnMgfSBmcm9tICcuL3dyYXBfcm91dGVycy5qcyc7XG5pbXBvcnQgeyB3cmFwRmliZXJzIH0gZnJvbSAnLi9hc3luYy5qcyc7XG5cbnZhciBpbnN0cnVtZW50ZWQgPSBmYWxzZTtcbkthZGlyYS5fc3RhcnRJbnN0cnVtZW50aW5nID0gZnVuY3Rpb24oY2FsbGJhY2spIHtcbiAgaWYoaW5zdHJ1bWVudGVkKSB7XG4gICAgY2FsbGJhY2soKTtcbiAgICByZXR1cm47XG4gIH1cblxuICBpbnN0cnVtZW50ZWQgPSB0cnVlO1xuICB3cmFwRmliZXJzKCk7XG4gIHdyYXBTdHJpbmdpZnlERFAoKTtcbiAgd3JhcFdlYkFwcCgpO1xuICB3cmFwRmFzdFJlbmRlcigpO1xuICB3cmFwUGlja2VyKCk7XG4gIHdyYXBGcygpO1xuICB3cmFwUm91dGVycygpO1xuXG4gIE1ldGVvclgub25SZWFkeShmdW5jdGlvbigpIHtcbiAgICAvL2luc3RydW1lbnRpbmcgc2Vzc2lvblxuICAgIHdyYXBTZXJ2ZXIoTWV0ZW9yWC5TZXJ2ZXIucHJvdG90eXBlKTtcbiAgICB3cmFwU2Vzc2lvbihNZXRlb3JYLlNlc3Npb24ucHJvdG90eXBlKTtcbiAgICB3cmFwU3Vic2NyaXB0aW9uKE1ldGVvclguU3Vic2NyaXB0aW9uLnByb3RvdHlwZSk7XG5cbiAgICBpZihNZXRlb3JYLk1vbmdvT3Bsb2dEcml2ZXIpIHtcbiAgICAgIHdyYXBPcGxvZ09ic2VydmVEcml2ZXIoTWV0ZW9yWC5Nb25nb09wbG9nRHJpdmVyLnByb3RvdHlwZSk7XG4gICAgfVxuXG4gICAgaWYoTWV0ZW9yWC5Nb25nb1BvbGxpbmdEcml2ZXIpIHtcbiAgICAgIHdyYXBQb2xsaW5nT2JzZXJ2ZURyaXZlcihNZXRlb3JYLk1vbmdvUG9sbGluZ0RyaXZlci5wcm90b3R5cGUpO1xuICAgIH1cblxuICAgIGlmKE1ldGVvclguTXVsdGlwbGV4ZXIpIHtcbiAgICAgIHdyYXBNdWx0aXBsZXhlcihNZXRlb3JYLk11bHRpcGxleGVyLnByb3RvdHlwZSk7XG4gICAgfVxuXG4gICAgd3JhcEZvckNvdW50aW5nT2JzZXJ2ZXJzKCk7XG4gICAgaGlqYWNrREJPcHMoKTtcblxuICAgIHNldExhYmVscygpO1xuICAgIGNhbGxiYWNrKCk7XG4gIH0pO1xufTtcblxuLy8gV2UgbmVlZCB0byBpbnN0cnVtZW50IHRoaXMgcmlnaHQgYXdheSBhbmQgaXQncyBva2F5XG4vLyBPbmUgcmVhc29uIGZvciB0aGlzIGlzIHRvIGNhbGwgYHNldExhYmxlcygpYCBmdW5jdGlvblxuLy8gT3RoZXJ3aXNlLCBDUFUgcHJvZmlsZSBjYW4ndCBzZWUgYWxsIG91ciBjdXN0b20gbGFiZWxpbmdcbkthZGlyYS5fc3RhcnRJbnN0cnVtZW50aW5nKGZ1bmN0aW9uKCkge1xuICBjb25zb2xlLmxvZygnTW9udGkgQVBNOiBjb21wbGV0ZWQgaW5zdHJ1bWVudGluZyB0aGUgYXBwJylcbn0pO1xuIiwiLy8gVGhpcyBoaWphY2sgaXMgaW1wb3J0YW50IHRvIG1ha2Ugc3VyZSwgY29sbGVjdGlvbnMgY3JlYXRlZCBiZWZvcmVcbi8vIHdlIGhpamFjayBkYk9wcywgZXZlbiBnZXRzIHRyYWNrZWQuXG4vLyAgTWV0ZW9yIGRvZXMgbm90IHNpbXBseSBleHBvc2UgTW9uZ29Db25uZWN0aW9uIG9iamVjdCB0byB0aGUgY2xpZW50XG4vLyAgSXQgcGlja3MgbWV0aG9kcyB3aGljaCBhcmUgbmVjZXNzb3J5IGFuZCBtYWtlIGEgYmluZGVkIG9iamVjdCBhbmRcbi8vICBhc3NpZ25lZCB0byB0aGUgTW9uZ28uQ29sbGVjdGlvblxuLy8gIHNvLCBldmVuIHdlIHVwZGF0ZWQgcHJvdG90eXBlLCB3ZSBjYW4ndCB0cmFjayB0aG9zZSBjb2xsZWN0aW9uc1xuLy8gIGJ1dCwgdGhpcyB3aWxsIGZpeCBpdC5cbnZhciBvcmlnaW5hbE9wZW4gPSBNb25nb0ludGVybmFscy5SZW1vdGVDb2xsZWN0aW9uRHJpdmVyLnByb3RvdHlwZS5vcGVuO1xuTW9uZ29JbnRlcm5hbHMuUmVtb3RlQ29sbGVjdGlvbkRyaXZlci5wcm90b3R5cGUub3BlbiA9IGZ1bmN0aW9uIG9wZW4obmFtZSkge1xuICB2YXIgc2VsZiA9IHRoaXM7XG4gIHZhciByZXQgPSBvcmlnaW5hbE9wZW4uY2FsbChzZWxmLCBuYW1lKTtcblxuICBfLmVhY2gocmV0LCBmdW5jdGlvbihmbiwgbSkge1xuICAgIC8vIG1ha2Ugc3VyZSwgaXQncyBpbiB0aGUgYWN0dWFsIG1vbmdvIGNvbm5lY3Rpb24gb2JqZWN0XG4gICAgLy8gbWV0ZW9yaGFja3M6bW9uZ28tY29sbGVjdGlvbi11dGlscyBwYWNrYWdlIGFkZCBzb21lIGFyYml0YXJ5IG1ldGhvZHNcbiAgICAvLyB3aGljaCBkb2VzIG5vdCBleGlzdCBpbiB0aGUgbW9uZ28gY29ubmVjdGlvblxuICAgIGlmKHNlbGYubW9uZ29bbV0pIHtcbiAgICAgIHJldFttXSA9IGZ1bmN0aW9uKCkge1xuICAgICAgICBBcnJheS5wcm90b3R5cGUudW5zaGlmdC5jYWxsKGFyZ3VtZW50cywgbmFtZSk7XG4gICAgICAgIHJldHVybiBPcHRpbWl6ZWRBcHBseShzZWxmLm1vbmdvLCBzZWxmLm1vbmdvW21dLCBhcmd1bWVudHMpO1xuICAgICAgfTtcbiAgICB9XG4gIH0pO1xuXG4gIHJldHVybiByZXQ7XG59O1xuXG4vLyBUT0RPOiB0aGlzIHNob3VsZCBiZSBhZGRlZCB0byBNZXRlb3J4XG5mdW5jdGlvbiBnZXRTeW5jcm9ub3VzQ3Vyc29yKCkge1xuICBjb25zdCBNb25nb0NvbGwgPSB0eXBlb2YgTW9uZ28gIT09IFwidW5kZWZpbmVkXCIgPyBNb25nby5Db2xsZWN0aW9uIDogTWV0ZW9yLkNvbGxlY3Rpb247XG4gIGNvbnN0IGNvbGwgPSBuZXcgTW9uZ29Db2xsKFwiX19kdW1teV9jb2xsX1wiICsgUmFuZG9tLmlkKCkpO1xuICAvLyB3ZSBuZWVkIHRvIHdhaXQgdW50aWwgdGhlIGRiIGlzIGNvbm5lY3RlZCB3aXRoIG1ldGVvci4gZmluZE9uZSBkb2VzIHRoYXRcbiAgY29sbC5maW5kT25lKCk7XG4gIFxuICBjb25zdCBjdXJzb3IgPSBjb2xsLmZpbmQoKTtcbiAgY3Vyc29yLmZldGNoKCk7XG4gIHJldHVybiBjdXJzb3IuX3N5bmNocm9ub3VzQ3Vyc29yLmNvbnN0cnVjdG9yXG59XG5cbmhpamFja0RCT3BzID0gZnVuY3Rpb24gaGlqYWNrREJPcHMoKSB7XG4gIHZhciBtb25nb0Nvbm5lY3Rpb25Qcm90byA9IE1ldGVvclguTW9uZ29Db25uZWN0aW9uLnByb3RvdHlwZTtcbiAgLy9maW5kT25lIGlzIGhhbmRsZWQgYnkgZmluZCAtIHNvIG5vIG5lZWQgdG8gdHJhY2sgaXRcbiAgLy91cHNlcnQgaXMgaGFuZGxlcyBieSB1cGRhdGVcbiAgWydmaW5kJywgJ3VwZGF0ZScsICdyZW1vdmUnLCAnaW5zZXJ0JywgJ19lbnN1cmVJbmRleCcsICdfZHJvcEluZGV4J10uZm9yRWFjaChmdW5jdGlvbihmdW5jKSB7XG4gICAgdmFyIG9yaWdpbmFsRnVuYyA9IG1vbmdvQ29ubmVjdGlvblByb3RvW2Z1bmNdO1xuICAgIG1vbmdvQ29ubmVjdGlvblByb3RvW2Z1bmNdID0gZnVuY3Rpb24oY29sbE5hbWUsIHNlbGVjdG9yLCBtb2QsIG9wdGlvbnMpIHtcbiAgICAgIHZhciBwYXlsb2FkID0ge1xuICAgICAgICBjb2xsOiBjb2xsTmFtZSxcbiAgICAgICAgZnVuYzogZnVuYyxcbiAgICAgIH07XG5cbiAgICAgIGlmKGZ1bmMgPT0gJ2luc2VydCcpIHtcbiAgICAgICAgLy9hZGQgbm90aGluZyBtb3JlIHRvIHRoZSBwYXlsb2FkXG4gICAgICB9IGVsc2UgaWYoZnVuYyA9PSAnX2Vuc3VyZUluZGV4JyB8fCBmdW5jID09ICdfZHJvcEluZGV4Jykge1xuICAgICAgICAvL2FkZCBpbmRleFxuICAgICAgICBwYXlsb2FkLmluZGV4ID0gSlNPTi5zdHJpbmdpZnkoc2VsZWN0b3IpO1xuICAgICAgfSBlbHNlIGlmKGZ1bmMgPT0gJ3VwZGF0ZScgJiYgb3B0aW9ucyAmJiBvcHRpb25zLnVwc2VydCkge1xuICAgICAgICBwYXlsb2FkLmZ1bmMgPSAndXBzZXJ0JztcbiAgICAgICAgcGF5bG9hZC5zZWxlY3RvciA9IEpTT04uc3RyaW5naWZ5KHNlbGVjdG9yKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vYWxsIHRoZSBvdGhlciBmdW5jdGlvbnMgaGF2ZSBzZWxlY3RvcnNcbiAgICAgICAgcGF5bG9hZC5zZWxlY3RvciA9IEpTT04uc3RyaW5naWZ5KHNlbGVjdG9yKTtcbiAgICAgIH1cblxuICAgICAgdmFyIGthZGlyYUluZm8gPSBLYWRpcmEuX2dldEluZm8oKTtcbiAgICAgIGlmKGthZGlyYUluZm8pIHtcbiAgICAgICAgdmFyIGV2ZW50SWQgPSBLYWRpcmEudHJhY2VyLmV2ZW50KGthZGlyYUluZm8udHJhY2UsICdkYicsIHBheWxvYWQpO1xuICAgICAgfVxuXG4gICAgICAvL3RoaXMgY2F1c2UgVjggdG8gYXZvaWQgYW55IHBlcmZvcm1hbmNlIG9wdGltaXphdGlvbnMsIGJ1dCB0aGlzIGlzIG11c3QgdG8gdXNlXG4gICAgICAvL290aGVyd2lzZSwgaWYgdGhlIGVycm9yIGFkZHMgdHJ5IGNhdGNoIGJsb2NrIG91ciBsb2dzIGdldCBtZXNzeSBhbmQgZGlkbid0IHdvcmtcbiAgICAgIC8vc2VlOiBpc3N1ZSAjNlxuICAgICAgdHJ5e1xuICAgICAgICB2YXIgcmV0ID0gb3JpZ2luYWxGdW5jLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gICAgICAgIC8vaGFuZGxpbmcgZnVuY3Rpb25zIHdoaWNoIGNhbiBiZSB0cmlnZ2VyZWQgd2l0aCBhbiBhc3luY0NhbGxiYWNrXG4gICAgICAgIHZhciBlbmRPcHRpb25zID0ge307XG5cbiAgICAgICAgaWYoSGF2ZUFzeW5jQ2FsbGJhY2soYXJndW1lbnRzKSkge1xuICAgICAgICAgIGVuZE9wdGlvbnMuYXN5bmMgPSB0cnVlO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYoZnVuYyA9PSAndXBkYXRlJykge1xuICAgICAgICAgIC8vIHVwc2VydCBvbmx5IHJldHVybnMgYW4gb2JqZWN0IHdoZW4gY2FsbGVkIGB1cHNlcnRgIGRpcmVjdGx5XG4gICAgICAgICAgLy8gb3RoZXJ3aXNlIGl0IG9ubHkgYWN0IGFuIHVwZGF0ZSBjb21tYW5kXG4gICAgICAgICAgaWYob3B0aW9ucyAmJiBvcHRpb25zLnVwc2VydCAmJiB0eXBlb2YgcmV0ID09ICdvYmplY3QnKSB7XG4gICAgICAgICAgICBlbmRPcHRpb25zLnVwZGF0ZWREb2NzID0gcmV0Lm51bWJlckFmZmVjdGVkO1xuICAgICAgICAgICAgZW5kT3B0aW9ucy5pbnNlcnRlZElkID0gcmV0Lmluc2VydGVkSWQ7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGVuZE9wdGlvbnMudXBkYXRlZERvY3MgPSByZXQ7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2UgaWYoZnVuYyA9PSAncmVtb3ZlJykge1xuICAgICAgICAgIGVuZE9wdGlvbnMucmVtb3ZlZERvY3MgPSByZXQ7XG4gICAgICAgIH1cblxuICAgICAgICBpZihldmVudElkKSB7XG4gICAgICAgICAgS2FkaXJhLnRyYWNlci5ldmVudEVuZChrYWRpcmFJbmZvLnRyYWNlLCBldmVudElkLCBlbmRPcHRpb25zKTtcbiAgICAgICAgfVxuICAgICAgfSBjYXRjaChleCkge1xuICAgICAgICBpZihldmVudElkKSB7XG4gICAgICAgICAgS2FkaXJhLnRyYWNlci5ldmVudEVuZChrYWRpcmFJbmZvLnRyYWNlLCBldmVudElkLCB7ZXJyOiBleC5tZXNzYWdlfSk7XG4gICAgICAgIH1cbiAgICAgICAgdGhyb3cgZXg7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiByZXQ7XG4gICAgfTtcbiAgfSk7XG5cbiAgdmFyIGN1cnNvclByb3RvID0gTWV0ZW9yWC5Nb25nb0N1cnNvci5wcm90b3R5cGU7XG4gIFsnZm9yRWFjaCcsICdtYXAnLCAnZmV0Y2gnLCAnY291bnQnLCAnb2JzZXJ2ZUNoYW5nZXMnLCAnb2JzZXJ2ZSddLmZvckVhY2goZnVuY3Rpb24odHlwZSkge1xuICAgIHZhciBvcmlnaW5hbEZ1bmMgPSBjdXJzb3JQcm90b1t0eXBlXTtcbiAgICBjdXJzb3JQcm90b1t0eXBlXSA9IGZ1bmN0aW9uKCkge1xuICAgICAgdmFyIGN1cnNvckRlc2NyaXB0aW9uID0gdGhpcy5fY3Vyc29yRGVzY3JpcHRpb247XG4gICAgICB2YXIgcGF5bG9hZCA9IE9iamVjdC5hc3NpZ24oT2JqZWN0LmNyZWF0ZShudWxsKSwge1xuICAgICAgICBjb2xsOiBjdXJzb3JEZXNjcmlwdGlvbi5jb2xsZWN0aW9uTmFtZSxcbiAgICAgICAgc2VsZWN0b3I6IEpTT04uc3RyaW5naWZ5KGN1cnNvckRlc2NyaXB0aW9uLnNlbGVjdG9yKSxcbiAgICAgICAgZnVuYzogdHlwZSxcbiAgICAgICAgY3Vyc29yOiB0cnVlXG4gICAgICB9KTtcblxuICAgICAgaWYoY3Vyc29yRGVzY3JpcHRpb24ub3B0aW9ucykge1xuICAgICAgICB2YXIgY3Vyc29yT3B0aW9ucyA9IF8ucGljayhjdXJzb3JEZXNjcmlwdGlvbi5vcHRpb25zLCBbJ2ZpZWxkcycsICdzb3J0JywgJ2xpbWl0J10pO1xuICAgICAgICBmb3IodmFyIGZpZWxkIGluIGN1cnNvck9wdGlvbnMpIHtcbiAgICAgICAgICB2YXIgdmFsdWUgPSBjdXJzb3JPcHRpb25zW2ZpZWxkXVxuICAgICAgICAgIGlmKHR5cGVvZiB2YWx1ZSA9PSAnb2JqZWN0Jykge1xuICAgICAgICAgICAgdmFsdWUgPSBKU09OLnN0cmluZ2lmeSh2YWx1ZSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHBheWxvYWRbZmllbGRdID0gdmFsdWU7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgdmFyIGthZGlyYUluZm8gPSBLYWRpcmEuX2dldEluZm8oKTtcbiAgICAgIHZhciBwcmV2aW91c1RyYWNrTmV4dE9iamVjdDtcbiAgICAgIGlmKGthZGlyYUluZm8pIHtcbiAgICAgICAgdmFyIGV2ZW50SWQgPSBLYWRpcmEudHJhY2VyLmV2ZW50KGthZGlyYUluZm8udHJhY2UsICdkYicsIHBheWxvYWQpO1xuXG4gICAgICAgIHByZXZpb3VzVHJhY2tOZXh0T2JqZWN0ID0ga2FkaXJhSW5mby50cmFja05leHRPYmplY3RcbiAgICAgICAgaWYgKHR5cGUgPT09ICdmb3JFYWNoJyB8fCB0eXBlID09PSAnbWFwJykge1xuICAgICAgICAgIGthZGlyYUluZm8udHJhY2tOZXh0T2JqZWN0ID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICB0cnl7XG4gICAgICAgIHZhciByZXQgPSBvcmlnaW5hbEZ1bmMuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcblxuICAgICAgICB2YXIgZW5kRGF0YSA9IHt9O1xuICAgICAgICBpZih0eXBlID09ICdvYnNlcnZlQ2hhbmdlcycgfHwgdHlwZSA9PSAnb2JzZXJ2ZScpIHtcbiAgICAgICAgICB2YXIgb2JzZXJ2ZXJEcml2ZXI7XG4gICAgICAgICAgZW5kRGF0YS5vcGxvZyA9IGZhbHNlO1xuICAgICAgICAgIC8vIGdldCBkYXRhIHdyaXR0ZW4gYnkgdGhlIG11bHRpcGxleGVyXG4gICAgICAgICAgZW5kRGF0YS53YXNNdWx0aXBsZXhlclJlYWR5ID0gcmV0Ll93YXNNdWx0aXBsZXhlclJlYWR5O1xuICAgICAgICAgIGVuZERhdGEucXVldWVMZW5ndGggPSByZXQuX3F1ZXVlTGVuZ3RoO1xuICAgICAgICAgIGVuZERhdGEuZWxhcHNlZFBvbGxpbmdUaW1lID0gcmV0Ll9lbGFwc2VkUG9sbGluZ1RpbWU7XG5cbiAgICAgICAgICBpZihyZXQuX211bHRpcGxleGVyKSB7XG4gICAgICAgICAgICAvLyBvbGRlciBtZXRlb3IgdmVyc2lvbnMgZG9uZSBub3QgaGF2ZSBhbiBfbXVsdGlwbGV4ZXIgdmFsdWVcbiAgICAgICAgICAgIG9ic2VydmVyRHJpdmVyID0gcmV0Ll9tdWx0aXBsZXhlci5fb2JzZXJ2ZURyaXZlcjtcbiAgICAgICAgICAgIGlmKG9ic2VydmVyRHJpdmVyKSB7XG4gICAgICAgICAgICAgIG9ic2VydmVyRHJpdmVyID0gcmV0Ll9tdWx0aXBsZXhlci5fb2JzZXJ2ZURyaXZlcjtcbiAgICAgICAgICAgICAgdmFyIG9ic2VydmVyRHJpdmVyQ2xhc3MgPSBvYnNlcnZlckRyaXZlci5jb25zdHJ1Y3RvcjtcbiAgICAgICAgICAgICAgdmFyIHVzZXNPcGxvZyA9IHR5cGVvZiBvYnNlcnZlckRyaXZlckNsYXNzLmN1cnNvclN1cHBvcnRlZCA9PSAnZnVuY3Rpb24nO1xuICAgICAgICAgICAgICBlbmREYXRhLm9wbG9nID0gdXNlc09wbG9nO1xuICAgICAgICAgICAgICB2YXIgc2l6ZSA9IDA7XG4gICAgICAgICAgICAgIHJldC5fbXVsdGlwbGV4ZXIuX2NhY2hlLmRvY3MuZm9yRWFjaChmdW5jdGlvbigpIHtzaXplKyt9KTtcbiAgICAgICAgICAgICAgZW5kRGF0YS5ub09mQ2FjaGVkRG9jcyA9IHNpemU7XG5cbiAgICAgICAgICAgICAgLy8gaWYgbXVsdGlwbGV4ZXJXYXNOb3RSZWFkeSwgd2UgbmVlZCB0byBnZXQgdGhlIHRpbWUgc3BlbmQgZm9yIHRoZSBwb2xsaW5nXG4gICAgICAgICAgICAgIGlmKCFyZXQuX3dhc011bHRpcGxleGVyUmVhZHkpIHtcbiAgICAgICAgICAgICAgICBlbmREYXRhLmluaXRpYWxQb2xsaW5nVGltZSA9IG9ic2VydmVyRHJpdmVyLl9sYXN0UG9sbFRpbWU7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG5cbiAgICAgICAgICBpZighZW5kRGF0YS5vcGxvZykge1xuICAgICAgICAgICAgLy8gbGV0J3MgdHJ5IHRvIGZpbmQgdGhlIHJlYXNvblxuICAgICAgICAgICAgdmFyIHJlYXNvbkluZm8gPSBLYWRpcmEuY2hlY2tXaHlOb09wbG9nKGN1cnNvckRlc2NyaXB0aW9uLCBvYnNlcnZlckRyaXZlcik7XG4gICAgICAgICAgICBlbmREYXRhLm5vT3Bsb2dDb2RlID0gcmVhc29uSW5mby5jb2RlO1xuICAgICAgICAgICAgZW5kRGF0YS5ub09wbG9nUmVhc29uID0gcmVhc29uSW5mby5yZWFzb247XG4gICAgICAgICAgICBlbmREYXRhLm5vT3Bsb2dTb2x1dGlvbiA9IHJlYXNvbkluZm8uc29sdXRpb247XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2UgaWYodHlwZSA9PSAnZmV0Y2gnIHx8IHR5cGUgPT0gJ21hcCcpe1xuICAgICAgICAgIC8vZm9yIG90aGVyIGN1cnNvciBvcGVyYXRpb25cblxuICAgICAgICAgIGVuZERhdGEuZG9jc0ZldGNoZWQgPSByZXQubGVuZ3RoO1xuXG4gICAgICAgICAgaWYodHlwZSA9PSAnZmV0Y2gnKSB7XG4gICAgICAgICAgICB2YXIgY29sbCA9IGN1cnNvckRlc2NyaXB0aW9uLmNvbGxlY3Rpb25OYW1lO1xuICAgICAgICAgICAgdmFyIHF1ZXJ5ID0gY3Vyc29yRGVzY3JpcHRpb24uc2VsZWN0b3I7XG4gICAgICAgICAgICB2YXIgb3B0cyA9IGN1cnNvckRlc2NyaXB0aW9uLm9wdGlvbnM7XG4gICAgICAgICAgICB2YXIgZG9jU2l6ZSA9IEthZGlyYS5kb2NTekNhY2hlLmdldFNpemUoY29sbCwgcXVlcnksIG9wdHMsIHJldCkgKiByZXQubGVuZ3RoO1xuICAgICAgICAgICAgZW5kRGF0YS5kb2NTaXplID0gZG9jU2l6ZTtcblxuICAgICAgICAgICAgaWYoa2FkaXJhSW5mbykge1xuICAgICAgICAgICAgICBpZihrYWRpcmFJbmZvLnRyYWNlLnR5cGUgPT09ICdtZXRob2QnKSB7XG4gICAgICAgICAgICAgICAgS2FkaXJhLm1vZGVscy5tZXRob2RzLnRyYWNrRG9jU2l6ZShrYWRpcmFJbmZvLnRyYWNlLm5hbWUsIGRvY1NpemUpO1xuICAgICAgICAgICAgICB9IGVsc2UgaWYoa2FkaXJhSW5mby50cmFjZS50eXBlID09PSAnc3ViJykge1xuICAgICAgICAgICAgICAgIEthZGlyYS5tb2RlbHMucHVic3ViLnRyYWNrRG9jU2l6ZShrYWRpcmFJbmZvLnRyYWNlLm5hbWUsIFwiY3Vyc29yRmV0Y2hlc1wiLCBkb2NTaXplKTtcbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIGthZGlyYUluZm8udHJhY2tOZXh0T2JqZWN0ID0gcHJldmlvdXNUcmFja05leHRPYmplY3RcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIC8vIEZldGNoIHdpdGggbm8ga2FkaXJhIGluZm8gYXJlIHRyYWNrZWQgYXMgZnJvbSBhIG51bGwgbWV0aG9kXG4gICAgICAgICAgICAgIEthZGlyYS5tb2RlbHMubWV0aG9kcy50cmFja0RvY1NpemUoXCI8bm90LWEtbWV0aG9kLW9yLWEtcHViPlwiLCBkb2NTaXplKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gVE9ETzogQWRkIGRvYyBzaXplIHRyYWNraW5nIHRvIGBtYXBgIGFzIHdlbGwuXG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgaWYoZXZlbnRJZCkge1xuICAgICAgICAgIEthZGlyYS50cmFjZXIuZXZlbnRFbmQoa2FkaXJhSW5mby50cmFjZSwgZXZlbnRJZCwgZW5kRGF0YSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJldDtcbiAgICAgIH0gY2F0Y2goZXgpIHtcbiAgICAgICAgaWYoZXZlbnRJZCkge1xuICAgICAgICAgIEthZGlyYS50cmFjZXIuZXZlbnRFbmQoa2FkaXJhSW5mby50cmFjZSwgZXZlbnRJZCwge2VycjogZXgubWVzc2FnZX0pO1xuICAgICAgICB9XG4gICAgICAgIHRocm93IGV4O1xuICAgICAgfVxuICAgIH07XG4gIH0pO1xuXG4gIGNvbnN0IFN5bmNyb25vdXNDdXJzb3IgPSBnZXRTeW5jcm9ub3VzQ3Vyc29yKCk7XG4gIHZhciBvcmlnTmV4dE9iamVjdCA9IFN5bmNyb25vdXNDdXJzb3IucHJvdG90eXBlLl9uZXh0T2JqZWN0XG4gIFN5bmNyb25vdXNDdXJzb3IucHJvdG90eXBlLl9uZXh0T2JqZWN0ID0gZnVuY3Rpb24gKCkge1xuICAgIHZhciBrYWRpcmFJbmZvID0gS2FkaXJhLl9nZXRJbmZvKCk7XG4gICAgdmFyIHNob3VsZFRyYWNrID0ga2FkaXJhSW5mbyAmJiBrYWRpcmFJbmZvLnRyYWNrTmV4dE9iamVjdDtcbiAgICBpZihzaG91bGRUcmFjayApIHtcbiAgICAgIHZhciBldmVudCA9IEthZGlyYS50cmFjZXIuZXZlbnQoa2FkaXJhSW5mby50cmFjZSwgJ2RiJywge1xuICAgICAgICBmdW5jOiAnX25leHRPYmplY3QnLFxuICAgICAgICBjb2xsOiB0aGlzLl9jdXJzb3JEZXNjcmlwdGlvbi5jb2xsZWN0aW9uTmFtZVxuICAgICAgfSk7XG4gICAgfVxuXG4gICAgdmFyIHJlc3VsdCA9IG9yaWdOZXh0T2JqZWN0LmNhbGwodGhpcyk7XG5cbiAgICBpZiAoc2hvdWxkVHJhY2spIHtcbiAgICAgIEthZGlyYS50cmFjZXIuZXZlbnRFbmQoa2FkaXJhSW5mby50cmFjZSwgZXZlbnQpO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xuICB9XG59O1xuIiwidmFyIG9yaWdpbmFsQ2FsbCA9IEhUVFAuY2FsbDtcblxuSFRUUC5jYWxsID0gZnVuY3Rpb24obWV0aG9kLCB1cmwpIHtcbiAgdmFyIGthZGlyYUluZm8gPSBLYWRpcmEuX2dldEluZm8oKTtcbiAgaWYoa2FkaXJhSW5mbykge1xuICAgIHZhciBldmVudElkID0gS2FkaXJhLnRyYWNlci5ldmVudChrYWRpcmFJbmZvLnRyYWNlLCAnaHR0cCcsIHttZXRob2Q6IG1ldGhvZCwgdXJsOiB1cmx9KTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgdmFyIHJlc3BvbnNlID0gb3JpZ2luYWxDYWxsLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG5cbiAgICAvL2lmIHRoZSB1c2VyIHN1cHBsaWVkIGFuIGFzeW5DYWxsYmFjaywgd2UgZG9uJ3QgaGF2ZSBhIHJlc3BvbnNlIG9iamVjdCBhbmQgaXQgaGFuZGxlZCBhc3luY2hyb25vdXNseVxuICAgIC8vd2UgbmVlZCB0byB0cmFjayBpdCBkb3duIHRvIHByZXZlbnQgaXNzdWVzIGxpa2U6ICMzXG4gICAgdmFyIGVuZE9wdGlvbnMgPSBIYXZlQXN5bmNDYWxsYmFjayhhcmd1bWVudHMpPyB7YXN5bmM6IHRydWV9OiB7c3RhdHVzQ29kZTogcmVzcG9uc2Uuc3RhdHVzQ29kZX07XG4gICAgaWYoZXZlbnRJZCkge1xuICAgICAgS2FkaXJhLnRyYWNlci5ldmVudEVuZChrYWRpcmFJbmZvLnRyYWNlLCBldmVudElkLCBlbmRPcHRpb25zKTtcbiAgICB9XG4gICAgcmV0dXJuIHJlc3BvbnNlO1xuICB9IGNhdGNoKGV4KSB7XG4gICAgaWYoZXZlbnRJZCkge1xuICAgICAgS2FkaXJhLnRyYWNlci5ldmVudEVuZChrYWRpcmFJbmZvLnRyYWNlLCBldmVudElkLCB7ZXJyOiBleC5tZXNzYWdlfSk7XG4gICAgfVxuICAgIHRocm93IGV4O1xuICB9XG59OyIsInZhciBvcmlnaW5hbFNlbmQgPSBFbWFpbC5zZW5kO1xuXG5FbWFpbC5zZW5kID0gZnVuY3Rpb24ob3B0aW9ucykge1xuICB2YXIga2FkaXJhSW5mbyA9IEthZGlyYS5fZ2V0SW5mbygpO1xuICBpZihrYWRpcmFJbmZvKSB7XG4gICAgdmFyIGRhdGEgPSBfLnBpY2sob3B0aW9ucywgJ2Zyb20nLCAndG8nLCAnY2MnLCAnYmNjJywgJ3JlcGx5VG8nKTtcbiAgICB2YXIgZXZlbnRJZCA9IEthZGlyYS50cmFjZXIuZXZlbnQoa2FkaXJhSW5mby50cmFjZSwgJ2VtYWlsJywgZGF0YSk7XG4gIH1cbiAgdHJ5IHtcbiAgICB2YXIgcmV0ID0gb3JpZ2luYWxTZW5kLmNhbGwodGhpcywgb3B0aW9ucyk7XG4gICAgaWYoZXZlbnRJZCkge1xuICAgICAgS2FkaXJhLnRyYWNlci5ldmVudEVuZChrYWRpcmFJbmZvLnRyYWNlLCBldmVudElkKTtcbiAgICB9XG4gICAgcmV0dXJuIHJldDtcbiAgfSBjYXRjaChleCkge1xuICAgIGlmKGV2ZW50SWQpIHtcbiAgICAgIEthZGlyYS50cmFjZXIuZXZlbnRFbmQoa2FkaXJhSW5mby50cmFjZSwgZXZlbnRJZCwge2VycjogZXgubWVzc2FnZX0pO1xuICAgIH1cbiAgICB0aHJvdyBleDtcbiAgfVxufTsiLCJ2YXIgRmliZXJzID0gTnBtLnJlcXVpcmUoJ2ZpYmVycycpO1xudmFyIEV2ZW50U3ltYm9sID0gU3ltYm9sKCk7XG52YXIgU3RhcnRUcmFja2VkID0gU3ltYm9sKCk7XG5cbnZhciBhY3RpdmVGaWJlcnMgPSAwO1xudmFyIHdyYXBwZWQgPSBmYWxzZTtcblxuZXhwb3J0IGZ1bmN0aW9uIHdyYXBGaWJlcnMoKSB7XG4gIGlmICh3cmFwcGVkKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIHdyYXBwZWQgPSB0cnVlO1xuXG4gIHZhciBvcmlnaW5hbFlpZWxkID0gRmliZXJzLnlpZWxkO1xuICBGaWJlcnMueWllbGQgPSBmdW5jdGlvbiAoKSB7XG4gICAgdmFyIGthZGlyYUluZm8gPSBLYWRpcmEuX2dldEluZm8oKTtcbiAgICBpZiAoa2FkaXJhSW5mbykge1xuICAgICAgdmFyIGV2ZW50SWQgPSBLYWRpcmEudHJhY2VyLmV2ZW50KGthZGlyYUluZm8udHJhY2UsICdhc3luYycpO1xuICAgICAgaWYgKGV2ZW50SWQpIHtcbiAgICAgICAgLy8gVGhlIGV2ZW50IHVuaXF1ZSB0byB0aGlzIGZpYmVyXG4gICAgICAgIC8vIFVzaW5nIGEgc3ltYm9sIHNpbmNlIE1ldGVvciBkb2Vzbid0IGNvcHkgc3ltYm9scyB0byBuZXcgZmliZXJzIGNyZWF0ZWRcbiAgICAgICAgLy8gZm9yIHByb21pc2VzLiBUaGlzIGlzIG5lZWRlZCBzbyB0aGUgY29ycmVjdCBldmVudCBpcyBlbmRlZCB3aGVuIGEgZmliZXIgcnVucyBhZnRlciBiZWluZyB5aWVsZGVkLlxuICAgICAgICBGaWJlcnMuY3VycmVudFtFdmVudFN5bWJvbF0gPSBldmVudElkO1xuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBvcmlnaW5hbFlpZWxkKCk7XG4gIH07XG5cbiAgdmFyIG9yaWdpbmFsUnVuID0gRmliZXJzLnByb3RvdHlwZS5ydW47XG4gIHZhciBvcmlnaW5hbFRocm93SW50byA9IEZpYmVycy5wcm90b3R5cGUudGhyb3dJbnRvO1xuXG4gIGZ1bmN0aW9uIGVuc3VyZUZpYmVyQ291bnRlZChmaWJlcikge1xuICAgIC8vIElmIGZpYmVyLnN0YXJ0ZWQgaXMgdHJ1ZSwgYW5kIFN0YXJ0VHJhY2tlZCBpcyBmYWxzZVxuICAgIC8vIHRoZW4gdGhlIGZpYmVyIHdhcyBwcm9iYWJseSBpbml0aWFsbHkgcmFuIGJlZm9yZSB3ZSB3cmFwcGVkIEZpYmVycy5ydW5cbiAgICBpZiAoIWZpYmVyLnN0YXJ0ZWQgfHwgIWZpYmVyW1N0YXJ0VHJhY2tlZF0pIHtcbiAgICAgIGFjdGl2ZUZpYmVycyArPSAxO1xuICAgICAgZmliZXJbU3RhcnRUcmFja2VkXSA9IHRydWU7XG4gICAgfVxuICB9XG5cbiAgRmliZXJzLnByb3RvdHlwZS5ydW4gPSBmdW5jdGlvbiAodmFsKSB7XG4gICAgZW5zdXJlRmliZXJDb3VudGVkKHRoaXMpO1xuXG4gICAgaWYgKHRoaXNbRXZlbnRTeW1ib2xdKSB7XG4gICAgICB2YXIga2FkaXJhSW5mbyA9IEthZGlyYS5fZ2V0SW5mbyh0aGlzKTtcbiAgICAgIGlmIChrYWRpcmFJbmZvKSB7XG4gICAgICAgIEthZGlyYS50cmFjZXIuZXZlbnRFbmQoa2FkaXJhSW5mby50cmFjZSwgdGhpc1tFdmVudFN5bWJvbF0pO1xuICAgICAgICB0aGlzW0V2ZW50U3ltYm9sXSA9IG51bGw7XG4gICAgICB9XG4gICAgfSBlbHNlIGlmICghdGhpcy5fX2thZGlyYUluZm8gJiYgRmliZXJzLmN1cnJlbnQgJiYgRmliZXJzLmN1cnJlbnQuX19rYWRpcmFJbmZvKSB7XG4gICAgICAvLyBDb3B5IGthZGlyYUluZm8gd2hlbiBwYWNrYWdlcyBvciB1c2VyIGNvZGUgY3JlYXRlcyBhIG5ldyBmaWJlclxuICAgICAgLy8gRG9uZSBieSBtYW55IGFwcHMgYW5kIHBhY2thZ2VzIGluIGNvbm5lY3QgbWlkZGxld2FyZSBzaW5jZSBvbGRlclxuICAgICAgLy8gdmVyc2lvbnMgb2YgTWV0ZW9yIGRpZCBub3QgZG8gaXQgYXV0b21hdGljYWxseVxuICAgICAgdGhpcy5fX2thZGlyYUluZm8gPSBGaWJlcnMuY3VycmVudC5fX2thZGlyYUluZm87XG4gICAgfVxuXG4gICAgbGV0IHJlc3VsdDtcbiAgICB0cnkge1xuICAgICAgcmVzdWx0ID0gb3JpZ2luYWxSdW4uY2FsbCh0aGlzLCB2YWwpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBpZiAoIXRoaXMuc3RhcnRlZCkge1xuICAgICAgICBhY3RpdmVGaWJlcnMgLT0gMTtcbiAgICAgICAgdGhpc1tTdGFydFRyYWNrZWRdID0gZmFsc2U7XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIHJlc3VsdDtcbiAgfTtcblxuICBGaWJlcnMucHJvdG90eXBlLnRocm93SW50byA9IGZ1bmN0aW9uICh2YWwpIHtcbiAgICBlbnN1cmVGaWJlckNvdW50ZWQodGhpcyk7XG5cbiAgICAvLyBUT0RPOiB0aGlzIHNob3VsZCBwcm9iYWJseSBlbmQgdGhlIGN1cnJlbnQgYXN5bmMgZXZlbnQgc2luY2UgaW4gc29tZSBwbGFjZXNcbiAgICAvLyBNZXRlb3IgY2FsbHMgdGhyb3dJbnRvIGluc3RlYWQgb2YgcnVuIGFmdGVyIGEgZmliZXIgaXMgeWllbGRlZC4gRm9yIGV4YW1wbGUsXG4gICAgLy8gd2hlbiBhIHByb21pc2UgaXMgYXdhaXRlZCBhbmQgcmVqZWN0cyBhbiBlcnJvci5cblxuICAgIGxldCByZXN1bHQ7XG4gICAgdHJ5IHtcbiAgICAgIHJlc3VsdCA9IG9yaWdpbmFsVGhyb3dJbnRvLmNhbGwodGhpcywgdmFsKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgaWYgKCF0aGlzLnN0YXJ0ZWQpIHtcbiAgICAgICAgYWN0aXZlRmliZXJzIC09IDE7XG4gICAgICAgIHRoaXNbU3RhcnRUcmFja2VkXSA9IGZhbHNlO1xuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiByZXN1bHQ7XG4gIH07XG59XG5cbmxldCBhY3RpdmVGaWJlclRvdGFsID0gMDtcbmxldCBhY3RpdmVGaWJlckNvdW50ID0gMDtcbmxldCBwcmV2aW91c1RvdGFsQ3JlYXRlZCA9IDA7XG5cbnNldEludGVydmFsKCgpID0+IHtcbiAgYWN0aXZlRmliZXJUb3RhbCArPSBhY3RpdmVGaWJlcnM7XG4gIGFjdGl2ZUZpYmVyQ291bnQgKz0gMTtcbn0sIDEwMDApO1xuXG5leHBvcnQgZnVuY3Rpb24gZ2V0RmliZXJNZXRyaWNzKCkge1xuICByZXR1cm4ge1xuICAgIGNyZWF0ZWQ6IEZpYmVycy5maWJlcnNDcmVhdGVkIC0gcHJldmlvdXNUb3RhbENyZWF0ZWQsXG4gICAgYWN0aXZlOiBhY3RpdmVGaWJlclRvdGFsIC8gYWN0aXZlRmliZXJDb3VudCxcbiAgICBwb29sU2l6ZTogRmliZXJzLnBvb2xTaXplXG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHJlc2V0RmliZXJNZXRyaWNzKCkge1xuICBhY3RpdmVGaWJlclRvdGFsID0gMDtcbiAgYWN0aXZlRmliZXJDb3VudCA9IDA7XG4gIHByZXZpb3VzVG90YWxDcmVhdGVkID0gRmliZXJzLmZpYmVyc0NyZWF0ZWQ7XG59XG4iLCJleHBvcnQgY29uc3QgTWV0ZW9yRGVidWdJZ25vcmUgPSBTeW1ib2woKVxuXG5UcmFja1VuY2F1Z2h0RXhjZXB0aW9ucyA9IGZ1bmN0aW9uICgpIHtcbiAgcHJvY2Vzcy5vbigndW5jYXVnaHRFeGNlcHRpb24nLCBmdW5jdGlvbiAoZXJyKSB7XG4gICAgLy8gc2tpcCBlcnJvcnMgd2l0aCBgX3NraXBLYWRpcmFgIGZsYWdcbiAgICBpZihlcnIuX3NraXBLYWRpcmEpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvLyBsZXQgdGhlIHNlcnZlciBjcmFzaCBub3JtYWxseSBpZiBlcnJvciB0cmFja2luZyBpcyBkaXNhYmxlZFxuICAgIGlmKCFLYWRpcmEub3B0aW9ucy5lbmFibGVFcnJvclRyYWNraW5nKSB7XG4gICAgICBwcmludEVycm9yQW5kS2lsbChlcnIpO1xuICAgIH1cblxuICAgIC8vIGxvb2tpbmcgZm9yIGFscmVhZHkgdHJhY2tlZCBlcnJvcnMgYW5kIHRocm93IHRoZW0gaW1tZWRpYXRlbHlcbiAgICAvLyB0aHJvdyBlcnJvciBpbW1lZGlhdGVseSBpZiBrYWRpcmEgaXMgbm90IHJlYWR5XG4gICAgaWYoZXJyLl90cmFja2VkIHx8ICFLYWRpcmEuY29ubmVjdGVkKSB7XG4gICAgICBwcmludEVycm9yQW5kS2lsbChlcnIpO1xuICAgIH1cblxuICAgIHZhciB0cmFjZSA9IGdldFRyYWNlKGVyciwgJ3NlcnZlci1jcmFzaCcsICd1bmNhdWdodEV4Y2VwdGlvbicpO1xuICAgIEthZGlyYS5tb2RlbHMuZXJyb3IudHJhY2tFcnJvcihlcnIsIHRyYWNlKTtcbiAgICBLYWRpcmEuX3NlbmRQYXlsb2FkKGZ1bmN0aW9uICgpIHtcbiAgICAgIGNsZWFyVGltZW91dCh0aW1lcik7XG4gICAgICB0aHJvd0Vycm9yKGVycik7XG4gICAgfSk7XG5cbiAgICB2YXIgdGltZXIgPSBzZXRUaW1lb3V0KGZ1bmN0aW9uICgpIHtcbiAgICAgIHRocm93RXJyb3IoZXJyKTtcbiAgICB9LCAxMDAwKjEwKTtcblxuICAgIGZ1bmN0aW9uIHRocm93RXJyb3IoZXJyKSB7XG4gICAgICAvLyBzb21ldGltZXMgZXJyb3IgY2FtZSBiYWNrIGZyb20gYSBmaWJlci5cbiAgICAgIC8vIEJ1dCB3ZSBkb24ndCBmaWJlcnMgdG8gdHJhY2sgdGhhdCBlcnJvciBmb3IgdXNcbiAgICAgIC8vIFRoYXQncyB3aHkgd2UgdGhyb3cgdGhlIGVycm9yIG9uIHRoZSBuZXh0VGlja1xuICAgICAgcHJvY2Vzcy5uZXh0VGljayhmdW5jdGlvbigpIHtcbiAgICAgICAgLy8gd2UgbmVlZCB0byBtYXJrIHRoaXMgZXJyb3Igd2hlcmUgd2UgcmVhbGx5IG5lZWQgdG8gdGhyb3dcbiAgICAgICAgZXJyLl90cmFja2VkID0gdHJ1ZTtcbiAgICAgICAgcHJpbnRFcnJvckFuZEtpbGwoZXJyKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgfSk7XG5cbiAgZnVuY3Rpb24gcHJpbnRFcnJvckFuZEtpbGwoZXJyKSB7XG4gICAgLy8gc2luY2Ugd2UgYXJlIGNhcHR1cmluZyBlcnJvciwgd2UgYXJlIGFsc28gb24gdGhlIGVycm9yIG1lc3NhZ2UuXG4gICAgLy8gc28gZGV2ZWxvcGVycyB0aGluayB3ZSBhcmUgYWxzbyByZXBvbnNpYmxlIGZvciB0aGUgZXJyb3IuXG4gICAgLy8gQnV0IHdlIGFyZSBub3QuIFRoaXMgd2lsbCBmaXggdGhhdC5cbiAgICBjb25zb2xlLmVycm9yKGVyci5zdGFjayk7XG4gICAgcHJvY2Vzcy5leGl0KDcpO1xuICB9XG59XG5cblRyYWNrVW5oYW5kbGVkUmVqZWN0aW9ucyA9IGZ1bmN0aW9uICgpIHtcbiAgcHJvY2Vzcy5vbigndW5oYW5kbGVkUmVqZWN0aW9uJywgZnVuY3Rpb24gKHJlYXNvbikge1xuICAgIC8vIHNraXAgZXJyb3JzIHdpdGggYF9za2lwS2FkaXJhYCBmbGFnXG4gICAgaWYoXG4gICAgICByZWFzb24uX3NraXBLYWRpcmEgfHxcbiAgICAgICFLYWRpcmEub3B0aW9ucy5lbmFibGVFcnJvclRyYWNraW5nXG4gICAgKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgdmFyIHRyYWNlID0gZ2V0VHJhY2UocmVhc29uLCAnc2VydmVyLWludGVybmFsJywgJ3VuaGFuZGxlZFJlamVjdGlvbicpO1xuICAgIEthZGlyYS5tb2RlbHMuZXJyb3IudHJhY2tFcnJvcihyZWFzb24sIHRyYWNlKTtcblxuICAgIC8vIFRPRE86IHdlIHNob3VsZCByZXNwZWN0IHRoZSAtLXVuaGFuZGxlZC1yZWplY3Rpb25zIG9wdGlvblxuICAgIC8vIG1lc3NhZ2UgdGFrZW4gZnJvbSBcbiAgICAvLyBodHRwczovL2dpdGh1Yi5jb20vbm9kZWpzL25vZGUvYmxvYi9mNDc5N2ZmMWVmNzMwNDY1OWQ3NDdkMTgxZWMxZTdhZmFjNDA4ZDUwL2xpYi9pbnRlcm5hbC9wcm9jZXNzL3Byb21pc2VzLmpzI0wyNDMtTDI0OFxuICAgIGNvbnN0IG1lc3NhZ2UgPVxuICAgICAgJ1RoaXMgZXJyb3Igb3JpZ2luYXRlZCBlaXRoZXIgYnkgJyArXG4gICAgICAndGhyb3dpbmcgaW5zaWRlIG9mIGFuIGFzeW5jIGZ1bmN0aW9uIHdpdGhvdXQgYSBjYXRjaCBibG9jaywgJyArXG4gICAgICAnb3IgYnkgcmVqZWN0aW5nIGEgcHJvbWlzZSB3aGljaCB3YXMgbm90IGhhbmRsZWQgd2l0aCAuY2F0Y2goKS4nICtcbiAgICAgICcgVGhlIHByb21pc2UgcmVqZWN0ZWQgd2l0aCB0aGUgcmVhc29uOiAnO1xuXG4gICAgLy8gV2UgY291bGQgZW1pdCBhIHdhcm5pbmcgaW5zdGVhZCBsaWtlIE5vZGUgZG9lcyBpbnRlcm5hbGx5XG4gICAgLy8gYnV0IGl0IHJlcXVpcmVzIE5vZGUgOCBvciBuZXdlclxuICAgIGNvbnNvbGUud2FybihtZXNzYWdlKTtcbiAgICBjb25zb2xlLmVycm9yKHJlYXNvbiAmJiByZWFzb24uc3RhY2sgPyByZWFzb24uc3RhY2sgOiByZWFzb24pXG4gIH0pO1xufVxuXG5UcmFja01ldGVvckRlYnVnID0gZnVuY3Rpb24gKCkge1xuICB2YXIgb3JpZ2luYWxNZXRlb3JEZWJ1ZyA9IE1ldGVvci5fZGVidWc7XG4gIE1ldGVvci5fZGVidWcgPSBmdW5jdGlvbiAobWVzc2FnZSwgc3RhY2spIHtcbiAgICAvLyBTb21ldGltZXMgTWV0ZW9yIGNhbGxzIE1ldGVvci5fZGVidWcgd2l0aCBubyBhcmd1bWVudHNcbiAgICAvLyB0byBsb2cgYW4gZW1wdHkgbGluZVxuICAgIGNvbnN0IGlzQXJncyA9IG1lc3NhZ2UgIT09IHVuZGVmaW5lZCB8fCBzdGFjayAhPT0gdW5kZWZpbmVkO1xuXG4gICAgLy8gV2UndmUgY2hhbmdlZCBgc3RhY2tgIGludG8gYW4gb2JqZWN0IGF0IG1ldGhvZCBhbmQgc3ViIGhhbmRsZXJzIHNvIHdlIGNhblxuICAgIC8vIGRldGVjdCB0aGUgZXJyb3IgaGVyZS4gVGhlc2UgZXJyb3JzIGFyZSBhbHJlYWR5IHRyYWNrZWQgc28gZG9uJ3QgdHJhY2sgdGhlbSBhZ2Fpbi5cbiAgICB2YXIgYWxyZWFkeVRyYWNrZWQgPSBmYWxzZTtcblxuICAgIC8vIFNvbWUgTWV0ZW9yIHZlcnNpb25zIHBhc3MgdGhlIGVycm9yLCBhbmQgb3RoZXIgdmVyc2lvbnMgcGFzcyB0aGUgZXJyb3Igc3RhY2tcbiAgICAvLyBSZXN0b3JlIHNvIG9yaWdpb25hbE1ldGVvckRlYnVnIHNob3dzIHRoZSBzdGFjayBhcyBhIHN0cmluZyBpbnN0ZWFkIGFzIGFuIG9iamVjdFxuICAgIGlmIChzdGFjayAmJiBzdGFja1tNZXRlb3JEZWJ1Z0lnbm9yZV0pIHtcbiAgICAgIGFscmVhZHlUcmFja2VkID0gdHJ1ZTtcbiAgICAgIGFyZ3VtZW50c1sxXSA9IHN0YWNrLnN0YWNrO1xuICAgIH0gZWxzZSBpZiAoc3RhY2sgJiYgc3RhY2suc3RhY2sgJiYgc3RhY2suc3RhY2tbTWV0ZW9yRGVidWdJZ25vcmVdKSB7XG4gICAgICBhbHJlYWR5VHJhY2tlZCA9IHRydWU7XG4gICAgICBhcmd1bWVudHNbMV0gPSBzdGFjay5zdGFjay5zdGFjaztcbiAgICB9XG5cbiAgICAvLyBvbmx5IHNlbmQgdG8gdGhlIHNlcnZlciBpZiBjb25uZWN0ZWQgdG8ga2FkaXJhXG4gICAgaWYgKFxuICAgICAgS2FkaXJhLm9wdGlvbnMuZW5hYmxlRXJyb3JUcmFja2luZyAmJlxuICAgICAgaXNBcmdzICYmXG4gICAgICAhYWxyZWFkeVRyYWNrZWQgJiZcbiAgICAgIEthZGlyYS5jb25uZWN0ZWRcbiAgICApIHtcbiAgICAgIGxldCBlcnJvck1lc3NhZ2UgPSBtZXNzYWdlO1xuXG4gICAgICBpZiAodHlwZW9mIG1lc3NhZ2UgPT0gJ3N0cmluZycgJiYgc3RhY2sgaW5zdGFuY2VvZiBFcnJvcikge1xuICAgICAgICBjb25zdCBzZXBhcmF0b3IgPSBtZXNzYWdlLmVuZHNXaXRoKCc6JykgPyAnJyA6ICc6J1xuICAgICAgICBlcnJvck1lc3NhZ2UgPSBgJHttZXNzYWdlfSR7c2VwYXJhdG9yfSAke3N0YWNrLm1lc3NhZ2V9YFxuICAgICAgfVxuXG4gICAgICBsZXQgZXJyb3IgPSBuZXcgRXJyb3IoZXJyb3JNZXNzYWdlKTtcbiAgICAgIGlmIChzdGFjayBpbnN0YW5jZW9mIEVycm9yKSB7XG4gICAgICAgIGVycm9yLnN0YWNrID0gc3RhY2suc3RhY2s7XG4gICAgICB9IGVsc2UgaWYgKHN0YWNrKSB7XG4gICAgICAgIGVycm9yLnN0YWNrID0gc3RhY2s7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBlcnJvci5zdGFjayA9IENyZWF0ZVVzZXJTdGFjayhlcnJvcik7XG4gICAgICB9XG4gICAgICB2YXIgdHJhY2UgPSBnZXRUcmFjZShlcnJvciwgJ3NlcnZlci1pbnRlcm5hbCcsICdNZXRlb3IuX2RlYnVnJyk7XG4gICAgICBLYWRpcmEubW9kZWxzLmVycm9yLnRyYWNrRXJyb3IoZXJyb3IsIHRyYWNlKTtcbiAgICB9XG5cbiAgICByZXR1cm4gb3JpZ2luYWxNZXRlb3JEZWJ1Zy5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICB9XG59XG5cbmZ1bmN0aW9uIGdldFRyYWNlKGVyciwgdHlwZSwgc3ViVHlwZSkge1xuICByZXR1cm4ge1xuICAgIHR5cGU6IHR5cGUsXG4gICAgc3ViVHlwZTogc3ViVHlwZSxcbiAgICBuYW1lOiBlcnIubWVzc2FnZSxcbiAgICBlcnJvcmVkOiB0cnVlLFxuICAgIGF0OiBLYWRpcmEuc3luY2VkRGF0ZS5nZXRUaW1lKCksXG4gICAgZXZlbnRzOiBbXG4gICAgICBbJ3N0YXJ0JywgMCwge31dLFxuICAgICAgWydlcnJvcicsIDAsIHtlcnJvcjoge21lc3NhZ2U6IGVyci5tZXNzYWdlLCBzdGFjazogZXJyLnN0YWNrfX1dXG4gICAgXSxcbiAgICBtZXRyaWNzOiB7XG4gICAgICB0b3RhbDogMFxuICAgIH1cbiAgfTtcbn1cbiIsInNldExhYmVscyA9IGZ1bmN0aW9uICgpIHtcbiAgLy8gbmFtZSBTZXNzaW9uLnByb3RvdHlwZS5zZW5kXG4gIHZhciBvcmlnaW5hbFNlbmQgPSBNZXRlb3JYLlNlc3Npb24ucHJvdG90eXBlLnNlbmQ7XG4gIE1ldGVvclguU2Vzc2lvbi5wcm90b3R5cGUuc2VuZCA9IGZ1bmN0aW9uIGthZGlyYV9TZXNzaW9uX3NlbmQgKG1zZykge1xuICAgIHJldHVybiBvcmlnaW5hbFNlbmQuY2FsbCh0aGlzLCBtc2cpO1xuICB9XG5cbiAgLy8gbmFtZSBNdWx0aXBsZXhlciBpbml0aWFsIGFkZHNcbiAgLy8gTXVsdGlwbGV4ZXIgaXMgdW5kZWZpbmVkIGluIHJvY2tldCBjaGF0XG4gIGlmIChNZXRlb3JYLk11bHRpcGxleGVyKSB7XG4gICAgdmFyIG9yaWdpbmFsU2VuZEFkZHMgPSBNZXRlb3JYLk11bHRpcGxleGVyLnByb3RvdHlwZS5fc2VuZEFkZHM7XG4gICAgTWV0ZW9yWC5NdWx0aXBsZXhlci5wcm90b3R5cGUuX3NlbmRBZGRzID0gZnVuY3Rpb24ga2FkaXJhX011bHRpcGxleGVyX3NlbmRBZGRzIChoYW5kbGUpIHtcbiAgICAgIHJldHVybiBvcmlnaW5hbFNlbmRBZGRzLmNhbGwodGhpcywgaGFuZGxlKTtcbiAgICB9XG4gIH1cblxuICAvLyBuYW1lIE1vbmdvQ29ubmVjdGlvbiBpbnNlcnRcbiAgdmFyIG9yaWdpbmFsTW9uZ29JbnNlcnQgPSBNZXRlb3JYLk1vbmdvQ29ubmVjdGlvbi5wcm90b3R5cGUuX2luc2VydDtcbiAgTWV0ZW9yWC5Nb25nb0Nvbm5lY3Rpb24ucHJvdG90eXBlLl9pbnNlcnQgPSBmdW5jdGlvbiBrYWRpcmFfTW9uZ29Db25uZWN0aW9uX2luc2VydCAoY29sbCwgZG9jLCBjYikge1xuICAgIHJldHVybiBvcmlnaW5hbE1vbmdvSW5zZXJ0LmNhbGwodGhpcywgY29sbCwgZG9jLCBjYik7XG4gIH1cblxuICAvLyBuYW1lIE1vbmdvQ29ubmVjdGlvbiB1cGRhdGVcbiAgdmFyIG9yaWdpbmFsTW9uZ29VcGRhdGUgPSBNZXRlb3JYLk1vbmdvQ29ubmVjdGlvbi5wcm90b3R5cGUuX3VwZGF0ZTtcbiAgTWV0ZW9yWC5Nb25nb0Nvbm5lY3Rpb24ucHJvdG90eXBlLl91cGRhdGUgPSBmdW5jdGlvbiBrYWRpcmFfTW9uZ29Db25uZWN0aW9uX3VwZGF0ZSAoY29sbCwgc2VsZWN0b3IsIG1vZCwgb3B0aW9ucywgY2IpIHtcbiAgICByZXR1cm4gb3JpZ2luYWxNb25nb1VwZGF0ZS5jYWxsKHRoaXMsIGNvbGwsIHNlbGVjdG9yLCBtb2QsIG9wdGlvbnMsIGNiKTtcbiAgfVxuXG4gIC8vIG5hbWUgTW9uZ29Db25uZWN0aW9uIHJlbW92ZVxuICB2YXIgb3JpZ2luYWxNb25nb1JlbW92ZSA9IE1ldGVvclguTW9uZ29Db25uZWN0aW9uLnByb3RvdHlwZS5fcmVtb3ZlO1xuICBNZXRlb3JYLk1vbmdvQ29ubmVjdGlvbi5wcm90b3R5cGUuX3JlbW92ZSA9IGZ1bmN0aW9uIGthZGlyYV9Nb25nb0Nvbm5lY3Rpb25fcmVtb3ZlIChjb2xsLCBzZWxlY3RvciwgY2IpIHtcbiAgICByZXR1cm4gb3JpZ2luYWxNb25nb1JlbW92ZS5jYWxsKHRoaXMsIGNvbGwsIHNlbGVjdG9yLCBjYik7XG4gIH1cblxuICAvLyBuYW1lIFB1YnN1YiBhZGRlZFxuICB2YXIgb3JpZ2luYWxQdWJzdWJBZGRlZCA9IE1ldGVvclguU2Vzc2lvbi5wcm90b3R5cGUuc2VuZEFkZGVkO1xuICBNZXRlb3JYLlNlc3Npb24ucHJvdG90eXBlLnNlbmRBZGRlZCA9IGZ1bmN0aW9uIGthZGlyYV9TZXNzaW9uX3NlbmRBZGRlZCAoY29sbCwgaWQsIGZpZWxkcykge1xuICAgIHJldHVybiBvcmlnaW5hbFB1YnN1YkFkZGVkLmNhbGwodGhpcywgY29sbCwgaWQsIGZpZWxkcyk7XG4gIH1cblxuICAvLyBuYW1lIFB1YnN1YiBjaGFuZ2VkXG4gIHZhciBvcmlnaW5hbFB1YnN1YkNoYW5nZWQgPSBNZXRlb3JYLlNlc3Npb24ucHJvdG90eXBlLnNlbmRDaGFuZ2VkO1xuICBNZXRlb3JYLlNlc3Npb24ucHJvdG90eXBlLnNlbmRDaGFuZ2VkID0gZnVuY3Rpb24ga2FkaXJhX1Nlc3Npb25fc2VuZENoYW5nZWQgKGNvbGwsIGlkLCBmaWVsZHMpIHtcbiAgICByZXR1cm4gb3JpZ2luYWxQdWJzdWJDaGFuZ2VkLmNhbGwodGhpcywgY29sbCwgaWQsIGZpZWxkcyk7XG4gIH1cblxuICAvLyBuYW1lIFB1YnN1YiByZW1vdmVkXG4gIHZhciBvcmlnaW5hbFB1YnN1YlJlbW92ZWQgPSBNZXRlb3JYLlNlc3Npb24ucHJvdG90eXBlLnNlbmRSZW1vdmVkO1xuICBNZXRlb3JYLlNlc3Npb24ucHJvdG90eXBlLnNlbmRSZW1vdmVkID0gZnVuY3Rpb24ga2FkaXJhX1Nlc3Npb25fc2VuZFJlbW92ZWQgKGNvbGwsIGlkKSB7XG4gICAgcmV0dXJuIG9yaWdpbmFsUHVic3ViUmVtb3ZlZC5jYWxsKHRoaXMsIGNvbGwsIGlkKTtcbiAgfVxuXG4gIC8vIG5hbWUgTW9uZ29DdXJzb3IgZm9yRWFjaFxuICB2YXIgb3JpZ2luYWxDdXJzb3JGb3JFYWNoID0gTWV0ZW9yWC5Nb25nb0N1cnNvci5wcm90b3R5cGUuZm9yRWFjaDtcbiAgTWV0ZW9yWC5Nb25nb0N1cnNvci5wcm90b3R5cGUuZm9yRWFjaCA9IGZ1bmN0aW9uIGthZGlyYV9DdXJzb3JfZm9yRWFjaCAoKSB7XG4gICAgcmV0dXJuIG9yaWdpbmFsQ3Vyc29yRm9yRWFjaC5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICB9XG5cbiAgLy8gbmFtZSBNb25nb0N1cnNvciBtYXBcbiAgdmFyIG9yaWdpbmFsQ3Vyc29yTWFwID0gTWV0ZW9yWC5Nb25nb0N1cnNvci5wcm90b3R5cGUubWFwO1xuICBNZXRlb3JYLk1vbmdvQ3Vyc29yLnByb3RvdHlwZS5tYXAgPSBmdW5jdGlvbiBrYWRpcmFfQ3Vyc29yX21hcCAoKSB7XG4gICAgcmV0dXJuIG9yaWdpbmFsQ3Vyc29yTWFwLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gIH1cblxuICAvLyBuYW1lIE1vbmdvQ3Vyc29yIGZldGNoXG4gIHZhciBvcmlnaW5hbEN1cnNvckZldGNoID0gTWV0ZW9yWC5Nb25nb0N1cnNvci5wcm90b3R5cGUuZmV0Y2g7XG4gIE1ldGVvclguTW9uZ29DdXJzb3IucHJvdG90eXBlLmZldGNoID0gZnVuY3Rpb24ga2FkaXJhX0N1cnNvcl9mZXRjaCAoKSB7XG4gICAgcmV0dXJuIG9yaWdpbmFsQ3Vyc29yRmV0Y2guYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbiAgfVxuXG4gIC8vIG5hbWUgTW9uZ29DdXJzb3IgY291bnRcbiAgdmFyIG9yaWdpbmFsQ3Vyc29yQ291bnQgPSBNZXRlb3JYLk1vbmdvQ3Vyc29yLnByb3RvdHlwZS5jb3VudDtcbiAgTWV0ZW9yWC5Nb25nb0N1cnNvci5wcm90b3R5cGUuY291bnQgPSBmdW5jdGlvbiBrYWRpcmFfQ3Vyc29yX2NvdW50ICgpIHtcbiAgICByZXR1cm4gb3JpZ2luYWxDdXJzb3JDb3VudC5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICB9XG5cbiAgLy8gbmFtZSBNb25nb0N1cnNvciBvYnNlcnZlQ2hhbmdlc1xuICB2YXIgb3JpZ2luYWxDdXJzb3JPYnNlcnZlQ2hhbmdlcyA9IE1ldGVvclguTW9uZ29DdXJzb3IucHJvdG90eXBlLm9ic2VydmVDaGFuZ2VzO1xuICBNZXRlb3JYLk1vbmdvQ3Vyc29yLnByb3RvdHlwZS5vYnNlcnZlQ2hhbmdlcyA9IGZ1bmN0aW9uIGthZGlyYV9DdXJzb3Jfb2JzZXJ2ZUNoYW5nZXMgKCkge1xuICAgIHJldHVybiBvcmlnaW5hbEN1cnNvck9ic2VydmVDaGFuZ2VzLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gIH1cblxuICAvLyBuYW1lIE1vbmdvQ3Vyc29yIG9ic2VydmVcbiAgdmFyIG9yaWdpbmFsQ3Vyc29yT2JzZXJ2ZSA9IE1ldGVvclguTW9uZ29DdXJzb3IucHJvdG90eXBlLm9ic2VydmU7XG4gIE1ldGVvclguTW9uZ29DdXJzb3IucHJvdG90eXBlLm9ic2VydmUgPSBmdW5jdGlvbiBrYWRpcmFfQ3Vyc29yX29ic2VydmUgKCkge1xuICAgIHJldHVybiBvcmlnaW5hbEN1cnNvck9ic2VydmUuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbiAgfVxuXG4gIC8vIG5hbWUgQ3Jvc3NCYXIgbGlzdGVuXG4gIHZhciBvcmlnaW5hbENyb3NzYmFyTGlzdGVuID0gRERQU2VydmVyLl9Dcm9zc2Jhci5wcm90b3R5cGUubGlzdGVuO1xuICBERFBTZXJ2ZXIuX0Nyb3NzYmFyLnByb3RvdHlwZS5saXN0ZW4gPSBmdW5jdGlvbiBrYWRpcmFfQ3Jvc3NiYXJfbGlzdGVuICh0cmlnZ2VyLCBjYWxsYmFjaykge1xuICAgIHJldHVybiBvcmlnaW5hbENyb3NzYmFyTGlzdGVuLmNhbGwodGhpcywgdHJpZ2dlciwgY2FsbGJhY2spO1xuICB9XG5cbiAgLy8gbmFtZSBDcm9zc0JhciBmaXJlXG4gIHZhciBvcmlnaW5hbENyb3NzYmFyRmlyZSA9IEREUFNlcnZlci5fQ3Jvc3NiYXIucHJvdG90eXBlLmZpcmU7XG4gIEREUFNlcnZlci5fQ3Jvc3NiYXIucHJvdG90eXBlLmZpcmUgPSBmdW5jdGlvbiBrYWRpcmFfQ3Jvc3NiYXJfZmlyZSAobm90aWZpY2F0aW9uKSB7XG4gICAgcmV0dXJuIG9yaWdpbmFsQ3Jvc3NiYXJGaXJlLmNhbGwodGhpcywgbm90aWZpY2F0aW9uKTtcbiAgfVxufVxuIiwiZXhwb3J0IGZ1bmN0aW9uIHdyYXBGYXN0UmVuZGVyICgpIHtcbiAgTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xuICAgIGlmIChQYWNrYWdlWydzdGFyaW5nYXRsaWdodHM6ZmFzdC1yZW5kZXInXSkge1xuICAgICAgY29uc3QgRmFzdFJlbmRlciA9IFBhY2thZ2VbJ3N0YXJpbmdhdGxpZ2h0czpmYXN0LXJlbmRlciddLkZhc3RSZW5kZXI7XG5cbiAgICAgIC8vIEZsb3cgUm91dGVyIGRvZXNuJ3QgY2FsbCBGYXN0UmVuZGVyLnJvdXRlIHVudGlsIGFmdGVyIGFsbFxuICAgICAgLy8gTWV0ZW9yLnN0YXJ0dXAgY2FsbGJhY2tzIGZpbmlzaFxuICAgICAgbGV0IG9yaWdSb3V0ZSA9IEZhc3RSZW5kZXIucm91dGVcbiAgICAgIEZhc3RSZW5kZXIucm91dGUgPSBmdW5jdGlvbiAocGF0aCwgX2NhbGxiYWNrKSB7XG4gICAgICAgIGxldCBjYWxsYmFjayA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICBjb25zdCBpbmZvID0gS2FkaXJhLl9nZXRJbmZvKClcbiAgICAgICAgICBpZiAoaW5mbykge1xuICAgICAgICAgICAgaW5mby5zdWdnZXN0ZWRSb3V0ZU5hbWUgPSBwYXRoXG4gICAgICAgICAgfVxuXG4gICAgICAgICAgcmV0dXJuIF9jYWxsYmFjay5hcHBseSh0aGlzLCBhcmd1bWVudHMpXG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gb3JpZ1JvdXRlLmNhbGwoRmFzdFJlbmRlciwgcGF0aCwgY2FsbGJhY2spXG4gICAgICB9XG4gICAgfVxuICB9KTtcbn1cbiIsImltcG9ydCBmcyBmcm9tICdmcyc7XG5jb25zdCBGaWJlcnMgPSByZXF1aXJlKCdmaWJlcnMnKTtcblxuZnVuY3Rpb24gd3JhcENhbGxiYWNrKGFyZ3MsIGNyZWF0ZVdyYXBwZXIpIHtcbiAgaWYgKHR5cGVvZiBhcmdzW2FyZ3MubGVuZ3RoIC0gMV0gPT09ICdmdW5jdGlvbicpIHtcbiAgICBhcmdzW2FyZ3MubGVuZ3RoIC0gMV0gPSBjcmVhdGVXcmFwcGVyKGFyZ3NbYXJncy5sZW5ndGggLSAxXSlcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gaGFuZGxlRXJyb3JFdmVudChldmVudEVtaXR0ZXIsIHRyYWNlLCBldmVudCkge1xuICBmdW5jdGlvbiBoYW5kbGVyIChlcnJvcikge1xuICAgIGlmICh0cmFjZSAmJiBldmVudCkge1xuICAgICAgS2FkaXJhLnRyYWNlci5ldmVudEVuZCh0cmFjZSwgZXZlbnQsIHtcbiAgICAgICAgZXJyb3I6IGVycm9yXG4gICAgICB9KTtcbiAgICB9XG5cbiAgICAvLyBOb2RlIHRocm93cyB0aGUgZXJyb3IgaWYgdGhlcmUgYXJlIG5vIGxpc3RlbmVyc1xuICAgIC8vIFdlIHdhbnQgaXQgdG8gYmVoYXZlIGFzIGlmIHdlIGFyZSBub3QgbGlzdGVuaW5nIHRvIGl0XG4gICAgaWYgKGV2ZW50RW1pdHRlci5saXN0ZW5lckNvdW50KCdlcnJvcicpID09PSAxKSB7XG4gICAgICBldmVudEVtaXR0ZXIucmVtb3ZlTGlzdGVuZXIoJ2Vycm9yJywgaGFuZGxlcik7XG4gICAgICBldmVudEVtaXR0ZXIuZW1pdCgnZXJyb3InLCBlcnJvcik7XG4gICAgfVxuICB9XG5cbiAgZXZlbnRFbWl0dGVyLm9uKCdlcnJvcicsIGhhbmRsZXIpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gd3JhcEZzKCkge1xuICAvLyBTb21lIG5wbSBwYWNrYWdlcyB3aWxsIGRvIGZzIGNhbGxzIGluIHRoZVxuICAvLyBjYWxsYmFjayBvZiBhbm90aGVyIGZzIGNhbGwuXG4gIC8vIFRoaXMgdmFyaWFibGUgaXMgc2V0IHdpdGggdGhlIGthZGlyYUluZm8gd2hpbGVcbiAgLy8gYSBjYWxsYmFjayBpcyBydW4gc28gd2UgY2FuIHRyYWNrIG90aGVyIGZzIGNhbGxzXG4gIGxldCBmc0thZGlyYUluZm8gPSBudWxsO1xuICBcbiAgbGV0IG9yaWdpbmFsU3RhdCA9IGZzLnN0YXQ7XG4gIGZzLnN0YXQgPSBmdW5jdGlvbiAoKSB7XG4gICAgY29uc3Qga2FkaXJhSW5mbyA9IEthZGlyYS5fZ2V0SW5mbygpIHx8IGZzS2FkaXJhSW5mbztcblxuICAgIGlmIChrYWRpcmFJbmZvKSB7XG4gICAgICBsZXQgZXZlbnQgPSBLYWRpcmEudHJhY2VyLmV2ZW50KGthZGlyYUluZm8udHJhY2UsICdmcycsIHtcbiAgICAgICAgZnVuYzogJ3N0YXQnLFxuICAgICAgICBwYXRoOiBhcmd1bWVudHNbMF0sXG4gICAgICAgIG9wdGlvbnM6IHR5cGVvZiBhcmd1bWVudHNbMV0gPT09ICdvYmplY3QnID8gYXJndW1lbnRzWzFdIDogdW5kZWZpbmVkXG4gICAgICB9KTtcblxuICAgICAgd3JhcENhbGxiYWNrKGFyZ3VtZW50cywgKGNiKSA9PiB7XG4gICAgICAgIHJldHVybiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgS2FkaXJhLnRyYWNlci5ldmVudEVuZChrYWRpcmFJbmZvLnRyYWNlLCBldmVudCk7XG5cbiAgICAgICAgICBpZiAoIUZpYmVycy5jdXJyZW50KSB7XG4gICAgICAgICAgICBmc0thZGlyYUluZm8gPSBrYWRpcmFJbmZvO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjYi5hcHBseShudWxsLCBhcmd1bWVudHMpXG4gICAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIGZzS2FkaXJhSW5mbyA9IG51bGw7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9XG5cbiAgICByZXR1cm4gb3JpZ2luYWxTdGF0LmFwcGx5KGZzLCBhcmd1bWVudHMpO1xuICB9O1xuXG4gIGxldCBvcmlnaW5hbENyZWF0ZVJlYWRTdHJlYW0gPSBmcy5jcmVhdGVSZWFkU3RyZWFtO1xuICBmcy5jcmVhdGVSZWFkU3RyZWFtID0gZnVuY3Rpb24gKCkge1xuICAgIGNvbnN0IGthZGlyYUluZm8gPSBLYWRpcmEuX2dldEluZm8oKSB8fCBmc0thZGlyYUluZm87XG4gICAgbGV0IHN0cmVhbSA9IG9yaWdpbmFsQ3JlYXRlUmVhZFN0cmVhbS5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuXG4gICAgaWYgKGthZGlyYUluZm8pIHtcbiAgICAgIGNvbnN0IGV2ZW50ID0gS2FkaXJhLnRyYWNlci5ldmVudChrYWRpcmFJbmZvLnRyYWNlLCAnZnMnLCB7XG4gICAgICAgIGZ1bmM6ICdjcmVhdGVSZWFkU3RyZWFtJyxcbiAgICAgICAgcGF0aDogYXJndW1lbnRzWzBdLFxuICAgICAgICBvcHRpb25zOiBKU09OLnN0cmluZ2lmeShhcmd1bWVudHNbMV0pXG4gICAgICB9KTtcblxuICAgICAgc3RyZWFtLm9uKCdlbmQnLCAoKSA9PiB7XG4gICAgICAgIEthZGlyYS50cmFjZXIuZXZlbnRFbmQoa2FkaXJhSW5mby50cmFjZSwgZXZlbnQpO1xuICAgICAgfSk7XG5cbiAgICAgIGhhbmRsZUVycm9yRXZlbnQoc3RyZWFtLCBrYWRpcmFJbmZvLnRyYWNlLCBldmVudCk7XG4gICAgfVxuXG4gICAgcmV0dXJuIHN0cmVhbTtcbiAgfTtcbn1cbiIsImxldCBQZXJmb3JtYW5jZU9ic2VydmVyO1xubGV0IGNvbnN0YW50cztcbmxldCBwZXJmb3JtYW5jZTtcblxudHJ5IHtcbiAgLy8gT25seSBhdmFpbGFibGUgaW4gTm9kZSA4LjUgYW5kIG5ld2VyXG4gICh7XG4gICAgUGVyZm9ybWFuY2VPYnNlcnZlcixcbiAgICBjb25zdGFudHMsXG4gICAgcGVyZm9ybWFuY2VcbiAgfSA9IHJlcXVpcmUoJ3BlcmZfaG9va3MnKSk7XG59IGNhdGNoIChlKSB7fVxuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBHQ01ldHJpY3Mge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICB0aGlzLl9vYnNlcnZlciA9IG51bGw7XG4gICAgdGhpcy5zdGFydGVkID0gZmFsc2U7XG4gICAgdGhpcy5tZXRyaWNzID0ge307XG5cbiAgICB0aGlzLnJlc2V0KCk7XG4gIH1cblxuICBzdGFydCgpIHtcbiAgICBpZiAodGhpcy5zdGFydGVkKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgaWYgKCFQZXJmb3JtYW5jZU9ic2VydmVyIHx8ICFjb25zdGFudHMpIHtcbiAgICAgIC8vIFRoZSBub2RlIHZlcnNpb24gaXMgdG9vIG9sZCB0byBoYXZlIFBlcmZvcm1hbmNlT2JzZXJ2ZXJcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG5cbiAgICB0aGlzLnN0YXJ0ZWQgPSB0cnVlO1xuXG4gICAgdGhpcy5vYnNlcnZlciA9IG5ldyBQZXJmb3JtYW5jZU9ic2VydmVyKGxpc3QgPT4ge1xuICAgICAgbGlzdC5nZXRFbnRyaWVzKCkuZm9yRWFjaChlbnRyeSA9PiB7XG4gICAgICAgIGxldCBtZXRyaWMgPSB0aGlzLl9tYXBLaW5kVG9NZXRyaWMoZW50cnkua2luZCk7XG4gICAgICAgIHRoaXMubWV0cmljc1ttZXRyaWNdICs9IGVudHJ5LmR1cmF0aW9uO1xuICAgICAgfSk7XG5cbiAgICAgIC8vIFRoZSBmdW5jdGlvbiB3YXMgcmVtb3ZlZCBpbiBOb2RlIDEwIHNpbmNlIGl0IHN0b3BwZWQgc3RvcmluZyBvbGRcbiAgICAgIC8vIGVudHJpZXNcbiAgICAgIGlmICh0eXBlb2YgcGVyZm9ybWFuY2UuY2xlYXJHQyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICBwZXJmb3JtYW5jZS5jbGVhckdDKCk7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICB0aGlzLm9ic2VydmVyLm9ic2VydmUoeyBlbnRyeVR5cGVzOiBbJ2djJ10sIGJ1ZmZlcmVkOiBmYWxzZSB9KTtcbiAgfVxuXG4gIF9tYXBLaW5kVG9NZXRyaWMoZ2NLaW5kKSB7XG4gICAgc3dpdGNoKGdjS2luZCkge1xuICAgICAgY2FzZSBjb25zdGFudHMuTk9ERV9QRVJGT1JNQU5DRV9HQ19NQUpPUjpcbiAgICAgICAgcmV0dXJuICdnY01ham9yJztcbiAgICAgIGNhc2UgY29uc3RhbnRzLk5PREVfUEVSRk9STUFOQ0VfR0NfTUlOT1I6XG4gICAgICAgIHJldHVybiAnZ2NNaW5vcic7XG4gICAgICBjYXNlIGNvbnN0YW50cy5OT0RFX1BFUkZPUk1BTkNFX0dDX0lOQ1JFTUVOVEFMOlxuICAgICAgICByZXR1cm4gJ2djSW5jcmVtZW50YWwnO1xuICAgICAgY2FzZSBjb25zdGFudHMuTk9ERV9QRVJGT1JNQU5DRV9HQ19XRUFLQ0I6XG4gICAgICAgIHJldHVybiAnZ2NXZWFrQ0InO1xuICAgICAgZGVmYXVsdDpcbiAgICAgICAgY29uc29sZS5sb2coYE1vbnRpIEFQTTogVW5yZWNvZ25pemVkIEdDIEtpbmQ6ICR7Z2NLaW5kfWApO1xuICAgIH1cbiAgfVxuXG4gIHJlc2V0KCkge1xuICAgIHRoaXMubWV0cmljcyA9IHtcbiAgICAgIGdjTWFqb3I6IDAsXG4gICAgICBnY01pbm9yOiAwLFxuICAgICAgZ2NJbmNyZW1lbnRhbDogMCxcbiAgICAgIGdjV2Vha0NCOiAwXG4gICAgfTtcbiAgfVxufVxuIiwidmFyIGNsaWVudDtcbnZhciBzZXJ2ZXJTdGF0dXMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuXG52YXIgb3RoZXJDaGVja291dHMgPSAwO1xuXG4vLyBUaGVzZSBtZXRyaWNzIGFyZSBvbmx5IGZvciB0aGUgbW9uZ28gcG9vbCBmb3IgdGhlIHByaW1hcnkgTW9uZ28gc2VydmVyXG52YXIgcHJpbWFyeUNoZWNrb3V0cyA9IDA7XG52YXIgdG90YWxDaGVja291dFRpbWUgPSAwO1xudmFyIG1heENoZWNrb3V0VGltZSA9IDA7XG52YXIgY3JlYXRlZCA9IDA7XG52YXIgbWVhc3VyZW1lbnRDb3VudCA9IDA7XG52YXIgcGVuZGluZ1RvdGFsID0gMDtcbnZhciBjaGVja2VkT3V0VG90YWwgPSAwO1xuXG5zZXRJbnRlcnZhbCgoKSA9PiB7XG4gIGxldCBzdGF0dXMgPSBnZXRTZXJ2ZXJTdGF0dXMoZ2V0UHJpbWFyeSgpLCB0cnVlKTtcblxuICBpZiAoc3RhdHVzKSB7XG4gICAgcGVuZGluZ1RvdGFsICs9IHN0YXR1cy5wZW5kaW5nLmxlbmd0aDtcbiAgICBjaGVja2VkT3V0VG90YWwgKz0gc3RhdHVzLmNoZWNrZWRPdXQuc2l6ZTtcbiAgICBtZWFzdXJlbWVudENvdW50ICs9IDE7XG4gIH1cbn0sIDEwMDApO1xuXG4vLyB0aGUgcG9vbCBkZWZhdWx0cyB0byAxMDAsIHRob3VnaCB1c3VhbGx5IHRoZSBkZWZhdWx0IGlzbid0IHVzZWRcbnZhciBERUZBVUxUX01BWF9QT09MX1NJWkUgPSAxMDA7XG5cbmZ1bmN0aW9uIGdldFBvb2xTaXplICgpIHtcbiAgaWYgKGNsaWVudCAmJiBjbGllbnQudG9wb2xvZ3kgJiYgY2xpZW50LnRvcG9sb2d5LnMgJiYgY2xpZW50LnRvcG9sb2d5LnMub3B0aW9ucykge1xuICAgIHJldHVybiBjbGllbnQudG9wb2xvZ3kucy5vcHRpb25zLm1heFBvb2xTaXplIHx8IERFRkFVTFRfTUFYX1BPT0xfU0laRTtcbiAgfVxuXG4gIHJldHVybiAwO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZ2V0TW9uZ29Ecml2ZXJTdGF0cyAoKSB7XG4gIHJldHVybiB7XG4gICAgcG9vbFNpemU6IGdldFBvb2xTaXplKCksXG4gICAgcHJpbWFyeUNoZWNrb3V0cyxcbiAgICBvdGhlckNoZWNrb3V0cyxcbiAgICBjaGVja291dFRpbWU6IHRvdGFsQ2hlY2tvdXRUaW1lLFxuICAgIG1heENoZWNrb3V0VGltZSxcbiAgICBwZW5kaW5nOiBwZW5kaW5nVG90YWwgLyBtZWFzdXJlbWVudENvdW50LFxuICAgIGNoZWNrZWRPdXQ6IGNoZWNrZWRPdXRUb3RhbCAvIG1lYXN1cmVtZW50Q291bnQsXG4gICAgY3JlYXRlZFxuICB9O1xufTtcblxuZXhwb3J0IGZ1bmN0aW9uIHJlc2V0TW9uZ29Ecml2ZXJTdGF0cygpIHtcbiAgcHJpbWFyeUNoZWNrb3V0cyA9IDA7XG4gIG90aGVyQ2hlY2tvdXRzID0gMDtcbiAgdG90YWxDaGVja291dFRpbWUgPSAwO1xuICBtYXhDaGVja291dFRpbWUgPSAwO1xuICBwZW5kaW5nVG90YWwgPSAwO1xuICBjaGVja2VkT3V0VG90YWwgPSAwO1xuICBtZWFzdXJlbWVudENvdW50ID0gMDtcbiAgcHJpbWFyeUNoZWNrb3V0cyA9IDA7XG4gIGNyZWF0ZWQgPSAwO1xufVxuXG5NZXRlb3Iuc3RhcnR1cCgoKSA9PiB7XG4gIGxldCBfY2xpZW50ID0gTW9uZ29JbnRlcm5hbHMuZGVmYXVsdFJlbW90ZUNvbGxlY3Rpb25Ecml2ZXIoKS5tb25nby5jbGllbnQ7XG5cbiAgaWYgKCFfY2xpZW50IHx8ICFfY2xpZW50LnMpIHtcbiAgICAvLyBPbGQgdmVyc2lvbiBvZiBhZ2VudFxuICAgIHJldHVybjtcbiAgfVxuXG4gIGxldCBvcHRpb25zID0gX2NsaWVudC5zLm9wdGlvbnM7XG4gIGlmICghb3B0aW9ucyB8fCAhb3B0aW9ucy51c2VVbmlmaWVkVG9wb2xvZ3kpIHtcbiAgICAvLyBDTUFQIGFuZCB0b3BvbG9neSBtb25pdG9yaW5nIHJlcXVpcmVzIHVzZVVuaWZpZWRUb3BvbG9neVxuICAgIHJldHVybjtcbiAgfVxuXG4gIGNsaWVudCA9IF9jbGllbnQ7XG5cbiAgLy8gR2V0IHRoZSBudW1iZXIgb2YgY29ubmVjdGlvbnMgYWxyZWFkeSBjcmVhdGVkXG4gIGxldCBwcmltYXJ5RGVzY3JpcHRpb24gPSBnZXRTZXJ2ZXJEZXNjcmlwdGlvbihnZXRQcmltYXJ5KCkpO1xuICBpZiAocHJpbWFyeURlc2NyaXB0aW9uICYmIHByaW1hcnlEZXNjcmlwdGlvbi5zICYmIHByaW1hcnlEZXNjcmlwdGlvbi5zLnBvb2wpIHtcbiAgICBsZXQgcG9vbCA9IHByaW1hcnlEZXNjcmlwdGlvbi5zLnBvb2w7XG4gICAgbGV0IHRvdGFsQ29ubmVjdGlvbnMgPSBwb29sLnRvdGFsQ29ubmVjdGlvbkNvdW50O1xuICAgIGxldCBhdmFpbGFibGVDb25uZWN0aW9ucyA9IHBvb2wuYXZhaWxhYmxlQ29ubmVjdGlvbkNvdW50O1xuXG4gICAgLy8gdG90YWxDb25uZWN0aW9uQ291bnQgY291bnRzIGF2YWlsYWJsZSBjb25uZWN0aW9ucyB0d2ljZVxuICAgIGNyZWF0ZWQgKz0gdG90YWxDb25uZWN0aW9ucyAtIGF2YWlsYWJsZUNvbm5lY3Rpb25zO1xuICB9XG5cbiAgY2xpZW50Lm9uKCdjb25uZWN0aW9uQ3JlYXRlZCcsIGV2ZW50ID0+IHtcbiAgICBsZXQgcHJpbWFyeSA9IGdldFByaW1hcnkoKTtcbiAgICBpZiAocHJpbWFyeSA9PT0gZXZlbnQuYWRkcmVzcykge1xuICAgICAgY3JlYXRlZCArPSAxO1xuICAgIH1cbiAgfSk7XG5cbiAgY2xpZW50Lm9uKCdjb25uZWN0aW9uQ2xvc2VkJywgZXZlbnQgPT4ge1xuICAgIGxldCBzdGF0dXMgPSBnZXRTZXJ2ZXJTdGF0dXMoZXZlbnQuYWRkcmVzcywgdHJ1ZSk7XG4gICAgaWYgKHN0YXR1cykge1xuICAgICAgc3RhdHVzLmNoZWNrZWRPdXQuZGVsZXRlKGV2ZW50LmNvbm5lY3Rpb25JZCk7XG4gICAgfVxuICB9KTtcblxuICBjbGllbnQub24oJ2Nvbm5lY3Rpb25DaGVja091dFN0YXJ0ZWQnLCBldmVudCA9PiB7XG4gICAgbGV0IHN0YXR1cyA9IGdldFNlcnZlclN0YXR1cyhldmVudC5hZGRyZXNzKTtcbiAgICBzdGF0dXMucGVuZGluZy5wdXNoKGV2ZW50LnRpbWUpO1xuICB9KTtcblxuICBjbGllbnQub24oJ2Nvbm5lY3Rpb25DaGVja091dEZhaWxlZCcsIGV2ZW50ID0+IHtcbiAgICBsZXQgc3RhdHVzID0gZ2V0U2VydmVyU3RhdHVzKGV2ZW50LmFkZHJlc3MsIHRydWUpO1xuICAgIGlmIChzdGF0dXMpIHtcbiAgICAgIHN0YXR1cy5wZW5kaW5nLnNoaWZ0KCk7XG4gICAgfVxuICB9KTtcblxuICBjbGllbnQub24oJ2Nvbm5lY3Rpb25DaGVja2VkT3V0JywgZXZlbnQgPT4ge1xuICAgIGxldCBzdGF0dXMgPSBnZXRTZXJ2ZXJTdGF0dXMoZXZlbnQuYWRkcmVzcyk7XG4gICAgbGV0IHN0YXJ0ID0gc3RhdHVzLnBlbmRpbmcuc2hpZnQoKTtcbiAgICBsZXQgcHJpbWFyeSA9IGdldFByaW1hcnkoKTtcblxuICAgIGlmIChzdGFydCAmJiBwcmltYXJ5ID09PSBldmVudC5hZGRyZXNzKSB7XG4gICAgICBsZXQgY2hlY2tvdXREdXJhdGlvbiA9IGV2ZW50LnRpbWUuZ2V0VGltZSgpIC0gc3RhcnQuZ2V0VGltZSgpO1xuXG4gICAgICBwcmltYXJ5Q2hlY2tvdXRzICs9IDE7XG4gICAgICB0b3RhbENoZWNrb3V0VGltZSArPSBjaGVja291dER1cmF0aW9uO1xuICAgICAgaWYgKGNoZWNrb3V0RHVyYXRpb24gPiBtYXhDaGVja291dFRpbWUpIHtcbiAgICAgICAgbWF4Q2hlY2tvdXRUaW1lID0gY2hlY2tvdXREdXJhdGlvbjtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgb3RoZXJDaGVja291dHMgKz0gMTtcbiAgICB9XG5cbiAgICBzdGF0dXMuY2hlY2tlZE91dC5hZGQoZXZlbnQuY29ubmVjdGlvbklkKTtcbiAgfSk7XG5cbiAgY2xpZW50Lm9uKCdjb25uZWN0aW9uQ2hlY2tlZEluJywgZXZlbnQgPT4ge1xuICAgIGxldCBzdGF0dXMgPSBnZXRTZXJ2ZXJTdGF0dXMoZXZlbnQuYWRkcmVzcywgdHJ1ZSk7XG4gICAgaWYgKHN0YXR1cykge1xuICAgICAgc3RhdHVzLmNoZWNrZWRPdXQuZGVsZXRlKGV2ZW50LmNvbm5lY3Rpb25JZCk7XG4gICAgfVxuICB9KTtcblxuICBjbGllbnQub24oJ3NlcnZlckNsb3NlZCcsIGZ1bmN0aW9uIChldmVudCkge1xuICAgIGRlbGV0ZSBzZXJ2ZXJTdGF0dXNbZXZlbnQuYWRkcmVzc107XG4gIH0pO1xufSk7XG5cbmZ1bmN0aW9uIGdldFNlcnZlclN0YXR1cyhhZGRyZXNzLCBkaXNhYmxlQ3JlYXRlKSB7XG4gIGlmICh0eXBlb2YgYWRkcmVzcyAhPT0gJ3N0cmluZycpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuXG4gIGlmIChhZGRyZXNzIGluIHNlcnZlclN0YXR1cykge1xuICAgIHJldHVybiBzZXJ2ZXJTdGF0dXNbYWRkcmVzc107XG4gIH1cblxuICBpZiAoZGlzYWJsZUNyZWF0ZSkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG5cbiAgc2VydmVyU3RhdHVzW2FkZHJlc3NdID0ge1xuICAgIHBlbmRpbmc6IFtdLFxuICAgIGNoZWNrZWRPdXQ6IG5ldyBTZXQoKSxcbiAgfVxuXG4gIHJldHVybiBzZXJ2ZXJTdGF0dXNbYWRkcmVzc107XG59XG5cbmZ1bmN0aW9uIGdldFByaW1hcnkoKSB7XG4gIGlmICghY2xpZW50IHx8ICFjbGllbnQudG9wb2xvZ3kpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuXG4gIGxldCBzZXJ2ZXIgPSBjbGllbnQudG9wb2xvZ3kubGFzdElzTWFzdGVyKCk7XG5cbiAgaWYgKHNlcnZlci50eXBlID09PSAnU3RhbmRhbG9uZScpIHtcbiAgICByZXR1cm4gc2VydmVyLmFkZHJlc3M7XG4gIH1cblxuICBpZiAoIXNlcnZlciB8fCAhc2VydmVyLnByaW1hcnkpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuXG4gIHJldHVybiBzZXJ2ZXIucHJpbWFyeTtcbn1cblxuZnVuY3Rpb24gZ2V0U2VydmVyRGVzY3JpcHRpb24oYWRkcmVzcykge1xuICBpZiAoIWNsaWVudCB8fCAhY2xpZW50LnRvcG9sb2d5IHx8ICFjbGllbnQudG9wb2xvZ3kucyB8fCAhY2xpZW50LnRvcG9sb2d5LnMuc2VydmVycykge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIGxldCBkZXNjcmlwdGlvbiA9IGNsaWVudC50b3BvbG9neS5zLnNlcnZlcnMuZ2V0KGFkZHJlc3MpO1xuXG4gIHJldHVybiBkZXNjcmlwdGlvbiB8fCBudWxsO1xufVxuIiwiaW1wb3J0IEZpYmVyIGZyb20gXCJmaWJlcnNcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIHdyYXBQaWNrZXIgKCkge1xuICBNZXRlb3Iuc3RhcnR1cCgoKSA9PiB7XG4gICAgaWYgKCFQYWNrYWdlWydtZXRlb3JoYWNrczpwaWNrZXInXSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IFBpY2tlciA9IFBhY2thZ2VbJ21ldGVvcmhhY2tzOnBpY2tlciddLlBpY2tlcjtcblxuICAgIC8vIFdyYXAgUGlja2VyLl9wcm9jZXNzUm91dGUgdG8gbWFrZSBzdXJlIGl0IHJ1bnMgdGhlXG4gICAgLy8gaGFuZGxlciBpbiBhIEZpYmVyIHdpdGggX19rYWRpcmFJbmZvIHNldFxuICAgIC8vIE5lZWRlZCBpZiBhbnkgcHJldmlvdXMgbWlkZGxld2FyZSBjYWxsZWQgYG5leHRgIG91dHNpZGUgb2YgYSBmaWJlci5cbiAgICBjb25zdCBvcmlnUHJvY2Vzc1JvdXRlID0gUGlja2VyLmNvbnN0cnVjdG9yLnByb3RvdHlwZS5fcHJvY2Vzc1JvdXRlO1xuICAgIFBpY2tlci5jb25zdHJ1Y3Rvci5wcm90b3R5cGUuX3Byb2Nlc3NSb3V0ZSA9IGZ1bmN0aW9uIChjYWxsYmFjaywgcGFyYW1zLCByZXEpIHtcbiAgICAgIGNvbnN0IGFyZ3MgPSBhcmd1bWVudHM7XG5cbiAgICAgIGlmICghRmliZXIuY3VycmVudCkge1xuICAgICAgICByZXR1cm4gbmV3IEZpYmVyKCgpID0+IHtcbiAgICAgICAgICBLYWRpcmEuX3NldEluZm8ocmVxLl9fa2FkaXJhSW5mbylcbiAgICAgICAgICByZXR1cm4gb3JpZ1Byb2Nlc3NSb3V0ZS5hcHBseSh0aGlzLCBhcmdzKTtcbiAgICAgICAgfSkucnVuKCk7XG4gICAgICB9XG4gICAgICBcbiAgICAgIGlmIChyZXEuX19rYWRpcmFJbmZvKSB7XG4gICAgICAgIEthZGlyYS5fc2V0SW5mbyhyZXEuX19rYWRpcmFJbmZvKTtcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIG9yaWdQcm9jZXNzUm91dGUuYXBwbHkodGhpcywgYXJncyk7XG4gICAgfTtcbiAgfSk7XG59XG4iLCJpbXBvcnQgRmliZXJzIGZyb20gJ2ZpYmVycyc7XG5cbmV4cG9ydCBmdW5jdGlvbiB3cmFwUm91dGVycyAoKSB7XG4gIGxldCBjb25uZWN0Um91dGVzID0gW11cbiAgdHJ5IHtcbiAgICBjb25uZWN0Um91dGVzLnB1c2gocmVxdWlyZSgnY29ubmVjdC1yb3V0ZScpKTtcbiAgfSBjYXRjaCAoZSkge1xuICAgIC8vIFdlIGNhbiBpZ25vcmUgZXJyb3JzXG4gIH1cblxuICB0cnkge1xuICAgIGlmIChQYWNrYWdlWydzaW1wbGU6anNvbi1yb3V0ZXMnXSkge1xuICAgICAgLy8gUmVsYXRpdmUgZnJvbSAubnBtL25vZGVfbW9kdWxlcy9tZXRlb3IvbW9udGlhcG1fYWdlbnQvbm9kZV9tb2R1bGVzXG4gICAgICAvLyBOcG0ucmVxdWlyZSBpcyBsZXNzIHN0cmljdCBvbiB3aGF0IHBhdGhzIHlvdSB1c2UgdGhhbiByZXF1aXJlXG4gICAgICBjb25uZWN0Um91dGVzLnB1c2goTnBtLnJlcXVpcmUoJy4uLy4uL3NpbXBsZV9qc29uLXJvdXRlcy9ub2RlX21vZHVsZXMvY29ubmVjdC1yb3V0ZScpKTtcbiAgICB9XG4gIH0gY2F0Y2ggKGUpIHtcbiAgICAgLy8gd2UgY2FuIGlnbm9yZSBlcnJvcnNcbiAgfVxuXG4gIGNvbm5lY3RSb3V0ZXMuZm9yRWFjaChjb25uZWN0Um91dGUgPT4ge1xuICAgIGlmICh0eXBlb2YgY29ubmVjdFJvdXRlICE9PSAnZnVuY3Rpb24nKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICBcbiAgICBjb25uZWN0Um91dGUoKHJvdXRlcikgPT4ge1xuICAgICAgY29uc3Qgb2xkQWRkID0gcm91dGVyLmNvbnN0cnVjdG9yLnByb3RvdHlwZS5hZGQ7XG4gICAgICByb3V0ZXIuY29uc3RydWN0b3IucHJvdG90eXBlLmFkZCA9IGZ1bmN0aW9uIChtZXRob2QsIHJvdXRlLCBoYW5kbGVyKSB7XG4gICAgICAgIC8vIFVubGlrZSBtb3N0IHJvdXRlcnMsIGNvbm5lY3Qtcm91dGUgZG9lc24ndCBsb29rIGF0IHRoZSBhcmd1bWVudHMgbGVuZ3RoXG4gICAgICAgIG9sZEFkZC5jYWxsKHRoaXMsIG1ldGhvZCwgcm91dGUsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICBpZiAoYXJndW1lbnRzWzBdICYmIGFyZ3VtZW50c1swXS5fX2thZGlyYUluZm8pIHtcbiAgICAgICAgICAgIGFyZ3VtZW50c1swXS5fX2thZGlyYUluZm8uc3VnZ2VzdGVkUm91dGVOYW1lID0gcm91dGU7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgaGFuZGxlci5hcHBseShudWxsLCBhcmd1bWVudHMpXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0pO1xuICB9KVxufVxuIiwiaW1wb3J0IHsgV2ViQXBwSW50ZXJuYWxzLCBXZWJBcHAgfSBmcm9tICdtZXRlb3Ivd2ViYXBwJztcbmltcG9ydCBGaWJlcnMgZnJvbSAnZmliZXJzJztcblxuLy8gTWF4aW11bSBjb250ZW50LWxlbmd0aCBzaXplXG5NQVhfQk9EWV9TSVpFID0gODAwMFxuLy8gTWF4aW11bSBjaGFyYWN0ZXJzIGZvciBzdHJpbmdpZmllZCBib2R5XG5NQVhfU1RSSU5HSUZJRURfQk9EWV9TSVpFID0gNDAwMFxuXG5jb25zdCBjYW5XcmFwU3RhdGljSGFuZGxlciA9ICEhV2ViQXBwSW50ZXJuYWxzLnN0YXRpY0ZpbGVzQnlBcmNoXG5cbi8vIFRoaXMgY2hlY2tzIGlmIHJ1bm5pbmcgb24gYSB2ZXJzaW9uIG9mIE1ldGVvciB0aGF0XG4vLyB3cmFwcyBjb25uZWN0IGhhbmRsZXJzIGluIGEgZmliZXIuXG4vLyBUaGlzIGNoZWNrIGlzIGRlcGVuZGFudCBvbiBNZXRlb3IncyBpbXBsZW1lbnRhdGlvbiBvZiBgdXNlYCxcbi8vIHdoaWNoIHdyYXBzIGV2ZXJ5IGhhbmRsZXIgaW4gYSBuZXcgZmliZXIuXG4vLyBUaGlzIHdpbGwgbmVlZCB0byBiZSB1cGRhdGVkIGlmIE1ldGVvciBzdGFydHMgcmV1c2luZ1xuLy8gZmliZXJzIHdoZW4gdGhleSBleGlzdC5cbmV4cG9ydCBmdW5jdGlvbiBjaGVja0hhbmRsZXJzSW5GaWJlciAoKSB7XG4gIGNvbnN0IGhhbmRsZXJzTGVuZ3RoID0gV2ViQXBwLnJhd0Nvbm5lY3RIYW5kbGVycy5zdGFjay5sZW5ndGg7XG4gIGxldCBpbkZpYmVyID0gZmFsc2U7XG4gIGxldCBvdXRzaWRlRmliZXIgPSBGaWJlcnMuY3VycmVudDtcblxuICBXZWJBcHAucmF3Q29ubmVjdEhhbmRsZXJzLnVzZSgoX3JlcSwgX3JlcywgbmV4dCkgPT4ge1xuICAgIGluRmliZXIgPSBGaWJlcnMuY3VycmVudCAmJiBGaWJlcnMuY3VycmVudCAhPT0gb3V0c2lkZUZpYmVyO1xuICAgIFxuICAgIC8vIGluIGNhc2Ugd2UgZGlkbid0IHN1Y2Nlc3NmdWxseSByZW1vdmUgdGhpcyBoYW5kbGVyXG4gICAgLy8gYW5kIGl0IGlzIGEgcmVhbCByZXF1ZXN0XG4gICAgbmV4dCgpO1xuICB9KTtcblxuICBpZiAoV2ViQXBwLnJhd0Nvbm5lY3RIYW5kbGVycy5zdGFja1toYW5kbGVyc0xlbmd0aF0pIHtcbiAgICBsZXQgaGFuZGxlciA9IFdlYkFwcC5yYXdDb25uZWN0SGFuZGxlcnMuc3RhY2tbaGFuZGxlcnNMZW5ndGhdLmhhbmRsZTtcblxuICAgIC8vIHJlbW92ZSB0aGUgbmV3bHkgYWRkZWQgaGFuZGxlclxuICAgIC8vIFdlIHJlbW92ZSBpdCBpbW1lZGlhdGVseSBzbyB0aGVyZSBpcyBubyBvcHBvcnR1bml0eSBmb3JcbiAgICAvLyBvdGhlciBjb2RlIHRvIGFkZCBoYW5kbGVycyBmaXJzdCBpZiB0aGUgY3VycmVudCBmaWJlciBpcyB5aWVsZGVkXG4gICAgLy8gd2hpbGUgcnVubmluZyB0aGUgaGFuZGxlclxuICAgIHdoaWxlIChXZWJBcHAucmF3Q29ubmVjdEhhbmRsZXJzLnN0YWNrLmxlbmd0aCA+IGhhbmRsZXJzTGVuZ3RoKSB7XG4gICAgICBXZWJBcHAucmF3Q29ubmVjdEhhbmRsZXJzLnN0YWNrLnBvcCgpO1xuICAgIH1cblxuICAgIGhhbmRsZXIoe30sIHt9LCAoKSA9PiB7fSlcbiAgfVxuXG4gIHJldHVybiBpbkZpYmVyO1xufVxuXG5jb25zdCBJbmZvU3ltYm9sID0gU3ltYm9sKClcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHdyYXBXZWJBcHAoKSB7XG4gIGlmICghY2hlY2tIYW5kbGVyc0luRmliZXIoKSB8fCAhY2FuV3JhcFN0YXRpY0hhbmRsZXIpIHtcbiAgICByZXR1cm47XG4gIH1cblxuICBjb25zdCBwYXJzZVVybCA9IHJlcXVpcmUoJ3BhcnNldXJsJyk7XG5cbiAgV2ViQXBwSW50ZXJuYWxzLnJlZ2lzdGVyQm9pbGVycGxhdGVEYXRhQ2FsbGJhY2soJ19fbW9udGlBcG1Sb3V0ZU5hbWUnLCBmdW5jdGlvbiAocmVxdWVzdCkge1xuICAgIC8vIFRPRE86IHJlY29yZCBpbiB0cmFjZSB3aGljaCBhcmNoIGlzIHVzZWRcblxuICAgIGlmIChyZXF1ZXN0W0luZm9TeW1ib2xdKSB7XG4gICAgICByZXF1ZXN0W0luZm9TeW1ib2xdLmlzQXBwUm91dGUgPSB0cnVlXG4gICAgfVxuXG4gICAgLy8gTGV0IFdlYkFwcCBrbm93IHdlIGRpZG4ndCBtYWtlIGNoYW5nZXNcbiAgICAvLyBzbyBpdCBjYW4gdXNlIGEgY2FjaGVcbiAgICByZXR1cm4gZmFsc2VcbiAgfSlcblxuICAvLyBXZSB3YW50IHRoZSByZXF1ZXN0IG9iamVjdCByZXR1cm5lZCBieSBjYXRlZ29yaXplUmVxdWVzdCB0byBoYXZlXG4gIC8vIF9fa2FkaXJhSW5mb1xuICBsZXQgb3JpZ0NhdGVnb3JpemVSZXF1ZXN0ID0gV2ViQXBwLmNhdGVnb3JpemVSZXF1ZXN0O1xuICBXZWJBcHAuY2F0ZWdvcml6ZVJlcXVlc3QgPSBmdW5jdGlvbiAocmVxKSB7XG4gICAgbGV0IHJlc3VsdCA9IG9yaWdDYXRlZ29yaXplUmVxdWVzdC5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuXG4gICAgaWYgKHJlc3VsdCAmJiByZXEuX19rYWRpcmFJbmZvKSB7XG4gICAgICByZXN1bHRbSW5mb1N5bWJvbF0gPSByZXEuX19rYWRpcmFJbmZvO1xuICAgIH1cblxuICAgIHJldHVybiByZXN1bHQ7XG4gIH1cblxuICAvLyBBZGRpbmcgdGhlIGhhbmRsZXIgZGlyZWN0bHkgdG8gdGhlIHN0YWNrXG4gIC8vIHRvIGZvcmNlIGl0IHRvIGJlIHRoZSBmaXJzdCBvbmUgdG8gcnVuXG4gIFdlYkFwcC5yYXdDb25uZWN0SGFuZGxlcnMuc3RhY2sudW5zaGlmdCh7XG4gICAgcm91dGU6ICcnLFxuICAgIGhhbmRsZTogKHJlcSwgcmVzLCBuZXh0KSA9PiB7XG4gICAgY29uc3QgbmFtZSA9IHBhcnNlVXJsKHJlcSkucGF0aG5hbWU7XG4gICAgY29uc3QgdHJhY2UgPSBLYWRpcmEudHJhY2VyLnN0YXJ0KGAke3JlcS5tZXRob2R9LSR7bmFtZX1gLCAnaHR0cCcpO1xuXG4gICAgY29uc3QgaGVhZGVycyA9IEthZGlyYS50cmFjZXIuX2FwcGx5T2JqZWN0RmlsdGVycyhyZXEuaGVhZGVycyk7XG4gICAgS2FkaXJhLnRyYWNlci5ldmVudCh0cmFjZSwgJ3N0YXJ0Jywge1xuICAgICAgdXJsOiByZXEudXJsLFxuICAgICAgbWV0aG9kOiByZXEubWV0aG9kLFxuICAgICAgaGVhZGVyczogSlNPTi5zdHJpbmdpZnkoaGVhZGVycyksXG4gICAgfSk7XG4gICAgcmVxLl9fa2FkaXJhSW5mbyA9IHsgdHJhY2UgfTtcblxuICAgIHJlcy5vbignZmluaXNoJywgKCkgPT4ge1xuICAgICAgaWYgKHJlcS5fX2thZGlyYUluZm8uYXN5bmNFdmVudCkge1xuICAgICAgICBLYWRpcmEudHJhY2VyLmV2ZW50RW5kKHRyYWNlLCByZXEuX19rYWRpcmFJbmZvLmFzeW5jRXZlbnQpO1xuICAgICAgfVxuXG4gICAgICBLYWRpcmEudHJhY2VyLmVuZExhc3RFdmVudCh0cmFjZSk7XG5cbiAgICAgIGlmIChyZXEuX19rYWRpcmFJbmZvLmlzU3RhdGljKSB7XG4gICAgICAgIHRyYWNlLm5hbWUgPSBgJHtyZXEubWV0aG9kfS08c3RhdGljIGZpbGU+YFxuICAgICAgfSBlbHNlIGlmIChyZXEuX19rYWRpcmFJbmZvLnN1Z2dlc3RlZFJvdXRlTmFtZSkge1xuICAgICAgICB0cmFjZS5uYW1lID0gYCR7cmVxLm1ldGhvZH0tJHtyZXEuX19rYWRpcmFJbmZvLnN1Z2dlc3RlZFJvdXRlTmFtZX1gXG4gICAgICB9IGVsc2UgaWYgKHJlcS5fX2thZGlyYUluZm8uaXNBcHBSb3V0ZSkge1xuICAgICAgICB0cmFjZS5uYW1lID0gYCR7cmVxLm1ldGhvZH0tPGFwcD5gXG4gICAgICB9XG5cbiAgICAgIGNvbnN0IGlzSnNvbiA9IHJlcS5oZWFkZXJzWydjb250ZW50LXR5cGUnXSA9PT0gJ2FwcGxpY2F0aW9uL2pzb24nO1xuICAgICAgY29uc3QgaGFzU21hbGxCb2R5ID0gcmVxLmhlYWRlcnNbJ2NvbnRlbnQtbGVuZ3RoJ10gPiAwICYmIHJlcS5oZWFkZXJzWydjb250ZW50LWxlbmd0aCddIDwgTUFYX0JPRFlfU0laRVxuXG4gICAgICAvLyBDaGVjayBhZnRlciBhbGwgbWlkZGxld2FyZSBoYXZlIHJ1biB0byBzZWUgaWYgYW55IG9mIHRoZW1cbiAgICAgIC8vIHNldCByZXEuYm9keVxuICAgICAgLy8gVGVjaG5pY2FsbHkgYm9kaWVzIGNhbiBiZSB1c2VkIHdpdGggYW55IG1ldGhvZCwgYnV0IHNpbmNlIG1hbnkgbG9hZCBiYWxhbmNlcnMgYW5kXG4gICAgICAvLyBvdGhlciBzb2Z0d2FyZSBvbmx5IHN1cHBvcnQgYm9kaWVzIGZvciBQT1NUIHJlcXVlc3RzLCB3ZSBhcmVcbiAgICAgIC8vIG5vdCByZWNvcmRpbmcgdGhlIGJvZHkgZm9yIG90aGVyIG1ldGhvZHMuXG4gICAgICBpZiAocmVxLm1ldGhvZCA9PT0gJ1BPU1QnICYmIHJlcS5ib2R5ICYmIGlzSnNvbiAmJiBoYXNTbWFsbEJvZHkpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBsZXQgYm9keSA9IEpTT04uc3RyaW5naWZ5KHJlcS5ib2R5KTtcblxuICAgICAgICAgIC8vIENoZWNrIHRoZSBib2R5IHNpemUgYWdhaW4gaW4gY2FzZSBpdCBpcyBtdWNoXG4gICAgICAgICAgLy8gbGFyZ2VyIHRoYW4gd2hhdCB3YXMgaW4gdGhlIGNvbnRlbnQtbGVuZ3RoIGhlYWRlclxuICAgICAgICAgIGlmIChib2R5Lmxlbmd0aCA8IE1BWF9TVFJJTkdJRklFRF9CT0RZX1NJWkUpIHtcbiAgICAgICAgICAgIHRyYWNlLmV2ZW50c1swXS5kYXRhLmJvZHkgPSBib2R5O1xuICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgIC8vIEl0IGlzIG9rYXkgaWYgdGhpcyBmYWlsc1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIC8vIFRPRE86IHJlY29yZCBzdGF0dXMgY29kZVxuICAgICAgS2FkaXJhLnRyYWNlci5ldmVudCh0cmFjZSwgJ2NvbXBsZXRlJyk7XG4gICAgICBsZXQgYnVpbHQgPSBLYWRpcmEudHJhY2VyLmJ1aWxkVHJhY2UodHJhY2UpO1xuICAgICAgS2FkaXJhLm1vZGVscy5odHRwLnByb2Nlc3NSZXF1ZXN0KGJ1aWx0LCByZXEsIHJlcyk7XG4gICAgfSk7XG5cbiAgICBuZXh0KCk7XG4gIH1cbn0pO1xuXG5cbiAgZnVuY3Rpb24gd3JhcEhhbmRsZXIoaGFuZGxlcikge1xuICAgIC8vIGNvbm5lY3QgaWRlbnRpZmllcyBlcnJvciBoYW5kbGVzIGJ5IHRoZW0gYWNjZXB0aW5nXG4gICAgLy8gZm91ciBhcmd1bWVudHNcbiAgICBsZXQgZXJyb3JIYW5kbGVyID0gaGFuZGxlci5sZW5ndGggPT09IDQ7XG5cbiAgICBmdW5jdGlvbiB3cmFwcGVyKHJlcSwgcmVzLCBuZXh0KSB7XG4gICAgICBsZXQgZXJyb3I7XG4gICAgICBpZiAoZXJyb3JIYW5kbGVyKSB7XG4gICAgICAgIGVycm9yID0gcmVxO1xuICAgICAgICByZXEgPSByZXM7XG4gICAgICAgIHJlcyA9IG5leHQ7XG4gICAgICAgIG5leHQgPSBhcmd1bWVudHNbM11cbiAgICAgIH1cblxuICAgICAgY29uc3Qga2FkaXJhSW5mbyA9IHJlcS5fX2thZGlyYUluZm87XG4gICAgICBLYWRpcmEuX3NldEluZm8oa2FkaXJhSW5mbyk7XG5cbiAgICAgIGxldCBuZXh0Q2FsbGVkID0gZmFsc2U7XG4gICAgICAvLyBUT0RPOiB0cmFjayBlcnJvcnMgcGFzc2VkIHRvIG5leHQgb3IgdGhyb3duXG4gICAgICBmdW5jdGlvbiB3cmFwcGVkTmV4dCguLi5hcmdzKSB7XG4gICAgICAgIGlmIChrYWRpcmFJbmZvICYmIGthZGlyYUluZm8uYXN5bmNFdmVudCkge1xuICAgICAgICAgIEthZGlyYS50cmFjZXIuZXZlbnRFbmQocmVxLl9fa2FkaXJhSW5mby50cmFjZSwgcmVxLl9fa2FkaXJhSW5mby5hc3luY0V2ZW50KTtcbiAgICAgICAgICByZXEuX19rYWRpcmFJbmZvLmFzeW5jRXZlbnQgPSBudWxsO1xuICAgICAgICB9XG5cbiAgICAgICAgbmV4dENhbGxlZCA9IHRydWU7XG4gICAgICAgIG5leHQoLi4uYXJncylcbiAgICAgIH1cblxuICAgICAgbGV0IHBvdGVudGlhbFByb21pc2VcblxuICAgICAgaWYgKGVycm9ySGFuZGxlcikge1xuICAgICAgICBwb3RlbnRpYWxQcm9taXNlID0gaGFuZGxlci5jYWxsKHRoaXMsIGVycm9yLCByZXEsIHJlcywgd3JhcHBlZE5leHQpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcG90ZW50aWFsUHJvbWlzZSA9IGhhbmRsZXIuY2FsbCh0aGlzLCByZXEsIHJlcywgd3JhcHBlZE5leHQpO1xuICAgICAgfVxuXG4gICAgICBpZiAocG90ZW50aWFsUHJvbWlzZSAmJiB0eXBlb2YgcG90ZW50aWFsUHJvbWlzZS50aGVuID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgIHBvdGVudGlhbFByb21pc2UudGhlbigoKSA9PiB7XG4gICAgICAgICAgLy8gcmVzLmZpbmlzaGVkIGlzIGRlcHJlY2lhdGVkIGluIE5vZGUgMTMsIGJ1dCBpdCBpcyB0aGUgb25seSBvcHRpb25cbiAgICAgICAgICAvLyBmb3IgTm9kZSAxMi45IGFuZCBvbGRlci5cbiAgICAgICAgICBpZiAoa2FkaXJhSW5mbyAmJiAhcmVzLmZpbmlzaGVkICYmICFuZXh0Q2FsbGVkKSB7XG4gICAgICAgICAgICBjb25zdCBsYXN0RXZlbnQgPSBLYWRpcmEudHJhY2VyLmdldExhc3RFdmVudChrYWRpcmFJbmZvLnRyYWNlKVxuICAgICAgICAgICAgaWYgKGxhc3RFdmVudC5lbmRBdCkge1xuICAgICAgICAgICAgICAvLyByZXEgaXMgbm90IGRvbmUsIGFuZCBuZXh0IGhhcyBub3QgYmVlbiBjYWxsZWRcbiAgICAgICAgICAgICAgLy8gY3JlYXRlIGFuIGFzeW5jIGV2ZW50IHRoYXQgd2lsbCBlbmQgd2hlbiBlaXRoZXIgb2YgdGhvc2UgaGFwcGVuc1xuICAgICAgICAgICAgICBrYWRpcmFJbmZvLmFzeW5jRXZlbnQgPSBLYWRpcmEudHJhY2VyLmV2ZW50KGthZGlyYUluZm8udHJhY2UsICdhc3luYycpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiBwb3RlbnRpYWxQcm9taXNlO1xuICAgIH1cblxuICAgIGlmIChlcnJvckhhbmRsZXIpIHtcbiAgICAgIHJldHVybiBmdW5jdGlvbiAoZXJyb3IsIHJlcSwgcmVzLCBuZXh0KSB7XG4gICAgICAgIHJldHVybiB3cmFwcGVyKGVycm9yLCByZXEsIHJlcywgbmV4dCk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBmdW5jdGlvbiAocmVxLCByZXMsIG5leHQpIHtcbiAgICAgICAgcmV0dXJuIHdyYXBwZXIocmVxLCByZXMsIG5leHQpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIGZ1bmN0aW9uIHdyYXBDb25uZWN0KGFwcCwgd3JhcFN0YWNrKSB7XG4gICAgbGV0IG9sZFVzZSA9IGFwcC51c2U7XG4gICAgaWYgKHdyYXBTdGFjaykge1xuICAgICAgLy8gV2UgbmVlZCB0byBzZXQga2FkaXJhSW5mbyBvbiB0aGUgRmliZXIgdGhlIGhhbmRsZXIgd2lsbCBydW4gaW4uXG4gICAgICAvLyBNZXRlb3IgaGFzIGFscmVhZHkgd3JhcHBlZCB0aGUgaGFuZGxlciB0byBydW4gaXQgaW4gYSBuZXcgRmliZXJcbiAgICAgIC8vIGJ5IHVzaW5nIFByb21pc2UuYXN5bmNBcHBseSBzbyB3ZSBhcmUgbm90IGFibGUgdG8gZGlyZWN0bHkgc2V0IGl0XG4gICAgICAvLyBvbiB0aGF0IEZpYmVyLiBcbiAgICAgIC8vIE1ldGVvcidzIHByb21pc2UgbGlicmFyeSBjb3BpZXMgcHJvcGVydGllcyBmcm9tIHRoZSBjdXJyZW50IGZpYmVyIHRvXG4gICAgICAvLyB0aGUgbmV3IGZpYmVyLCBzbyB3ZSBjYW4gd3JhcCBpdCBpbiBhbm90aGVyIEZpYmVyIHdpdGgga2FkaXJhSW5mbyBzZXRcbiAgICAgIC8vIGFuZCBNZXRlb3Igd2lsbCBjb3B5IGthZGlyYUluZm8gdG8gdGhlIG5ldyBGaWJlci5cbiAgICAgIC8vIEl0IHdpbGwgb25seSBjcmVhdGUgdGhlIGFkZGl0aW9uYWwgRmliZXIgaWYgaXQgaXNuJ3QgYWxyZWFkeSBydW5uaW5nIGluIGEgRmliZXJcbiAgICAgIGFwcC5zdGFjay5mb3JFYWNoKGVudHJ5ID0+IHtcbiAgICAgICAgbGV0IHdyYXBwZWRIYW5kbGVyID0gd3JhcEhhbmRsZXIoZW50cnkuaGFuZGxlKVxuICAgICAgICBpZiAoZW50cnkuaGFuZGxlLmxlbmd0aCA+PSA0KSB7XG4gICAgICAgICAgZW50cnkuaGFuZGxlID0gZnVuY3Rpb24gKGVycm9yLCByZXEsIHJlcywgbmV4dCkge1xuICAgICAgICAgICAgcmV0dXJuIFByb21pc2UuYXN5bmNBcHBseShcbiAgICAgICAgICAgICAgd3JhcHBlZEhhbmRsZXIsXG4gICAgICAgICAgICAgIHRoaXMsXG4gICAgICAgICAgICAgIGFyZ3VtZW50cyxcbiAgICAgICAgICAgICAgdHJ1ZVxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9O1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGVudHJ5LmhhbmRsZSA9IGZ1bmN0aW9uIChyZXEsIHJlcywgbmV4dCkge1xuICAgICAgICAgICAgcmV0dXJuIFByb21pc2UuYXN5bmNBcHBseShcbiAgICAgICAgICAgICAgd3JhcHBlZEhhbmRsZXIsXG4gICAgICAgICAgICAgIHRoaXMsXG4gICAgICAgICAgICAgIGFyZ3VtZW50cyxcbiAgICAgICAgICAgICAgdHJ1ZVxuICAgICAgICAgICAgKVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICAgIGFwcC51c2UgPSBmdW5jdGlvbiAoLi4uYXJncykge1xuICAgICAgYXJnc1thcmdzLmxlbmd0aCAtIDFdID0gd3JhcEhhbmRsZXIoYXJnc1thcmdzLmxlbmd0aCAtIDFdKVxuICAgICAgcmV0dXJuIG9sZFVzZS5hcHBseShhcHAsIGFyZ3MpO1xuICAgIH1cbiAgfVxuXG4gIHdyYXBDb25uZWN0KFdlYkFwcC5yYXdDb25uZWN0SGFuZGxlcnMsIGZhbHNlKTtcbiAgd3JhcENvbm5lY3QoV2ViQXBwSW50ZXJuYWxzLm1ldGVvckludGVybmFsSGFuZGxlcnMsIGZhbHNlKTtcblxuICAvLyBUaGUgb2F1dGggcGFja2FnZSBhbmQgb3RoZXIgY29yZSBwYWNrYWdlcyBtaWdodCBoYXZlIGFscmVhZHkgYWRkZWQgdGhlaXIgbWlkZGxld2FyZSxcbiAgLy8gc28gd2UgbmVlZCB0byB3cmFwIHRoZSBleGlzdGluZyBtaWRkbGV3YXJlXG4gIHdyYXBDb25uZWN0KFdlYkFwcC5jb25uZWN0SGFuZGxlcnMsIHRydWUpO1xuXG4gIHdyYXBDb25uZWN0KFdlYkFwcC5jb25uZWN0QXBwLCBmYWxzZSk7XG5cbiAgbGV0IG9sZFN0YXRpY0ZpbGVzTWlkZGxld2FyZSA9IFdlYkFwcEludGVybmFscy5zdGF0aWNGaWxlc01pZGRsZXdhcmU7XG4gIGNvbnN0IHN0YXRpY0hhbmRsZXIgPSB3cmFwSGFuZGxlcihvbGRTdGF0aWNGaWxlc01pZGRsZXdhcmUuYmluZChXZWJBcHBJbnRlcm5hbHMsIFdlYkFwcEludGVybmFscy5zdGF0aWNGaWxlc0J5QXJjaCkpO1xuICBXZWJBcHBJbnRlcm5hbHMuc3RhdGljRmlsZXNNaWRkbGV3YXJlID0gZnVuY3Rpb24gKF9zdGF0aWNGaWxlcywgcmVxLCByZXMsIG5leHQpIHtcbiAgICBpZiAocmVxLl9fa2FkaXJhSW5mbykge1xuICAgICAgcmVxLl9fa2FkaXJhSW5mby5pc1N0YXRpYyA9IHRydWU7XG4gICAgfVxuXG4gICAgcmV0dXJuIHN0YXRpY0hhbmRsZXIocmVxLCByZXMsIGZ1bmN0aW9uICgpIHtcbiAgICAgIC8vIGlmIHRoZSByZXF1ZXN0IGlzIGZvciBhIHN0YXRpYyBmaWxlLCB0aGUgc3RhdGljIGhhbmRsZXIgd2lsbCBlbmQgdGhlIHJlc3BvbnNlXG4gICAgICAvLyBpbnN0ZWFkIG9mIGNhbGxpbmcgbmV4dFxuICAgICAgcmVxLl9fa2FkaXJhSW5mby5pc1N0YXRpYyA9IGZhbHNlO1xuICAgICAgcmV0dXJuIG5leHQuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbiAgICB9KTtcbiAgfTtcbn1cbiIsImZ1bmN0aW9uIG5vcm1hbGl6ZWRQcmVmaXggKG5hbWUpIHtcbiAgcmV0dXJuIG5hbWUucmVwbGFjZSgnS0FESVJBXycsICdNT05USV8nKTtcbn1cblxuS2FkaXJhLl9wYXJzZUVudiA9IGZ1bmN0aW9uIChlbnYpIHtcbiAgdmFyIG9wdGlvbnMgPSB7fTtcbiAgZm9yKHZhciBuYW1lIGluIGVudikge1xuICAgIHZhciB2YWx1ZSA9IGVudltuYW1lXTtcbiAgICB2YXIgbm9ybWFsaXplZE5hbWUgPSBub3JtYWxpemVkUHJlZml4KG5hbWUpO1xuICAgIHZhciBpbmZvID0gS2FkaXJhLl9wYXJzZUVudi5fb3B0aW9uc1tub3JtYWxpemVkTmFtZV07XG5cbiAgICBpZihpbmZvICYmIHZhbHVlKSB7XG4gICAgICBvcHRpb25zW2luZm8ubmFtZV0gPSBpbmZvLnBhcnNlcih2YWx1ZSk7XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIG9wdGlvbnM7XG59O1xuXG5cbkthZGlyYS5fcGFyc2VFbnYucGFyc2VJbnQgPSBmdW5jdGlvbiAoc3RyKSB7XG4gIHZhciBudW0gPSBwYXJzZUludChzdHIpO1xuICBpZihudW0gfHwgbnVtID09PSAwKSByZXR1cm4gbnVtO1xuICB0aHJvdyBuZXcgRXJyb3IoJ0thZGlyYTogTWF0Y2ggRXJyb3I6IFwiJytudW0rJ1wiIGlzIG5vdCBhIG51bWJlcicpO1xufTtcblxuXG5LYWRpcmEuX3BhcnNlRW52LnBhcnNlQm9vbCA9IGZ1bmN0aW9uIChzdHIpIHtcbiAgc3RyID0gc3RyLnRvTG93ZXJDYXNlKCk7XG4gIGlmKHN0ciA9PT0gJ3RydWUnKSByZXR1cm4gdHJ1ZTtcbiAgaWYoc3RyID09PSAnZmFsc2UnKSByZXR1cm4gZmFsc2U7XG4gIHRocm93IG5ldyBFcnJvcignS2FkaXJhOiBNYXRjaCBFcnJvcjogJytzdHIrJyBpcyBub3QgYSBib29sZWFuJyk7XG59O1xuXG5cbkthZGlyYS5fcGFyc2VFbnYucGFyc2VVcmwgPSBmdW5jdGlvbiAoc3RyKSB7XG4gIHJldHVybiBzdHI7XG59O1xuXG5cbkthZGlyYS5fcGFyc2VFbnYucGFyc2VTdHJpbmcgPSBmdW5jdGlvbiAoc3RyKSB7XG4gIHJldHVybiBzdHI7XG59O1xuXG5cbkthZGlyYS5fcGFyc2VFbnYuX29wdGlvbnMgPSB7XG4gIC8vIGF1dGhcbiAgTU9OVElfQVBQX0lEOiB7XG4gICAgbmFtZTogJ2FwcElkJyxcbiAgICBwYXJzZXI6IEthZGlyYS5fcGFyc2VFbnYucGFyc2VTdHJpbmdcbiAgfSxcbiAgTU9OVElfQVBQX1NFQ1JFVDoge1xuICAgIG5hbWU6ICdhcHBTZWNyZXQnLFxuICAgIHBhcnNlcjogS2FkaXJhLl9wYXJzZUVudi5wYXJzZVN0cmluZ1xuICB9LFxuICAvLyBkZWxheSB0byBzZW5kIHRoZSBpbml0aWFsIHBpbmcgdG8gdGhlIGthZGlyYSBlbmdpbmUgYWZ0ZXIgcGFnZSBsb2Fkc1xuICBNT05USV9PUFRJT05TX0NMSUVOVF9FTkdJTkVfU1lOQ19ERUxBWToge1xuICAgIG5hbWU6ICdjbGllbnRFbmdpbmVTeW5jRGVsYXknLFxuICAgIHBhcnNlcjogS2FkaXJhLl9wYXJzZUVudi5wYXJzZUludCxcbiAgfSxcbiAgLy8gdGltZSBiZXR3ZWVuIHNlbmRpbmcgZXJyb3JzIHRvIHRoZSBlbmdpbmVcbiAgTU9OVElfT1BUSU9OU19FUlJPUl9EVU1QX0lOVEVSVkFMOiB7XG4gICAgbmFtZTogJ2Vycm9yRHVtcEludGVydmFsJyxcbiAgICBwYXJzZXI6IEthZGlyYS5fcGFyc2VFbnYucGFyc2VJbnQsXG4gIH0sXG4gIC8vIG5vIG9mIGVycm9ycyBhbGxvd2VkIGluIGEgZ2l2ZW4gaW50ZXJ2YWxcbiAgTU9OVElfT1BUSU9OU19NQVhfRVJST1JTX1BFUl9JTlRFUlZBTDoge1xuICAgIG5hbWU6ICdtYXhFcnJvcnNQZXJJbnRlcnZhbCcsXG4gICAgcGFyc2VyOiBLYWRpcmEuX3BhcnNlRW52LnBhcnNlSW50LFxuICB9LFxuICAvLyBhIHpvbmUuanMgc3BlY2lmaWMgb3B0aW9uIHRvIGNvbGxlY3QgdGhlIGZ1bGwgc3RhY2sgdHJhY2Uod2hpY2ggaXMgbm90IG11Y2ggdXNlZnVsKVxuICBNT05USV9PUFRJT05TX0NPTExFQ1RfQUxMX1NUQUNLUzoge1xuICAgIG5hbWU6ICdjb2xsZWN0QWxsU3RhY2tzJyxcbiAgICBwYXJzZXI6IEthZGlyYS5fcGFyc2VFbnYucGFyc2VCb29sLFxuICB9LFxuICAvLyBlbmFibGUgZXJyb3IgdHJhY2tpbmcgKHdoaWNoIGlzIHR1cm5lZCBvbiBieSBkZWZhdWx0KVxuICBNT05USV9PUFRJT05TX0VOQUJMRV9FUlJPUl9UUkFDS0lORzoge1xuICAgIG5hbWU6ICdlbmFibGVFcnJvclRyYWNraW5nJyxcbiAgICBwYXJzZXI6IEthZGlyYS5fcGFyc2VFbnYucGFyc2VCb29sLFxuICB9LFxuICAvLyBrYWRpcmEgZW5naW5lIGVuZHBvaW50XG4gIE1PTlRJX09QVElPTlNfRU5EUE9JTlQ6IHtcbiAgICBuYW1lOiAnZW5kcG9pbnQnLFxuICAgIHBhcnNlcjogS2FkaXJhLl9wYXJzZUVudi5wYXJzZVVybCxcbiAgfSxcbiAgLy8gZGVmaW5lIHRoZSBob3N0bmFtZSBvZiB0aGUgY3VycmVudCBydW5uaW5nIHByb2Nlc3NcbiAgTU9OVElfT1BUSU9OU19IT1NUTkFNRToge1xuICAgIG5hbWU6ICdob3N0bmFtZScsXG4gICAgcGFyc2VyOiBLYWRpcmEuX3BhcnNlRW52LnBhcnNlU3RyaW5nLFxuICB9LFxuICAvLyBpbnRlcnZhbCBiZXR3ZWVuIHNlbmRpbmcgZGF0YSB0byB0aGUga2FkaXJhIGVuZ2luZSBmcm9tIHRoZSBzZXJ2ZXJcbiAgTU9OVElfT1BUSU9OU19QQVlMT0FEX1RJTUVPVVQ6IHtcbiAgICBuYW1lOiAncGF5bG9hZFRpbWVvdXQnLFxuICAgIHBhcnNlcjogS2FkaXJhLl9wYXJzZUVudi5wYXJzZUludCxcbiAgfSxcbiAgLy8gc2V0IEhUVFAvSFRUUFMgcHJveHlcbiAgTU9OVElfT1BUSU9OU19QUk9YWToge1xuICAgIG5hbWU6ICdwcm94eScsXG4gICAgcGFyc2VyOiBLYWRpcmEuX3BhcnNlRW52LnBhcnNlVXJsLFxuICB9LFxuICAvLyBudW1iZXIgb2YgaXRlbXMgY2FjaGVkIGZvciB0cmFja2luZyBkb2N1bWVudCBzaXplXG4gIE1PTlRJX09QVElPTlNfRE9DVU1FTlRfU0laRV9DQUNIRV9TSVpFOiB7XG4gICAgbmFtZTogJ2RvY3VtZW50U2l6ZUNhY2hlU2l6ZScsXG4gICAgcGFyc2VyOiBLYWRpcmEuX3BhcnNlRW52LnBhcnNlSW50LFxuICB9LFxuICAvLyBlbmFibGUgdXBsb2FkaW5nIHNvdXJjZW1hcHNcbiAgTU9OVElfVVBMT0FEX1NPVVJDRV9NQVBTOiB7XG4gICAgbmFtZTogJ3VwbG9hZFNvdXJjZU1hcHMnLFxuICAgIHBhcnNlcjogS2FkaXJhLl9wYXJzZUVudi5wYXJzZUJvb2xcbiAgfSxcbiAgTU9OVElfUkVDT1JEX0lQX0FERFJFU1M6IHtcbiAgICBuYW1lOiAncmVjb3JkSVBBZGRyZXNzJyxcbiAgICBwYXJzZXI6IEthZGlyYS5fcGFyc2VFbnYucGFyc2VTdHJpbmcsXG4gIH0sXG4gIE1PTlRJX0VWRU5UX1NUQUNLX1RSQUNFOiB7XG4gICAgbmFtZTogJ2V2ZW50U3RhY2tUcmFjZScsXG4gICAgcGFyc2VyOiBLYWRpcmEuX3BhcnNlRW52LnBhcnNlQm9vbCxcbiAgfVxufTtcbiIsIkthZGlyYS5fY29ubmVjdFdpdGhFbnYgPSBmdW5jdGlvbigpIHtcbiAgdmFyIG9wdGlvbnMgPSBLYWRpcmEuX3BhcnNlRW52KHByb2Nlc3MuZW52KTtcbiAgaWYob3B0aW9ucy5hcHBJZCAmJiBvcHRpb25zLmFwcFNlY3JldCkge1xuXG4gICAgS2FkaXJhLmNvbm5lY3QoXG4gICAgICBvcHRpb25zLmFwcElkLFxuICAgICAgb3B0aW9ucy5hcHBTZWNyZXQsXG4gICAgICBvcHRpb25zXG4gICAgKTtcblxuICAgIEthZGlyYS5jb25uZWN0ID0gZnVuY3Rpb24oKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0thZGlyYSBoYXMgYmVlbiBhbHJlYWR5IGNvbm5lY3RlZCB1c2luZyBjcmVkZW50aWFscyBmcm9tIEVudmlyb25tZW50IFZhcmlhYmxlcycpO1xuICAgIH07XG4gIH1cbn07XG5cblxuS2FkaXJhLl9jb25uZWN0V2l0aFNldHRpbmdzID0gZnVuY3Rpb24gKCkge1xuICB2YXIgbW9udGlTZXR0aW5ncyA9IE1ldGVvci5zZXR0aW5ncy5tb250aSB8fCBNZXRlb3Iuc2V0dGluZ3Mua2FkaXJhXG5cbiAgaWYoXG4gICAgbW9udGlTZXR0aW5ncyAmJlxuICAgIG1vbnRpU2V0dGluZ3MuYXBwSWQgJiZcbiAgICBtb250aVNldHRpbmdzLmFwcFNlY3JldFxuICApIHtcbiAgICBLYWRpcmEuY29ubmVjdChcbiAgICAgIG1vbnRpU2V0dGluZ3MuYXBwSWQsXG4gICAgICBtb250aVNldHRpbmdzLmFwcFNlY3JldCxcbiAgICAgIG1vbnRpU2V0dGluZ3Mub3B0aW9ucyB8fCB7fVxuICAgICk7XG5cbiAgICBLYWRpcmEuY29ubmVjdCA9IGZ1bmN0aW9uKCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdLYWRpcmEgaGFzIGJlZW4gYWxyZWFkeSBjb25uZWN0ZWQgdXNpbmcgY3JlZGVudGlhbHMgZnJvbSBNZXRlb3Iuc2V0dGluZ3MnKTtcbiAgICB9O1xuICB9XG59O1xuXG5cbi8vIFRyeSB0byBjb25uZWN0IGF1dG9tYXRpY2FsbHlcbkthZGlyYS5fY29ubmVjdFdpdGhFbnYoKTtcbkthZGlyYS5fY29ubmVjdFdpdGhTZXR0aW5ncygpO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5cbmNvbnN0IGNvbmZsaWN0aW5nUGFja2FnZXMgPSBbXG4gICdtZGc6bWV0ZW9yLWFwbS1hZ2VudCcsXG4gICdsbWFjaGVuczprYWRpcmEnLFxuICAnbWV0ZW9yaGFja3M6a2FkaXJhJyxcbl07XG5cbk1ldGVvci5zdGFydHVwKCgpID0+IHtcbiAgY29uZmxpY3RpbmdQYWNrYWdlcy5mb3JFYWNoKChuYW1lKSA9PiB7XG4gICAgaWYgKG5hbWUgaW4gUGFja2FnZSkge1xuICAgICAgY29uc29sZS5sb2coYE1vbnRpIEFQTTogeW91ciBhcHAgaXMgdXNpbmcgdGhlICR7bmFtZX0gcGFja2FnZS4gVXNpbmcgbW9yZSB0aGFuIG9uZSBBUE0gYWdlbnQgaW4gYW4gYXBwIGNhbiBjYXVzZSB1bmV4cGVjdGVkIHByb2JsZW1zLmApO1xuICAgIH1cbiAgfSk7XG59KTtcbiJdfQ==
