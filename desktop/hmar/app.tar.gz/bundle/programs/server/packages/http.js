(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var URL = Package.url.URL;
var URLSearchParams = Package.url.URLSearchParams;
var ECMAScript = Package.ecmascript.ECMAScript;
var fetch = Package.fetch.fetch;
var meteorInstall = Package.modules.meteorInstall;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var HTTP, HTTPInternals;

var require = meteorInstall({"node_modules":{"meteor":{"http":{"httpcall_server.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/http/httpcall_server.js                                                                                 //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  HTTP: () => HTTP,
  HTTPInternals: () => HTTPInternals
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let fetch, Request;
module.link("meteor/fetch", {
  fetch(v) {
    fetch = v;
  },

  Request(v) {
    Request = v;
  }

}, 1);
let URL, URLSearchParams;
module.link("meteor/url", {
  URL(v) {
    URL = v;
  },

  URLSearchParams(v) {
    URLSearchParams = v;
  }

}, 2);
let HTTP, makeErrorByStatus, populateData;
module.link("./httpcall_common.js", {
  HTTP(v) {
    HTTP = v;
  },

  makeErrorByStatus(v) {
    makeErrorByStatus = v;
  },

  populateData(v) {
    populateData = v;
  }

}, 3);
const hasOwn = Object.prototype.hasOwnProperty;
/**
 * @deprecated
 */

const HTTPInternals = {};

// _call always runs asynchronously; HTTP.call, defined below,
// wraps _call and runs synchronously when no callback is provided.
function _call(method, url, options, callback) {
  ////////// Process arguments //////////
  if (!callback && typeof options === 'function') {
    // support (method, url, callback) argument list
    callback = options;
    options = null;
  }

  options = options || {};

  if (hasOwn.call(options, 'beforeSend')) {
    throw new Error('Option beforeSend not supported on server.');
  }

  method = (method || '').toUpperCase();

  if (!/^https?:\/\//.test(url)) {
    throw new Error('url must be absolute and start with http:// or https://');
  }

  const headers = {};
  let content = options.content;

  if (options.data) {
    content = JSON.stringify(options.data);
    headers['Content-Type'] = 'application/json';
  }

  let paramsForUrl;
  let paramsForBody;

  if (content || method === 'GET' || method === 'HEAD') {
    paramsForUrl = options.params;
  } else {
    paramsForBody = options.params;
  }

  const newUrl = URL._constructUrl(url, options.query, paramsForUrl);

  if (options.auth) {
    if (options.auth.indexOf(':') < 0) {
      throw new Error('auth option should be of the form "username:password"');
    }

    const base64 = Buffer.from(options.auth, 'ascii').toString('base64');
    headers['Authorization'] = "Basic ".concat(base64);
  }

  if (paramsForBody) {
    const data = new URLSearchParams();
    Object.entries(paramsForBody).forEach(_ref => {
      let [key, value] = _ref;
      data.append(key, value);
    });
    content = data;
    headers['Content-Type'] = 'application/x-www-form-urlencoded';
  }

  if (options.headers) {
    Object.keys(options.headers).forEach(function (key) {
      headers[key] = options.headers[key];
    });
  }

  let caching;

  if (options.caching) {// TODO implement fetch-specific options
  }

  let corsMode;

  if (options.mode) {// TODO implement fetch-specific options
  }

  let credentials; // wrap callback to add a 'response' property on an error, in case
  // we have both (http 4xx/5xx error, which has a response payload)

  callback = function (cb) {
    let called = false;
    return function (error, response) {
      if (!called) {
        called = true;

        if (error && response) {
          error.response = response;
        }

        cb(error, response);
      }
    };
  }(callback); // is false if false, otherwise always true


  const followRedirects = options.followRedirects === false ? 'manual' : 'follow'; ////////// Kickoff! //////////
  // Allow users to override any request option with the npmRequestOptions
  // option.

  const requestOptions = {
    method: method,
    caching: caching,
    mode: corsMode,
    jar: false,
    timeout: options.timeout,
    body: content,
    redirect: followRedirects,
    referrer: options.referrer,
    integrity: options.integrity,
    headers: headers
  };
  const request = new Request(newUrl, requestOptions);
  fetch(request).then(res => Promise.asyncApply(() => {
    const content = Promise.await(res.text());
    const response = {};
    response.statusCode = res.status;
    response.content = '' + content; // fetch headers don't allow simple read using bracket notation
    // so we iterate their entries and assign them to a new Object

    response.headers = {};

    for (const entry of res.headers.entries()) {
      const [key, val] = entry;
      response.headers[key] = val;
    }

    response.ok = res.ok;
    response.redirected = res.redirected;
    populateData(response);

    if (response.statusCode >= 400) {
      const error = makeErrorByStatus(response.statusCode, response.content);
      callback(error, response);
    } else {
      callback(undefined, response);
    }
  })).catch(err => callback(err));
}

HTTP.call = Meteor.wrapAsync(_call);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"httpcall_common.js":function module(require,exports){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/http/httpcall_common.js                                                                                 //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
var MAX_LENGTH = 500; // if you change this, also change the appropriate test

var slice = Array.prototype.slice;

exports.makeErrorByStatus = function (statusCode, content) {
  var message = "failed [" + statusCode + "]";

  if (content) {
    var stringContent = typeof content == "string" ? content : content.toString();
    message += ' ' + truncate(stringContent.replace(/\n/g, ' '), MAX_LENGTH);
  }

  return new Error(message);
};

function truncate(str, length) {
  return str.length > length ? str.slice(0, length) + '...' : str;
} // Fill in `response.data` if the content-type is JSON.


exports.populateData = function (response) {
  // Read Content-Type header, up to a ';' if there is one.
  // A typical header might be "application/json; charset=utf-8"
  // or just "application/json".
  var contentType = (response.headers['content-type'] || ';').split(';')[0]; // Only try to parse data as JSON if server sets correct content type.

  if (['application/json', 'text/javascript', 'application/javascript', 'application/x-javascript'].indexOf(contentType) >= 0) {
    try {
      response.data = JSON.parse(response.content);
    } catch (err) {
      response.data = null;
    }
  } else {
    response.data = null;
  }
};

var HTTP = exports.HTTP = {};
/**
 * @summary Send an HTTP `GET` request. Equivalent to calling [`HTTP.call`](#http_call) with "GET" as the first argument.
 * @param {String} url The URL to which the request should be sent.
 * @param {Object} [callOptions] Options passed on to [`HTTP.call`](#http_call).
 * @param {Function} [asyncCallback] Callback that is called when the request is completed. Required on the client.
 * @locus Anywhere
 * @deprecated
 */

HTTP.get = function () {
  return HTTP.call.apply(this, ["GET"].concat(slice.call(arguments)));
};
/**
 * @summary Send an HTTP `POST` request. Equivalent to calling [`HTTP.call`](#http_call) with "POST" as the first argument.
 * @param {String} url The URL to which the request should be sent.
 * @param {Object} [callOptions] Options passed on to [`HTTP.call`](#http_call).
 * @param {Function} [asyncCallback] Callback that is called when the request is completed. Required on the client.
 * @locus Anywhere
 * @deprecated
 */


HTTP.post = function () {
  return HTTP.call.apply(this, ["POST"].concat(slice.call(arguments)));
};
/**
 * @summary Send an HTTP `PUT` request. Equivalent to calling [`HTTP.call`](#http_call) with "PUT" as the first argument.
 * @param {String} url The URL to which the request should be sent.
 * @param {Object} [callOptions] Options passed on to [`HTTP.call`](#http_call).
 * @param {Function} [asyncCallback] Callback that is called when the request is completed. Required on the client.
 * @locus Anywhere
 * @deprecated
 */


HTTP.put = function () {
  return HTTP.call.apply(this, ["PUT"].concat(slice.call(arguments)));
};
/**
 * @summary Send an HTTP `DELETE` request. Equivalent to calling [`HTTP.call`](#http_call) with "DELETE" as the first argument. (Named `del` to avoid conflict with the Javascript keyword `delete`)
 * @param {String} url The URL to which the request should be sent.
 * @param {Object} [callOptions] Options passed on to [`HTTP.call`](#http_call).
 * @param {Function} [asyncCallback] Callback that is called when the request is completed. Required on the client.
 * @locus Anywhere
 * @deprecated
 */


HTTP.del = function () {
  return HTTP.call.apply(this, ["DELETE"].concat(slice.call(arguments)));
};
/**
 * @summary Send an HTTP `PATCH` request. Equivalent to calling [`HTTP.call`](#http_call) with "PATCH" as the first argument.
 * @param {String} url The URL to which the request should be sent.
 * @param {Object} [callOptions] Options passed on to [`HTTP.call`](#http_call).
 * @param {Function} [asyncCallback] Callback that is called when the request is completed. Required on the client.
 * @locus Anywhere
 * @deprecated
 */


HTTP.patch = function () {
  return HTTP.call.apply(this, ["PATCH"].concat(slice.call(arguments)));
};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

var exports = require("/node_modules/meteor/http/httpcall_server.js");

/* Exports */
Package._define("http", exports, {
  HTTP: HTTP,
  HTTPInternals: HTTPInternals
});

})();

//# sourceURL=meteor://💻app/packages/http.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvaHR0cC9odHRwY2FsbF9zZXJ2ZXIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL2h0dHAvaHR0cGNhbGxfY29tbW9uLmpzIl0sIm5hbWVzIjpbIm1vZHVsZSIsImV4cG9ydCIsIkhUVFAiLCJIVFRQSW50ZXJuYWxzIiwiTWV0ZW9yIiwibGluayIsInYiLCJmZXRjaCIsIlJlcXVlc3QiLCJVUkwiLCJVUkxTZWFyY2hQYXJhbXMiLCJtYWtlRXJyb3JCeVN0YXR1cyIsInBvcHVsYXRlRGF0YSIsImhhc093biIsIk9iamVjdCIsInByb3RvdHlwZSIsImhhc093blByb3BlcnR5IiwiX2NhbGwiLCJtZXRob2QiLCJ1cmwiLCJvcHRpb25zIiwiY2FsbGJhY2siLCJjYWxsIiwiRXJyb3IiLCJ0b1VwcGVyQ2FzZSIsInRlc3QiLCJoZWFkZXJzIiwiY29udGVudCIsImRhdGEiLCJKU09OIiwic3RyaW5naWZ5IiwicGFyYW1zRm9yVXJsIiwicGFyYW1zRm9yQm9keSIsInBhcmFtcyIsIm5ld1VybCIsIl9jb25zdHJ1Y3RVcmwiLCJxdWVyeSIsImF1dGgiLCJpbmRleE9mIiwiYmFzZTY0IiwiQnVmZmVyIiwiZnJvbSIsInRvU3RyaW5nIiwiZW50cmllcyIsImZvckVhY2giLCJrZXkiLCJ2YWx1ZSIsImFwcGVuZCIsImtleXMiLCJjYWNoaW5nIiwiY29yc01vZGUiLCJtb2RlIiwiY3JlZGVudGlhbHMiLCJjYiIsImNhbGxlZCIsImVycm9yIiwicmVzcG9uc2UiLCJmb2xsb3dSZWRpcmVjdHMiLCJyZXF1ZXN0T3B0aW9ucyIsImphciIsInRpbWVvdXQiLCJib2R5IiwicmVkaXJlY3QiLCJyZWZlcnJlciIsImludGVncml0eSIsInJlcXVlc3QiLCJ0aGVuIiwicmVzIiwidGV4dCIsInN0YXR1c0NvZGUiLCJzdGF0dXMiLCJlbnRyeSIsInZhbCIsIm9rIiwicmVkaXJlY3RlZCIsInVuZGVmaW5lZCIsImNhdGNoIiwiZXJyIiwid3JhcEFzeW5jIiwiTUFYX0xFTkdUSCIsInNsaWNlIiwiQXJyYXkiLCJleHBvcnRzIiwibWVzc2FnZSIsInN0cmluZ0NvbnRlbnQiLCJ0cnVuY2F0ZSIsInJlcGxhY2UiLCJzdHIiLCJsZW5ndGgiLCJjb250ZW50VHlwZSIsInNwbGl0IiwicGFyc2UiLCJnZXQiLCJhcHBseSIsImNvbmNhdCIsImFyZ3VtZW50cyIsInBvc3QiLCJwdXQiLCJkZWwiLCJwYXRjaCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUNDLE1BQUksRUFBQyxNQUFJQSxJQUFWO0FBQWVDLGVBQWEsRUFBQyxNQUFJQTtBQUFqQyxDQUFkO0FBQStELElBQUlDLE1BQUo7QUFBV0osTUFBTSxDQUFDSyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRCxRQUFNLENBQUNFLENBQUQsRUFBRztBQUFDRixVQUFNLEdBQUNFLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUMsS0FBSixFQUFVQyxPQUFWO0FBQWtCUixNQUFNLENBQUNLLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNFLE9BQUssQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFNBQUssR0FBQ0QsQ0FBTjtBQUFRLEdBQWxCOztBQUFtQkUsU0FBTyxDQUFDRixDQUFELEVBQUc7QUFBQ0UsV0FBTyxHQUFDRixDQUFSO0FBQVU7O0FBQXhDLENBQTNCLEVBQXFFLENBQXJFO0FBQXdFLElBQUlHLEdBQUosRUFBUUMsZUFBUjtBQUF3QlYsTUFBTSxDQUFDSyxJQUFQLENBQVksWUFBWixFQUF5QjtBQUFDSSxLQUFHLENBQUNILENBQUQsRUFBRztBQUFDRyxPQUFHLEdBQUNILENBQUo7QUFBTSxHQUFkOztBQUFlSSxpQkFBZSxDQUFDSixDQUFELEVBQUc7QUFBQ0ksbUJBQWUsR0FBQ0osQ0FBaEI7QUFBa0I7O0FBQXBELENBQXpCLEVBQStFLENBQS9FO0FBQWtGLElBQUlKLElBQUosRUFBU1MsaUJBQVQsRUFBMkJDLFlBQTNCO0FBQXdDWixNQUFNLENBQUNLLElBQVAsQ0FBWSxzQkFBWixFQUFtQztBQUFDSCxNQUFJLENBQUNJLENBQUQsRUFBRztBQUFDSixRQUFJLEdBQUNJLENBQUw7QUFBTyxHQUFoQjs7QUFBaUJLLG1CQUFpQixDQUFDTCxDQUFELEVBQUc7QUFBQ0sscUJBQWlCLEdBQUNMLENBQWxCO0FBQW9CLEdBQTFEOztBQUEyRE0sY0FBWSxDQUFDTixDQUFELEVBQUc7QUFBQ00sZ0JBQVksR0FBQ04sQ0FBYjtBQUFlOztBQUExRixDQUFuQyxFQUErSCxDQUEvSDtBQU0zVyxNQUFNTyxNQUFNLEdBQUdDLE1BQU0sQ0FBQ0MsU0FBUCxDQUFpQkMsY0FBaEM7QUFFQTtBQUNBO0FBQ0E7O0FBQ08sTUFBTWIsYUFBYSxHQUFHLEVBQXRCOztBQUVQO0FBQ0E7QUFDQSxTQUFTYyxLQUFULENBQWdCQyxNQUFoQixFQUF3QkMsR0FBeEIsRUFBNkJDLE9BQTdCLEVBQXNDQyxRQUF0QyxFQUFnRDtBQUM5QztBQUVBLE1BQUksQ0FBQ0EsUUFBRCxJQUFhLE9BQU9ELE9BQVAsS0FBbUIsVUFBcEMsRUFBZ0Q7QUFDOUM7QUFDQUMsWUFBUSxHQUFHRCxPQUFYO0FBQ0FBLFdBQU8sR0FBRyxJQUFWO0FBQ0Q7O0FBRURBLFNBQU8sR0FBR0EsT0FBTyxJQUFJLEVBQXJCOztBQUVBLE1BQUlQLE1BQU0sQ0FBQ1MsSUFBUCxDQUFZRixPQUFaLEVBQXFCLFlBQXJCLENBQUosRUFBd0M7QUFDdEMsVUFBTSxJQUFJRyxLQUFKLENBQVUsNENBQVYsQ0FBTjtBQUNEOztBQUVETCxRQUFNLEdBQUcsQ0FBQ0EsTUFBTSxJQUFJLEVBQVgsRUFBZU0sV0FBZixFQUFUOztBQUVBLE1BQUksQ0FBQyxlQUFlQyxJQUFmLENBQW9CTixHQUFwQixDQUFMLEVBQStCO0FBQzdCLFVBQU0sSUFBSUksS0FBSixDQUFVLHlEQUFWLENBQU47QUFDRDs7QUFFRCxRQUFNRyxPQUFPLEdBQUcsRUFBaEI7QUFDQSxNQUFJQyxPQUFPLEdBQUdQLE9BQU8sQ0FBQ08sT0FBdEI7O0FBRUEsTUFBSVAsT0FBTyxDQUFDUSxJQUFaLEVBQWtCO0FBQ2hCRCxXQUFPLEdBQUdFLElBQUksQ0FBQ0MsU0FBTCxDQUFlVixPQUFPLENBQUNRLElBQXZCLENBQVY7QUFDQUYsV0FBTyxDQUFDLGNBQUQsQ0FBUCxHQUEwQixrQkFBMUI7QUFDRDs7QUFFRCxNQUFJSyxZQUFKO0FBQ0EsTUFBSUMsYUFBSjs7QUFFQSxNQUFJTCxPQUFPLElBQUlULE1BQU0sS0FBSyxLQUF0QixJQUErQkEsTUFBTSxLQUFLLE1BQTlDLEVBQXNEO0FBQ3BEYSxnQkFBWSxHQUFHWCxPQUFPLENBQUNhLE1BQXZCO0FBQ0QsR0FGRCxNQUdLO0FBQ0hELGlCQUFhLEdBQUdaLE9BQU8sQ0FBQ2EsTUFBeEI7QUFDRDs7QUFFRCxRQUFNQyxNQUFNLEdBQUd6QixHQUFHLENBQUMwQixhQUFKLENBQWtCaEIsR0FBbEIsRUFBdUJDLE9BQU8sQ0FBQ2dCLEtBQS9CLEVBQXNDTCxZQUF0QyxDQUFmOztBQUVBLE1BQUlYLE9BQU8sQ0FBQ2lCLElBQVosRUFBa0I7QUFDaEIsUUFBSWpCLE9BQU8sQ0FBQ2lCLElBQVIsQ0FBYUMsT0FBYixDQUFxQixHQUFyQixJQUE0QixDQUFoQyxFQUFtQztBQUNqQyxZQUFNLElBQUlmLEtBQUosQ0FBVSx1REFBVixDQUFOO0FBQ0Q7O0FBRUQsVUFBTWdCLE1BQU0sR0FBR0MsTUFBTSxDQUFDQyxJQUFQLENBQVlyQixPQUFPLENBQUNpQixJQUFwQixFQUEwQixPQUExQixFQUFtQ0ssUUFBbkMsQ0FBNEMsUUFBNUMsQ0FBZjtBQUNBaEIsV0FBTyxDQUFDLGVBQUQsQ0FBUCxtQkFBb0NhLE1BQXBDO0FBQ0Q7O0FBRUQsTUFBSVAsYUFBSixFQUFtQjtBQUNqQixVQUFNSixJQUFJLEdBQUcsSUFBSWxCLGVBQUosRUFBYjtBQUNBSSxVQUFNLENBQUM2QixPQUFQLENBQWVYLGFBQWYsRUFBOEJZLE9BQTlCLENBQXNDLFFBQWtCO0FBQUEsVUFBakIsQ0FBQ0MsR0FBRCxFQUFNQyxLQUFOLENBQWlCO0FBQ3REbEIsVUFBSSxDQUFDbUIsTUFBTCxDQUFZRixHQUFaLEVBQWlCQyxLQUFqQjtBQUNELEtBRkQ7QUFHQW5CLFdBQU8sR0FBR0MsSUFBVjtBQUNBRixXQUFPLENBQUMsY0FBRCxDQUFQLEdBQTBCLG1DQUExQjtBQUNEOztBQUVELE1BQUlOLE9BQU8sQ0FBQ00sT0FBWixFQUFxQjtBQUNuQlosVUFBTSxDQUFDa0MsSUFBUCxDQUFZNUIsT0FBTyxDQUFDTSxPQUFwQixFQUE2QmtCLE9BQTdCLENBQXFDLFVBQVVDLEdBQVYsRUFBZTtBQUNsRG5CLGFBQU8sQ0FBQ21CLEdBQUQsQ0FBUCxHQUFlekIsT0FBTyxDQUFDTSxPQUFSLENBQWdCbUIsR0FBaEIsQ0FBZjtBQUNELEtBRkQ7QUFHRDs7QUFFRCxNQUFJSSxPQUFKOztBQUNBLE1BQUk3QixPQUFPLENBQUM2QixPQUFaLEVBQXFCLENBQ25CO0FBQ0Q7O0FBRUQsTUFBSUMsUUFBSjs7QUFDQSxNQUFJOUIsT0FBTyxDQUFDK0IsSUFBWixFQUFrQixDQUNoQjtBQUNEOztBQUVELE1BQUlDLFdBQUosQ0EzRThDLENBNkU5QztBQUNBOztBQUNBL0IsVUFBUSxHQUFJLFVBQVVnQyxFQUFWLEVBQWM7QUFDeEIsUUFBSUMsTUFBTSxHQUFHLEtBQWI7QUFDQSxXQUFPLFVBQVVDLEtBQVYsRUFBaUJDLFFBQWpCLEVBQTJCO0FBQ2hDLFVBQUksQ0FBQ0YsTUFBTCxFQUFhO0FBQ1hBLGNBQU0sR0FBRyxJQUFUOztBQUNBLFlBQUlDLEtBQUssSUFBSUMsUUFBYixFQUF1QjtBQUNyQkQsZUFBSyxDQUFDQyxRQUFOLEdBQWlCQSxRQUFqQjtBQUNEOztBQUNESCxVQUFFLENBQUNFLEtBQUQsRUFBUUMsUUFBUixDQUFGO0FBQ0Q7QUFDRixLQVJEO0FBU0QsR0FYVSxDQVdSbkMsUUFYUSxDQUFYLENBL0U4QyxDQTRGOUM7OztBQUNBLFFBQU1vQyxlQUFlLEdBQUdyQyxPQUFPLENBQUNxQyxlQUFSLEtBQTRCLEtBQTVCLEdBQ3BCLFFBRG9CLEdBRXBCLFFBRkosQ0E3RjhDLENBaUc5QztBQUVBO0FBQ0E7O0FBRUEsUUFBTUMsY0FBYyxHQUFHO0FBQ3JCeEMsVUFBTSxFQUFFQSxNQURhO0FBRXJCK0IsV0FBTyxFQUFFQSxPQUZZO0FBR3JCRSxRQUFJLEVBQUVELFFBSGU7QUFLckJTLE9BQUcsRUFBRSxLQUxnQjtBQU1yQkMsV0FBTyxFQUFFeEMsT0FBTyxDQUFDd0MsT0FOSTtBQU9yQkMsUUFBSSxFQUFFbEMsT0FQZTtBQVFyQm1DLFlBQVEsRUFBRUwsZUFSVztBQVNyQk0sWUFBUSxFQUFFM0MsT0FBTyxDQUFDMkMsUUFURztBQVVyQkMsYUFBUyxFQUFFNUMsT0FBTyxDQUFDNEMsU0FWRTtBQVdyQnRDLFdBQU8sRUFBRUE7QUFYWSxHQUF2QjtBQWNBLFFBQU11QyxPQUFPLEdBQUcsSUFBSXpELE9BQUosQ0FBWTBCLE1BQVosRUFBb0J3QixjQUFwQixDQUFoQjtBQUVBbkQsT0FBSyxDQUFDMEQsT0FBRCxDQUFMLENBQ0dDLElBREgsQ0FDY0MsR0FBTiw2QkFBYTtBQUNqQixVQUFNeEMsT0FBTyxpQkFBU3dDLEdBQUcsQ0FBQ0MsSUFBSixFQUFULENBQWI7QUFDQSxVQUFNWixRQUFRLEdBQUcsRUFBakI7QUFDQUEsWUFBUSxDQUFDYSxVQUFULEdBQXNCRixHQUFHLENBQUNHLE1BQTFCO0FBQ0FkLFlBQVEsQ0FBQzdCLE9BQVQsR0FBbUIsS0FBS0EsT0FBeEIsQ0FKaUIsQ0FNakI7QUFDQTs7QUFDQTZCLFlBQVEsQ0FBQzlCLE9BQVQsR0FBbUIsRUFBbkI7O0FBQ0EsU0FBSyxNQUFNNkMsS0FBWCxJQUFvQkosR0FBRyxDQUFDekMsT0FBSixDQUFZaUIsT0FBWixFQUFwQixFQUEyQztBQUN6QyxZQUFNLENBQUNFLEdBQUQsRUFBTTJCLEdBQU4sSUFBYUQsS0FBbkI7QUFDQWYsY0FBUSxDQUFDOUIsT0FBVCxDQUFpQm1CLEdBQWpCLElBQXdCMkIsR0FBeEI7QUFDRDs7QUFFRGhCLFlBQVEsQ0FBQ2lCLEVBQVQsR0FBY04sR0FBRyxDQUFDTSxFQUFsQjtBQUNBakIsWUFBUSxDQUFDa0IsVUFBVCxHQUFzQlAsR0FBRyxDQUFDTyxVQUExQjtBQUVBOUQsZ0JBQVksQ0FBQzRDLFFBQUQsQ0FBWjs7QUFFQSxRQUFJQSxRQUFRLENBQUNhLFVBQVQsSUFBdUIsR0FBM0IsRUFBZ0M7QUFDOUIsWUFBTWQsS0FBSyxHQUFHNUMsaUJBQWlCLENBQzdCNkMsUUFBUSxDQUFDYSxVQURvQixFQUU3QmIsUUFBUSxDQUFDN0IsT0FGb0IsQ0FBL0I7QUFJQU4sY0FBUSxDQUFDa0MsS0FBRCxFQUFRQyxRQUFSLENBQVI7QUFDRCxLQU5ELE1BTU87QUFDTG5DLGNBQVEsQ0FBQ3NELFNBQUQsRUFBWW5CLFFBQVosQ0FBUjtBQUNEO0FBQ0YsR0E1QkssQ0FEUixFQThCR29CLEtBOUJILENBOEJTQyxHQUFHLElBQUl4RCxRQUFRLENBQUN3RCxHQUFELENBOUJ4QjtBQStCRDs7QUFFRDNFLElBQUksQ0FBQ29CLElBQUwsR0FBWWxCLE1BQU0sQ0FBQzBFLFNBQVAsQ0FBaUI3RCxLQUFqQixDQUFaLEM7Ozs7Ozs7Ozs7O0FDdEtBLElBQUk4RCxVQUFVLEdBQUcsR0FBakIsQyxDQUFzQjs7QUFDdEIsSUFBSUMsS0FBSyxHQUFHQyxLQUFLLENBQUNsRSxTQUFOLENBQWdCaUUsS0FBNUI7O0FBRUFFLE9BQU8sQ0FBQ3ZFLGlCQUFSLEdBQTRCLFVBQVMwRCxVQUFULEVBQXFCMUMsT0FBckIsRUFBOEI7QUFDeEQsTUFBSXdELE9BQU8sR0FBRyxhQUFhZCxVQUFiLEdBQTBCLEdBQXhDOztBQUVBLE1BQUkxQyxPQUFKLEVBQWE7QUFDWCxRQUFJeUQsYUFBYSxHQUFHLE9BQU96RCxPQUFQLElBQWtCLFFBQWxCLEdBQ2xCQSxPQURrQixHQUNSQSxPQUFPLENBQUNlLFFBQVIsRUFEWjtBQUdBeUMsV0FBTyxJQUFJLE1BQU1FLFFBQVEsQ0FBQ0QsYUFBYSxDQUFDRSxPQUFkLENBQXNCLEtBQXRCLEVBQTZCLEdBQTdCLENBQUQsRUFBb0NQLFVBQXBDLENBQXpCO0FBQ0Q7O0FBRUQsU0FBTyxJQUFJeEQsS0FBSixDQUFVNEQsT0FBVixDQUFQO0FBQ0QsQ0FYRDs7QUFhQSxTQUFTRSxRQUFULENBQWtCRSxHQUFsQixFQUF1QkMsTUFBdkIsRUFBK0I7QUFDN0IsU0FBT0QsR0FBRyxDQUFDQyxNQUFKLEdBQWFBLE1BQWIsR0FBc0JELEdBQUcsQ0FBQ1AsS0FBSixDQUFVLENBQVYsRUFBYVEsTUFBYixJQUF1QixLQUE3QyxHQUFxREQsR0FBNUQ7QUFDRCxDLENBRUQ7OztBQUNBTCxPQUFPLENBQUN0RSxZQUFSLEdBQXVCLFVBQVM0QyxRQUFULEVBQW1CO0FBQ3hDO0FBQ0E7QUFDQTtBQUNBLE1BQUlpQyxXQUFXLEdBQUcsQ0FBQ2pDLFFBQVEsQ0FBQzlCLE9BQVQsQ0FBaUIsY0FBakIsS0FBb0MsR0FBckMsRUFBMENnRSxLQUExQyxDQUFnRCxHQUFoRCxFQUFxRCxDQUFyRCxDQUFsQixDQUp3QyxDQU14Qzs7QUFDQSxNQUFJLENBQUMsa0JBQUQsRUFDQyxpQkFERCxFQUVDLHdCQUZELEVBR0MsMEJBSEQsRUFJRXBELE9BSkYsQ0FJVW1ELFdBSlYsS0FJMEIsQ0FKOUIsRUFJaUM7QUFDL0IsUUFBSTtBQUNGakMsY0FBUSxDQUFDNUIsSUFBVCxHQUFnQkMsSUFBSSxDQUFDOEQsS0FBTCxDQUFXbkMsUUFBUSxDQUFDN0IsT0FBcEIsQ0FBaEI7QUFDRCxLQUZELENBRUUsT0FBT2tELEdBQVAsRUFBWTtBQUNackIsY0FBUSxDQUFDNUIsSUFBVCxHQUFnQixJQUFoQjtBQUNEO0FBQ0YsR0FWRCxNQVVPO0FBQ0w0QixZQUFRLENBQUM1QixJQUFULEdBQWdCLElBQWhCO0FBQ0Q7QUFDRixDQXBCRDs7QUFzQkEsSUFBSTFCLElBQUksR0FBR2dGLE9BQU8sQ0FBQ2hGLElBQVIsR0FBZSxFQUExQjtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0FBLElBQUksQ0FBQzBGLEdBQUwsR0FBVyxZQUF5QjtBQUNsQyxTQUFPMUYsSUFBSSxDQUFDb0IsSUFBTCxDQUFVdUUsS0FBVixDQUFnQixJQUFoQixFQUFzQixDQUFDLEtBQUQsRUFBUUMsTUFBUixDQUFlZCxLQUFLLENBQUMxRCxJQUFOLENBQVd5RSxTQUFYLENBQWYsQ0FBdEIsQ0FBUDtBQUNELENBRkQ7QUFJQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQTdGLElBQUksQ0FBQzhGLElBQUwsR0FBWSxZQUF5QjtBQUNuQyxTQUFPOUYsSUFBSSxDQUFDb0IsSUFBTCxDQUFVdUUsS0FBVixDQUFnQixJQUFoQixFQUFzQixDQUFDLE1BQUQsRUFBU0MsTUFBVCxDQUFnQmQsS0FBSyxDQUFDMUQsSUFBTixDQUFXeUUsU0FBWCxDQUFoQixDQUF0QixDQUFQO0FBQ0QsQ0FGRDtBQUlBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBN0YsSUFBSSxDQUFDK0YsR0FBTCxHQUFXLFlBQXlCO0FBQ2xDLFNBQU8vRixJQUFJLENBQUNvQixJQUFMLENBQVV1RSxLQUFWLENBQWdCLElBQWhCLEVBQXNCLENBQUMsS0FBRCxFQUFRQyxNQUFSLENBQWVkLEtBQUssQ0FBQzFELElBQU4sQ0FBV3lFLFNBQVgsQ0FBZixDQUF0QixDQUFQO0FBQ0QsQ0FGRDtBQUlBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBN0YsSUFBSSxDQUFDZ0csR0FBTCxHQUFXLFlBQXlCO0FBQ2xDLFNBQU9oRyxJQUFJLENBQUNvQixJQUFMLENBQVV1RSxLQUFWLENBQWdCLElBQWhCLEVBQXNCLENBQUMsUUFBRCxFQUFXQyxNQUFYLENBQWtCZCxLQUFLLENBQUMxRCxJQUFOLENBQVd5RSxTQUFYLENBQWxCLENBQXRCLENBQVA7QUFDRCxDQUZEO0FBSUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0E3RixJQUFJLENBQUNpRyxLQUFMLEdBQWEsWUFBeUI7QUFDcEMsU0FBT2pHLElBQUksQ0FBQ29CLElBQUwsQ0FBVXVFLEtBQVYsQ0FBZ0IsSUFBaEIsRUFBc0IsQ0FBQyxPQUFELEVBQVVDLE1BQVYsQ0FBaUJkLEtBQUssQ0FBQzFELElBQU4sQ0FBV3lFLFNBQVgsQ0FBakIsQ0FBdEIsQ0FBUDtBQUNELENBRkQsQyIsImZpbGUiOiIvcGFja2FnZXMvaHR0cC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgZmV0Y2gsIFJlcXVlc3QgfSBmcm9tICdtZXRlb3IvZmV0Y2gnO1xuaW1wb3J0IHsgVVJMLCBVUkxTZWFyY2hQYXJhbXMgfSBmcm9tICdtZXRlb3IvdXJsJztcbmltcG9ydCB7IEhUVFAsIG1ha2VFcnJvckJ5U3RhdHVzLCBwb3B1bGF0ZURhdGEgfSBmcm9tICcuL2h0dHBjYWxsX2NvbW1vbi5qcyc7XG5cbmV4cG9ydCB7IEhUVFAgfTtcbmNvbnN0IGhhc093biA9IE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHk7XG5cbi8qKlxuICogQGRlcHJlY2F0ZWRcbiAqL1xuZXhwb3J0IGNvbnN0IEhUVFBJbnRlcm5hbHMgPSB7fTtcblxuLy8gX2NhbGwgYWx3YXlzIHJ1bnMgYXN5bmNocm9ub3VzbHk7IEhUVFAuY2FsbCwgZGVmaW5lZCBiZWxvdyxcbi8vIHdyYXBzIF9jYWxsIGFuZCBydW5zIHN5bmNocm9ub3VzbHkgd2hlbiBubyBjYWxsYmFjayBpcyBwcm92aWRlZC5cbmZ1bmN0aW9uIF9jYWxsIChtZXRob2QsIHVybCwgb3B0aW9ucywgY2FsbGJhY2spIHtcbiAgLy8vLy8vLy8vLyBQcm9jZXNzIGFyZ3VtZW50cyAvLy8vLy8vLy8vXG5cbiAgaWYgKCFjYWxsYmFjayAmJiB0eXBlb2Ygb3B0aW9ucyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgIC8vIHN1cHBvcnQgKG1ldGhvZCwgdXJsLCBjYWxsYmFjaykgYXJndW1lbnQgbGlzdFxuICAgIGNhbGxiYWNrID0gb3B0aW9ucztcbiAgICBvcHRpb25zID0gbnVsbDtcbiAgfVxuXG4gIG9wdGlvbnMgPSBvcHRpb25zIHx8IHt9O1xuXG4gIGlmIChoYXNPd24uY2FsbChvcHRpb25zLCAnYmVmb3JlU2VuZCcpKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdPcHRpb24gYmVmb3JlU2VuZCBub3Qgc3VwcG9ydGVkIG9uIHNlcnZlci4nKTtcbiAgfVxuXG4gIG1ldGhvZCA9IChtZXRob2QgfHwgJycpLnRvVXBwZXJDYXNlKCk7XG5cbiAgaWYgKCEvXmh0dHBzPzpcXC9cXC8vLnRlc3QodXJsKSkge1xuICAgIHRocm93IG5ldyBFcnJvcigndXJsIG11c3QgYmUgYWJzb2x1dGUgYW5kIHN0YXJ0IHdpdGggaHR0cDovLyBvciBodHRwczovLycpO1xuICB9XG5cbiAgY29uc3QgaGVhZGVycyA9IHt9O1xuICBsZXQgY29udGVudCA9IG9wdGlvbnMuY29udGVudDtcblxuICBpZiAob3B0aW9ucy5kYXRhKSB7XG4gICAgY29udGVudCA9IEpTT04uc3RyaW5naWZ5KG9wdGlvbnMuZGF0YSk7XG4gICAgaGVhZGVyc1snQ29udGVudC1UeXBlJ10gPSAnYXBwbGljYXRpb24vanNvbic7XG4gIH1cblxuICBsZXQgcGFyYW1zRm9yVXJsO1xuICBsZXQgcGFyYW1zRm9yQm9keTtcblxuICBpZiAoY29udGVudCB8fCBtZXRob2QgPT09ICdHRVQnIHx8IG1ldGhvZCA9PT0gJ0hFQUQnKSB7XG4gICAgcGFyYW1zRm9yVXJsID0gb3B0aW9ucy5wYXJhbXM7XG4gIH1cbiAgZWxzZSB7XG4gICAgcGFyYW1zRm9yQm9keSA9IG9wdGlvbnMucGFyYW1zO1xuICB9XG5cbiAgY29uc3QgbmV3VXJsID0gVVJMLl9jb25zdHJ1Y3RVcmwodXJsLCBvcHRpb25zLnF1ZXJ5LCBwYXJhbXNGb3JVcmwpO1xuXG4gIGlmIChvcHRpb25zLmF1dGgpIHtcbiAgICBpZiAob3B0aW9ucy5hdXRoLmluZGV4T2YoJzonKSA8IDApIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignYXV0aCBvcHRpb24gc2hvdWxkIGJlIG9mIHRoZSBmb3JtIFwidXNlcm5hbWU6cGFzc3dvcmRcIicpO1xuICAgIH1cblxuICAgIGNvbnN0IGJhc2U2NCA9IEJ1ZmZlci5mcm9tKG9wdGlvbnMuYXV0aCwgJ2FzY2lpJykudG9TdHJpbmcoJ2Jhc2U2NCcpO1xuICAgIGhlYWRlcnNbJ0F1dGhvcml6YXRpb24nXSA9IGBCYXNpYyAke2Jhc2U2NH1gO1xuICB9XG5cbiAgaWYgKHBhcmFtc0ZvckJvZHkpIHtcbiAgICBjb25zdCBkYXRhID0gbmV3IFVSTFNlYXJjaFBhcmFtcygpO1xuICAgIE9iamVjdC5lbnRyaWVzKHBhcmFtc0ZvckJvZHkpLmZvckVhY2goKFtrZXksIHZhbHVlXSkgPT4ge1xuICAgICAgZGF0YS5hcHBlbmQoa2V5LCB2YWx1ZSk7XG4gICAgfSk7XG4gICAgY29udGVudCA9IGRhdGE7XG4gICAgaGVhZGVyc1snQ29udGVudC1UeXBlJ10gPSAnYXBwbGljYXRpb24veC13d3ctZm9ybS11cmxlbmNvZGVkJztcbiAgfVxuXG4gIGlmIChvcHRpb25zLmhlYWRlcnMpIHtcbiAgICBPYmplY3Qua2V5cyhvcHRpb25zLmhlYWRlcnMpLmZvckVhY2goZnVuY3Rpb24gKGtleSkge1xuICAgICAgaGVhZGVyc1trZXldID0gb3B0aW9ucy5oZWFkZXJzW2tleV07XG4gICAgfSk7XG4gIH1cblxuICBsZXQgY2FjaGluZztcbiAgaWYgKG9wdGlvbnMuY2FjaGluZykge1xuICAgIC8vIFRPRE8gaW1wbGVtZW50IGZldGNoLXNwZWNpZmljIG9wdGlvbnNcbiAgfVxuXG4gIGxldCBjb3JzTW9kZTtcbiAgaWYgKG9wdGlvbnMubW9kZSkge1xuICAgIC8vIFRPRE8gaW1wbGVtZW50IGZldGNoLXNwZWNpZmljIG9wdGlvbnNcbiAgfVxuXG4gIGxldCBjcmVkZW50aWFscztcblxuICAvLyB3cmFwIGNhbGxiYWNrIHRvIGFkZCBhICdyZXNwb25zZScgcHJvcGVydHkgb24gYW4gZXJyb3IsIGluIGNhc2VcbiAgLy8gd2UgaGF2ZSBib3RoIChodHRwIDR4eC81eHggZXJyb3IsIHdoaWNoIGhhcyBhIHJlc3BvbnNlIHBheWxvYWQpXG4gIGNhbGxiYWNrID0gKGZ1bmN0aW9uIChjYikge1xuICAgIGxldCBjYWxsZWQgPSBmYWxzZTtcbiAgICByZXR1cm4gZnVuY3Rpb24gKGVycm9yLCByZXNwb25zZSkge1xuICAgICAgaWYgKCFjYWxsZWQpIHtcbiAgICAgICAgY2FsbGVkID0gdHJ1ZTtcbiAgICAgICAgaWYgKGVycm9yICYmIHJlc3BvbnNlKSB7XG4gICAgICAgICAgZXJyb3IucmVzcG9uc2UgPSByZXNwb25zZTtcbiAgICAgICAgfVxuICAgICAgICBjYihlcnJvciwgcmVzcG9uc2UpO1xuICAgICAgfVxuICAgIH1cbiAgfSkoY2FsbGJhY2spO1xuXG4gIC8vIGlzIGZhbHNlIGlmIGZhbHNlLCBvdGhlcndpc2UgYWx3YXlzIHRydWVcbiAgY29uc3QgZm9sbG93UmVkaXJlY3RzID0gb3B0aW9ucy5mb2xsb3dSZWRpcmVjdHMgPT09IGZhbHNlXG4gICAgPyAnbWFudWFsJ1xuICAgIDogJ2ZvbGxvdyc7XG5cbiAgLy8vLy8vLy8vLyBLaWNrb2ZmISAvLy8vLy8vLy8vXG5cbiAgLy8gQWxsb3cgdXNlcnMgdG8gb3ZlcnJpZGUgYW55IHJlcXVlc3Qgb3B0aW9uIHdpdGggdGhlIG5wbVJlcXVlc3RPcHRpb25zXG4gIC8vIG9wdGlvbi5cblxuICBjb25zdCByZXF1ZXN0T3B0aW9ucyA9IHtcbiAgICBtZXRob2Q6IG1ldGhvZCxcbiAgICBjYWNoaW5nOiBjYWNoaW5nLFxuICAgIG1vZGU6IGNvcnNNb2RlLFxuXG4gICAgamFyOiBmYWxzZSxcbiAgICB0aW1lb3V0OiBvcHRpb25zLnRpbWVvdXQsXG4gICAgYm9keTogY29udGVudCxcbiAgICByZWRpcmVjdDogZm9sbG93UmVkaXJlY3RzLFxuICAgIHJlZmVycmVyOiBvcHRpb25zLnJlZmVycmVyLFxuICAgIGludGVncml0eTogb3B0aW9ucy5pbnRlZ3JpdHksXG4gICAgaGVhZGVyczogaGVhZGVyc1xuICB9O1xuXG4gIGNvbnN0IHJlcXVlc3QgPSBuZXcgUmVxdWVzdChuZXdVcmwsIHJlcXVlc3RPcHRpb25zKTtcblxuICBmZXRjaChyZXF1ZXN0KVxuICAgIC50aGVuKGFzeW5jIHJlcyA9PiB7XG4gICAgICBjb25zdCBjb250ZW50ID0gYXdhaXQgcmVzLnRleHQoKTtcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0ge307XG4gICAgICByZXNwb25zZS5zdGF0dXNDb2RlID0gcmVzLnN0YXR1cztcbiAgICAgIHJlc3BvbnNlLmNvbnRlbnQgPSAnJyArIGNvbnRlbnQ7XG5cbiAgICAgIC8vIGZldGNoIGhlYWRlcnMgZG9uJ3QgYWxsb3cgc2ltcGxlIHJlYWQgdXNpbmcgYnJhY2tldCBub3RhdGlvblxuICAgICAgLy8gc28gd2UgaXRlcmF0ZSB0aGVpciBlbnRyaWVzIGFuZCBhc3NpZ24gdGhlbSB0byBhIG5ldyBPYmplY3RcbiAgICAgIHJlc3BvbnNlLmhlYWRlcnMgPSB7fTtcbiAgICAgIGZvciAoY29uc3QgZW50cnkgb2YgcmVzLmhlYWRlcnMuZW50cmllcygpKSB7XG4gICAgICAgIGNvbnN0IFtrZXksIHZhbF0gPSBlbnRyeTtcbiAgICAgICAgcmVzcG9uc2UuaGVhZGVyc1trZXldID0gdmFsO1xuICAgICAgfVxuXG4gICAgICByZXNwb25zZS5vayA9IHJlcy5vaztcbiAgICAgIHJlc3BvbnNlLnJlZGlyZWN0ZWQgPSByZXMucmVkaXJlY3RlZDtcblxuICAgICAgcG9wdWxhdGVEYXRhKHJlc3BvbnNlKTtcblxuICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1c0NvZGUgPj0gNDAwKSB7XG4gICAgICAgIGNvbnN0IGVycm9yID0gbWFrZUVycm9yQnlTdGF0dXMoXG4gICAgICAgICAgcmVzcG9uc2Uuc3RhdHVzQ29kZSxcbiAgICAgICAgICByZXNwb25zZS5jb250ZW50XG4gICAgICAgICk7XG4gICAgICAgIGNhbGxiYWNrKGVycm9yLCByZXNwb25zZSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjYWxsYmFjayh1bmRlZmluZWQsIHJlc3BvbnNlKTtcbiAgICAgIH1cbiAgICB9KVxuICAgIC5jYXRjaChlcnIgPT4gY2FsbGJhY2soZXJyKSk7XG59XG5cbkhUVFAuY2FsbCA9IE1ldGVvci53cmFwQXN5bmMoX2NhbGwpO1xuIiwidmFyIE1BWF9MRU5HVEggPSA1MDA7IC8vIGlmIHlvdSBjaGFuZ2UgdGhpcywgYWxzbyBjaGFuZ2UgdGhlIGFwcHJvcHJpYXRlIHRlc3RcbnZhciBzbGljZSA9IEFycmF5LnByb3RvdHlwZS5zbGljZTtcblxuZXhwb3J0cy5tYWtlRXJyb3JCeVN0YXR1cyA9IGZ1bmN0aW9uKHN0YXR1c0NvZGUsIGNvbnRlbnQpIHtcbiAgdmFyIG1lc3NhZ2UgPSBcImZhaWxlZCBbXCIgKyBzdGF0dXNDb2RlICsgXCJdXCI7XG5cbiAgaWYgKGNvbnRlbnQpIHtcbiAgICB2YXIgc3RyaW5nQ29udGVudCA9IHR5cGVvZiBjb250ZW50ID09IFwic3RyaW5nXCIgP1xuICAgICAgY29udGVudCA6IGNvbnRlbnQudG9TdHJpbmcoKTtcblxuICAgIG1lc3NhZ2UgKz0gJyAnICsgdHJ1bmNhdGUoc3RyaW5nQ29udGVudC5yZXBsYWNlKC9cXG4vZywgJyAnKSwgTUFYX0xFTkdUSCk7XG4gIH1cblxuICByZXR1cm4gbmV3IEVycm9yKG1lc3NhZ2UpO1xufTtcblxuZnVuY3Rpb24gdHJ1bmNhdGUoc3RyLCBsZW5ndGgpIHtcbiAgcmV0dXJuIHN0ci5sZW5ndGggPiBsZW5ndGggPyBzdHIuc2xpY2UoMCwgbGVuZ3RoKSArICcuLi4nIDogc3RyO1xufVxuXG4vLyBGaWxsIGluIGByZXNwb25zZS5kYXRhYCBpZiB0aGUgY29udGVudC10eXBlIGlzIEpTT04uXG5leHBvcnRzLnBvcHVsYXRlRGF0YSA9IGZ1bmN0aW9uKHJlc3BvbnNlKSB7XG4gIC8vIFJlYWQgQ29udGVudC1UeXBlIGhlYWRlciwgdXAgdG8gYSAnOycgaWYgdGhlcmUgaXMgb25lLlxuICAvLyBBIHR5cGljYWwgaGVhZGVyIG1pZ2h0IGJlIFwiYXBwbGljYXRpb24vanNvbjsgY2hhcnNldD11dGYtOFwiXG4gIC8vIG9yIGp1c3QgXCJhcHBsaWNhdGlvbi9qc29uXCIuXG4gIHZhciBjb250ZW50VHlwZSA9IChyZXNwb25zZS5oZWFkZXJzWydjb250ZW50LXR5cGUnXSB8fCAnOycpLnNwbGl0KCc7JylbMF07XG5cbiAgLy8gT25seSB0cnkgdG8gcGFyc2UgZGF0YSBhcyBKU09OIGlmIHNlcnZlciBzZXRzIGNvcnJlY3QgY29udGVudCB0eXBlLlxuICBpZiAoWydhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAndGV4dC9qYXZhc2NyaXB0JyxcbiAgICAgICAnYXBwbGljYXRpb24vamF2YXNjcmlwdCcsXG4gICAgICAgJ2FwcGxpY2F0aW9uL3gtamF2YXNjcmlwdCcsXG4gICAgICBdLmluZGV4T2YoY29udGVudFR5cGUpID49IDApIHtcbiAgICB0cnkge1xuICAgICAgcmVzcG9uc2UuZGF0YSA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICByZXNwb25zZS5kYXRhID0gbnVsbDtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgcmVzcG9uc2UuZGF0YSA9IG51bGw7XG4gIH1cbn07XG5cbnZhciBIVFRQID0gZXhwb3J0cy5IVFRQID0ge307XG5cbi8qKlxuICogQHN1bW1hcnkgU2VuZCBhbiBIVFRQIGBHRVRgIHJlcXVlc3QuIEVxdWl2YWxlbnQgdG8gY2FsbGluZyBbYEhUVFAuY2FsbGBdKCNodHRwX2NhbGwpIHdpdGggXCJHRVRcIiBhcyB0aGUgZmlyc3QgYXJndW1lbnQuXG4gKiBAcGFyYW0ge1N0cmluZ30gdXJsIFRoZSBVUkwgdG8gd2hpY2ggdGhlIHJlcXVlc3Qgc2hvdWxkIGJlIHNlbnQuXG4gKiBAcGFyYW0ge09iamVjdH0gW2NhbGxPcHRpb25zXSBPcHRpb25zIHBhc3NlZCBvbiB0byBbYEhUVFAuY2FsbGBdKCNodHRwX2NhbGwpLlxuICogQHBhcmFtIHtGdW5jdGlvbn0gW2FzeW5jQ2FsbGJhY2tdIENhbGxiYWNrIHRoYXQgaXMgY2FsbGVkIHdoZW4gdGhlIHJlcXVlc3QgaXMgY29tcGxldGVkLiBSZXF1aXJlZCBvbiB0aGUgY2xpZW50LlxuICogQGxvY3VzIEFueXdoZXJlXG4gKiBAZGVwcmVjYXRlZFxuICovXG5IVFRQLmdldCA9IGZ1bmN0aW9uICgvKiB2YXJhcmdzICovKSB7XG4gIHJldHVybiBIVFRQLmNhbGwuYXBwbHkodGhpcywgW1wiR0VUXCJdLmNvbmNhdChzbGljZS5jYWxsKGFyZ3VtZW50cykpKTtcbn07XG5cbi8qKlxuICogQHN1bW1hcnkgU2VuZCBhbiBIVFRQIGBQT1NUYCByZXF1ZXN0LiBFcXVpdmFsZW50IHRvIGNhbGxpbmcgW2BIVFRQLmNhbGxgXSgjaHR0cF9jYWxsKSB3aXRoIFwiUE9TVFwiIGFzIHRoZSBmaXJzdCBhcmd1bWVudC5cbiAqIEBwYXJhbSB7U3RyaW5nfSB1cmwgVGhlIFVSTCB0byB3aGljaCB0aGUgcmVxdWVzdCBzaG91bGQgYmUgc2VudC5cbiAqIEBwYXJhbSB7T2JqZWN0fSBbY2FsbE9wdGlvbnNdIE9wdGlvbnMgcGFzc2VkIG9uIHRvIFtgSFRUUC5jYWxsYF0oI2h0dHBfY2FsbCkuXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBbYXN5bmNDYWxsYmFja10gQ2FsbGJhY2sgdGhhdCBpcyBjYWxsZWQgd2hlbiB0aGUgcmVxdWVzdCBpcyBjb21wbGV0ZWQuIFJlcXVpcmVkIG9uIHRoZSBjbGllbnQuXG4gKiBAbG9jdXMgQW55d2hlcmVcbiAqIEBkZXByZWNhdGVkXG4gKi9cbkhUVFAucG9zdCA9IGZ1bmN0aW9uICgvKiB2YXJhcmdzICovKSB7XG4gIHJldHVybiBIVFRQLmNhbGwuYXBwbHkodGhpcywgW1wiUE9TVFwiXS5jb25jYXQoc2xpY2UuY2FsbChhcmd1bWVudHMpKSk7XG59O1xuXG4vKipcbiAqIEBzdW1tYXJ5IFNlbmQgYW4gSFRUUCBgUFVUYCByZXF1ZXN0LiBFcXVpdmFsZW50IHRvIGNhbGxpbmcgW2BIVFRQLmNhbGxgXSgjaHR0cF9jYWxsKSB3aXRoIFwiUFVUXCIgYXMgdGhlIGZpcnN0IGFyZ3VtZW50LlxuICogQHBhcmFtIHtTdHJpbmd9IHVybCBUaGUgVVJMIHRvIHdoaWNoIHRoZSByZXF1ZXN0IHNob3VsZCBiZSBzZW50LlxuICogQHBhcmFtIHtPYmplY3R9IFtjYWxsT3B0aW9uc10gT3B0aW9ucyBwYXNzZWQgb24gdG8gW2BIVFRQLmNhbGxgXSgjaHR0cF9jYWxsKS5cbiAqIEBwYXJhbSB7RnVuY3Rpb259IFthc3luY0NhbGxiYWNrXSBDYWxsYmFjayB0aGF0IGlzIGNhbGxlZCB3aGVuIHRoZSByZXF1ZXN0IGlzIGNvbXBsZXRlZC4gUmVxdWlyZWQgb24gdGhlIGNsaWVudC5cbiAqIEBsb2N1cyBBbnl3aGVyZVxuICogQGRlcHJlY2F0ZWRcbiAqL1xuSFRUUC5wdXQgPSBmdW5jdGlvbiAoLyogdmFyYXJncyAqLykge1xuICByZXR1cm4gSFRUUC5jYWxsLmFwcGx5KHRoaXMsIFtcIlBVVFwiXS5jb25jYXQoc2xpY2UuY2FsbChhcmd1bWVudHMpKSk7XG59O1xuXG4vKipcbiAqIEBzdW1tYXJ5IFNlbmQgYW4gSFRUUCBgREVMRVRFYCByZXF1ZXN0LiBFcXVpdmFsZW50IHRvIGNhbGxpbmcgW2BIVFRQLmNhbGxgXSgjaHR0cF9jYWxsKSB3aXRoIFwiREVMRVRFXCIgYXMgdGhlIGZpcnN0IGFyZ3VtZW50LiAoTmFtZWQgYGRlbGAgdG8gYXZvaWQgY29uZmxpY3Qgd2l0aCB0aGUgSmF2YXNjcmlwdCBrZXl3b3JkIGBkZWxldGVgKVxuICogQHBhcmFtIHtTdHJpbmd9IHVybCBUaGUgVVJMIHRvIHdoaWNoIHRoZSByZXF1ZXN0IHNob3VsZCBiZSBzZW50LlxuICogQHBhcmFtIHtPYmplY3R9IFtjYWxsT3B0aW9uc10gT3B0aW9ucyBwYXNzZWQgb24gdG8gW2BIVFRQLmNhbGxgXSgjaHR0cF9jYWxsKS5cbiAqIEBwYXJhbSB7RnVuY3Rpb259IFthc3luY0NhbGxiYWNrXSBDYWxsYmFjayB0aGF0IGlzIGNhbGxlZCB3aGVuIHRoZSByZXF1ZXN0IGlzIGNvbXBsZXRlZC4gUmVxdWlyZWQgb24gdGhlIGNsaWVudC5cbiAqIEBsb2N1cyBBbnl3aGVyZVxuICogQGRlcHJlY2F0ZWRcbiAqL1xuSFRUUC5kZWwgPSBmdW5jdGlvbiAoLyogdmFyYXJncyAqLykge1xuICByZXR1cm4gSFRUUC5jYWxsLmFwcGx5KHRoaXMsIFtcIkRFTEVURVwiXS5jb25jYXQoc2xpY2UuY2FsbChhcmd1bWVudHMpKSk7XG59O1xuXG4vKipcbiAqIEBzdW1tYXJ5IFNlbmQgYW4gSFRUUCBgUEFUQ0hgIHJlcXVlc3QuIEVxdWl2YWxlbnQgdG8gY2FsbGluZyBbYEhUVFAuY2FsbGBdKCNodHRwX2NhbGwpIHdpdGggXCJQQVRDSFwiIGFzIHRoZSBmaXJzdCBhcmd1bWVudC5cbiAqIEBwYXJhbSB7U3RyaW5nfSB1cmwgVGhlIFVSTCB0byB3aGljaCB0aGUgcmVxdWVzdCBzaG91bGQgYmUgc2VudC5cbiAqIEBwYXJhbSB7T2JqZWN0fSBbY2FsbE9wdGlvbnNdIE9wdGlvbnMgcGFzc2VkIG9uIHRvIFtgSFRUUC5jYWxsYF0oI2h0dHBfY2FsbCkuXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBbYXN5bmNDYWxsYmFja10gQ2FsbGJhY2sgdGhhdCBpcyBjYWxsZWQgd2hlbiB0aGUgcmVxdWVzdCBpcyBjb21wbGV0ZWQuIFJlcXVpcmVkIG9uIHRoZSBjbGllbnQuXG4gKiBAbG9jdXMgQW55d2hlcmVcbiAqIEBkZXByZWNhdGVkXG4gKi9cbkhUVFAucGF0Y2ggPSBmdW5jdGlvbiAoLyogdmFyYXJncyAqLykge1xuICByZXR1cm4gSFRUUC5jYWxsLmFwcGx5KHRoaXMsIFtcIlBBVENIXCJdLmNvbmNhdChzbGljZS5jYWxsKGFyZ3VtZW50cykpKTtcbn07XG4iXX0=
